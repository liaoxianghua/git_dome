package com.spring.scenic.test.support;

 
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Log4jConfigurer;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath*:config/applicationContext.xml" })
public class BaseTest {
	static {
	      try {
	        Log4jConfigurer.initLogging("classpath:properties/log4j.properties");
	      } catch (Exception ex) {
	        System.err.println("Cannot Initialize log4j");
	      }
	    }
	//protected static final Logger logger = org.apache.log4j.Logger.getLogger();

	
	@Test
	public void doTest() {
	}
	
}
