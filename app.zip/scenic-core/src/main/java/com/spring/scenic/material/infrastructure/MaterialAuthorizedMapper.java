package com.spring.scenic.material.infrastructure;

import java.util.List;

import com.spring.scenic.material.domain.MaterialAuthorized;

public interface MaterialAuthorizedMapper {

	List<MaterialAuthorized> getMaterialAuthorizedList(MaterialAuthorized authorized);

	MaterialAuthorized getMaterialAuthorized(MaterialAuthorized authorized);

	int saveMaterialAuthorized(MaterialAuthorized authorized);

	int updateMaterialAuthorized(MaterialAuthorized authorized);
	
}