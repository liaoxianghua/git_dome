package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.basic.domain.Province;

public interface ProvinceMapper {

	/**
	 * @param province
	 * @return
	 */
	List<Province> getProvinceInfoList(Province province);

	/**
	 * @param province
	 */
	void addProvinceInfo(Province province);

	/**
	 * @param province
	 */
	void updateProvinceInfo(Province province);

	/**
	 * @param province
	 * @return
	 */
	Object getProvinceInfoById(Province province);

	/**
	 * @param id
	 * @param status 
	 */
	void deleteByPrimaryKey(Integer id, Integer status);

	/**
	 * @param valid 
	 * @return
	 */
	List<Province> getCountryList();
	
	/**
	 * @param province
	 */
	void updateProvinceStatus(Province province);

	/**
	 * @return
	 */
	List<Province> getCityList();

	/**
	 * @param province
	 * @return
	 */
	int getProvinceCount(Province province);

	/**
	 * @param dto
	 * @return
	 */
	List<Province> getProvinceList(Province dto);

	/**
	 * @return
	 */
	List<Province> selectProvinceList();

	/**
	 * @param province
	 * @return
	 */
	List<Province> getCityListByIdParam(Province province);


  
}