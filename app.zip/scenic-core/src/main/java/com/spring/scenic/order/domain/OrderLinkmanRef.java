package com.spring.scenic.order.domain;

import java.util.Date;

/**
 * 订单出行人人表
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年5月10日
 */
public class OrderLinkmanRef {

	private Integer id;

	private Integer orderId;

	private String orderNo;

	private Integer memberId;

	private Integer memberDetailInfoId;

	private String nameCh;

	private String nameChPin;

	private String nameEnF;

	private String nameEnS;

	private Integer sex;

	private Integer nationality;

	private Date birthday;

	private String phoneCh;

	private String phoneOverseas;

	private String fixTelArea;

	private String fixTel;

	private String fixTelExtension;

	private String mail;

	private Integer countryId;

	private Integer provinceId;

	private Integer cityId;

	private Integer isSelf;

	private Integer createUser;

	private Date createTime;

	private Integer updateUser;

	private Date updateTime;

	//订单出行人默认证件号
	private OrderLinkmanDoc orderLinkmanDoc;
	
	public OrderLinkmanDoc getOrderLinkmanDoc() {
		return orderLinkmanDoc;
	}

	public void setOrderLinkmanDoc(OrderLinkmanDoc orderLinkmanDoc) {
		this.orderLinkmanDoc = orderLinkmanDoc;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo == null ? null : orderNo.trim();
	}

	public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public Integer getMemberDetailInfoId() {
		return memberDetailInfoId;
	}

	public void setMemberDetailInfoId(Integer memberDetailInfoId) {
		this.memberDetailInfoId = memberDetailInfoId;
	}

	public String getNameCh() {
		return nameCh;
	}

	public void setNameCh(String nameCh) {
		this.nameCh = nameCh == null ? null : nameCh.trim();
	}

	public String getNameChPin() {
		return nameChPin;
	}

	public void setNameChPin(String nameChPin) {
		this.nameChPin = nameChPin == null ? null : nameChPin.trim();
	}

	public String getNameEnF() {
		return nameEnF;
	}

	public void setNameEnF(String nameEnF) {
		this.nameEnF = nameEnF == null ? null : nameEnF.trim();
	}

	public String getNameEnS() {
		return nameEnS;
	}

	public void setNameEnS(String nameEnS) {
		this.nameEnS = nameEnS == null ? null : nameEnS.trim();
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public Integer getNationality() {
		return nationality;
	}

	public void setNationality(Integer nationality) {
		this.nationality = nationality;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getPhoneCh() {
		return phoneCh;
	}

	public void setPhoneCh(String phoneCh) {
		this.phoneCh = phoneCh == null ? null : phoneCh.trim();
	}

	public String getPhoneOverseas() {
		return phoneOverseas;
	}

	public void setPhoneOverseas(String phoneOverseas) {
		this.phoneOverseas = phoneOverseas == null ? null : phoneOverseas.trim();
	}

	public String getFixTelArea() {
		return fixTelArea;
	}

	public void setFixTelArea(String fixTelArea) {
		this.fixTelArea = fixTelArea == null ? null : fixTelArea.trim();
	}

	public String getFixTel() {
		return fixTel;
	}

	public void setFixTel(String fixTel) {
		this.fixTel = fixTel == null ? null : fixTel.trim();
	}

	public String getFixTelExtension() {
		return fixTelExtension;
	}

	public void setFixTelExtension(String fixTelExtension) {
		this.fixTelExtension = fixTelExtension == null ? null : fixTelExtension.trim();
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail == null ? null : mail.trim();
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getIsSelf() {
		return isSelf;
	}

	public void setIsSelf(Integer isSelf) {
		this.isSelf = isSelf;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
