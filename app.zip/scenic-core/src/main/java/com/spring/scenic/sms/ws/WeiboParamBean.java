package com.spring.scenic.sms.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for weiboParamBean complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="weiboParamBean">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountMarket" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="content" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targets" type="{http://webservice.spring.com/}sendTargets" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "weiboParamBean", propOrder = { "accountMarket", "content", "targets" })
public class WeiboParamBean {

    protected String accountMarket;

    protected String content;

    protected SendTargets targets;

    /**
     * Gets the value of the accountMarket property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getAccountMarket() {
        return accountMarket;
    }

    /**
     * Sets the value of the accountMarket property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAccountMarket(String value) {
        this.accountMarket = value;
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setContent(String value) {
        this.content = value;
    }

    /**
     * Gets the value of the targets property.
     * 
     * @return
     *         possible object is {@link SendTargets }
     * 
     */
    public SendTargets getTargets() {
        return targets;
    }

    /**
     * Sets the value of the targets property.
     * 
     * @param value
     *            allowed object is {@link SendTargets }
     * 
     */
    public void setTargets(SendTargets value) {
        this.targets = value;
    }

}
