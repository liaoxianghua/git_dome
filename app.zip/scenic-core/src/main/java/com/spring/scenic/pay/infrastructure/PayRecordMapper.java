package com.spring.scenic.pay.infrastructure;

import com.spring.scenic.pay.domain.PayRecord;

public interface PayRecordMapper {

    int deleteByPrimaryKey(Integer id);

    int savePayRecord(PayRecord record);

    int insertSelective(PayRecord record);

    PayRecord selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(PayRecord record);

    int updateByPrimaryKey(PayRecord record);
}