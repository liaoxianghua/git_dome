package com.spring.scenic.praise.infrastructure;

import java.util.List;

import com.spring.scenic.praise.domain.MyPushPraise;
import com.spring.scenic.praise.domain.PushPraise;

public interface PushPraiseMapper {

    int insert(PushPraise record);

    int insertSelective(PushPraise record);
    
	List<MyPushPraise> selectPushPraiseListOfTravle(Integer memberId);//查询我的游记攻略点赞列表
	
	List<MyPushPraise> selectPushPraiseListOfProduct(Integer memberId);//查询我的产品点赞列表

	PushPraise selectBySessionId(PushPraise pushpraise);

	int deleteByPrimaryKey(Integer id);
	
	int deletePushPraise(PushPraise pushpraise);

    List<MyPushPraise> selectMemberPraiseList(Integer memberId);

	void deleteMyPushPraise(List delList);

    int deleteMemberPraiseByBatch(List<String> idList);
    
    int getPushPraiseCount(PushPraise pushPraise);
    
}