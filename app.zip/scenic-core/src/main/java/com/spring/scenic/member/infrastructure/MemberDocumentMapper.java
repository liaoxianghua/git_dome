package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberDocument;

public interface MemberDocumentMapper {
    
    int deleteByPrimaryKey(Integer id);

    int insert(MemberDocument record);

    int addMemberDocumenInfo(MemberDocument memberDocument);

    MemberDocument selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MemberDocument record);

    int updateByPrimaryKey(MemberDocument record);

	List<MemberDocument> selectMemberDocumentList(List<Integer> passengerIdList);
	
	void addPassengerDocumentInfo(List<MemberDocument> addDocuments);
	
	List<MemberDocument> queryDocumentByCommonPassengerId(
			MemberDetailInfo memberDetailInfo);
	
	void deleteByPassageId(MemberDocument memberDocument);

	void deleteDocumentByMemberDetail(MemberDetailInfo memberDetailInfo);

    List<MemberDocument> selectCommonTripManDocumentList(Integer fkId);

    MemberDocument selectCommonTripManDocument(Integer fkId);

    void deleteDocumentByParam(MemberDocument memberDocument);


}