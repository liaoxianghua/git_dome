package com.spring.scenic.comment.domain;

import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.member.domain.MemberBasic;

public class ProductComment  extends Entity<ProductComment>{

	private Integer id;

	private Integer orderId;

	private String content;

	private Integer gread;

	private Integer isRecommend;

	private Integer sellerId;

	private Integer productId;

	private String productName;

	private Integer src;

	private String sellerComtent;

	private Integer createUser;

	private Date createTime;

	private Integer updateUser;

	private Date updateTime;

	private Integer parenteId; 
	private List<ProductCommentFile> productcommentfile;
	private String sessionId;
	/**
	 * 当前登录的会员
	 */
	private Integer userId;
	/** 是否点赞   1表示已点赞  0 表示未点赞*/
    private Integer praised;
    //点赞数
    private Integer praiseCount;
    
	public Integer getPraiseCount() {
		return praiseCount;
	}

	public void setPraiseCount(Integer praiseCount) {
		this.praiseCount = praiseCount;
	}

	public String getSessionId() {
		return sessionId;
	}
	
	public Integer getPraised() {
		return praised;
	}


	public void setPraised(Integer praised) {
		this.praised = praised;
	}


	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	private MemberBasic memberBasic;
	 
	public MemberBasic getMemberBasic() {
        return memberBasic;
    }

    public void setMemberBasic(MemberBasic memberBasic) {
        this.memberBasic = memberBasic;
    }

    public List<ProductCommentFile> getProductcommentfile() {
        return productcommentfile;
    }

    public void setProductcommentfile(List<ProductCommentFile> productcommentfile) {
        this.productcommentfile = productcommentfile;
    }

    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public Integer getGread() {
		return gread;
	}

	public void setGread(Integer gread) {
		this.gread = gread;
	}

	public Integer getIsRecommend() {
		return isRecommend;
	}

	public void setIsRecommend(Integer isRecommend) {
		this.isRecommend = isRecommend;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName == null ? null : productName.trim();
	}

	public Integer getSrc() {
		return src;
	}

	public void setSrc(Integer src) {
		this.src = src;
	}

	public String getSellerComtent() {
		return sellerComtent;
	}

	public void setSellerComtent(String sellerComtent) {
		this.sellerComtent = sellerComtent == null ? null : sellerComtent
				.trim();
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

    public Integer getParenteId() {
        return parenteId;
    }

    public void setParenteId(Integer parenteId) {
        this.parenteId = parenteId;
    }

}