package com.spring.scenic.product.application.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.domain.vo.ProductHolidayHotelVo;
import com.spring.scenic.product.domain.vo.ProductMoreImgVo;
import com.spring.scenic.product.domain.vo.ProductTouristVo;
import com.spring.scenic.product.domain.vo.ProductVo;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductMealsMapper;
import com.spring.scenic.search.domain.vo.ProductCategoryVo;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.City;
import com.spring.scenic.system.domain.Dictionary;
import com.spring.scenic.system.infrastructure.CityMapper;

@Service
public class ProductServiceImpl implements ProductService {

    @Resource
    private ProductMapper productMapper;
    
    @Resource
    private ProductMealsMapper productMealsMapper;

    @Resource
    private ProductPicRelService productPicRelService;
    
    @Autowired
    private DictionaryService dictionaryService;
    @Resource
    private CityMapper cityMapper;

    @Override
    public List<Product> getProductList(Product product, boolean page) throws Exception{
        if (page) {
            PageHelper.startPage(product.getPageNum(), product.getPageSize());
        }
        
        List<Product> list =  productMapper.getProductList(product);
        for (Product pro: list) {
			ProductPicRel productPicRel = new ProductPicRel();
			productPicRel.setProductId(pro.getId());
			//主图
            List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(pro);
            if (productPics != null && productPics.size() > 0) {
                BusiPictureLib pic = productPics.get(0);
                pro.setMainPic(pic.getFileUrl());
            }
			//关键字
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setOutRelatedType(3);// 3产品类型
			keywordRef.setOutRelatedId(pro.getId());
			keywordRef.setType(2);// 标签类
			List<KeywordRef> listKeywordRef = productMapper.getRealtiveKeywordList(keywordRef);
			pro.setListKeyword(listKeywordRef);
			//二级类别名称
//        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
//			if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
//			    pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
//			}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
//			    pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
//			}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
//			    pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
//			}
			if(!pro.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
			    pro.setPrice(productMapper.getProductMinPrice(pro.getId()));
			}
		}
        return list;
    }

    @Override
    public ProductWithBLOBs selectByPrimaryKey(Integer id) {
    	ProductWithBLOBs bo = productMapper.selectByPrimaryKey(id);
    	if(bo == null){
    		return null;
    	}
    	if(!bo.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
    		bo.setPrice(productMapper.getProductMinPrice(bo.getId()));
		}
    	bo.setReadCount(bo.getReadCount() == null ? 1 : bo.getReadCount() + 1);
    	productMapper.updateByPrimaryKey(bo);
        return bo;
    }

    @Override
    public int updateByPrimaryKeySelective(ProductWithBLOBs product) {
    	if(product != null ){
            ProductWithBLOBs productWithBLOBs = productMapper.selectByPrimaryKey(product.getId());
            if (productWithBLOBs == null) {
                return 0;
            }else{
                if(product.getValid() != null){
                    productWithBLOBs.setValid(product.getValid());
                }
                if(product.getIsSale() != null){
                    productWithBLOBs.setIsSale(product.getIsSale());
                    productWithBLOBs.setSalesTime(new Date());
                }
                productWithBLOBs.setUpdateUser(product.getUpdateUser());
                productWithBLOBs.setUpdateTime(new Date());
                return productMapper.updateByPrimaryKeySelective(productWithBLOBs);
            }
        }else{
            return 0;
        }
    }
    
    @Override
    public int update(ProductWithBLOBs product){
        return productMapper.updateByPrimaryKeySelective(product);
    }
    @Override
    public int delete(Integer id){
        return productMapper.deleteByPrimaryKey(id);
    }
    @Override
    public int updateBatch(String ids,Integer isSale,BusiSellerUser sellerUser){
        List<Product> list = new ArrayList<Product>();
        if(StringUtil.isNotEmpty(ids)){
           List<String> listIds = Arrays.asList(ids.split(","));
           Product p = null;
           
           for (String id : listIds) {
               p = new Product();
               p.setId(Integer.valueOf(id));
               p.setUpdateTime(new Date());
               p.setUpdateUser(sellerUser.getId());
               if(isSale == 1){
                   p.setSalesTime(new Date());
               }
               p.setIsSale(isSale);
               p.setSellerId(sellerUser.getSellerId());
               list.add(p);
           }
        }else{
            return 0;
        }
        return productMapper.batchUpdate(list);
    }

    @Override
    public int saveProduct(ProductWithBLOBs productWithBLOBs) {
        productWithBLOBs.setIsSale(0);
        productWithBLOBs.setValid(1);
        productWithBLOBs.setCreateTime(new Date());
        productWithBLOBs.setUpdateTime(new Date());
        int result = productMapper.insert(productWithBLOBs); 
        if(result > 0){
        	SimpleDateFormat sdf= new SimpleDateFormat("yyyyMMddHHmmss");
        	ProductMeals record = new ProductMeals();
        	record.setMealsName(productWithBLOBs.getProductName());
        	record.setProductId(productWithBLOBs.getId());
        	record.setValid(1);
        	record.setCreateTime(new Date());
        	record.setUpdateTime(new Date());
        	record.setCreateUser(productWithBLOBs.getCreateUser());
        	record.setUpdateUser(productWithBLOBs.getUpdateUser());
        	record.setMealsCode(sdf.format(new Date()));
        	result = productMealsMapper.insert(record);
        }
        return result;
    }
    
    @Override
	public List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef) {
		return productMapper.getRealtiveKeywordList(keywordRef);
	}

    @Override
    public List<ProductWithBLOBs> getRecommendProductList(ProductVo productExample) {
    	Product product = productMapper.selectByPrimaryKey(productExample.getId());
    	if(product != null ){
    		City city =  cityMapper.selectByPrimaryKey(product.getCityId());
    		if(city != null ){
    			productExample.setCityName(city.getName());
    		}
    	}
        List<ProductWithBLOBs> typeCityRecommends = productMapper.getRecommendProductList(productExample);
        //按城市、类别取4个，不足按类别补差额个
        if(typeCityRecommends==null || typeCityRecommends.size()<4){
            List<ProductWithBLOBs> recommends  = productMapper.getRecommendLeftProductList(productExample);
            int size = 4 - typeCityRecommends.size();
            if(recommends!=null && !recommends.isEmpty()){
                for (int i = 0; i < size && i<recommends.size(); i++) {
                    typeCityRecommends.add(recommends.get(i));
                }
            }
        }
        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
        for (Product pro: typeCityRecommends) {
            ProductPicRel productPicRel = new ProductPicRel();
            productPicRel.setProductId(pro.getId());
            //主图
            List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(pro);
            if (productPics != null && productPics.size() > 0) {
                BusiPictureLib pic = productPics.get(0);
                pro.setMainPic(pic.getFileUrl());
            }
            //关键字
            KeywordRef keywordRef = new KeywordRef();
            keywordRef.setOutRelatedType(3);// 3产品类型
            keywordRef.setOutRelatedId(pro.getId());
            keywordRef.setType(2);// 标签类
            List<KeywordRef> listKeywordRef = productMapper.getRealtiveKeywordList(keywordRef);
            pro.setListKeyword(listKeywordRef);
            //二级类别名称
            if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
            }
            if(!pro.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
                pro.setPrice(productMapper.getProductMinPrice(pro.getId()));
            }
        }
        return typeCityRecommends;
    }

	@Override
	public List<ProductHolidayHotelVo> selectHolidayHote(ProductHolidayHotelVo productholidayhotelvo) {
		// TODO Auto-generated method stub
		List<ProductHolidayHotelVo> listholidayHote=productMapper.selectHolidayHote(productholidayhotelvo);
	 
		//增加封面图片
		Product product = new Product();
		for (ProductHolidayHotelVo productHolidayHotelVo2 : listholidayHote) {
			product.setId(productHolidayHotelVo2.getId());
            List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(product);
            if (productPics != null && productPics.size() > 0) {
                BusiPictureLib pic = productPics.get(0);
                productHolidayHotelVo2.setFileUrl(pic.getFileUrl());
            }
		}
		return listholidayHote;
	}

	@Override
	public List<ProductTouristVo> selectProductTourist(ProductTouristVo productholidayhotelvo) {
		
		List<ProductTouristVo> listholidayHote=productMapper.selectProductTourist(productholidayhotelvo);
	 
		//增加封面图片
		Product product = new Product();
		for (ProductTouristVo productTouristVo : listholidayHote) {
            product.setId(productTouristVo.getId());
            List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(product);
            if (productPics != null && productPics.size() > 0) {
                BusiPictureLib pic = productPics.get(0);
                productTouristVo.setFileUrl(pic.getFileUrl());
            }
		}
		return listholidayHote;
	}

    @Override
    public List<Product> searchProduct(Product param, boolean pageAble) {
        if (pageAble) {
            PageHelper.startPage(param.getPageNum(), param.getPageSize());
        }
        List<Product> searchList = productMapper.searchProduct(param);
        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
        for (Product pro: searchList) {
            ProductPicRel productPicRel = new ProductPicRel();
            productPicRel.setProductId(pro.getId());
            //主图
            List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(pro);
            if (productPics != null && productPics.size() > 0) {
                BusiPictureLib pic = productPics.get(0);
                pro.setMainPic(pic.getFileUrl());
            }
            //关键字
            KeywordRef keywordRef = new KeywordRef();
            keywordRef.setOutRelatedType(3);// 3产品类型
            keywordRef.setOutRelatedId(pro.getId());
            keywordRef.setType(2);// 标签类
            List<KeywordRef> listKeywordRef = productMapper.getRealtiveKeywordList(keywordRef);
            pro.setListKeyword(listKeywordRef);
            //二级类别名称
            if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
            }
            if(!pro.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
                pro.setPrice(productMapper.getProductMinPrice(pro.getId()));
            }
        }
        return searchList;
    }

    @Override
    public List<ProductCategoryVo> initProductCategorys(Integer productType, Integer productSubType) {
        Dictionary dictionary = new Dictionary();
        List<ProductCategoryVo> productCategoryVos = new ArrayList<ProductCategoryVo>();
        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
        //全部
        ProductCategoryVo productCategoryVo = new ProductCategoryVo();
        productCategoryVo.setShow(true);
        productCategoryVo.setProductTypeName("全部");
        productCategoryVo.setProductSubTypeName("全部");
        if(productType==null || productSubType==null){
            productCategoryVo.setActive(true);
        }
        productCategoryVos.add(productCategoryVo);
        
        //景点
        dictionary.setCode("PRODUCT_TYPE_SCENIC");
        List<Dictionary> scenics = dicMap.get("PRODUCT_TYPE_SCENIC");
        if(scenics != null){
        	for (Dictionary scenic : scenics) {
        		productCategoryVo = new ProductCategoryVo();
        		productCategoryVo.setProductType(1);
        		productCategoryVo.setProductTypeName(SysEnum.PRODUCT_TYPE_SCENIC.getDescription());
        		productCategoryVo.setProductSubType(Integer.valueOf(scenic.getValue()));
        		productCategoryVo.setProductSubTypeName(getDicName(scenic.getValue(),scenics));
        		productCategoryVo.setShow(true);
        		if((productType!=null && productSubType!=null ) && (1 == productType && Integer.parseInt(scenic.getValue()) == productSubType)){
        			productCategoryVo.setActive(true);
        		}
        		productCategoryVos.add(productCategoryVo);
        	}
        }
        //购物
        dictionary.setCode("PRODUCT_TYPE_SHOPPING");
        List<Dictionary> shoppings = dicMap.get("PRODUCT_TYPE_SHOPPING");
        if(shoppings != null){
        	for (Dictionary shopping : shoppings) {
        		productCategoryVo = new ProductCategoryVo();
        		productCategoryVo.setProductType(2);
        		productCategoryVo.setProductTypeName(SysEnum.PRODUCT_TYPE_SHOPPING.getDescription());
        		productCategoryVo.setProductSubType(Integer.valueOf(shopping.getValue()));
        		productCategoryVo.setProductSubTypeName(getDicName(shopping.getValue(),shoppings));
        		productCategoryVo.setShow(true);
        		if((productType!=null && productSubType!=null ) && (2 == productType && Integer.parseInt(shopping.getValue()) == productSubType)){
        			productCategoryVo.setActive(true);
        		}
        		productCategoryVos.add(productCategoryVo);
        	}
        }
       //旅游线路
        dictionary.setCode("PRODUCT_TYPE_LINE");
        List<Dictionary> lines = dicMap.get("PRODUCT_TYPE_LINE");
        if(lines != null){
        	for (Dictionary line : lines) {
        		productCategoryVo = new ProductCategoryVo();
        		productCategoryVo.setProductType(3);
        		productCategoryVo.setProductTypeName(SysEnum.PRODUCT_TYPE_LINE.getDescription());
        		productCategoryVo.setProductSubType(Integer.valueOf(line.getValue()));
        		productCategoryVo.setProductSubTypeName(getDicName(line.getValue(),lines));
        		productCategoryVo.setShow(true);
        		if((productType!=null && productSubType!=null ) && (3 == productType && Integer.parseInt(line.getValue()) == productSubType)){
        			productCategoryVo.setActive(true);
        		}
        		productCategoryVos.add(productCategoryVo);
        	}
        }
        return productCategoryVos;
    }
    
    private String getDicName(String value, List<Dictionary> dics){
        if(StringUtils.isBlank(value)){
           return null; 
        }
        for (Dictionary dataDictionary : dics) {
            if(dataDictionary.getValue().equals(value)){
                return dataDictionary.getName();
            }
        }
        return null;
    }
    
    @Override
	public List<ProductMoreImgVo> selectOfficialImgList(Integer productId) {
		try {
			List<ProductMoreImgVo> list = productMapper
					.selectOfficialImgList(productId);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"), e);
		}
	}
    
	@Override
	public List<ProductMoreImgVo> selectOnlineImgList(Integer productId) {
		try {
			List<ProductMoreImgVo> list = productMapper
					.selectOnlineImgList(productId);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"), e);
		}
	}
    
}
