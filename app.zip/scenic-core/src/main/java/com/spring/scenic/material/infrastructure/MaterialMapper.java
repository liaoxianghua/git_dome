package com.spring.scenic.material.infrastructure;

import java.util.List;
import java.util.Map;

import com.spring.scenic.material.domain.Material;
import com.spring.scenic.material.domain.vo.MaterialChannelBarVo;
import com.spring.scenic.material.domain.vo.MaterialDirectSeedingVo;
import com.spring.scenic.material.domain.vo.MaterialLoveDestinationVo;
import com.spring.scenic.material.domain.vo.MaterialVo;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;

public interface MaterialMapper {

	/**
	 * @Description 批量保存素材信息
	 * @param materials
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	int saveBatchMaterials(List<Material> materials);

	/**
	 * @Description 查询素材列表数据
	 * @param material
	 * @return List<Material>
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	List<Material> getMaterialList(Material material);

	/**
	 * @Description 查询单个素材
	 * @param material
	 * @return Material
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	Material getMaterial(Material material);

	/**
	 * @Description 删除素材
	 * @param material
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int deleteMaterial(Material material);

	/**
	 * @Description 修改素材库信息
	 * @param materialExample
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	int updateMaterial(Material materialExample);

	/** @Description 根据城市查询当前的轮播图
	 * @author lzj
	 * @date 2017年4月20日16:45:15
	 * 
	 * */
	public List<MaterialVo> selectMaterial();

	/** @Description 根据城市查询当前的渠道栏
	 * @author lzj
	 * @date 2017年4月23日14:43:04
	 * 
	 * */
	public List<MaterialChannelBarVo> selectChannelBar();
	/** @Description 根据城市查询当前的最爱目的地
	 * @author lzj
	 * @date 2017年4月23日15:39:25
	 * 
	 * */
	public List<MaterialLoveDestinationVo> selectloveDestination(MaterialLoveDestinationVo materiallovedestinationvo);
	/** @Description 根据城市查询当前的直播
	 * @author lzj
	 * @date 2017年4月23日15:39:25
	 * 
	 * */
	public List<MaterialDirectSeedingVo> selectdirectSeeding(Map<String,Object> map);
	/** @Description  游记
	 * @author lzj
	 * @date 2017年4月23日15:39:25
	 * 
	 * */
	public List<MaterialtravelsVo> getTravelNotesList(MaterialtravelsVo materialtravelsVo);

	List<MaterialtravelsVo> selectPassMytravelsList(MaterialtravelsVo materialtravelsVs);
	
} 