package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.vo.ProductStockVo;

public interface ProductStockService {
 
	/**
	 * 时间段查询
	 * @param 
	 * @return
	 */
	public List<ProductStock> selectList(ProductStockVo productStockVo);
	/**
	 * 根据套餐ID 月份查询库存
	 * @param 
	 * @return
	 */
	public List<ProductStock> selectMonthAll(ProductStock productStock);

    public ProductStock getProductStock(Integer stockId);
}
