package com.spring.scenic.basic.application.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.basic.infrastructure.KeywordMapper;
import com.spring.scenic.product.domain.Keyword;

@Service
public class KeywordServiceImpl implements KeywordService {
    
    @Autowired
    private KeywordMapper keywordMapper;

    @Override
    public List<Keyword> getHotSearchKeyword() {
        return keywordMapper.getHotSearchKeyword();
    }

    @Override
    public List<Keyword> getHotCityKeyword() {
        return keywordMapper.getHotCityKeyword();
    }

    @Override
    public List<Keyword> getMatchKeywords(String keyword) {
        return keywordMapper.getMatchKeywords(keyword);
    }



}
