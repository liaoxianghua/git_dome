package com.spring.scenic.product.application.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.vo.ProductStockVo;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductMealsMapper;
import com.spring.scenic.product.infrastructure.ProductStockMapper;

@Service
public class ProductStockServiceImpl implements ProductStockService {

	@Resource
	private ProductStockMapper productStockMapper;
	@Resource
	private ProductMapper productMapper;
	@Resource
	private ProductMealsMapper productMealsMapper;
 
	@Override
	public List<ProductStock> selectMonthAll(ProductStock productStock) {
		ProductMeals productMeals = productMealsMapper.selectByPrimaryKey(productStock.getMealsId());
		List<ProductStock> list = productStockMapper.selectMonthAll(productStock);
		if(productMeals != null ){
			Product product =  productMapper.selectByPrimaryKey(productMeals.getProductId());
			if(product != null){
				//限制购买日期
				Calendar limitOrderDay = Calendar.getInstance();
				if(product.getLastOrderDay() != null && product.getLastOrderTime() != null){
					limitOrderDay.add(Calendar.DATE, product.getLastOrderDay());//几天后
					limitOrderDay.set(Calendar.HOUR_OF_DAY, product.getLastOrderTime());//几点
					limitOrderDay.set(Calendar.MINUTE, 0);
					limitOrderDay.set(Calendar.SECOND, 0);
					Date lastOrderTime = limitOrderDay.getTime();
					for (ProductStock temp : list) {
						Calendar c = Calendar.getInstance();
						Calendar b = Calendar.getInstance();
								b.setTime(temp.getPlayDay());
								b.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY));
								b.set(Calendar.MINUTE, c.get(Calendar.MINUTE));
								b.set(Calendar.SECOND, c.get(Calendar.SECOND));
								Date playTime = b.getTime();
								//如果是同一天 比较小时
						if(DateUtil.dateToString2(temp.getPlayDay()).equals(DateUtil.dateToString2(lastOrderTime)) || temp.getTotalNum()
								< 1){
							if(b.get(Calendar.HOUR_OF_DAY) > limitOrderDay.get(Calendar.HOUR_OF_DAY)  || temp.getTotalNum()
									< 1){
								temp.setId(null);
								temp.setProductType(null);
								temp.setMealsId(null);
								temp.setPrice(null);
								temp.setAdultPrice(null);
								temp.setChildPrice(null);
								temp.setSingleRoomPrice(null);
								temp.setTotalNum(null);
								temp.setSaleNum(null);
								temp.setCreateTime(null);
								temp.setCreateUser(null);
								temp.setUpdateTime(null);
								temp.setUpdateUser(null);
							}
						}else if(playTime.before(lastOrderTime)  || temp.getTotalNum()
								< 1){//如果出行日期在最晚预定之前
							temp.setId(null);
							temp.setProductType(null);
							temp.setMealsId(null);
							temp.setPrice(null);
							temp.setAdultPrice(null);
							temp.setChildPrice(null);
							temp.setSingleRoomPrice(null);
							temp.setTotalNum(null);
							temp.setSaleNum(null);
							temp.setCreateTime(null);
							temp.setCreateUser(null);
							temp.setUpdateTime(null);
							temp.setUpdateUser(null);
						}
					}
				}
				return list;
			}else{
				return new ArrayList<ProductStock>();
			}
		}else{
			return new ArrayList<ProductStock>();
		}
	}

	@Override
	public List<ProductStock> selectList(ProductStockVo productStockVo) {
		 
		return productStockMapper.selectList(productStockVo);
	}

    @Override
    public ProductStock getProductStock(Integer stockId) {
        return productStockMapper.selectByPrimaryKey(stockId);
    }

}
