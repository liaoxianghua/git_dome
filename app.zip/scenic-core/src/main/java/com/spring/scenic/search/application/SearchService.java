package com.spring.scenic.search.application;

import java.util.List;

import com.spring.scenic.product.domain.Product;


public interface SearchService {

    List<Product> getProductList(Product product, boolean pageAble);

    List<Product> searchProduct(Product product, boolean pageAble);
    

}
