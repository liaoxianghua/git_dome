package com.spring.scenic.material.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.material.domain.Material;
import com.spring.scenic.material.domain.vo.MaterialChannelBarVo;
import com.spring.scenic.material.domain.vo.MaterialDirectSeedingVo;
import com.spring.scenic.material.domain.vo.MaterialLoveDestinationVo;
import com.spring.scenic.material.domain.vo.MaterialVo;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.system.domain.AuthUser;

public interface MaterialService {

	int saveMaterialUpload(AuthUser user,Map<String, List<MultipartFile>> filesMap, String[] descriptions,
			Integer[] types, Integer[] usertypes, Integer[] authorizedIds,
			String[] keys, String[] names);

	List<Material> getMaterialList(Material material, boolean pageAble);

	Material getMaterial(Material material);

	int deleteMaterial(Material material);

	int auditMaterial(AuthUser user, Material material);
	/** 轮播大图广告位5 条数据*/
	public   List<MaterialVo> selectMaterial();
	/**  渠道栏*/
	public List<MaterialChannelBarVo> selectChannelBar();
	/** 最爱目的地*/
	public List<MaterialLoveDestinationVo> selectLoveDestination(MaterialLoveDestinationVo materiallovedestinationvo);
	/** 直播*/
	public List<MaterialDirectSeedingVo> selectDirectSeeding(Integer status,String sessionId,Integer userId);
	/** 游记*/
	public List<MaterialtravelsVo> getTravelNotesList(MaterialtravelsVo materialtravelsVo,Boolean flag);

}
