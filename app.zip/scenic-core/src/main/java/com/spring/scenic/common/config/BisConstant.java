package com.spring.scenic.common.config;

public class BisConstant {
    
    //SESSION保存会员的key
    public static final String SESSION_MEMBER = "APP_MEMEBER";
    public static final String PASS_PARAM_GLOB_MSG_IS_NOT_NULL="传递的参数不能为空";
    public static final String FORBIDDEN_MSG = "非法的请求";
    public static final Integer USER_NOT_LOGIN_GLOB_CODE=101;//用户未登录状态码
    public static final String USER_NOT_LOGIN_GLOB_MESSAGE="会员未登录";//用户未登录状态码
    public static final Integer INDEX_COLLECTION_STATUS=2;//收藏类型 1产品 2游记攻略 
    public static final Integer INDEXCONTROLLER_QUERY_ALL_LOVEDESTINATION_CODE=2;// 0:表示查询国内  1:表示查询处境 2:表示查询所有
    public static final Integer INDEXCONTROLLER_QUERY_DOMESTIC_LOVEDESTINATION_CODE=0;// 0:表示查询国内  1:表示查询处境 2:表示查询所有
    
    //短信业务ID
    public static final String SMS_BIS_ID = "41";
    //短信应用ID
    public static final String SMS_SYS_ID ="35";
    //短信类别ID
    public static final String SMS_TYPE = "1"; 
    
    //用户定位的城市
    public static final String SESSION_LOCATION_CITY = "SESSION_LOCATION_CITY";
    
    //默认城市
    public static final String LOCATION_CITY_DEFAULT = "上海";
    
    //会员快速注册默认密码
    public static final String INITIAL_PASSWORD = "123456";
    
    
}
