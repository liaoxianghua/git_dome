package com.spring.scenic.praise.domain;

import java.util.Date;

public class PushPraise {
    
    private Integer id;

    private String sessionId;

    private Integer memberId;

    private Integer praiseType;

    private Integer praiseContentId;

    private Date createTime;

    private Integer createUser;

    private Date updateTime;

    private Integer updateUser;
    
    /** 会员点赞是否可见*/
    private Integer isView;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId == null ? null : sessionId.trim();
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public Integer getPraiseType() {
        return praiseType;
    }

    public void setPraiseType(Integer praiseType) {
        this.praiseType = praiseType;
    }

    public Integer getPraiseContentId() {
        return praiseContentId;
    }

    public void setPraiseContentId(Integer praiseContentId) {
        this.praiseContentId = praiseContentId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

	public Integer getIsView() {
		return isView;
	}

	public void setIsView(Integer isView) {
		this.isView = isView;
	}
    
}