package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberMsg;

public interface MemberMsgMapper {
   
    int deleteByPrimaryKey(Integer id);

    int insert(MemberMsg record);

    MemberMsg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MemberMsg record);

    int updateByPrimaryKeyWithBLOBs(MemberMsg record);

    int updateByPrimaryKey(MemberMsg record);
    
    List<MemberMsg> selectMemberMsg(Integer memberId);//我的系统通知列表
    
    int addMemberMsg(MemberMsg memberMsg);//添加会员消息

    /**   
     * 此处为类方法说明：查询会员收到的系统通知列表
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    List<MemberMsg> selectSystemNoticeList(Integer memberId);

    /**   
     * 此处为类方法说明:批量删除会员系统消息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月12日     
     * @memo ：   
     **
     */
    int deleteMemberSysMsgByBatch(List<String> idList);

    /**   
     * 此处为类方法说明:查询会员收到的系统通知详情
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月18日     
     * @memo ：   
     **
     */
    MemberMsg selectSystemNoticeDetail(Integer id);
}