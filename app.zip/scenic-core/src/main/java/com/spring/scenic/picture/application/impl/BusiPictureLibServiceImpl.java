package com.spring.scenic.picture.application.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.picture.domain.vo.BusiPictureAttachVo;
import com.spring.scenic.picture.domain.vo.BusiPictureLibVo;
import com.spring.scenic.picture.infrastructure.BusiPictureLibMapper;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;

@Service
public class BusiPictureLibServiceImpl implements BusiPictureLibService {

    @Resource
    private BusiPictureLibMapper pictureLibMapper;
    @Resource(name = "fastDFSStorageService")
    private StorageService fastDFSStorageService;
    
    @Override
    public List<BusiPictureLib> list(BusiPictureLibVo busiPictureLibVo, boolean page) {
        if (page) {
            PageHelper.startPage(busiPictureLibVo.getPageNum(), busiPictureLibVo.getPageSize());
        }
        return pictureLibMapper.selectList(busiPictureLibVo);
    }

	@Override
	public BusiPictureAttachVo saveUploadFile(Map<String, List<MultipartFile>> filesMap) {
		BusiPictureAttachVo vo = new BusiPictureAttachVo();
		try {
			if (filesMap != null && !filesMap.isEmpty()) {
				List<MultipartFile> multipartFiles = filesMap.get("upload");
				if (multipartFiles != null && !multipartFiles.isEmpty()) {
					MultipartFile multipartFile = multipartFiles.get(0);
					String fileType = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
					if(StringUtils.isNotBlank(fileType)) {
					    fileType = fileType.toLowerCase();
					}
					String fileName = multipartFile.getOriginalFilename();
					String fileUrl = fastDFSStorageService.uploadResource(fileType, multipartFile.getBytes(), null);
					vo.setName(fileName);
					vo.setUrlAttach(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL) + fileUrl);
				}
			}
			return vo;
		} catch (Exception e) {
		    throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

}
