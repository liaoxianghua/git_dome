package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * 游记详情
 * @author lzj
 * @date 2017年5月3日21:16:22
 */
public class TravelNotesStrategyVo implements Serializable{
  
	private static final long serialVersionUID = 1L;
	/** ID */
	private Integer id;
	/** 用户名 */
	private String name;
	/** 用户头像 */
	private String imageUrl;
	/** 发表日期 */
	private Date publishDate;
	/** 标题 */
	private String title;
	/** 封面图*/
	private String coversImageUrl;
	/** 评论数*/
	private Integer readCount;
	/** 类型*/
	private Integer type;
	/** 谁创建*/
	private Integer createUser;
	/** 用户类型*/
	private Integer createUserType;
	
	private List<TravelNotesDetailsVo> travelnotesdetailsList;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<TravelNotesDetailsVo> getTravelnotesdetailsList() {
		return travelnotesdetailsList;
	}

	public void setTravelnotesdetailsList(
			List<TravelNotesDetailsVo> travelnotesdetailsList) {
		this.travelnotesdetailsList = travelnotesdetailsList;
	}

	public String getCoversImageUrl() {
		return coversImageUrl;
	}

	public void setCoversImageUrl(String coversImageUrl) {
		this.coversImageUrl = coversImageUrl;
	}

	public Integer getReadCount() {
		return readCount;
	}

	public void setReadCount(Integer readCount) {
		this.readCount = readCount;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Integer getCreateUserType() {
		return createUserType;
	}

	public void setCreateUserType(Integer createUserType) {
		this.createUserType = createUserType;
	}
	

}
