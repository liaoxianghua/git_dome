package com.spring.scenic.product.domain.vo;

import java.io.Serializable;

public class ProductTouristVo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** ID */
	private Integer id;
	/** 产品名称 */
	private String productName;
	/** 最低价格 */
	private String minprice;
	/** 城市*/
	private String city;
	private String fileUrl;
	/** 出行人数*/
	private Integer saleNum;
	/** 类型   2 表示自由行   3:表示直通车*/
	private Integer subType;
	/** 还差几个*/
	private Integer missingCount;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMinprice() {
		return minprice;
	}

	public void setMinprice(String minprice) {
		this.minprice = minprice;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public Integer getSaleNum() {
		return saleNum;
	}

	public void setSaleNum(Integer saleNum) {
		this.saleNum = saleNum;
	}

	public Integer getSubType() {
		return subType;
	}

	public void setSubType(Integer subType) {
		this.subType = subType;
	}

	public Integer getMissingCount() {
		return missingCount;
	}

	public void setMissingCount(Integer missingCount) {
		this.missingCount = missingCount;
	}
	
}
