package com.spring.scenic.member.domain.vo;

import java.math.BigDecimal;
import java.util.List;

import com.spring.scenic.product.domain.vo.KeywordHolidayHotelVo;

public class MyConllectionOfProduct {
	private Integer id;

	private String cityName;

	private String pictuerName;

	private Integer productType;

	private String productName;

	private BigDecimal price;

	private Integer saleNum;

	private Integer productSubType;

	private String productSubTypeName;

	private Integer collectionType;

	private List<KeywordHolidayHotelVo> keyWordProduct;

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getPictuerName() {
		return pictuerName;
	}

	public void setPictuerName(String pictuerName) {
		this.pictuerName = pictuerName;
	}

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getSaleNum() {
		return saleNum;
	}

	public void setSaleNum(Integer saleNum) {
		this.saleNum = saleNum;
	}

	public Integer getProductSubType() {
		return productSubType;
	}

	public void setProductSubType(Integer productSubType) {
		this.productSubType = productSubType;
	}

	public String getProductSubTypeName() {
		return productSubTypeName;
	}

	public void setProductSubTypeName(String productSubTypeName) {
		this.productSubTypeName = productSubTypeName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
    
	public Integer getCollectionType() {
		return collectionType;
	}

	public void setCollectionType(Integer collectionType) {
		this.collectionType = collectionType;
	}
	public List<KeywordHolidayHotelVo> getKeyWordProduct() {
		return keyWordProduct;
	}

	public void setKeyWordProduct(List<KeywordHolidayHotelVo> keyWordProduct) {
		this.keyWordProduct = keyWordProduct;
	}

}
