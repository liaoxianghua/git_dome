package com.spring.scenic.member.application;

import java.util.List;

import com.spring.scenic.member.domain.MemberMsg;

public interface MemberMsgService {
	
	public List<MemberMsg> selectMemberMsg(Integer memberId);//我的系统通知

    /**   
     * 此处为类方法说明:查询会员收到的系统通知列表
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    public List<MemberMsg> selectSystemNoticeList(Integer memberId);

    /**   
     * 此处为类方法说明：查询会员收到的系统通知详情
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月18日     
     * @memo ：   
     **
     */
    public MemberMsg selectSystemNoticeDetail(Integer noticeId);

    /**   
     * 此处为类方法说明:创建会员消息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    public void addMemberMsg(MemberMsg memberMsg);

    /**   
     * 此处为类方法说明:
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    public void deleteMemberSysMsgByBatch(List<String> idList);

}
