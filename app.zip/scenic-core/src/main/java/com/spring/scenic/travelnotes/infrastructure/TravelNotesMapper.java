package com.spring.scenic.travelnotes.infrastructure;

import java.util.List;

import com.spring.scenic.travelnotes.domain.TravelNotes;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesCountVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;

public interface TravelNotesMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(TravelNotes record);

    int insertSelective(TravelNotes record);

    TravelNotes selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TravelNotes record);

    int updateByPrimaryKey(TravelNotes record);

	List<TravelNotesVo> selectmytravelsList(TravelNotesVo travelnotesvo);

    List<TravelNotes> searchTravelNoteList(TravelNotes travelNote);
    
	public TravelNotesStrategyVo selectBydetailMytravel(Integer id);

	public List<TravelNotesDetailStrategyVo> selectByDetailStrategyVo(Integer id);

	public TravelNotesVo getTravelNote(TravelNotesVo TravelNotesVo);

	List<IndexTravelNotesUserCommentslVo> selectByIndexTravelNotesUserCommentslVo(Integer id);

	public int updateReadCountTravelNote(Integer id);

	public TravelNotesCountVo selectTravelNoteCount(Integer id);

    /**   
     * 此处为类方法说明:我的第一篇游记查询
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月25日     
     * @memo ：   
     **
     */
    TravelNotesVo selectMyFirstTravelNote(TravelNotesVo travelNote);

    /**   
     * 此处为类方法说明:我的第一篇游记查询(未通过)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月26日     
     * @memo ：   
     **
     */
    TravelNotesVo selectMyFirstTravelNoteNotPass(TravelNotesVo travelNote);
}