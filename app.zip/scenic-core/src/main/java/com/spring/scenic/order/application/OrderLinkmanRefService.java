package com.spring.scenic.order.application;

import com.spring.scenic.order.domain.OrderLinkmanRef;

/**
 * 订单出行人关系表
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年5月4日
 */
public interface OrderLinkmanRefService {

	/**
	 * 添加出行人关系表
	 * @param orderLinkmanRef
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月4日下午4:05:49
	 */
	int add(OrderLinkmanRef orderLinkmanRef);
}
