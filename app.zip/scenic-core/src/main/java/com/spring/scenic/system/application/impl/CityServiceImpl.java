package com.spring.scenic.system.application.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.system.application.CityService;
import com.spring.scenic.system.domain.City;
import com.spring.scenic.system.infrastructure.CityMapper;

@Service
public class CityServiceImpl implements CityService {

    @Autowired
    private CityMapper cityMapper;
    
    
    @Override
    public Map<String,List<City>> getGroupCitys() {
        Map<String,List<City>> map = new HashMap<String,List<City>>();
        List<City> initialLetterList = cityMapper.getInitialLetterGroup();
        if(initialLetterList!=null && !initialLetterList.isEmpty()){
            for (City city : initialLetterList) {
                List<City> gourpCitys = cityMapper.getGourpCitysByInitialLetter(city);
                if(gourpCitys!=null && !gourpCitys.isEmpty()){
                    map.put(city.getInitialLetter(),gourpCitys);
                }
            }
        }
        return map;
    }

}
