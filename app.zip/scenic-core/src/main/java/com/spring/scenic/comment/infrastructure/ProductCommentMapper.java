package com.spring.scenic.comment.infrastructure;

import java.util.List;

import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.product.domain.vo.ProductVo;

public interface ProductCommentMapper {

    public List<ProductComment> getProductCommentList(ProductComment productComment);

    Integer getAComment(ProductVo productExample);

    Integer getBComment(ProductVo productExample);

    Integer getCComment(ProductVo productExample);
    /**
     * 查询评论是否有图
     * 此处为类方法说明
     * @param productExample
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月23日下午3:40:24
     */
    Integer getPicComment(ProductVo productExample);
    
    int insertProductComment(ProductComment productComment);

    int getProductCommentCount(ProductComment productComment);

    /**   
     * 此处为类方法说明:通过主键查询该条产品评论信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月24日     
     * @memo ：   
     **
     */
    public ProductComment selectByPrimaryKey(Integer id);
    
}