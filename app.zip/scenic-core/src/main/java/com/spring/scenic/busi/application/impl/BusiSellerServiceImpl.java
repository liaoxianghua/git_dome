package com.spring.scenic.busi.application.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.infrastructure.BusiSellerMapper;
import com.spring.scenic.busi.infrastructure.BusiSellerUserMapper;

@Service
public class BusiSellerServiceImpl implements BusiSellerService {

    @Autowired
    private BusiSellerMapper busiSellerMapper;
    
    @Autowired
    private BusiSellerUserMapper busiSellerUserMapper;

    @Override
    public BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser) {
        return busiSellerMapper.getBusiSellerByUser(busiSellerUser);
    }

    @Override
    public BusiSeller getBusiSellerById(Integer sellerId) {
        return busiSellerMapper.getBusiSellerById(sellerId);
    }

    @Override
    public BusiSellerUser getBusiSellerUserBySellerId(Integer sellerId) {
        return busiSellerUserMapper.queryUserInfoBySellerId(sellerId);
    }
    
    
    

}
