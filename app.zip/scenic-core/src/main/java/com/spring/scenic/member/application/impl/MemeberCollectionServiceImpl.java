package com.spring.scenic.member.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.member.domain.vo.MyConllectionOfProduct;
import com.spring.scenic.member.domain.vo.MyConllectionOfTravel;
import com.spring.scenic.member.infrastructure.MemberCollectionMapper;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;
@Service
public class MemeberCollectionServiceImpl implements MemberCollectionService{
	
	@Autowired
	private MemberCollectionMapper memberCollectionMapper;
	
	@Autowired
    private DictionaryService dictionaryService;
	
	@Resource
	private ProductService productService;

	@Resource
	private ProductPicRelService productPicRelService;

	@Override
	public List<MemberCollection> selectCollection(MemberCollection membercollection) {
		return memberCollectionMapper.selectCollection(membercollection);
	}	
	
	@Override
    public int getMemberCollectCount(MemberCollection membercollection) {
	    return memberCollectionMapper.getMemberCollectCount(membercollection);
    }

    @Override
	public Integer add(Integer memberId, Integer collectionType, Integer collectionContentId) {
		MemberCollection memberCollection = new MemberCollection();
		memberCollection.setMemberId(memberId);
		memberCollection.setCollectionContentId(collectionContentId);
		memberCollection.setCollectionType(collectionType);
		memberCollection.setCreateUser(memberId);
		memberCollection.setCreateTime(new Date());
		memberCollection.setUpdateUser(memberId);
		memberCollection.setUpdateTime(new Date());
		return memberCollectionMapper.insert(memberCollection);
	}

	@Override
	public Integer delete(Integer memberId, Integer collectionType, Integer collectionContentId) {
		MemberCollection memberCollection = new MemberCollection();
		memberCollection.setMemberId(memberId);
		memberCollection.setCollectionContentId(collectionContentId);
		memberCollection.setCollectionType(collectionType);
		memberCollection.setCreateUser(memberId);
		memberCollection.setCreateTime(new Date());
		memberCollection.setUpdateUser(memberId);
		memberCollection.setUpdateTime(new Date());
		return memberCollectionMapper.delete(memberCollection);
	}

    /**
     * 我的收藏游记攻略
     */
	@Override
	public List<MyConllectionOfTravel> selectMyConllectionOfTravel(MaterialtravelsVo materialtravelsVo) {
		try{
    		List<MyConllectionOfTravel> lists = memberCollectionMapper.selectMyConllectionOfTravel(materialtravelsVo);
            if(null==lists || lists.size()==0){
    			return lists;
    		}
    		for(MyConllectionOfTravel myConllectionOfTravel : lists){
    			myConllectionOfTravel.setNowTime(DateUtil.currentDateToNowTime(myConllectionOfTravel.getNowTime()));
    			myConllectionOfTravel.setSubTitle(StringUtils.isBlank(myConllectionOfTravel.getSubTitle()) ? null:myConllectionOfTravel.getSubTitle().length()>100 ? myConllectionOfTravel.getSubTitle().substring(0, 100):myConllectionOfTravel.getSubTitle());
    			myConllectionOfTravel.setReadCount(null==myConllectionOfTravel.getReadCount() ? 0 :myConllectionOfTravel.getReadCount());
    		}
    		return lists;
		}catch(Exception e){
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

    /**
     * 我的收藏产品
     */
	@Override
	public List<MyConllectionOfProduct> selectPushPraiseListOfProduct(Integer memberId) {
		try{
			List<MyConllectionOfProduct> list = memberCollectionMapper.selectMyConllectionOfProduct(memberId);
			 Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
			for(MyConllectionOfProduct mcop:list){
				if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
				}else if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
				}else if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
				}
				if(mcop.getPictuerName()==null){
					// 基本属性
					ProductWithBLOBs product = productService.selectByPrimaryKey(mcop.getId());
					// 产品图片
					List<BusiPictureLib> productPicList = productPicRelService.getProductPicOrDefault(product);
					if(productPicList==null || productPicList.isEmpty()){//没图片给默认图片
					    product.setMainPic(PropertiesUtil.getProperty("scenic_default_user_img"));
					    mcop.setPictuerName(product.getMainPic());
					}else{//有图片取第一张
					    product.setMainPic(productPicList.get(0).getFileUrl());
					    product.setProductPics(productPicList);
					    mcop.setPictuerName(product.getMainPic());
					}
				}
			}
		    return list;
		}catch(Exception e){
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	private String getDicName(String value, List<Dictionary> dics){
        for (Dictionary dataDictionary : dics) {
            if(dataDictionary.getValue().equals(value)){
                return dataDictionary.getName();
            }
        }
        return null;
    }

    @Override
    public int getMemberCollecttionCount(MemberCollection mcCollection) {
        return memberCollectionMapper.getMemberCollecttionCount(mcCollection);
    }


	@Override
	public List<TravelNotesVo> getTravelNoteViewHistory(Map<String,Object> param) {
		try{
			List<TravelNotesVo> travelNoteHis = memberCollectionMapper.getTravelNoteViewHistory(param);
	        if(null==travelNoteHis || travelNoteHis.size()==0){
				return travelNoteHis;
			}
			for(TravelNotesVo myConllectionOfTravel : travelNoteHis){
				myConllectionOfTravel.setNowTime(DateUtil.currentDateToNowTime(myConllectionOfTravel.getNowTime()));
//				if(null!=myConllectionOfTravel.getWords()) {
//				    myConllectionOfTravel.setWords(myConllectionOfTravel.getWords().length()>20 ? myConllectionOfTravel.getWords().substring(0, 20):myConllectionOfTravel.getWords());
//				}
				myConllectionOfTravel.setReadCount(null==myConllectionOfTravel.getReadCount() ? 0 :myConllectionOfTravel.getReadCount());
			}
			return travelNoteHis;
		}catch(Exception e){
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public List<MyConllectionOfProduct> selectMyBrowserProduct(List<Integer> integerlist) {
		try{
			
			List<MyConllectionOfProduct> list = new ArrayList<MyConllectionOfProduct>();
			if(integerlist.size()!=0){
				for (Integer id : integerlist) {
					MyConllectionOfProduct myConllectionOfProduct=memberCollectionMapper.selectMyBrowserProductId(id);
					if(myConllectionOfProduct != null){
					    //增加封面图片
					    Product product = new Product();
					    product.setId(myConllectionOfProduct.getId());
					    List<BusiPictureLib> productPics = productPicRelService.getProductPicOrDefault(product);
					    if (productPics != null && productPics.size() > 0) {
					        BusiPictureLib pic = productPics.get(0);
					        myConllectionOfProduct.setPictuerName(pic.getFileUrl());
					    }
					    myConllectionOfProduct.setPictuerName(null==myConllectionOfProduct.getPictuerName() ? 
					            PropertiesUtil.getProperty("scenic_default_user_img") : myConllectionOfProduct.getPictuerName());
					    list.add(myConllectionOfProduct);
					}
				}
			}
			
			 Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
			for(MyConllectionOfProduct mcop:list){
				if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
				}else if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
				}else if(mcop.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
					mcop.setProductSubTypeName(getDicName(mcop.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
				}
			}
		    return list;
		}catch(Exception e){
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

}
