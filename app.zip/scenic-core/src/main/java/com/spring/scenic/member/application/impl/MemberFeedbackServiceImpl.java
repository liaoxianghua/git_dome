package com.spring.scenic.member.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.ValidateUtil;
import com.spring.scenic.member.application.MemberFeedbackService;
import com.spring.scenic.member.domain.MemberFeedback;
import com.spring.scenic.member.domain.MemberFeedbackImg;
import com.spring.scenic.member.infrastructure.MemberFeedbackImgMapper;
import com.spring.scenic.member.infrastructure.MemberFeedbackMapper;
/**
 * 
 * 此处为类说明:用户意见反馈接口实现类
 * @author rmp
 * @date 2017年5月5日
 */
@Service
public class MemberFeedbackServiceImpl implements MemberFeedbackService{
    
	@Autowired
	private MemberFeedbackMapper memberFeedbackMapper;
	@Autowired
	MemberFeedbackImgMapper memberFeedbackImgMapper;
	
	@Override
	/**
	 * 新增意见反馈
	 */
	public void addMemberFeedback(MemberFeedback memberFeedback){		
	try{
		MessageData data=new MessageData(null, null,null);
		memberFeedbackMapper.insertSelective(memberFeedback);
		data.setMessage("成功");
	} catch (Exception e) {
		e.printStackTrace();
		throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
	}
	}
	/**
	 * 用户意见反馈:文件名、文件url以字符串接收，用","隔开
	 */
    @Override
    public MessageData addMemberFeedback(Integer memberId,String feedbackContent, String linkPhone, String imgUrls) {
        try {
            MessageData messageData = new MessageData(null, null);
            if(StringUtil.isEmpty(feedbackContent)) {
                messageData.setStatus(102);
                messageData.setMessage("反馈信息不能为空！");
                return messageData;
            }
            if(StringUtil.isEmpty(linkPhone)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号不能为空");
                return messageData;
            }
            if(!ValidateUtil.isCellPhone(linkPhone)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号格式不正确");
                return messageData;
            }
//            if(StringUtil.isEmpty(imgUrls)) {
//                messageData.setStatus(102);
//                messageData.setMessage("图片地址参数为空！");
//                return messageData;
//            }
            //新增意见反馈信息，返回id作为外键储存意见相关的图片信息
            MemberFeedback memberFeedback = new MemberFeedback();
            memberFeedback.setMemberId(memberId);
            memberFeedback.setFeedbackContent(feedbackContent);
            memberFeedback.setLinkPhone(linkPhone);
            memberFeedback.setFeedbackTime(new Date());
            memberFeedbackMapper.addMemberFeedback(memberFeedback);
            Integer feedbackId = memberFeedback.getId();
            if(null!=feedbackId) {
                //组装反馈信息图片信息成为一个list 批量插入数据
                List <MemberFeedbackImg> feedbackImgList = new ArrayList<MemberFeedbackImg>();
                String imgUrlArray[] = null;
                if(StringUtil.isNotEmpty(imgUrls)) {
                    imgUrlArray = imgUrls.split(",");
                    //上传图片，最多9张
                    if(imgUrlArray.length>9) {
                        messageData.setStatus(102);
                        messageData.setMessage("最多上传9张图片！");
                        return messageData;
                    }
                    for (String imgUrl : imgUrlArray) {
                        MemberFeedbackImg memberFeedbackImg = new MemberFeedbackImg();
                        memberFeedbackImg.setFeedbackId(feedbackId);
                        memberFeedbackImg.setImgUrl(imgUrl);
                        feedbackImgList.add(memberFeedbackImg);
                    }
                    memberFeedbackImgMapper.addMemberFeedbackImgs(feedbackImgList);
                }
            }
            messageData.setStatus(200);
            messageData.setMessage("新增成功！");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);        
            }
    }
}
