package com.spring.scenic.order.application;

import java.util.List;

import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductWithBLOBs;
/**
 * 订单处理service
 * @author liaoxianghua
 * @date 2017年5月4日
 */
public interface OrderService {
 
	/**
	 * 会员提交订单<br>
	 * 1、创建订单<br>
	 * 2、创建订单出行人关系（旅游线路）<br>
	 * 3、创建订单发票（可选）<br>
	 * 4、修改库存<br>
	 */
	Order saveOrder(Order order, MemberBasic memberBasic, ProductWithBLOBs product,ProductStock productStock,String passengers);
	/**
	 * 会员保存购物订单<br>
	 * 1、创建订单<br>
	 * 2、创建订单出行人关系（旅游线路）<br>
	 * 3、创建订单发票（可选）<br>
	 * 4、修改库存<br>
	 */
	Order saveShoppingOrder(Order order, MemberBasic memberBasic, ProductWithBLOBs product);
	/**
	 * 会员查个订单列表方法
	 * 此处为类方法说明
	 * @param order 查询参数
	 * @param page 是否分页
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月4日上午11:02:36
	 */
	List<Order> selectList(Order order,boolean page);
	/**
	 * 查询订单详情
	 * @param inte
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月5日下午1:45:41
	 */
	Order selectOrderDetail(Integer orderId);
	
    int updateOrderStatus(Order order,MemberBasic memberBasic);
}
