package com.spring.scenic.picture.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.picture.domain.vo.BusiPictureAttachVo;
import com.spring.scenic.picture.domain.vo.BusiPictureLibVo;

public interface BusiPictureLibService {

    public List<BusiPictureLib> list(BusiPictureLibVo pictureLib, boolean page);


	/**
	 * 
	 * @param filesMap
	 * @return 文件上传后直接,调取返回的URL地址
	 */
	public BusiPictureAttachVo saveUploadFile(Map<String, List<MultipartFile>> filesMap);

}
