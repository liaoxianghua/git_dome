package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.system.domain.AuthUser;

public interface CountryService {
	
	public List<Country> selectCuntryList();
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月9日     
     * @memo ：   
     **
     */
    public List<Country> initAddressData();
	
	
}
