package com.spring.scenic.member.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class MemberBasic {
    private Integer id;

    private String memberAccount;

    private String password;

    private String imageUrl;

    private Short careerType;

    private Short educateType;

    private Short activatedFlg;

    private String memberFrom;

    private Short valid;

    private Date loginTime;

    private Short loginFrom;

    private Date lastLoginTime;

    private String loginIp;

    private String guid;

    private String memberLevel;

    private String activityDegree;

    private BigDecimal growthValue;

    private Date growthDate;

    private Integer createUser;

    private Date createTime;

    private Integer updateUser;

    private Date updateTime;
    
    private MemberDetailInfo memberDetail;
    
    private List<MemberSharedAccount> memberSharedAccountList;
    /**
     * 接受、拒绝评论(1、接受；0：拒绝)
     */
    private Integer receiveComment;
    /**
     * 接受、拒绝点赞(1、接受；0：拒绝)
     */
    private Integer receivePrasie;
    /**
     * 接受、拒绝评论开始时间
     */
    private Date receiveCommentStart;
    /**
     * 接受、拒绝点赞开始时间
     */
    private Date receivePrasieStart;
    
    private String countryName;
    
    private String provinceName;
    /**
     * 城市名称
     */
    private String cityName;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount == null ? null : memberAccount.trim();
    }

    public String getPassword() {
        return password;
    }
   
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? null : imageUrl.trim();
    }

    public Short getCareerType() {
        return careerType;
    }

    public void setCareerType(Short careerType) {
        this.careerType = careerType;
    }

    public Short getEducateType() {
        return educateType;
    }

    public void setEducateType(Short educateType) {
        this.educateType = educateType;
    }

    public Short getActivatedFlg() {
        return activatedFlg;
    }

    public void setActivatedFlg(Short activatedFlg) {
        this.activatedFlg = activatedFlg;
    }

    public String getMemberFrom() {
        return memberFrom;
    }

    public void setMemberFrom(String memberFrom) {
        this.memberFrom = memberFrom == null ? null : memberFrom.trim();
    }

    public Short getValid() {
        return valid;
    }

    public void setValid(Short valid) {
        this.valid = valid;
    }

    public Date getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }

    public Short getLoginFrom() {
        return loginFrom;
    }

  
    public void setLoginFrom(Short loginFrom) {
        this.loginFrom = loginFrom;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }
   
    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp == null ? null : loginIp.trim();
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid == null ? null : guid.trim();
    }

    public String getMemberLevel() {
        return memberLevel;
    }

    public void setMemberLevel(String memberLevel) {
        this.memberLevel = memberLevel == null ? null : memberLevel.trim();
    }

    public String getActivityDegree() {
        return activityDegree;
    }

    public void setActivityDegree(String activityDegree) {
        this.activityDegree = activityDegree == null ? null : activityDegree.trim();
    }

    public BigDecimal getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(BigDecimal growthValue) {
        this.growthValue = growthValue;
    }

    public Date getGrowthDate() {
        return growthDate;
    }

    public void setGrowthDate(Date growthDate) {
        this.growthDate = growthDate;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

	public MemberDetailInfo getMemberDetail() {
		return memberDetail;
	}

	public void setMemberDetail(MemberDetailInfo memberDetail) {
		this.memberDetail = memberDetail;
	}

    public List<MemberSharedAccount> getMemberSharedAccountList() {
        return memberSharedAccountList;
    }

    public void setMemberSharedAccountList(List<MemberSharedAccount> memberSharedAccountList) {
        this.memberSharedAccountList = memberSharedAccountList;
    }

    public Integer getReceiveComment() {
        return receiveComment;
    }

    public void setReceiveComment(Integer receiveComment) {
        this.receiveComment = receiveComment;
    }

    public Integer getReceivePrasie() {
        return receivePrasie;
    }

    public void setReceivePrasie(Integer receivePrasie) {
        this.receivePrasie = receivePrasie;
    }

    public Date getReceiveCommentStart() {
        return receiveCommentStart;
    }

    public void setReceiveCommentStart(Date receiveCommentStart) {
        this.receiveCommentStart = receiveCommentStart;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public Date getReceivePrasieStart() {
        return receivePrasieStart;
    }

    public void setReceivePrasieStart(Date receivePrasieStart) {
        this.receivePrasieStart = receivePrasieStart;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    
    
}