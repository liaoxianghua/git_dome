package com.spring.scenic.common.util;
public class RSAkey {

    	private String modules;
    	private String exponent;

    	public RSAkey(String modules, String exponent) {
    		super();
    		this.modules = modules;
    		this.exponent = exponent;
    	}

    	public String getModules() {
    		return modules;
    	}

    	public void setModules(String modules) {
    		this.modules = modules;
    	}

    	public String getExponent() {
    		return exponent;
    	}

    	public void setExponent(String exponent) {
    		this.exponent = exponent;
    	}

    }