package com.spring.scenic.comment.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.product.domain.vo.ProductVo;

/**
 * 
 * @author lzj
 * 描述:商品点评表
 * 日期:2017年4月1日15:22:08
 */
public interface ProductCommentService {

	/**
	 * 描述:查询商品点评列表
	 */
	public List<ProductComment> getProductCommentList(ProductComment productComment, boolean page);
	
	
	/**
	 * 获取最近一个点评数据
	 */
    public ProductComment getFirstProductComment(ProductComment productComment);
    
    
    /**   
     * 订单好中差评论统计
     */
    public Map<String,Object> getCommentStatistic(ProductVo productExample);
    
    public int insertProductComment(Integer orderId, String content, Integer gread, Integer sellerId,
        Integer productId, String productName, Integer src, String imgUrls, Integer parentId, Integer memberId);
    
    /**
     * 订单是否被当前会员评论了，true：是
     */
    public boolean hasCommentedOrderProduct(Integer orderId, Integer memeberId);


    /**   
     * 此处为类方法说明:通过主键查询该条产品评论信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月24日     
     * @memo ：   
     **
     */
    public ProductComment selectByPrimaryKey(Integer id);

}
