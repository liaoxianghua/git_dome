package com.spring.scenic.common.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(value = "智慧景区接口信息封装类")
public class MessageData {
	
    @ApiModelProperty(value = "服务器处理请求后响应返回的状态码（必选）:200(成功)、201(失败)、500(程序异常)", required = true)
	private Integer status;
	
    @ApiModelProperty(value = "服务器处理请求后响应返回的常用的文本信息（必选）", required = true)
	private String message;
	
    @ApiModelProperty(value = "服务器处理请求后响应返回的自定义对象（可选）", required = false)
	private Object obj;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }

    public MessageData(Integer status, String message, Object obj) {
        super();
        this.status = status;
        this.message = message;
        this.obj = obj;
    }

    public MessageData(Integer status, String message) {
        super();
        this.status = status;
        this.message = message;
    }
	
}
