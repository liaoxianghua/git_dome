package com.spring.scenic.security.authority;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;

import com.spring.scenic.busi.application.BusiSellerUserService;

public class CustomInvocationSecurityMetadataSourceService implements FilterInvocationSecurityMetadataSource {
	
	private static Logger logger = LoggerFactory.getLogger(CustomInvocationSecurityMetadataSourceService.class);
	
	private BusiSellerUserService busiSellerUserService;

	private Collection<ConfigAttribute> allAttribute = new HashSet<ConfigAttribute>();
	
	private static Map<String, Collection<ConfigAttribute>> resourceMap = new LinkedHashMap<String, Collection<ConfigAttribute>>();

	@Autowired
	public CustomInvocationSecurityMetadataSourceService(BusiSellerUserService busiSellerUserService) {
		this.busiSellerUserService = busiSellerUserService;
		initResourceConfig();
	}
	
	@Override
	public Collection<ConfigAttribute> getAllConfigAttributes() {
		return this.allAttribute;
	}

	@Override
	public Collection<ConfigAttribute> getAttributes(Object object)throws IllegalArgumentException {
		String url = ((FilterInvocation) object).getRequestUrl().toLowerCase();
		int firstMark = url.indexOf("?");
		if (firstMark > -1) {
			url = url.substring(0, firstMark);
		}
		Collection<ConfigAttribute>  configAttributes = resourceMap.get(url); 
		logger.info("FilterInvocationSecurityMetadataSource : There is no configAttributes for url ("+url+"),AccessDecisionManager will be use original...");
		return configAttributes;
	}

	@Override
	public boolean supports(Class<?> arg0) {
		return true;
	}

	public void initResourceConfig() {
	    System.out.println(busiSellerUserService);
//		try {
//			List<AuthRole> allRole = authUserService.getRoleList(new AuthRole());
//			if(allRole!=null && !allRole.isEmpty()){
//				for (AuthRole authRole : allRole) {
//					allAttribute.add(new SecurityConfig(authRole.getRoleName()));
//				}
//			}
//			List<AuthResource> allResources = authUserService.getResourceList(new AuthResource());
//			if (allResources == null || allResources.isEmpty()) {
//				logger.warn("Could not find anyelse resource from system...");
//			} else {
//				for (AuthResource resource : allResources) {
//					if(StringUtils.isBlank(resource.getUrl())){
//						continue;
//					}else{
//						List<AuthRole> assignedRoles = authUserService.getRoleListByResource(resource);
//						if(assignedRoles == null || assignedRoles.isEmpty()){
//							continue;
//						}else{
//							Collection<ConfigAttribute> roleAttributes = new ArrayList<ConfigAttribute>();
//							for (AuthRole authRole : assignedRoles) {
//								SecurityConfig securityConfig = new SecurityConfig(authRole.getRoleName());
//								roleAttributes.add(securityConfig);
//							}
//							resourceMap.put(resource.getUrl(), roleAttributes);
//						}
//					}
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			logger.error("initResourceConfig:加载资源权限异常...",e);
//			throw e;
//		}
	}

}
