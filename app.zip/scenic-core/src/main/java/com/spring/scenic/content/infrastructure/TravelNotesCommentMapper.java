package com.spring.scenic.content.infrastructure;

import java.util.List;

import com.spring.scenic.content.domain.TravelNotesComment;
import com.spring.scenic.content.domain.vo.MyCommentVo;

public interface TravelNotesCommentMapper {
   
    int deleteByPrimaryKey(Integer id);

    int insert(TravelNotesComment record);

    int insertSelective(TravelNotesComment record);

    TravelNotesComment selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TravelNotesComment record);

    int updateByPrimaryKey(TravelNotesComment record);
    
    int selectTravelNotesCommentCount(Integer createUser);//查询我的评论
    
    List<TravelNotesComment> selectTravelNotesComment(Integer createUser);//我的评论列表

	List<MyCommentVo> selectCommentOfProduct(Integer commentUser);

	List<MyCommentVo> selectCommentOfTravel(Integer commentUser);

	void deleteMyComment(List delList);

    /**   
     * 此处为类方法说明：此处为类方法说明:查询会员本人的游记被评论列表,点赞类别(1、游记攻略；2、产品的评论；3、直播)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    List<MyCommentVo> selectMemberCommentList(Integer memberId);

    /**   
     * 此处为类方法说明:批量删除会员游记被评论记录 
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月11日     
     * @memo ：   
     **
     */
    int deleteMemberCommentByBatch(List<String> idList);
}