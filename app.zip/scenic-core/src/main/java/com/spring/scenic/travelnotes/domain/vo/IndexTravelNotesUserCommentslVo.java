package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;

/**
 * 
 * 描述:首页游记详情页面用户评论
 * 
 * @author lzj
 * @date 2017年5月4日20:39:34
 */
public class IndexTravelNotesUserCommentslVo implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;
	/** 评论ID */
	private Integer id;
	/** 评论信息用户头像 */
	private String imageUrl;
	/** 评论游记用户姓名 */
	private String name;
	/** 评论用户 信息 */
	private String comments;
	/** 评论用户距离当前日期多少分钟 */
	private String nowTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getNowTime() {
		return nowTime;
	}

	public void setNowTime(String nowTime) {
		this.nowTime = nowTime;
	}

}
