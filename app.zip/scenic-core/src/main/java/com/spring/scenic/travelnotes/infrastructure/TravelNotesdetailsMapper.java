package com.spring.scenic.travelnotes.infrastructure;

import java.util.List;

import com.spring.scenic.travelnotes.domain.TravelNotes;
import com.spring.scenic.travelnotes.domain.TravelNotesdetails;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailsVo;

public interface TravelNotesdetailsMapper {
 
    int deleteByPrimaryKey(Integer id);
    int insert(TravelNotesdetails record);
    int insertSelective(TravelNotesdetails record);
    TravelNotesdetails selectByPrimaryKey(Integer id);
   
    int updateByPrimaryKeySelective(TravelNotesdetails record);
    int updateByPrimaryKeyWithBLOBs(TravelNotesdetails record);
    int updateByPrimaryKey(TravelNotesdetails record);
    
     List<TravelNotesDetailsVo> selectTravelNotesDetailsVo(Integer id);
     List<TravelNotesDetailsVo> selectIndexTravelNotesDetailsVo(Integer id);

     TravelNotesdetails getDefaultSubTitle(TravelNotes travelNote);
  
}