package com.spring.scenic.notice.application;

import java.util.List;

import com.spring.scenic.notice.domain.BusiNotice;

public interface NoticeService {

    List<BusiNotice> getNoticeList(BusiNotice notice, boolean page);

    BusiNotice getNotice(BusiNotice notice);

    BusiNotice getTop1Notice();
    
    List<BusiNotice> getTop5Notice();

}
