package com.spring.scenic.product.domain.vo;

import java.io.Serializable;

/**
 * 
 * @author lzj 度假酒店标签显示
 */
public class KeywordHolidayHotelVo implements Serializable {

	private static final long serialVersionUID = 1L;

	 
	/** 显示的标签名字 */
	private String name;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
