package com.spring.scenic.busi.infrastructure;

import com.spring.scenic.busi.domain.BusiSellerUser;



public interface BusiSellerUserMapper {

    BusiSellerUser getSellerByAccount(String username);
    
    BusiSellerUser getUserNameByTel(String tel);//通过tel查询出用户和电话和id
    
	void updatePwdByTel(BusiSellerUser busiSellerUser);//通过tel修改用户密码
	
	BusiSellerUser queryUserInfoById(Integer id);//通过ID查询商户账号信息 
	
	void updatePwdById(BusiSellerUser busiSellerUser);//通过ID修改密码

    BusiSellerUser queryUserInfoBySellerId(Integer sellerId);
	
}