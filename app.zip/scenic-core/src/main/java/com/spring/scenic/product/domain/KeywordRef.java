package com.spring.scenic.product.domain;

import java.io.Serializable;

public class KeywordRef implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private Integer id;

    private Integer outRelatedId;
    
    private Integer outRelatedType;
    
    private Integer keywordId;
    
    private String name;

    private Integer type;

    private Integer valid;
    
    private Integer ord;
    
    private String flag;
    
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getValid() {
		return valid;
	}

	public void setValid(Integer valid) {
		this.valid = valid;
	}

	public Integer getKeywordId() {
		return keywordId;
	}

	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOutRelatedId() {
		return outRelatedId;
	}

	public void setOutRelatedId(Integer outRelatedId) {
		this.outRelatedId = outRelatedId;
	}

	public Integer getOutRelatedType() {
		return outRelatedType;
	}

	public void setOutRelatedType(Integer outRelatedType) {
		this.outRelatedType = outRelatedType;
	}

	public Integer getOrd() {
		return ord;
	}

	public void setOrd(Integer ord) {
		this.ord = ord;
	}
 
    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    
}