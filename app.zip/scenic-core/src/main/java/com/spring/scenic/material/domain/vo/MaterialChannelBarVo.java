package com.spring.scenic.material.domain.vo;

import java.io.Serializable;

/**
 * @Description 渠道栏Vo
 * 2017年4月23日14:39:39
 * @author lzj
 * 
 */
public class MaterialChannelBarVo implements Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**素材库ID*/
    private Integer id;
    
    /** 标题*/
    private String title;
    /** 跳转URL地址*/
    private String skipUrl;
    
    /** 图片的地址*/
    private String pictureUrl;
    

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSkipUrl() {
		return skipUrl;
	}

	public void setSkipUrl(String skipUrl) {
		this.skipUrl = skipUrl;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

 

}