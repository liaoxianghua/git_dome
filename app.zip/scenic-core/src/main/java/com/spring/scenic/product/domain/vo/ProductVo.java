package com.spring.scenic.product.domain.vo;

import com.spring.scenic.product.domain.Product;

public class ProductVo extends Product {
    
    private String cityName;

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    

}
