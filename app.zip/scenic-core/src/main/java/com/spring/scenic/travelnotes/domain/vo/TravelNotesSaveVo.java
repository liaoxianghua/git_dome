package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 游记Vo
 * @author lzj
 * 时间:2017年5月2日15:40:36
 */
public class TravelNotesSaveVo implements Serializable{


	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;
	/** ID*/
	private Integer id;
	/** 会员ID*/
	private Integer mememberId;
	/** 类型*/
	private Integer type;
	/** 类型*/
	private String title;
	/** 创建时间*/
	private Date createTime;
	
	/** 状态 0 表示 草稿  1表示未审核  2表示审核通过*/
	private Integer status;
	
	private List<TravelNotesDetailsVo> travelnotesdetailsList;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMememberId() {
		return mememberId;
	}

	public void setMememberId(Integer mememberId) {
		this.mememberId = mememberId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<TravelNotesDetailsVo> getTravelnotesdetailsList() {
		return travelnotesdetailsList;
	}

	public void setTravelnotesdetailsList(
			List<TravelNotesDetailsVo> travelnotesdetailsList) {
		this.travelnotesdetailsList = travelnotesdetailsList;
	}
	
}
