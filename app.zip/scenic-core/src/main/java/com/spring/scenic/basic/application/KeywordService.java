package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.product.domain.Keyword;

public interface KeywordService {
    
    List<Keyword> getHotSearchKeyword();
    
    List<Keyword> getHotCityKeyword();

    /**
     * 关键字匹配范围
     * 城市、关键字
     */
    List<Keyword> getMatchKeywords(String keyword);

}
