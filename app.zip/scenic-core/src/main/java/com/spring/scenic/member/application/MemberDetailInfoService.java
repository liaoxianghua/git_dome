/**
 * 
 */
package com.spring.scenic.member.application;

import java.util.List;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.system.domain.AuthUser;

/**	@Description：会员管理常用出行人接口实现类
 *  @author：ranmaoping
 *  @date:下午3:12:58 2017年1月17日
 *  @version:1.0
 *
 */
public interface MemberDetailInfoService {

	/**
	 * 
	 *@Description:查询常用出行人
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	List<MemberDetailInfo> selectCommonTripManList(MemberBasic member);

	/**
	 * 新增常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	void addMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo);

	/**
	 * 修改常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	void updateMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo);
	/**
	 * 查询常用出行人信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月22日
	 */
	MemberDetailInfo updateMemberCommonTripMan(MemberDetailInfo memberDetailInfo);
	/**
	 * 删除常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月22日
	 */
	void deleteInfo(MemberDetailInfo memberDetailInfo);
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年4月28日     
     * @memo ：   
     **
     */
    MemberDetailInfo selectcommonTripManInfo(MemberDetailInfo memberDetailInfo);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    MessageData addCommonTripMan(Integer memberId,String nameCh, String nameEnF, String nameEnS, Integer sex, String phoneCh,
         Integer nationality, Integer documentType, String documentNo, Integer isSelf,String birthdayDate);
	/**
	 * 
	 * @param memerberid
	 * @return
	 * 根据会员的ID查询会员的详细资料
	 * 日期:2017年4月27日22:21:26
	 * @author lzj
	 */
	public MemberDetailInfo selectByFkId(Integer fkId);


    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    MessageData deleteCommonTripMan(Integer passengerId);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    MessageData updateCommonTripMan(Integer passengerId, Integer documentId, Integer memberId, String nameCh,
        String nameEnF, String nameEnS, Integer sex, String phoneCh, Integer nationality, Integer documentType,
        String documentNo, Integer isSelf, String birthdayDate);

    /**   
     * 此处为类方法说明:添加会员 详情信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    void addMemberDetailInfo(MemberDetailInfo memberDetailInfo);


}
