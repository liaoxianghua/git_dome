package com.spring.scenic.sms.ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.spring.scenic.sms.ws package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SendMessage_QNAME = new QName("http://webservice.spring.com/", "sendMessage");

    private final static QName _SendMessageResponse_QNAME = new QName("http://webservice.spring.com/",
            "sendMessageResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of
     * schema derived classes for package: com.spring.scenic.sms.ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PushParamBean }
     * 
     */
    public PushParamBean createPushParamBean() {
        return new PushParamBean();
    }

    /**
     * Create an instance of {@link RetBeanOfSendMessage }
     * 
     */
    public RetBeanOfSendMessage createRetBeanOfSendMessage() {
        return new RetBeanOfSendMessage();
    }

    /**
     * Create an instance of {@link SendMessageType }
     * 
     */
    public SendMessageType createSendMessageType() {
        return new SendMessageType();
    }

    /**
     * Create an instance of {@link WeixinParamBean }
     * 
     */
    public WeixinParamBean createWeixinParamBean() {
        return new WeixinParamBean();
    }

    /**
     * Create an instance of {@link SmsParamBean }
     * 
     */
    public SmsParamBean createSmsParamBean() {
        return new SmsParamBean();
    }

    /**
     * Create an instance of {@link EmailParamBean }
     * 
     */
    public EmailParamBean createEmailParamBean() {
        return new EmailParamBean();
    }

    /**
     * Create an instance of {@link SendTargets }
     * 
     */
    public SendTargets createSendTargets() {
        return new SendTargets();
    }

    /**
     * Create an instance of {@link SendMessageResponse }
     * 
     */
    public SendMessageResponse createSendMessageResponse() {
        return new SendMessageResponse();
    }

    /**
     * Create an instance of {@link WeiboParamBean }
     * 
     */
    public WeiboParamBean createWeiboParamBean() {
        return new WeiboParamBean();
    }

    /**
     * Create an instance of {@link SendMessage }
     * 
     */
    public SendMessage createSendMessage() {
        return new SendMessage();
    }

    /**
     * Create an instance of {@link BeanOfSendMessage }
     * 
     */
    public BeanOfSendMessage createBeanOfSendMessage() {
        return new BeanOfSendMessage();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendMessage }
     * {@code >}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.spring.com/", name = "sendMessage")
    public JAXBElement<SendMessage> createSendMessage(SendMessage value) {
        return new JAXBElement<SendMessage>(_SendMessage_QNAME, SendMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}
     * {@link SendMessageResponse }{@code >}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.spring.com/", name = "sendMessageResponse")
    public JAXBElement<SendMessageResponse> createSendMessageResponse(SendMessageResponse value) {
        return new JAXBElement<SendMessageResponse>(_SendMessageResponse_QNAME, SendMessageResponse.class, null, value);
    }

}
