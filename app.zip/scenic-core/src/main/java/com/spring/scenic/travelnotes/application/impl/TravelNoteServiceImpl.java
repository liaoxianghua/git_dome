package com.spring.scenic.travelnotes.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.material.infrastructure.MaterialMapper;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;
import com.spring.scenic.travelnotes.domain.TravelNotesdetails;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesCountVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailsVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesSaveVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;
import com.spring.scenic.travelnotes.infrastructure.TravelNotesMapper;
import com.spring.scenic.travelnotes.infrastructure.TravelNotesdetailsMapper;
import com.spring.scenic.utl.JsonMapper;

/**
 * @Description 游记攻略业务实现类
 * @author 006568（shuchang）
 * @date 2016年12月26日
 */
@Service
public class TravelNoteServiceImpl implements TravelNoteService {

	@Resource
	private TravelNotesMapper travelNotesMapper;
	@Resource
	private TravelNotesdetailsMapper travelnotesdetailsmapper;
	@Resource
	private MemberDetailInfoService memberDetailInfoService;
	@Resource
	private AuthUserService authUserService;
	@Resource
	private MemberBasicService memberBasicService;
	@Resource
	private MaterialMapper materialMapper;
	@Resource
	private ProductPicRelService productPicRelService;
	
	
	@Resource(name="fastDFSStorageService")
	private StorageService fastDFSStorageService;

	@Override
	public List<TravelNotes> getTravelNoteList(TravelNotes travelNote,
			Boolean pageAble) {
		
		return null;
	}

	@Override
	public int saveTravelNote(AuthUser user, TravelNotes travelNote,
			Map<String, List<MultipartFile>> filesMap, String coversImageFile) {
		
		return 0;
	}

	@Override
	public TravelNotes getTravelNoteWithDetail(TravelNotes travelNote) {
		
		return null;
	}

	@Override
	public int saveAuditTravelNote(AuthUser user, TravelNotes travelNote) {
		
		return 0;
	}

	@Override
	public List<Keyword> getKeywordListById(Integer id) {
		
		return null;
	}

	@Override
	public int updateTravelNote(AuthUser user, TravelNotes travelNote,
			Map<String, List<MultipartFile>> filesMap, String coversImageFile) {
		
		return 0;
	}


	@Override
	public List<TravelNotesVo> selectmytravelsList(TravelNotesVo travelnotesvo, boolean page) {
		 if (page) {
	            PageHelper.startPage(travelnotesvo.getPageNum(), travelnotesvo.getPageSize());
	        }
			List<TravelNotesVo> list=travelNotesMapper.selectmytravelsList(travelnotesvo);
//			List<TravelNotesVo> tempTravelNotesVoList=new ArrayList<TravelNotesVo>();
			for (TravelNotesVo vo : list) {
				List<TravelNotesDetailsVo> detVo=travelnotesdetailsmapper.selectTravelNotesDetailsVo(vo.getId());
				vo.setTravelnotesdetailsList(detVo);
				vo.setSubTitle(vo.getSubTitle()==null ? null :vo.getSubTitle().length()>100 ? vo.getSubTitle().substring(0,100):vo.getSubTitle());
//				tempTravelNotesVoList.add(vo);
			}
			return list;
			
		}

	@Transactional
	@Override
	public int addMytravel(Integer memerberid, String arryStr) {
		JsonMapper mapper = new JsonMapper();
		
		try {
			List<TravelNotesSaveVo> travelNotesVolist=mapper.fromJson("[" + arryStr + "]", mapper.createCollectionType(List.class, TravelNotesSaveVo.class));
			if(null!=travelNotesVolist){
				for (TravelNotesSaveVo travelNotesVo : travelNotesVolist) {
					addSaveTraveleNote(memerberid, travelNotesVo);//保存游记
				}
			}
		} catch (Exception e) {
			return 0;
		}
		
		return 1;
	}
	
	
    @Override
    public List<TravelNotes> searchTravelNoteList(TravelNotes travelNote, boolean page) {
        if (page) {
            PageHelper.startPage(travelNote.getPageNum(), travelNote.getPageSize());
        }
        List<TravelNotes> travelNotes = travelNotesMapper.searchTravelNoteList(travelNote);
        for (TravelNotes travelNoteTemp : travelNotes) {
        	travelNoteTemp.setNowTime(DateUtil.currentDateToNowTime(travelNoteTemp.getNowTime()));
       travelNoteTemp.setSubTitle(StringUtils.isBlank(travelNoteTemp.getSubTitle()) ? null : travelNoteTemp.getSubTitle().length()>100 ? travelNoteTemp.getSubTitle().substring(0, 100): travelNoteTemp.getSubTitle());
            if(travelNoteTemp.getCreateUserType()==null ||2==travelNoteTemp.getCreateUserType()){ //会员状态  为 null 或者1 为系统创建类型
                travelNoteTemp.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
                travelNoteTemp.setAuthorName(PropertiesUtil.getProperty("scenic_default_user_name"));
            }else if(1==travelNoteTemp.getCreateUserType()){
                MemberBasic memberBasicExample = new MemberBasic();
                memberBasicExample.setId(travelNoteTemp.getCreateUser());
                MemberBasic memberBasic = memberBasicService.getMemberDetailInfo(memberBasicExample);
                travelNoteTemp.setImageUrl(
                        StringUtils.isBlank(memberBasic.getImageUrl())?PropertiesUtil.getProperty("scenic_default_user_img") : memberBasic.getImageUrl());
                if(StringUtils.isBlank(memberBasic.getMemberDetail().getNameCh())){
                    travelNoteTemp.setAuthorName(memberBasic.getMemberDetail().getPhoneCh().substring(0,3)+"****"+memberBasic.getMemberDetail().getPhoneCh().substring(7, 11));
                }else{
                    travelNoteTemp.setAuthorName(memberBasic.getMemberDetail().getNameCh()); 
                }
                
            }
        }
        return travelNotes;
    }

    @Transactional
	@Override
	public int updateMytravel(Integer memerberid, String arryStr) {
		MemberDetailInfo memberdetailinfo=memberDetailInfoService.selectByFkId(memerberid);
		List<String> urlStr=new ArrayList<String>();
		JsonMapper mapper = new JsonMapper();
		
		List<Integer> oldTraveNote=new ArrayList<Integer>();
		List<Integer> oldTravelNotesdetails=new ArrayList<Integer>();
		
		Map<Integer, Integer> indexs = new HashMap<Integer, Integer>();
		Map<Integer, Integer> indexsTravelNotesdetails = new HashMap<Integer, Integer>();
    	
		try {
			//从页面传递过来的列表值
			List<TravelNotesSaveVo> travelNotesVolist=mapper.fromJson("[" + arryStr + "]", mapper.createCollectionType(List.class, TravelNotesSaveVo.class));
			
			TravelNotesVo travelnotesvo=new TravelNotesVo();
			travelnotesvo.setMememberId(memerberid);
			travelnotesvo.setType(travelNotesMapper.selectByPrimaryKey(travelNotesVolist.get(0).getId()).getStatus());
			travelnotesvo.setId(travelNotesVolist.get(0).getId());
			List<TravelNotesVo> oldlist=selectmytravelsList(travelnotesvo,false);
			//获取根据用户查询用户以前的数据
			if(oldlist.size()>0){
				for (int i = 0; i < oldlist.size(); i++) {
					oldTraveNote.add(oldlist.get(i).getId());
					indexs.put(oldlist.get(i).getId(), i);
					for (int j = 0; j < oldlist.get(i).getTravelnotesdetailsList().size(); j++) {
						oldTravelNotesdetails.add(oldlist.get(i).getTravelnotesdetailsList().get(j).getId());
						indexsTravelNotesdetails.put(oldlist.get(i).getTravelnotesdetailsList().get(j).getId(),j);
					}
				}
			}
			if(null!=travelNotesVolist){
				for (TravelNotesSaveVo travelNotesSaveVo : travelNotesVolist) {
					for(TravelNotesDetailsVo vo : travelNotesSaveVo.getTravelnotesdetailsList()){
						
						if(StringUtils.isNotBlank(vo.getUrl())){
							urlStr.add(vo.getUrl().trim());
						}
					}
					
					if(null!=travelNotesSaveVo.getId()){
						TravelNotes travelNotes=new TravelNotes();
						if(oldTraveNote.contains(travelNotesSaveVo.getId())){
							oldTraveNote.remove(travelNotesSaveVo.getId());
							travelNotes=travelNotesMapper.selectByPrimaryKey(travelNotesSaveVo.getId());
							travelNotes.setId(travelNotesSaveVo.getId());
							travelNotes.setTitle(travelNotesSaveVo.getTitle());//标题
							travelNotes.setAuthorName(memberdetailinfo.getNameCh());//作者名称
							travelNotes.setType(memberdetailinfo.getType());//游记
							travelNotes.setCoversImageUrl(memberdetailinfo.getImgUrl());//封面图片
							travelNotes.setValid(1);//是否有效
							travelNotes.setStatus(travelNotesSaveVo.getStatus());//0表示草稿箱   1:未审核 2 已审核 3 未通过
//							travelNotes.setPublishDate(new Date()); //发布时间
//							travelNotes.setCreateTime(new Date());//创建时间
							travelNotes.setCreateUser(memerberid);//谁创建
							travelNotes.setCreateUserType(1L); // 1是会员   2表示 后台人员
							//如果用户没有上传图片则取第一张,没有的话则为猴爸爸的图片
							if(urlStr.size()==0){
								travelNotes.setCoversImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
							}else{
								travelNotes.setCoversImageUrl(urlStr.get(0));
							}
							travelNotesMapper.updateByPrimaryKey(travelNotes);
						}
						for (TravelNotesDetailsVo travelnotesdetailsvo : travelNotesSaveVo.getTravelnotesdetailsList()) {
							TravelNotesdetails travelNotesdetails=new TravelNotesdetails();
							if(null!=travelnotesdetailsvo.getId()){
								if(oldTravelNotesdetails.contains(travelnotesdetailsvo.getId())){
									oldTravelNotesdetails.remove(travelnotesdetailsvo.getId());
									travelNotesdetails=travelnotesdetailsmapper.selectByPrimaryKey(travelnotesdetailsvo.getId());
									if(1==travelnotesdetailsvo.getType()){
										travelNotesdetails.setType(1);
									}else if(2==travelnotesdetailsvo.getType()){
										travelNotesdetails.setType(2);
									} 
									travelNotesdetails.setWords(travelnotesdetailsvo.getWords()); //文字
									travelNotesdetails.setUrl(travelnotesdetailsvo.getUrl());//图片地址
									travelNotesdetails.setSortIndex(travelnotesdetailsvo.getSortIndex());//排序
									travelNotesdetails.setUpdateUser(memerberid);//修改者
//									travelNotesdetails.setUpdateTime(new Date());//创建时间 
									travelNotesdetails.setTravelNotesId(travelNotes.getId());//获取的游记的ID
									travelnotesdetailsmapper.updateByPrimaryKey(travelNotesdetails);
								}
							}else{
								TravelNotesdetails tnts=new TravelNotesdetails();
								if(null!=travelnotesdetailsvo){
									if(1==travelnotesdetailsvo.getType()){
										tnts.setType(1);
									}else if(2==travelnotesdetailsvo.getType()){
										tnts.setType(2);
									} 
									tnts.setWords(travelnotesdetailsvo.getWords()); //文字
									tnts.setUrl(travelnotesdetailsvo.getUrl());//图片地址
									tnts.setSortIndex(travelnotesdetailsvo.getSortIndex());//排序
									tnts.setCreateUser(memerberid);//创建者
									tnts.setUpdateUser(memerberid);//修改者
//									tnts.setUpdateTime(new Date());//创建时间 
//									tnts.setCreateTime(new Date());//修改时间
									tnts.setTravelNotesId(travelNotes.getId());//获取的游记的ID
									travelnotesdetailsmapper.insertSelective(tnts);
								}
							}
							
						}
							
					}else{
						addSaveTraveleNote(memerberid, travelNotesSaveVo);//保存游记
					}
				}
			}
			
			if(oldTravelNotesdetails.size()>0){
				for (int i = 0; i < oldTravelNotesdetails.size(); i++) {
					TravelNotesdetails tempdetail=travelnotesdetailsmapper.selectByPrimaryKey(oldTravelNotesdetails.get(i));
					travelnotesdetailsmapper.deleteByPrimaryKey(tempdetail.getId());
				}
			}
			
			if(oldTraveNote.size()>0){
				for (int i = 0; i < oldTraveNote.size(); i++) {
					TravelNotes travelNotes=travelNotesMapper.selectByPrimaryKey(oldTraveNote.get(i));
					travelNotesMapper.deleteByPrimaryKey(travelNotes.getId());
				}
			}
			 
		} catch (Exception e) {
			return 0;
		}
		return 1;
	}

	@Transactional
	@Override
	public int deleteMytravel(Integer id,Integer mememberid) {
		TravelNotes travelNotes=travelNotesMapper.selectByPrimaryKey(id);
		if(null==travelNotes){
			return 0;
		}
		if(mememberid==travelNotes.getCreateUser()){
			try {
				List<TravelNotesDetailsVo>	travelNotesDetailsVo=travelnotesdetailsmapper.selectTravelNotesDetailsVo(travelNotes.getId());
				for (TravelNotesDetailsVo vo : travelNotesDetailsVo) {
					travelnotesdetailsmapper.deleteByPrimaryKey(vo.getId());
				}
				travelNotesMapper.deleteByPrimaryKey(id);
				return 1;
			} catch (Exception e) {
				return -1;
			}
		}
		return -1;
	}	
	/**
	 * 
	 * @param memerberid
	 * @param travelNotesVo
	 * 描述:保存游记
	 * @author  lzj
	 * 时间:2017年5月1日14:16:58 
	 */
	public void addSaveTraveleNote(Integer memerberid,TravelNotesSaveVo travelNotesVo){
		
		MemberDetailInfo memberdetailinfo=memberDetailInfoService.selectByFkId(memerberid);
		List<String> urlStr=new ArrayList<String>();
		for(TravelNotesDetailsVo vo : travelNotesVo.getTravelnotesdetailsList()){
			if(StringUtils.isNotBlank(vo.getUrl())){
				urlStr.add(vo.getUrl().trim());
			}
		}
		
		TravelNotes travelNotes=new TravelNotes();
		travelNotes.setTitle(travelNotesVo.getTitle());//标题
		travelNotes.setAuthorName(memberdetailinfo.getNameCh());//作者名称
		travelNotes.setType(memberdetailinfo.getType());//游记
		travelNotes.setCoversImageUrl(memberdetailinfo.getImgUrl());//封面图片
		travelNotes.setValid(1);//是否有效
		travelNotes.setStatus(travelNotesVo.getStatus());//0表示草稿箱   1:未审核 2 已审核 3 未通过
//		travelNotes.setPublishDate(new Date()); //发布时间
//		travelNotes.setCreateTime(new Date());//创建时间
		travelNotes.setCreateUser(memerberid);//谁创建
		travelNotes.setCreateUserType(1L); // 1是会员   2表示 后台人员
		travelNotes.setReadCount(0L); //给新增的游记添加默认的阅读数0
		//如果用户没有上传图片则取第一张,没有的话则为猴爸爸的图片
		if(urlStr.size()==0){
			travelNotes.setCoversImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
		}else{
			travelNotes.setCoversImageUrl(urlStr.get(0));
		}
		travelNotesMapper.insertSelective(travelNotes);
		
		for (TravelNotesDetailsVo travelNotesDetailsVo : travelNotesVo.getTravelnotesdetailsList()) {
			TravelNotesdetails travelNotesdetails=new TravelNotesdetails();
			if(null!=travelNotesDetailsVo){
				if(1==travelNotesDetailsVo.getType()){
					travelNotesdetails.setType(1);
				}else if(2==travelNotesDetailsVo.getType()){
					travelNotesdetails.setType(2);
				} 
				travelNotesdetails.setWords(travelNotesDetailsVo.getWords()); //文字
				travelNotesdetails.setUrl(travelNotesDetailsVo.getUrl());//图片地址
				travelNotesdetails.setSortIndex(travelNotesDetailsVo.getSortIndex());//排序
				travelNotesdetails.setCreateUser(memerberid);//创建者
				travelNotesdetails.setUpdateUser(memerberid);//修改者
//				travelNotesdetails.setUpdateTime(new Date());//创建时间 
//				travelNotesdetails.setCreateTime(new Date());//修改时间
				travelNotesdetails.setTravelNotesId(travelNotes.getId());//获取的游记的ID
				travelnotesdetailsmapper.insertSelective(travelNotesdetails);
			}
		}
	}

	@Override
	public TravelNotes selectByPrimaryKey(Integer id) {
	 
		return travelNotesMapper.selectByPrimaryKey(id);
	}

//	@Override
//	public TravelNotesStrategyVo selectBydetailMytravel(Integer id) {
//		TravelNotesStrategyVo travelNotesStrategyVo=travelNotesMapper.selectBydetailMytravel(id);
//		if(null!=travelNotesStrategyVo){
//			if(travelNotesStrategyVo.getCreateUserType()==null ||2==travelNotesStrategyVo.getCreateUserType()){ //会员状态  为 null 或者1 为系统创建类型
//				travelNotesStrategyVo.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
//				travelNotesStrategyVo.setName(PropertiesUtil.getProperty("scenic_default_user_name"));
//			 }else if(1==travelNotesStrategyVo.getCreateUserType()){ 
//				 MemberBasic memberBasicExample = new MemberBasic();
//	             memberBasicExample.setId(travelNotesStrategyVo.getCreateUser());
//	             MemberBasic memberBasic = memberBasicService.getMemberDetailInfo(memberBasicExample);
//				 ///如果普通用户的头像和姓名为空的话,则取默认的取配置文件的值
//	             travelNotesStrategyVo.setImageUrl(StringUtils.isBlank(memberBasic.getImageUrl()) ? PropertiesUtil.getProperty("scenic_default_user_img") : memberBasic.getImageUrl());
//				 if(StringUtils.isBlank(memberBasic.getMemberDetail().getNameCh())){
//					 travelNotesStrategyVo.setName(memberBasic.getMemberDetail().getPhoneCh().substring(0,3)+"****"+memberBasic.getMemberDetail().getPhoneCh().substring(7, 11));
//	             }else{
//	            	 travelNotesStrategyVo.setName(memberBasic.getMemberDetail().getNameCh()); 
//	             }
//			 }
//			return travelNotesStrategyVo;
//		}
//		return  null;
//	}

	@Override
	public List<TravelNotesDetailStrategyVo> selectByDetailStrategyVo(Integer id) {
		Product product = new Product();
		List<TravelNotesDetailStrategyVo> list=travelNotesMapper.selectByDetailStrategyVo(id);
		for (TravelNotesDetailStrategyVo travelNotesDetailStrategyVo : list) {
		    product.setId(travelNotesDetailStrategyVo.getId());
		    ProductPicRel productPicRel=new ProductPicRel();
			productPicRel.setProductId(travelNotesDetailStrategyVo.getId());
            List<BusiPictureLib> listPic = productPicRelService.getProductPicOrDefault(product);
            if (listPic != null && listPic.size() > 0) {
                travelNotesDetailStrategyVo.setFileUrl(listPic.get(0).getFileUrl());
            } 
		}
	 
		return list;
	}

	@Override
	public TravelNotesVo getTravelNote(Integer id,String sessionId,Integer memberId) {
		try {
    		TravelNotesVo travelNotesVoExample=new TravelNotesVo();
    		travelNotesVoExample.setId(id);
    		travelNotesVoExample.setSessionId(sessionId);
    		if(memberId != null){
    		    travelNotesVoExample.setUserId(memberId);
    		}
    		TravelNotesVo travelNoteVo = travelNotesMapper.getTravelNote(travelNotesVoExample);
    		//计算从游记发布时到当前的时间，2小时内显示“X分钟前”，超出2小时少于2天内显示“X小时前”，超出2天少于3个月内显示“X天前”，超出3个月显示“X月前”。
    		travelNoteVo.setNowTime(DateUtil.currentDateToNowTime(travelNoteVo.getNowTime().trim()));
    		if(travelNoteVo.getCreateUserType()==null ||2==travelNoteVo.getCreateUserType()){ //会员状态  为 null 或者1 为系统创建类型
    			travelNoteVo.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
    			travelNoteVo.setName(PropertiesUtil.getProperty("scenic_default_user_name"));
    		}else if(1==travelNoteVo.getCreateUserType()){ 
    			 MemberBasic memberBasicExample = new MemberBasic();
                 memberBasicExample.setId(travelNoteVo.getUserId());
                 MemberBasic memberBasic = memberBasicService.getMemberDetailInfo(memberBasicExample);
    			 ///如果普通用户的头像和姓名为空的话,则取默认的取配置文件的值
                 travelNoteVo.setImageUrl(StringUtils.isBlank(memberBasic.getImageUrl()) ? PropertiesUtil.getProperty("scenic_default_user_img") : memberBasic.getImageUrl());
    			 if(StringUtils.isBlank(memberBasic.getMemberDetail().getNameCh())){
    				 travelNoteVo.setName(memberBasic.getMemberDetail().getPhoneCh().substring(0,3)+"****"+memberBasic.getMemberDetail().getPhoneCh().substring(7, 11));
                 }else{
                	 travelNoteVo.setName(memberBasic.getMemberDetail().getNameCh()); 
                 }
    		}
    		return travelNoteVo;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<IndexTravelNotesUserCommentslVo> selectByIndexTravelNotesUserCommentslVo(Integer id) {
		// TODO Auto-generated method stub
		List<IndexTravelNotesUserCommentslVo> list=travelNotesMapper.selectByIndexTravelNotesUserCommentslVo(id);
		if(null==list || list.size()==0){
			return list;
		}
		List<IndexTravelNotesUserCommentslVo> listVo=new ArrayList<IndexTravelNotesUserCommentslVo>();
		for (IndexTravelNotesUserCommentslVo indexTravelNotesUserCommentslVo : list) {
			
			indexTravelNotesUserCommentslVo.setNowTime(DateUtil.currentDateToNowTime(indexTravelNotesUserCommentslVo.getNowTime()));
			indexTravelNotesUserCommentslVo.setName(indexTravelNotesUserCommentslVo.getName()==null ? PropertiesUtil.getProperty("scenic_default_user_name") : indexTravelNotesUserCommentslVo.getName());
			indexTravelNotesUserCommentslVo.setImageUrl(indexTravelNotesUserCommentslVo.getImageUrl()==null ? PropertiesUtil.getProperty("scenic_default_user_img") : indexTravelNotesUserCommentslVo.getImageUrl());
			listVo.add(indexTravelNotesUserCommentslVo);
		}
		return listVo;
	}

    @Override
    public TravelNotesdetails getDefaultSubTitle(TravelNotes travelNote) {
        return travelnotesdetailsmapper.getDefaultSubTitle(travelNote);
    }

	@Override
	public List<MaterialtravelsVo> selectPassMytravelsList(MaterialtravelsVo materialtravelsVs,Boolean flag) {
		// TODO Auto-generated method stub
		if(flag){
			PageHelper.startPage(materialtravelsVs.getPageNum(),materialtravelsVs.getPageSize());
		}
		List<MaterialtravelsVo> list=materialMapper.selectPassMytravelsList(materialtravelsVs);
		if(null==list || list.size()==0){
			return list;
		}
 
		for (MaterialtravelsVo materialtravelsVo : list) {
            List<TravelNotesDetailsVo> details = travelnotesdetailsmapper.selectTravelNotesDetailsVo(materialtravelsVo.getId());
            materialtravelsVo.setTravelnotesdetailsList(details);
			//计算从游记发布时到当前的时间，2小时内显示“X分钟前”，超出2小时少于2天内显示“X小时前”，超出2天少于3个月内显示“X天前”，超出3个月显示“X月前”。
			materialtravelsVo.setNowTime(DateUtil.currentDateToNowTime(materialtravelsVo.getNowTime().trim()));
 
			if(materialtravelsVo.getCreateUserType()==null ||2==materialtravelsVo.getCreateUserType()){ //会员状态  为 null 或者1 为系统创建类型
				materialtravelsVo.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
				materialtravelsVo.setAuthorName(PropertiesUtil.getProperty("scenic_default_user_name"));
			 }else if(1==materialtravelsVo.getCreateUserType()){ 
				 MemberBasic memberBasicExample = new MemberBasic();
	             memberBasicExample.setId(materialtravelsVo.getUserId());
	             MemberBasic memberBasic = memberBasicService.getMemberDetailInfo(memberBasicExample);
				 ///如果普通用户的头像和姓名为空的话,则取默认的取配置文件的值
	             materialtravelsVo.setImageUrl(StringUtils.isBlank(memberBasic.getImageUrl()) ? PropertiesUtil.getProperty("scenic_default_user_img") : memberBasic.getImageUrl());
				 if(StringUtils.isBlank(memberBasic.getMemberDetail().getNameCh())){
					 materialtravelsVo.setAuthorName(memberBasic.getMemberDetail().getPhoneCh().substring(0,3)+"****"+memberBasic.getMemberDetail().getPhoneCh().substring(7, 11));
	             }else{
	                 materialtravelsVo.setAuthorName(memberBasic.getMemberDetail().getNameCh()); 
	             }
			 }
		}
		return list;
	}

	   
	 /**
     * 此处为类方法说明:点击“我的”，进入页面加载该会员的一篇游记，
     * 加载规则为：有游记的 优先按已发表-待审-草稿-未通过 取创建时间最近那条，如果
     * 是已发表的要在游记下面显示点赞 、评论、收藏、浏览量 发表时间等
     * 一篇游记都没有的话：显示“亲，您还没有发表的游记，快来编写您的个人游记吧”。
     **
     */
    @Override
    public TravelNotesVo selectMyFirstTravelNote(String sessionId, Integer memberId) {
        try {
            TravelNotesVo travelNote = new TravelNotesVo();
            travelNote.setSessionId(sessionId);
            travelNote.setUserId(memberId);
            //根据游记状态（0 草稿 1 未审核 2 已审核 3 未通过 除去3）倒序查询一篇游记，如果查询结果为空，去查询未通过的游记并且根据创建时间倒叙排列取第一篇
            //1.查询已审核-未审核-草稿中的一篇游记
            TravelNotesVo travelNoteVo = new TravelNotesVo();
            travelNoteVo = travelNotesMapper.selectMyFirstTravelNote(travelNote);
            //2.已审核-未审核-草稿状态的游记不存在，查询未通过的一篇游记
            if(null==travelNoteVo) {
                travelNoteVo = travelNotesMapper.selectMyFirstTravelNoteNotPass(travelNote);
            }
            //计算从游记发布时到当前的时间，2小时内显示“X分钟前”，超出2小时少于2天内显示“X小时前”，超出2天少于3个月内显示“X天前”，超出3个月显示“X月前”。
            if(null!=travelNoteVo) {
                travelNoteVo.setNowTime(DateUtil.currentDateToNowTime(travelNoteVo.getNowTime()));
                   MemberBasic memberBasicExample = new MemberBasic();
                   memberBasicExample.setId(travelNoteVo.getUserId());
                   MemberBasic memberBasic = memberBasicService.getMemberDetailInfo(memberBasicExample);
                   ///如果普通用户的头像和姓名为空的话,则取默认的取配置文件的值
                   if(null!=memberBasic) {
                       travelNoteVo.setImageUrl(StringUtils.isBlank(memberBasic.getImageUrl()) ? PropertiesUtil.getProperty("scenic_default_user_img") : memberBasic.getImageUrl());
                       if(StringUtils.isBlank(memberBasic.getMemberDetail().getNameCh())){
                           travelNoteVo.setName(memberBasic.getMemberDetail().getPhoneCh().substring(0,3)+"****"+memberBasic.getMemberDetail().getPhoneCh().substring(7, 11));
                       }else{
                           travelNoteVo.setName(memberBasic.getMemberDetail().getNameCh()); 
                       }
                   }
            }
            return travelNoteVo;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    
    }
	
	@Override
	public int updateReadCountTravelNote(Integer id) {
		 
		return travelNotesMapper.updateReadCountTravelNote(id);
	}

	@Override
	public TravelNotesCountVo selectTravelNoteCount(Integer id) {
		// TODO Auto-generated method stub
		return travelNotesMapper.selectTravelNoteCount(id);
	}

	
	 
}
