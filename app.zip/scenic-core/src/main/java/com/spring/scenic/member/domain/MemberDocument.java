package com.spring.scenic.member.domain;

import java.util.Date;

public class MemberDocument {
    private Integer id;

    private Integer fkId;

    private Integer type;//1会员2常旅客
    	
    private Integer documentType;

    private String documentNo;

    private Date documentexpiredate;

    private Integer valid;

    private String guid;

    private Date createTime;

    private Integer createUser;

    private Date updateTime;

    private Integer updateUser;
   
    private String  credentialsValidity;
    
    private String primaryId;
    
    /**
     * 证件名
     */
    private String documentName;
    
    public String getPrimaryId() {
		return primaryId;
	}

	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}

	public Integer getFkId() {
		return fkId;
	}

	public void setFkId(Integer fkId) {
		this.fkId = fkId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCredentialsValidity() {
		return credentialsValidity;
	}

	public void setCredentialsValidity(String credentialsValidity) {
		this.credentialsValidity = credentialsValidity;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDocumentType() {
        return documentType;
    }

    public void setDocumentType(Integer documentType) {
        this.documentType = documentType;
    }

    public String getDocumentNo() {
        return documentNo;
    }

    public void setDocumentNo(String documentNo) {
        this.documentNo = documentNo == null ? null : documentNo.trim();
    }

    public Date getDocumentexpiredate() {
        return documentexpiredate;
    }

    public void setDocumentexpiredate(Date documentexpiredate) {
        this.documentexpiredate = documentexpiredate;
    }

    public Integer getValid() {
        return valid;
    }

    public void setValid(Integer valid) {
        this.valid = valid;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid == null ? null : guid.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }
    
    
}