package com.spring.scenic.comment.domain.vo;

import java.util.Date;
import java.util.List;

import com.spring.scenic.comment.domain.ProductCommentFile;
import com.spring.scenic.common.domain.Entity;

/**
 * 
 * @author lzj 描述:点评VO
 * 
 */
public class ProductCommentVo extends Entity<ProductCommentVo> {

	private Integer id;// ID
	private String orderId;// 订单号
	private Integer productId;// 产品ID
	private String src;// 全部来源
	private Integer gread;// 全部评级
	private Integer isRecommend;// 是否推荐
	private String sellerComtent;// 是否回复

	private String content;// 评论信息

	private String productName;// 产品名称

	private Date createTime; // 创建时间

	private String name;// 会员姓名
	
	private List<ProductCommentFile> productcommentfile;
	private String urlImage;//图片
	
	private Integer isPictureComment;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getGread() {
		return gread;
	}

	public void setGread(Integer gread) {
		this.gread = gread;
	}

	public String getSellerComtent() {
		return sellerComtent;
	}

	public void setSellerComtent(String sellerComtent) {
		this.sellerComtent = sellerComtent;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getIsRecommend() {
		return isRecommend;
	}

	public void setIsRecommend(Integer isRecommend) {
		this.isRecommend = isRecommend;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
 

	public String getUrlImage() {
		return urlImage;
	}

	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}

	public List<ProductCommentFile> getProductcommentfile() {
		return productcommentfile;
	}

	public void setProductcommentfile(List<ProductCommentFile> productcommentfile) {
		this.productcommentfile = productcommentfile;
	}

	public Integer getIsPictureComment() {
		return isPictureComment;
	}

	public void setIsPictureComment(Integer isPictureComment) {
		this.isPictureComment = isPictureComment;
	}

}
