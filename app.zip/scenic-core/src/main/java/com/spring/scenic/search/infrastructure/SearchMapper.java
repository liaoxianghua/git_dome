package com.spring.scenic.search.infrastructure;

import java.util.List;

import com.spring.scenic.product.domain.Product;

public interface SearchMapper {

    List<Product> getProductList(Product product);

    List<Product> searchProductList(Product product);

}
