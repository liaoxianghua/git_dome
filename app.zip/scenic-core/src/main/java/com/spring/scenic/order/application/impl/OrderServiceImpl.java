package com.spring.scenic.order.application.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberDocument;
import com.spring.scenic.member.infrastructure.MemberDetailInfoMapper;
import com.spring.scenic.member.infrastructure.MemberDocumentMapper;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderLinkmanDoc;
import com.spring.scenic.order.domain.OrderLinkmanRef;
import com.spring.scenic.order.infrastructure.OrderInvoiceMapper;
import com.spring.scenic.order.infrastructure.OrderLinkmanDocMapper;
import com.spring.scenic.order.infrastructure.OrderLinkmanRefMapper;
import com.spring.scenic.order.infrastructure.OrderMapper;
import com.spring.scenic.order.infrastructure.OrderMoneyChangeRecMapper;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductStockMapper;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderMapper orderMapper;

	@Resource
	private ProductMapper productMapper;

	@Resource
	private ProductStockMapper productStockMapper;

	@Autowired
	private OrderMoneyChangeRecMapper orderMoneyChangeRecMapper;

	@Autowired
	private OrderInvoiceMapper orderInvoiceMapper;

	@Resource
	private OrderLinkmanRefMapper orderLinkmanRefMapper;
	
	@Resource
	private OrderLinkmanDocMapper orderLinkmanDocMapper;
	
	@Resource
	private MemberDocumentMapper memberDocumentMapper;
	@Resource
	private MemberDetailInfoMapper memberDetailInfoMapper;

	@Override
	public Order saveShoppingOrder(Order order, MemberBasic memberBasic, ProductWithBLOBs product) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.HOUR, product.getConfirmHour() == null ? 0 : product.getConfirmHour());
		order.setConfirmTime(c.getTime());
		order.setCreateTime(new Date());
		order.setUpdateTime(new Date());
		order.setUpdateUser(memberBasic.getId());
		order.setCreateUser(memberBasic.getId());
		order.setMemberAccount(memberBasic.getMemberAccount());
		order.setMemberId(memberBasic.getId());
		order.setMakeUser(2);//默认制单人
		if(product.getConfirmHour() == null || product.getConfirmHour() == 0){
			order.setOrderStatus(3);//确认时间为0 订单状态直接为已确认
		}
		// 保存订单
		order.setOrderNo(orderMapper.getOrderNo());
		orderMapper.saveOrder(order);
		// 修改商品销量
		productMapper.updateByPrimaryKey(product);
		// 发票
		if(order.getInvoice() != null){
			order.getInvoice().setOrderNo(order.getOrderNo());
		}
		orderInvoiceMapper.insert(order.getInvoice());
		return order;
	}
	
	@Override
	public Order saveOrder(Order order, MemberBasic memberBasic, ProductWithBLOBs product, ProductStock record,String passengers) {
		Order returnOrder = saveOrder(order, memberBasic, product, record);
		if(StringUtils.isNotBlank(passengers)){
			String[] list = passengers.split(",");
			if (list != null && list.length > 0) {
				OrderLinkmanRef ref = null;
				for (int i = 0; i < list.length; i++) {
					ref = new OrderLinkmanRef();
					String[] LinkmanAndDoc = list[i].split("\\|");
					String linkmanId = LinkmanAndDoc[0];//出行人ID
					String linkmanDocId = LinkmanAndDoc[1];//出行证件ID
					MemberDetailInfo memberDetailInfo = memberDetailInfoMapper.selectByPrimaryKey(Integer.valueOf(linkmanId));
					BeanUtils.copyProperties(memberDetailInfo, ref); 
					ref.setMemberDetailInfoId(Integer.valueOf(linkmanId));
					ref.setOrderId(returnOrder.getId());
					ref.setOrderNo(returnOrder.getOrderNo());
					ref.setCreateTime(new Date());
					ref.setCreateUser(memberBasic.getId());
					ref.setUpdateTime(new Date());
					ref.setUpdateUser(memberBasic.getId());
					ref.setMemberId(memberBasic.getId());
					ref.setBirthday(memberDetailInfo.getBirthday());
					orderLinkmanRefMapper.insert(ref);
					//TODO 批量保存出行人证件信息
					List<MemberDocument> linkmanDocs = getLinkmanDocuments(Integer.valueOf(linkmanId));
					for (int j = 0; j < linkmanDocs.size(); j++) {
						OrderLinkmanDoc old = new OrderLinkmanDoc();
						if(linkmanDocs.get(j).getId().equals(Integer.valueOf(linkmanDocId))){
							old.setIsDefault(1);//下单时选择的证件ID
						}
						old.setDocumentId(Integer.valueOf(linkmanDocId));
						old.setDocumentName(linkmanDocs.get(j).getDocumentName());
						old.setDocumentNo(linkmanDocs.get(j).getDocumentNo());
						old.setRefId(ref.getId());
						orderLinkmanDocMapper.insertSelective(old);
					}
				}
			}
		}
		return order;
	}

	private List<MemberDocument> getLinkmanDocuments(Integer detailInfoId) {
        return memberDocumentMapper.selectCommonTripManDocumentList(detailInfoId);
    }

	@Transactional
    public synchronized  Order saveOrder(Order order, MemberBasic memberBasic, ProductWithBLOBs product, ProductStock record) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.HOUR, product.getConfirmHour() == null ? 0 : product.getConfirmHour());
		order.setConfirmTime(c.getTime());
		order.setCreateTime(new Date());
		order.setUpdateTime(new Date());
		order.setUpdateUser(memberBasic.getId());
		order.setCreateUser(memberBasic.getId());
		order.setMemberAccount(memberBasic.getMemberAccount());
		order.setMemberId(memberBasic.getId());
		order.setMakeUser(2);//默认制单人
		if(product.getConfirmHour() == null || product.getConfirmHour() == 0){
			order.setOrderStatus(3);//确认时间为0 订单状态直接为已确认
		}
		// 保存订单
		order.setOrderNo(orderMapper.getOrderNo());
		orderMapper.saveOrder(order);
		// 修改商品销量
		productMapper.updateByPrimaryKey(product);
		// 修改库存
		productStockMapper.updateByPrimaryKey(record);
		//发票
		if(order.getInvoice() != null){
			order.getInvoice().setOrderNo(order.getOrderNo());
		}
		orderInvoiceMapper.insert(order.getInvoice());
		return order;
	}

	@Override
	public List<Order> selectList(Order order, boolean page) {
		if (page) {
			PageHelper.startPage(order.getPageNum(), order.getPageSize());
		}
		List<Order> list = orderMapper.selectList(order);
		return list;
	}

	public Order selectOrderDetail(Integer orderId){
		return orderMapper.selectOrderDetail(orderId);
	}

    @Override
    public int updateOrderStatus(Order order,MemberBasic memberBasic) {
    	int i = 0;
        try {
            if(order.getId()==null || order.getOrderStatus()==null){
                throw new BussinessException(new BussinessExceptionBean("exception.syserror")); 
            }else{
				Order orderParam = new Order();
				orderParam.setId(order.getId());
				Order temp = orderMapper.getOrder(orderParam);
				//会员申请退单
				boolean needEditStock = false;
				if(order.getOrderStatus()==2){
    				if(temp.getOrderStatus() == 1){//订单是新单-->已取消
                        temp.setOrderStatus(2);
                        i = orderMapper.updateOrderStatus(temp);
                    }
    				needEditStock = true;
				}else if(order.getOrderStatus()==4){
			        if(temp.getOrderStatus() == 3){//订单是已确认-->申请退单
                        order.setOrderStatus(4);
                        i = orderMapper.updateOrderStatus(order);
                    }
				}
				if(i==0){
				    throw new BussinessException(new BussinessExceptionBean("订单状态已更新，请刷新再试！"));
				}
				if(null != temp){
					if(needEditStock){//会员只有取消的新单 才会去退库存
						Product product = productMapper.selectByPrimaryKey(temp.getProductId());
						product.setUpdateTime(new Date());
						product.setUpdateUser(memberBasic.getId());
						if (temp.getOrderType().equals(1)) {//景区
							product.setSaleNum(product.getSaleNum()
									- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
							productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
							ProductStock productStock = new ProductStock();
							productStock.setPlayDay(temp.getTravelTime());
							productStock.setMealsId(temp.getMealsId());
							productStock = productStockMapper.selectByPrimaryParam(productStock);
							productStock.setUpdateTime(new Date());
							productStock.setUpdateUser(memberBasic.getId());
							productStock.setSaleNum(productStock.getSaleNum()
									- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
							productStockMapper.updateByPrimaryKeySelective(productStock);
						} else if (temp.getOrderType().equals(3)) {//线路
							product.setSaleNum(product.getSaleNum()
									- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
									- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
							productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
							ProductStock productStock = new ProductStock();
							productStock.setPlayDay(temp.getTravelTime());
							productStock.setMealsId(temp.getMealsId());
							productStock = productStockMapper.selectByPrimaryParam(productStock);
							productStock.setUpdateTime(new Date());
							productStock.setUpdateUser(memberBasic.getId());
							productStock.setSaleNum(productStock.getSaleNum()
									- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
									- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
							productStockMapper.updateByPrimaryKeySelective(productStock);
						} else if (temp.getOrderType().equals(2)){//购物
							product.setSaleNum(product.getSaleNum()
									- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
							productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
						}
					}
				}
				return i;
			}
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
	
	
}
