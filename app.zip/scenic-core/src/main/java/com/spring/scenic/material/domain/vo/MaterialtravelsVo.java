package com.spring.scenic.material.domain.vo;

import java.util.List;

import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailsVo;

/**
 * @Description  游记Vo
 * 2017年4月23日14:39:39
 * @author lzj
 * 
 */
public class MaterialtravelsVo extends Entity<MaterialtravelsVo>{
 
	/**游记攻略ID*/
    private Integer id;
    /** 用户名字*/
    private String authorName;
    /** 标题*/
    private String title;
    /** 游记图片*/
    private String coversImageUrl;
    /** 点赞数*/
    private Integer praiseCount;
    /** 评论数*/
    private Integer commentCount;
    /** 收藏数*/
    private Integer collectionCount;
    /** 浏览数*/
    private Integer readCount;
    /** 当前会员点赞数量*/
    private Integer praised;
    /** 当前会员收藏数量*/
    private Integer collected;
    /** 距离限制好多钟*/
    private String nowTime;
    /** 用户头像*/
    private String imageUrl;
    /** 用户城市 */
    private String cityName;
    /** 页面显示数量*/
    private Integer status;
    /** 会话ID*/
    private String sessionId;
    /** 用户ID*/
    private Integer userId;
    /** 用户类型    1 为普通会员 2 为 系统会员*/
    private Integer createUserType;
    /** 副标题*/
    private String subTitle;
    /** 1表示游记 2表示攻略*/
    private Integer type;

	/** 还差几个*/
	private Integer missingCount;
	/** 标记*/
	private Integer missingCountType;
	
	/** 游记攻略具体内容 */
    private List<TravelNotesDetailsVo> travelnotesdetailsList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCoversImageUrl() {
        return coversImageUrl;
    }

    public void setCoversImageUrl(String coversImageUrl) {
        this.coversImageUrl = coversImageUrl;
    }

    public Integer getPraiseCount() {
        return praiseCount;
    }

    public void setPraiseCount(Integer praiseCount) {
        this.praiseCount = praiseCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getCollectionCount() {
        return collectionCount;
    }

    public void setCollectionCount(Integer collectionCount) {
        this.collectionCount = collectionCount;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public String getNowTime() {
        return nowTime;
    }

    public void setNowTime(String nowTime) {
        this.nowTime = nowTime;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getPraised() {
        return praised;
    }

    public void setPraised(Integer praised) {
        this.praised = praised;
    }

    public Integer getCollected() {
        return collected;
    }

    public void setCollected(Integer collected) {
        this.collected = collected;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getCreateUserType() {
        return createUserType;
    }

    public void setCreateUserType(Integer createUserType) {
        this.createUserType = createUserType;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getMissingCount() {
        return missingCount;
    }

    public void setMissingCount(Integer missingCount) {
        this.missingCount = missingCount;
    }

    public Integer getMissingCountType() {
        return missingCountType;
    }

    public void setMissingCountType(Integer missingCountType) {
        this.missingCountType = missingCountType;
    }

    public List<TravelNotesDetailsVo> getTravelnotesdetailsList() {
        return travelnotesdetailsList;
    }

    public void setTravelnotesdetailsList(List<TravelNotesDetailsVo> travelnotesdetailsList) {
        this.travelnotesdetailsList = travelnotesdetailsList;
    }
}