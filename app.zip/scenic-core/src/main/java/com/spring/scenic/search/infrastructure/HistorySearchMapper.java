package com.spring.scenic.search.infrastructure;

import java.util.List;

import com.spring.scenic.search.domain.HistorySearch;

public interface HistorySearchMapper {

    List<HistorySearch> getHistorySearchList(HistorySearch historySearch);

    int deleteHistorySearchBySession(HistorySearch historySearchExample);

    int deleteHistorySearch(HistorySearch historySearchExample);

    int saveHistorySearch(HistorySearch historySearch);
    
}