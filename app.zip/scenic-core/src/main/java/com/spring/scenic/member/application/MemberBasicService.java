/**
 * 
 */
package com.spring.scenic.member.application;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberCollection;

/**	@Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:12:58 2017年1月17日
 *  @version:1.0
 *
 */
public interface MemberBasicService { 

	/**
	 * @param member
	 * @param pageTrue
	 * @return
	 */
	

	/**
	 * @param member
	 * @return
	 */
	MemberBasic getMemberDetailInfo(MemberBasic member);

	/**
	 * @param member
	 */
	void saveMemberBasicInfo(MemberBasic member);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月29日     
     * @memo ：   
     **
     */

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月29日     
     * @memo ：   
     **
     */
    List<MemberCollection> getMemberCollections(MemberCollection memberCollection, boolean pageAble);

    MemberBasic getMemberBasicByPhone(String phone);

    MessageData AddCommonRegister(String phone,String verifyCode,String password,String confirmPassword,String token,String verifyCodeType);

    MessageData bookRegiste(String phone);

    MessageData updateMemberPassword(String phone, String verifyCode,String newPassword,String token,String verifyCodeType);

    MessageData resetPassword(String phone, String verifyCode,String newPassword, String repetitionPassword);

    MessageData memberBand(String phone);
    
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年4月21日     
     * @memo ：   
     **
     */
    MessageData login(HttpServletRequest request,String phone, String loginType,String password, String captcha,String verifyCodeType,String token);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年4月21日     
     * @memo ：   
     **
     */
    MessageData getVerifyCode(String phone, String verifyCodeType);
    
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年4月24日   
     * @memo ：   
     **
     */
    MessageData validateVerifyCode(String phone, String verifyCode, String verifyCodeType, String token);

    MemberBasic saveNewMemberBasicInfo(MemberBasic registMemberBasic);

	MessageData updateCommentState(MemberBasic memberBasic);//接受评论通知
    
	MessageData updatePrasieState(MemberBasic memberBasic);//接受点赞通知

    /**   
     * 此处为类方法说明:编辑会员信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月3日     
     * @memo ：   
     **
     */
    MessageData updateMemberInfo(Integer memberId, String imageUrl,String nameCh,String phoneCh, Integer sex, String birthDay,
        Integer countryId, Integer provinceId, Integer cityId, String mail);

    /**
	 * 此处为类方法说明:查询会员信息
	 * 
	 * @param
	 * @return
	 * @creator ：rmp
	 * @date ：2017年5月3日
	 * @memo ：
	 ** 
	 */
	MemberBasic selectMemberInfo(Integer memberId);

    /**   
     * 此处为类方法说明:消息设置页面  type=1 为接受评论通知开关,type=2 为接受点赞通知开关
     *             更新消息接收是否接收的状态
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    MessageData updateMessageReceiveStatus(Integer memberId,Integer receivePraise, Integer receiveComment);

    /**   
     * 此处为类方法说明:添加会员基本信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    void addMemberBasicInfo(MemberBasic memberBasic);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    int updateMemberPassword(MemberBasic memberBasic);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    void updateMemberBasicInfoById(MemberBasic memberBasicExample);
}
