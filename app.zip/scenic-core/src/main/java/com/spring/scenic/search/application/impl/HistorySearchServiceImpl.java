package com.spring.scenic.search.application.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.search.application.HistorySearchService;
import com.spring.scenic.search.domain.HistorySearch;
import com.spring.scenic.search.infrastructure.HistorySearchMapper;

@Service
public class HistorySearchServiceImpl implements HistorySearchService {
    
    @Autowired
    private HistorySearchMapper historySearchMapper;

    @Override
    public List<HistorySearch> getHistorySearchList(HistorySearch historySearch) {
        return historySearchMapper.getHistorySearchList(historySearch);
    }

    @Override
    public int deleteHistorySearchBySession(HistorySearch historySearchExample) {
        return historySearchMapper.deleteHistorySearchBySession(historySearchExample);
    }

    @Override
    public int deleteHistorySearch(HistorySearch historySearchExample) {
        return historySearchMapper.deleteHistorySearch(historySearchExample);
    }

    @Override
    public int saveHistorySearch(HistorySearch historySearch) {
        return historySearchMapper.saveHistorySearch(historySearch);
    }
    
    

}
