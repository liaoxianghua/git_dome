package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.order.domain.OrderLinkmanDoc;

public interface OrderLinkmanDocMapper {
     
    int deleteByPrimaryKey(Integer id);
 
    int insert(OrderLinkmanDoc record);
 
    int insertSelective(OrderLinkmanDoc record);
 
    OrderLinkmanDoc selectByPrimaryKey(Integer id);
 
    int updateByPrimaryKeySelective(OrderLinkmanDoc record);
 
    int updateByPrimaryKey(OrderLinkmanDoc record);
    /**
     * 批量添加出行人证件-订单关系表
     * @param list
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月10日下午3:44:06
     */
    int batchInsert(List<OrderLinkmanDoc> list);
}