package com.spring.scenic.praise.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.ValidateUtil;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.content.infrastructure.TravelNotesCommentMapper;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.infrastructure.MemberMsgMapper;
import com.spring.scenic.praise.application.PushPraiseService;
import com.spring.scenic.praise.domain.MyPushPraise;
import com.spring.scenic.praise.domain.PushPraise;
import com.spring.scenic.praise.infrastructure.PushPraiseMapper;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;

@Service
public class PushPraiseServiceImpl implements PushPraiseService {

	@Autowired
	private PushPraiseMapper pushPraiseMapper;
	@Autowired
    private TravelNotesCommentMapper travelNotesCommentMapper;
	@Autowired
    private MemberMsgMapper memberMsgMapper;
	@Resource
	private TravelNoteService  travelNoteService;
	@Resource
	private MemberBasicService memberBasicService;
	@Autowired
	private TravelNotesCommentService travelNotesCommentService;
	@Autowired
	private MemberMsgService memberMsgService;
	
	/**
	 * 查询会员本人的点赞列表,点赞类别(1、游记攻略；2、产品的评论；3、直播)
	 */
	@Override
    public List<MyPushPraise> selectMemberPraiseList(Integer memberId) {
	    try {
            List<MyPushPraise> memberPraiseList = new ArrayList<MyPushPraise>();
            List<MyPushPraise> list = pushPraiseMapper.selectMemberPraiseList(memberId);
            if(null!=list&&list.size()>0) {
                for (MyPushPraise myPushPraise : list) {
                    //MyPushPraise myPushPraiseDto = myPushPraise;
                    //如果点赞人memberId为空，在消息中用默认小猴子图片和猴爸爸旅行。会员没有维护姓名，取账号作为姓名
                    if(null==myPushPraise.getMemberId()) {
                        myPushPraise.setNameCh(PropertiesUtil.getProperty("scenic_default_user_name"));
                        myPushPraise.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
                    }else {
                        if(StringUtil.isEmpty(myPushPraise.getNameCh())) {
                            myPushPraise.setNameCh(myPushPraise.getMemberAccount().substring(0,3)+"****"+myPushPraise.getMemberAccount().substring(7, 11));
                        }
                    }
                    //调用计算时间的公共方法
                    String nowTime = DateUtil.currentDateToNowTime(myPushPraise.getNowTime());
                    myPushPraise.setNowTime(nowTime);
                    memberPraiseList.add(myPushPraise);
                }
                
            }
            return memberPraiseList;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 我的游记攻略点赞列表
     */
	@Override
	public List<MyPushPraise> selectPushPraiseListOfTravle(Integer memberId) {
        List<MyPushPraise> lists = pushPraiseMapper.selectPushPraiseListOfTravle(memberId);
        if(null==lists || lists.size()==0){
			return lists;
		}
		List<MyPushPraise> list = new ArrayList<MyPushPraise>();
		for(MyPushPraise myPushPraise : lists){
			MyPushPraise myPushPraises = myPushPraise;
			Integer votime=Integer.valueOf(myPushPraise.getNowTime().trim());
			if(votime<=120){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime()))+"分钟前");
			}
			if(votime>120 && votime<=2880){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60)+"小时前");
			}
			if(votime>2880 && votime<=129600){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60/24)+"天前");
			}
			if(votime>129600){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60/24/30)+"月前");
			}
			list.add(myPushPraises);
		}
		return list;
	}
	
	/**
     * 我的产品点赞列表
     */
	@Override
	public List<MyPushPraise> selectPushPraiseListOfProduct(Integer memberId) {
        List<MyPushPraise> lists = pushPraiseMapper.selectPushPraiseListOfProduct(memberId);
        if(null==lists || lists.size()==0){
			return lists;
		}
		List<MyPushPraise> list = new ArrayList<MyPushPraise>();
		for(MyPushPraise myPushPraise : lists){
			MyPushPraise myPushPraises = myPushPraise;
			Integer votime=Integer.valueOf(myPushPraise.getNowTime().trim());
			if(votime<=120){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime()))+"分钟前");
			}
			if(votime>120 && votime<=2880){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60)+"小时前");
			}
			if(votime>2880 && votime<=129600){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60/24)+"天前");
			}
			if(votime>129600){
				myPushPraise.setNowTime(String.valueOf(Integer.valueOf(myPushPraise.getNowTime())/60/24/30)+"月前");
			}
			list.add(myPushPraises);
		}
		return list;
	}

	@Override
	public int directSeedingUpvote(Integer id, Integer type, String sessionId,Integer userId,Integer praiseType) {
		PushPraise pushPraise=new PushPraise();
    	if(null==userId){
    		pushPraise.setSessionId(sessionId);//回话ID
    	}
    	if(1==praiseType){
    		TravelNotes tn=travelNoteService.selectByPrimaryKey(id);
    		pushPraise.setMemberId(tn.getCreateUser());// 游记创建者
    		
    		if(1==tn.getCreateUserType()){
    			MemberBasic	memberBasic=memberBasicService.selectMemberInfo(tn.getCreateUser());
    			if(1==(memberBasic.getReceivePrasie()==null ? 1:memberBasic.getReceivePrasie())){
    				pushPraise.setIsView(1);//用户默认为使用期间可见
    			}else{
    				pushPraise.setIsView(0);
    			}
    		}else{
    			pushPraise.setIsView(1);//后台管理使用可见
    		}
    		
    	}
    	pushPraise.setCreateTime(new Date());//修改时间
    	pushPraise.setUpdateTime(new Date());//创建时间
    	pushPraise.setPraiseContentId(id); //评论内容ID
    	pushPraise.setPraiseType(praiseType);//点赞类别(1、游记攻略；2、产品的评论；3、直播)
    	pushPraise.setCreateUser(userId);
    	int flag=pushPraiseMapper.insert(pushPraise);
		return flag;
	}
	
	@Override
    public int savePushPraise(PushPraise pushPraise) {
        return pushPraiseMapper.insert(pushPraise);
    }

    @Override
	public int deletePushPraise(PushPraise pushPraise) {
		return pushPraiseMapper.deletePushPraise(pushPraise);
	}

	@Override
	public MessageData deleteMyPushPraise(List delList) {
		try {
            MessageData messageData = new MessageData(null, null);
            pushPraiseMapper.deleteMyPushPraise(delList);
            messageData.setStatus(200);
            messageData.setMessage("删除成功");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
	}
	
	/**
	 * 批量删除会员游记被点赞记录、会员被评论记录 1:点赞 2：评论3：系统消息
	 */
    @Override
    public MessageData deleteMemberMessagesByBatch(String ids,Integer type) {
        try {
            MessageData messageData = new MessageData(null, null);
            if(StringUtil.isEmpty(ids)) {
                messageData.setStatus(160);
                messageData.setMessage("参数为空！");
                return messageData;
            }
            if(!ValidateUtil.isIdArray(ids)) {
                messageData.setStatus(161);
                messageData.setMessage("参数格式错误！");
                return messageData;
            }
            List<String> idList = new ArrayList<String>();
            String [] idArray = ids.split(",");
            for(String id : idArray) {
                idList.add(id);
            }
            if(null!=idList&&idList.size()>0) {
                //删除会员游记被点赞记录
                if(type==1) {
                    pushPraiseMapper.deleteMemberPraiseByBatch(idList);
                }
                //批量会员被评论记录
                if(type==2) {
                    travelNotesCommentService.deleteMemberCommentByBatch(idList);
                }
                //批量删除会员系统消息
                if(type==3) {
                    memberMsgService.deleteMemberSysMsgByBatch(idList);
                }
            }
            messageData.setStatus(200);
            messageData.setMessage("删除成功！");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public int getPushPraiseCount(PushPraise pushPraise) {
        return pushPraiseMapper.getPushPraiseCount(pushPraise);
    }

    @Override
    public void deleteMemberPraiseByBatch(List<String> idList) {
        try {
            pushPraiseMapper.deleteMemberPraiseByBatch(idList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }



}
