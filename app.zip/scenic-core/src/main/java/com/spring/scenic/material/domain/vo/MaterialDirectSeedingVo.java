package com.spring.scenic.material.domain.vo;

import java.io.Serializable;

/**
 * @Description 首页直播
 * 2017年4月23日14:39:39
 * @author lzj
 * 
 */
public class MaterialDirectSeedingVo implements Serializable{
 
	/**
     * 此处为属性说明
     */
    private static final long serialVersionUID = -3129979457547897364L;

    /**素材库ID*/
    private Integer id;
    
    /** 标题*/
    private String title;
    
    /** 副标题*/
    private String subTitle;
    
    /** 跳转URL地址*/
    private String skipUrl;
    
    /** 图片的地址*/
    private String pictureUrl;
    
    /** 点赞数*/
    private Integer praiseCount;
    
    /** 是否查询更多*/
    private Integer status;
    
    /** 是否点赞   1表示已点赞  0 表示未点赞*/
    private Integer praised;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSkipUrl() {
		return skipUrl;
	}

	public void setSkipUrl(String skipUrl) {
		this.skipUrl = skipUrl;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public Integer getPraiseCount() {
        return praiseCount;
    }

    public void setPraiseCount(Integer praiseCount) {
        this.praiseCount = praiseCount;
    }

    public Integer getPraised() {
        return praised;
    }

    public void setPraised(Integer praised) {
        this.praised = praised;
    }

    public Integer getStatus() {
		return status;
	}
	
	public void setStatus(Integer status) {
		this.status = status;
	}


	 
}