package com.spring.scenic.search.domain.vo;


/**
 * 搜索结果
 * @author lenovo
 * @date 2016年12月1日
 */
public class SearhResult {
    
    /**
     * 关键字名称
     */
    private String name;
    
    /**
     * 标题
     */
    private String title;
    
    /**
     * 类别：1、产品；2、游记攻略
     */
    private Integer type;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
