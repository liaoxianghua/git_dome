package com.spring.scenic.product.domain.vo;

import java.util.Date;

import com.spring.scenic.product.domain.ProductStock;

public class ProductStockVo extends ProductStock {

	// 开始时间
	private Date createStartTime;

	// 结束时间
	private Date createEndTime;

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}
}
