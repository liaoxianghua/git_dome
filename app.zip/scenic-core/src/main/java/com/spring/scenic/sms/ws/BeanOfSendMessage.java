package com.spring.scenic.sms.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for beanOfSendMessage complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="beanOfSendMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bizFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailParamBean" type="{http://webservice.spring.com/}emailParamBean" minOccurs="0"/>
 *         &lt;element name="messageTypes" type="{http://webservice.spring.com/}sendMessageType" minOccurs="0"/>
 *         &lt;element name="pushParamBean" type="{http://webservice.spring.com/}pushParamBean" minOccurs="0"/>
 *         &lt;element name="smsParamBean" type="{http://webservice.spring.com/}smsParamBean" minOccurs="0"/>
 *         &lt;element name="sysFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="weiboParamBean" type="{http://webservice.spring.com/}weiboParamBean" minOccurs="0"/>
 *         &lt;element name="weixinParamBean" type="{http://webservice.spring.com/}weixinParamBean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "beanOfSendMessage", propOrder = { "bizFlag", "emailParamBean", "messageTypes", "pushParamBean",
        "smsParamBean", "sysFlag", "weiboParamBean", "weixinParamBean" })
public class BeanOfSendMessage {

    protected String bizFlag;

    protected EmailParamBean emailParamBean;

    protected SendMessageType messageTypes;

    protected PushParamBean pushParamBean;

    protected SmsParamBean smsParamBean;

    protected String sysFlag;

    protected WeiboParamBean weiboParamBean;

    protected WeixinParamBean weixinParamBean;

    /**
     * Gets the value of the bizFlag property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getBizFlag() {
        return bizFlag;
    }

    /**
     * Sets the value of the bizFlag property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setBizFlag(String value) {
        this.bizFlag = value;
    }

    /**
     * Gets the value of the emailParamBean property.
     * 
     * @return
     *         possible object is {@link EmailParamBean }
     * 
     */
    public EmailParamBean getEmailParamBean() {
        return emailParamBean;
    }

    /**
     * Sets the value of the emailParamBean property.
     * 
     * @param value
     *            allowed object is {@link EmailParamBean }
     * 
     */
    public void setEmailParamBean(EmailParamBean value) {
        this.emailParamBean = value;
    }

    /**
     * Gets the value of the messageTypes property.
     * 
     * @return
     *         possible object is {@link SendMessageType }
     * 
     */
    public SendMessageType getMessageTypes() {
        return messageTypes;
    }

    /**
     * Sets the value of the messageTypes property.
     * 
     * @param value
     *            allowed object is {@link SendMessageType }
     * 
     */
    public void setMessageTypes(SendMessageType value) {
        this.messageTypes = value;
    }

    /**
     * Gets the value of the pushParamBean property.
     * 
     * @return
     *         possible object is {@link PushParamBean }
     * 
     */
    public PushParamBean getPushParamBean() {
        return pushParamBean;
    }

    /**
     * Sets the value of the pushParamBean property.
     * 
     * @param value
     *            allowed object is {@link PushParamBean }
     * 
     */
    public void setPushParamBean(PushParamBean value) {
        this.pushParamBean = value;
    }

    /**
     * Gets the value of the smsParamBean property.
     * 
     * @return
     *         possible object is {@link SmsParamBean }
     * 
     */
    public SmsParamBean getSmsParamBean() {
        return smsParamBean;
    }

    /**
     * Sets the value of the smsParamBean property.
     * 
     * @param value
     *            allowed object is {@link SmsParamBean }
     * 
     */
    public void setSmsParamBean(SmsParamBean value) {
        this.smsParamBean = value;
    }

    /**
     * Gets the value of the sysFlag property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getSysFlag() {
        return sysFlag;
    }

    /**
     * Sets the value of the sysFlag property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setSysFlag(String value) {
        this.sysFlag = value;
    }

    /**
     * Gets the value of the weiboParamBean property.
     * 
     * @return
     *         possible object is {@link WeiboParamBean }
     * 
     */
    public WeiboParamBean getWeiboParamBean() {
        return weiboParamBean;
    }

    /**
     * Sets the value of the weiboParamBean property.
     * 
     * @param value
     *            allowed object is {@link WeiboParamBean }
     * 
     */
    public void setWeiboParamBean(WeiboParamBean value) {
        this.weiboParamBean = value;
    }

    /**
     * Gets the value of the weixinParamBean property.
     * 
     * @return
     *         possible object is {@link WeixinParamBean }
     * 
     */
    public WeixinParamBean getWeixinParamBean() {
        return weixinParamBean;
    }

    /**
     * Sets the value of the weixinParamBean property.
     * 
     * @param value
     *            allowed object is {@link WeixinParamBean }
     * 
     */
    public void setWeixinParamBean(WeixinParamBean value) {
        this.weixinParamBean = value;
    }

}
