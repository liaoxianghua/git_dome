package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.product.domain.ProductWithBLOBs;

public interface ProductPicRelService {
    
    List<BusiPictureLib> getProductPicOrDefault(Product product);
    
    int updateIsLogo(ProductPicRel productPicRel);

    int delete(Integer id);
    
    boolean productLibSave(Product product,String ids,BusiSellerUser sellerUser);
}
