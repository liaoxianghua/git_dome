package com.spring.scenic.search.domain.vo;

/**
 * 产品二级类别
 * @author lenovo
 * @date 2016年12月5日
 */
public class ProductCategoryVo {
    
    /**
     * 一级类别
     */
    private Integer productType;
    
    /**
     * 一级类别名称
     */
    private String productTypeName;
    
    /**
     * 二级类别
     */
    private Integer productSubType;
    
    /**
     * 二级类别名称
     */
    private String productSubTypeName;
    
    /**
     * 是否激活
     */
    private boolean active;
    
    /**
     * 是否展示
     */
    private boolean show;

    public Integer getProductType() {
        return productType;
    }

    public void setProductType(Integer productType) {
        this.productType = productType;
    }

    public String getProductTypeName() {
        return productTypeName;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public Integer getProductSubType() {
        return productSubType;
    }

    public void setProductSubType(Integer productSubType) {
        this.productSubType = productSubType;
    }

    public String getProductSubTypeName() {
        return productSubTypeName;
    }

    public void setProductSubTypeName(String productSubTypeName) {
        this.productSubTypeName = productSubTypeName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }
    
}
