/**
 * 
 */
package com.spring.scenic.cms.application;

public interface SysConfigService {

}
