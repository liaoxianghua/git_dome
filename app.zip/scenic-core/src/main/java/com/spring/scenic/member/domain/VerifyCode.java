package com.spring.scenic.member.domain;

import java.util.Date;

public class VerifyCode {
   
    /**
     * 验证码
     */
    private String verifyCode;
    /**
     * 开始请求获取验证码的时间点
     */
    private Date startTime;
    
    public String getVerifyCode() {
        return verifyCode;
    }
    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }
    public Date getStartTime() {
        return startTime;
    }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

  
}