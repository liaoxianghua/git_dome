/**
 * 
 */
package com.spring.scenic.member.application;


/**
 * @Description:会员证件
 *@Auth: lichangmao
 *@2017年1月24日
 */
public interface MemberDocumentService {

}
