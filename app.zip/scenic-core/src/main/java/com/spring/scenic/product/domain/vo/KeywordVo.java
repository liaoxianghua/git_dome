package com.spring.scenic.product.domain.vo;

import java.io.Serializable;

public class KeywordVo implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private Integer id;

    private Integer outRelatedId;
    
    private Integer outRelatedType;
    
    private Integer keywordId;
    
    private String name;

}
