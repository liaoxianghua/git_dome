package com.spring.scenic.basic.application.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.basic.application.CountryService;
import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.basic.domain.Province;
import com.spring.scenic.basic.infrastructure.CountryMapper;
import com.spring.scenic.basic.infrastructure.ProvinceMapper;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.domain.City;
import com.spring.scenic.system.infrastructure.CityMapper;

@Service
public class CountryServiceImpl implements CountryService {

	@Autowired
	private CountryMapper countryMapper;
	@Autowired
    private ProvinceMapper provinceMapper;
	@Autowired
    private CityMapper cityMapper;



	/**
	 * 查询所有的国家信息
	 */
	@Override
	public List<Country> selectCuntryList() {
		try {
			return countryMapper.selectCuntryList();
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/*
	 * 组装国家省份城市json数据
	 */
    @Override
    public List<Country> initAddressData() {
        try {
            List<Country> countryList = countryMapper.selectCuntryList();
            List<Province> provinceList = provinceMapper.selectProvinceList();
            List<City> cityList = cityMapper.selectCityList();
            List<Country> list = new ArrayList<Country>();
            for (Country country : countryList) {
                List<Province> provinces = new ArrayList<Province>();
                    for (Province province : provinceList) { 
                        if(province.getCountryId()==country.getId()) {
                            //Province provincDto = new Province();
                            List<City> newCity = new ArrayList<City>();
                            for (City city : cityList) {
                                if(province.getId()==city.getProvinceId()){
                                    newCity.add(city);
                                }
                            }
                            province.setCityList(newCity);
                            provinces.add(province);
                        }
                    }
                    //把没有省份的城市列出来
                    List<City> noneProvinceCitys = new ArrayList<City>(); 
                    for (City city : cityList) {
                        if(null==city.getProvinceId()&&city.getCountryId()==country.getId()) {
                            noneProvinceCitys.add(city);
                        }
                    }
                    country.setCityList(noneProvinceCitys);
                    country.setProvinceList(provinces);
                    list.add(country);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }



}
