package com.spring.scenic.material.domain.vo;

import java.io.Serializable;

/**
 * @Description 最爱目的地Vo
 * 2017年4月23日14:39:39
 * @author lzj
 * 
 */
public class MaterialLoveDestinationVo implements Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**素材库ID*/
    private Integer id;
    
    /** 标题*/
    private String title;
    
    /** 副标题*/
    private String subTitle;
    
    /** 跳转URL地址*/
    private String skipUrl;
    
    /** 图片的地址*/
    private String pictureUrl;
    
    private Integer type;
    /** 是否显示4条记录*/
    private Integer status;
    
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSkipUrl() {
		return skipUrl;
	}

	public void setSkipUrl(String skipUrl) {
		this.skipUrl = skipUrl;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}