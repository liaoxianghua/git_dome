package com.spring.scenic.praise.application;

import java.util.List;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.praise.domain.MyPushPraise;
import com.spring.scenic.praise.domain.PushPraise;

public interface PushPraiseService {
	

	 List<MyPushPraise> selectPushPraiseListOfTravle(Integer memberId);//我的游记攻略点赞列表
	 
	 List<MyPushPraise> selectPushPraiseListOfProduct(Integer memberId);//我的产品点赞列表

	 
	 /**
	  * 
	  * @param id
	  * @param type
	  * @param id2
	  * @return
	  */
	 public int directSeedingUpvote(Integer id, Integer type, String sessionId,Integer userId,Integer praiseType);
	 /**
	  * 
	  * @param id
	  * @param type
	  * @param sessionId
	  * @return
	  */
	 public int deletePushPraise(PushPraise pushPraise);

    /**   
     * 此处为类方法说明:查询会员本人的点赞列表,点赞类别(1、游记攻略；2、产品的评论；3、直播)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    List<MyPushPraise> selectMemberPraiseList(Integer memberId);

	MessageData deleteMyPushPraise(List delList);

    /**   
     * 此处为类方法说明:批量删除会员游记被点赞记录、会员被评论记录、系统消息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月11日     
     * @memo ：   
     **
     */
    MessageData deleteMemberMessagesByBatch(String ids,Integer type);
    /**
     * 
     * 根据当前会话是否对该游记或者直播是否点过赞
     * @param pushPraise
     * @return
     * @creator ：lzj  
     * @date ：2017年5月18日上午9:56:51
     */
	int getPushPraiseCount(PushPraise pushPraise);

    int savePushPraise(PushPraise pushPraise);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    void deleteMemberPraiseByBatch(List<String> idList);

}
