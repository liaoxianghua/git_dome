package com.spring.scenic.content.application;

import java.util.List;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.content.domain.TravelNotesComment;
import com.spring.scenic.content.domain.vo.MyCommentVo;


public interface TravelNotesCommentService {

	int selectTravelNotesCommentCount(Integer createUser);//查询我的评论
	
	public List<TravelNotesComment> selectTravelNotesComment(Integer createUser);//评论详情

	List<MyCommentVo> selectCommentOfTravel(Integer commentUser);

	List<MyCommentVo> selectCommentOfProduct(Integer commentUser);

	int insertIndexTraveNotesDetailComments(Integer id,String comments, Integer userId);

	MessageData deleteMyComment(List delList);

    /**   
     * 此处为类方法说明：查询会员本人的游记被评论列表,点赞类别(1、游记攻略；2、产品的评论；3、直播)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    List<MyCommentVo> selectMemberCommentList(Integer memberId);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月31日     
     * @memo ：   
     **
     */
    void deleteMemberCommentByBatch(List<String> idList);
}
