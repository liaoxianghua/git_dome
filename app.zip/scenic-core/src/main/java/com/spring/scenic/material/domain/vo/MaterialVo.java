package com.spring.scenic.material.domain.vo;

import java.io.Serializable;

/**
 * @Description 素材库Vo
 * 2017年4月20日16:28:59
 * @author lzj
 * 
 */
public class MaterialVo implements Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**素材库ID*/
    private Integer id;
    
    /** 跳转URL地址*/
    private String skipUrl;
    
    /** 图片的地址*/
    private String pictureUrl;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSkipUrl() {
		return skipUrl;
	}

	public void setSkipUrl(String skipUrl) {
		this.skipUrl = skipUrl;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

 

}