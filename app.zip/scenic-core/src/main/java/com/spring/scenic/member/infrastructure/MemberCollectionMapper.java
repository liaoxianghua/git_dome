package com.spring.scenic.member.infrastructure;

import java.util.List;
import java.util.Map;

import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.member.domain.vo.MyConllectionOfProduct;
import com.spring.scenic.member.domain.vo.MyConllectionOfTravel;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;

public interface MemberCollectionMapper {

	
	List<MemberCollection> getMemberCollections(MemberCollection membercollection);
	
    List<MemberCollection> selectCollection(MemberCollection membercollection);
    
    Integer insert(MemberCollection membercollection);
    
    Integer delete(MemberCollection membercollection);
    
    List<MyConllectionOfTravel> selectMyConllectionOfTravel(MaterialtravelsVo materialtravelsVo);
    
    List<MyConllectionOfProduct> selectMyConllectionOfProduct(Integer memberId);

    int getMemberCollecttionCount(MemberCollection mcCollection);

	List<TravelNotesVo> getTravelNoteViewHistory(Map<String,Object> param);
	
	List<MyConllectionOfProduct> selectMyBrowserProduct(List<Integer> integerlist);
	
	 MyConllectionOfProduct selectMyBrowserProductId(Integer id);

    int getMemberCollectCount(MemberCollection membercollection);
    
}