package com.spring.scenic.cms.infrastructure;


public interface SysConfigPicMapper {
   
}