package com.spring.scenic.product.domain.vo;

import java.io.Serializable;
import java.util.List;

public class ProductHolidayHotelVo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** ID */
	private Integer id;
	/** 产品名称 */
	private String productName;
	/** 最低价格 */
	private String minprice;
	/** 城市*/
	private String city;
	private List<KeywordHolidayHotelVo> keywordholidayhotelvo;
	private String fileUrl;
	/** 还差几个*/
	private Integer missingCount;
	/** 类型*/
	private Integer missintCountType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMinprice() {
		return minprice;
	}

	public void setMinprice(String minprice) {
		this.minprice = minprice;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public List<KeywordHolidayHotelVo> getKeywordholidayhotelvo() {
		return keywordholidayhotelvo;
	}

	public void setKeywordholidayhotelvo(List<KeywordHolidayHotelVo> keywordholidayhotelvo) {
		this.keywordholidayhotelvo = keywordholidayhotelvo;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public Integer getMissingCount() {
		return missingCount;
	}

	public void setMissingCount(Integer missingCount) {
		this.missingCount = missingCount;
	}

	public Integer getMissintCountType() {
		return missintCountType;
	}

	public void setMissintCountType(Integer missintCountType) {
		this.missintCountType = missintCountType;
	}
	
}
