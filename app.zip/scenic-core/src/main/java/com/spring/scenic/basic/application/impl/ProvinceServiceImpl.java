package com.spring.scenic.basic.application.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.application.ProvinceService;
import com.spring.scenic.basic.domain.Province;
import com.spring.scenic.basic.infrastructure.ProvinceMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

@Service("provinceService")
public class ProvinceServiceImpl implements ProvinceService {
	
	@Autowired
	private ProvinceMapper provinceMapper;
	/**查询城市信息，用于装填下拉框
	 * @return
	 */
	public List<Province> getCityList() {
		try {
			List<Province> list = provinceMapper.getCityList();
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
