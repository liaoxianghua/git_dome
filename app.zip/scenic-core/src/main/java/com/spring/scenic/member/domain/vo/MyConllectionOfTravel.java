package com.spring.scenic.member.domain.vo;

import java.io.Serializable;


public class MyConllectionOfTravel implements Serializable{
	
    private static final long serialVersionUID = 4259916810507088987L;

    private Integer id;

	private String coversImageUrl;
	
	private String nowTime;
	
	private Integer collectionType;
	
	private String title;
	
	private String words;
	
	private Integer type; 
	
	/** 是否点赞 */
	private Integer praised;
	
	/** 点赞数 */
	private Integer praiseCount;
	
	/** 是否收藏*/
	private Integer collected;
	
	/** 收藏数*/
	private Integer collectionCount;
	
	/** 评论数*/
    private Integer commentCount;

    /** 阅读数*/
    private Integer readCount;
    /** 第一段文字*/
    private String subTitle;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCoversImageUrl() {
        return coversImageUrl;
    }

    public void setCoversImageUrl(String coversImageUrl) {
        this.coversImageUrl = coversImageUrl;
    }

    public String getNowTime() {
        return nowTime;
    }

    public void setNowTime(String nowTime) {
        this.nowTime = nowTime;
    }

    public Integer getCollectionType() {
        return collectionType;
    }

    public void setCollectionType(Integer collectionType) {
        this.collectionType = collectionType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWords() {
        return words;
    }

    public void setWords(String words) {
        this.words = words;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getPraised() {
        return praised;
    }

    public void setPraised(Integer praised) {
        this.praised = praised;
    }

    public Integer getPraiseCount() {
        return praiseCount;
    }

    public void setPraiseCount(Integer praiseCount) {
        this.praiseCount = praiseCount;
    }

    public Integer getCollected() {
        return collected;
    }

    public void setCollected(Integer collected) {
        this.collected = collected;
    }

    public Integer getCollectionCount() {
        return collectionCount;
    }

    public void setCollectionCount(Integer collectionCount) {
        this.collectionCount = collectionCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}
    
}
