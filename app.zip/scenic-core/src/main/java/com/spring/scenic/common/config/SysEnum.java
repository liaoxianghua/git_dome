package com.spring.scenic.common.config;

/**
 * @Description 业务系统字典表枚举类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public enum SysEnum {
	
    SYSTEM_USER_MEMBER("1","注册会员"),
    SYSTEM_USER_MANAGER("2","系统管理人员"),
    
	COMMON_BOOL_NO("0","否"),
	COMMON_BOOL_YES("1","是"),
	
	COMMON_VALID_NO("0","无效"),
	COMMON_VALID_YES("1","有效"),
	
	COMMON_TOP_NO("0","未置顶"),
	COMMON_TOP_YES("1","未置顶"),
	
	COMMON_USEABLE_NO("0","禁用"),
	COMMON_USEABLE_YES("1","启用"),
	
	CONTENT_STATUS_UNAPPROVE("1","未审核"),
	CONTENT_STATUS_PASS("2","已通过"),
	CONTENT_STATUS_UNPASS("3","未通过"),
	
	CONTENT_TYPE_WORD("1","文字"),
	CONTENT_TYPE_PICTURE("2","图片"),
	CONTENT_TYPE_VOICE("3","语音"),
	CONTENT_TYPE_VIDEO("4","视频"),
	CONTENT_TYPE_TITLE("5","标题"),
	
	CONTENT_FROM_WECHAt("1","微信"),
	CONTENT_FROM_M("2","M网"),
	CONTENT_FROM_ANDRIOD("3","安卓"),
	CONTENT_FROM_IOS("4","IOS"),
	CONTENT_FROM_PC("5","PC"),
	CONTENT_FROM_IMPORT("6","系统导入"),
	
	MATERIAL_STATUS_UNAPPROVE("1","未审核"),
	MATERIAL_STATUS_PASS("2","已通过"),
	MATERIAL_STATUS_UNPASS("3","未通过"),
	
	MATERIAL_TYPE_PICTURE("1","图片"),
	MATERIAL_TYPE_VOICE("2","音频"),
	MATERIAL_TYPE_VIDEO("3","视频"),
	
	MATERIAL_USETYPE_PRODUCT("1","产品"),
	MATERIAL_USETYPE_SUBJECT("2","专题"),
	MATERIAL_USETYPE_WECHAt("3","微信"),
	MATERIAL_USETYPE_OTHER("4","其他"),
	
	POSITION_TYPE_LANDMARK("1","地标"),
	POSITION_TYPE_CITY("2","城市"),
	POSITION_TYPE_SCENIC("3","景区商户"),
	
	AREA_TYPE_CANTON("1","行政区"),
	AREA_TYPE_BUSINESS("2","商业区"),
	
	MAIN_TYPE("MAIN_TYPE","景区/商户"),
	MAIN_TYPE_SCENIC("1","景区"),
	MAIN_TYPE_SELLER("2","商户"),
	
    //订单支付状态
    ORDER_STATUS_ALL("0","全部"),
    ORDER_STATUS_NEW("1","新单"),
    ORDER_STATUS_CANCELED("2","已取消"),
    ORDER_STATUS_CONFIRMED("3","已确认"),
    ORDER_STATUS_CHARGEBACK("4","申请退单"),
    ORDER_STATUS_CHARGEBACKED("5","已退单"),
    ORDER_STATUS_COMPLETED("6","已完成"),
	
    //订单支付状态
    ORDER_PAY_STATUS_NO("1","未付款"),
    ORDER_PAY_STATUS_PAID_PART("2","部分付款"),
    ORDER_PAY_STATUS_PAID_ALL("3","付全款"),
    ORDER_PAY_STATUS_PAID_EXCESS("4","超额付款"),
    
    //产品大类
    PRODUCT_TYPE_SCENIC("1","景点"),
    PRODUCT_TYPE_SHOPPING("2","购物"),
    PRODUCT_TYPE_LINE("3","旅游线路"),
    
    //产品二级类别
    PRODUCT_TYPE_SCENIC_TICKET("1","门票"),
    PRODUCT_TYPE_SCENIC_TOWN("2","古镇"),
    PRODUCT_TYPE_SCENIC_SPRING("3","温泉"),
    PRODUCT_TYPE_SCENIC_PARK("4","乐园"),
    PRODUCT_TYPE_SHOPPING_NATIVE("1","土特产"),
    PRODUCT_TYPE_LINE_HOTEL("1","度假酒店"),
    PRODUCT_TYPE_LINE_FREEWALK("2","自由行"),
    PRODUCT_TYPE_LINE_DIRECTTRAIN("3","直通车"),
    
	//菜单数据字典
	RESOURCE_TYPE_MODULE("0","模块"),
	RESOURCE_TYPE_MENU("1","菜单"),
	RESOURCE_TYPE_FUNCTION("2","功能"),
	RESOURCE_SYSTEM_SCENIC("1","景区平台"),
	
    COMMON_TYPE_PRODUCT("1","产品"),
    COMMON_TYPE_TRAVELNOTE("2","游记攻略"),
	
	//用户日志类型数据字典
	USER_LOG_TYPE_ADD("1","新增"),
	USER_LOG_TYPE_UPDATE("2","修改"),
	USER_LOG_TYPE_DEL("3","删除"),
	USER_LOG_TYPE_RESET("4","重置密码"),
	USER_LOG_TYPE_UPDATE_PERMISSIONS("5","修改权限"),
	
	KEYWORD_RELEVANCE_TYPE_TRAVEL("1","游记攻略"),
	KEYWORD_RELEVANCE_TYPE_SYSCONFIG("2","系统配置"),
	
	PASSENGER_DETAIL_TYPE_MEMBER("1","会员"),
	PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN("2","常旅客"),
	
	EFFECTIVE_TYPE_TEMPORARY("1","临时"),
	EFFECTIVE_TYPE_QUALIFIED("2","合格"),
	
	;
	
	SysEnum(String code,String description){
		this.code=code;
		this.description=description;
	}
	
	private String code ;
	
    private String description ;

    public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

	@Override
	public String toString() {
		return this.code;
	}

	public static void main(String[] args) {
		System.out.println(SysEnum.CONTENT_TYPE_PICTURE.getCode().equals("1"));
	}

}
