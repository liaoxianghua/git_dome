package com.spring.scenic.order.application.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.order.application.OrderLinkmanRefService;
import com.spring.scenic.order.domain.OrderLinkmanRef;
import com.spring.scenic.order.infrastructure.OrderLinkmanRefMapper;

@Service
public class OrderLinkmanRefServiceImpl implements OrderLinkmanRefService {

	@Resource
	private OrderLinkmanRefMapper orderLinkmanRefMapper;
	
	@Override
	public int add(OrderLinkmanRef orderLinkmanRef) {
		return orderLinkmanRefMapper.insert(orderLinkmanRef);
	}

}
