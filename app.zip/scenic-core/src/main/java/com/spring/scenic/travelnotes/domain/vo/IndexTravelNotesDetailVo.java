package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * 描述:首页游记详情页面
 * 
 * @author lzj
 * @date 2017年5月4日20:39:34
 */
public class IndexTravelNotesDetailVo implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;

	/** 游记ID */
	private Integer id;

	/** 用户姓名 */
	private String name;

	/** 用户头像 */
	private String imageUrl;

	/** 用户发布时间 */
	private Date departureDate;

	/** 人均费用 */
	private String fee;
	/** 出游人群*/
	private String persons;

	/** 出行天数 */
	private Integer days;

	/** 封面图片 */
	private String coversImageUrl;

	/** 游记点赞数 */
	private Integer pointcount;

	/** 游记评论数 */
	private Integer comments;

	/** 游记收藏数 */
	private Integer collections;
	/** 距离现在多少时间 */
	private String nowTime;
	/** 阅读数*/
	private Integer readCount;
	
	/** 用户ID*/
	private Integer userId;
    /** 用户类型    1为 系统会员 2 为普通会员*/
    private Integer createUserType;
	/** 用户创建者*/
	private List<TravelNotesDetailsVo> travelnotesdetailsList;
	/** 回话ID*/
	private String sessionId;
	
	/** 是否点赞*/
	private Integer isFlag;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	public String getCoversImageUrl() {
		return coversImageUrl;
	}

	public void setCoversImageUrl(String coversImageUrl) {
		this.coversImageUrl = coversImageUrl;
	}

	public Integer getPointcount() {
		return pointcount;
	}

	public void setPointcount(Integer pointcount) {
		this.pointcount = pointcount;
	}

	public Integer getComments() {
		return comments;
	}

	public void setComments(Integer comments) {
		this.comments = comments;
	}

	public Integer getCollections() {
		return collections;
	}

	public void setCollections(Integer collections) {
		this.collections = collections;
	}

	public String getNowTime() {
		return nowTime;
	}

	public void setNowTime(String nowTime) {
		this.nowTime = nowTime;
	}

	public List<TravelNotesDetailsVo> getTravelnotesdetailsList() {
		return travelnotesdetailsList;
	}

	public void setTravelnotesdetailsList(
			List<TravelNotesDetailsVo> travelnotesdetailsList) {
		this.travelnotesdetailsList = travelnotesdetailsList;
	}

	public Integer getReadCount() {
		return readCount;
	}

	public void setReadCount(Integer readCount) {
		this.readCount = readCount;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getCreateUserType() {
		return createUserType;
	}

	public void setCreateUserType(Integer createUserType) {
		this.createUserType = createUserType;
	}

	public String getPersons() {
		return persons;
	}

	public void setPersons(String persons) {
		this.persons = persons;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getIsFlag() {
		return isFlag;
	}

	public void setIsFlag(Integer isFlag) {
		this.isFlag = isFlag;
	}
	

}
