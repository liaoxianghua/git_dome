package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;

/**
 * 
 * 游记详情
 * 
 * @author lzj
 * @date 2017年5月3日21:16:22
 */
public class TravelNotesDetailStrategyVo implements Serializable {

	private static final long serialVersionUID = 1L;
	/** ID */
	private Integer id;
	/** 产品名称 */
	private String productName;
	/** 城市 */
	private String name;
	/** 当前日期 */
	private Integer nowTime;
	/** 销售量 */
	private Integer saleNum;
	/** 文件名称 */
	private String fileUrl;
	/** 最低价格 */
	private Integer minPrice;
	/** 产品类型*/
	private Integer productType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getNowTime() {
		return nowTime;
	}

	public void setNowTime(Integer nowTime) {
		this.nowTime = nowTime;
	}

	public Integer getSaleNum() {
		return saleNum;
	}

	public void setSaleNum(Integer saleNum) {
		this.saleNum = saleNum;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public Integer getMinPrice() {
		return minPrice;
	}

	public void setMinPrice(Integer minPrice) {
		this.minPrice = minPrice;
	}

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	
}
