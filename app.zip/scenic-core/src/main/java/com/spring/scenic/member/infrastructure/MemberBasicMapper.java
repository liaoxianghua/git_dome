package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;

public interface MemberBasicMapper {
    int deleteByPrimaryKey(Integer id);
    
    int insert(int id,String password);
    
    int addMemberBasicInfo(MemberBasic memberBasic);
    
    MemberBasic selectByPrimaryKey(Integer id);
    
    int updateByPrimaryKeySelective(MemberBasic record);
    
    int updateMemberBasicInfoById(MemberBasic record);
    
	List<MemberBasic> getMemberList(MemberBasic member);

	MemberBasic getMemberDetailInfo(MemberBasic member);

	void updateMemberBasicInfo(MemberBasic member);

	void updateMemberDetailInfo(MemberDetailInfo memberDetailInfo);

    MemberBasic selectMemberDetailInfoByAccount(String phone);
    
    int updateMemberPassword(MemberBasic member);
    
    int updatePassword(MemberBasic member);

    MemberBasic saveNewMemberBasicInfo(MemberBasic registMemberBasic);
    
    void updateCommentState(MemberBasic memberBasic);//更新我的接受评论通知
    
    void updatePrasieState(MemberBasic memberBasic);//更新我的接受点赞通知

	MemberBasic selectMemberInfo(Integer memberId);
}