package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;

/**
 * 
 * 此处为类说明
 * @author lzj
 * @date 2017年5月19日
 */
public class TravelNotesCountVo implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;

	/**草稿状态*/
	private Integer cgtype;
	
	/**未审核状态*/
	private Integer dshtype;
	
	/**审核通过状态*/
	private Integer shtgtype;
	
	/**未通过状态 3*/
	private Integer wtgtype;

	public Integer getCgtype() {
		return cgtype;
	}

	public void setCgtype(Integer cgtype) {
		this.cgtype = cgtype;
	}

	public Integer getDshtype() {
		return dshtype;
	}

	public void setDshtype(Integer dshtype) {
		this.dshtype = dshtype;
	}

	public Integer getShtgtype() {
		return shtgtype;
	}

	public void setShtgtype(Integer shtgtype) {
		this.shtgtype = shtgtype;
	}

	public Integer getWtgtype() {
		return wtgtype;
	}

	public void setWtgtype(Integer wtgtype) {
		this.wtgtype = wtgtype;
	}
	 

}
