package com.spring.scenic.material.application;

import java.util.List;

import com.spring.scenic.material.domain.MaterialAuthorized;
import com.spring.scenic.system.domain.AuthUser;

public interface MaterialAuthorizedService {
	
	/**
	 * @Description 获取素材授权列表
	 * @param authorized
	 * @param pageAble 是否分页
	 * @return
	 * @return List<MaterialAuthorized>
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	List<MaterialAuthorized> getMaterialAuthorizedList(MaterialAuthorized authorized,boolean pageAble);

	/**
	 * @Description 获取单个素材授权信息
	 * @param authorized
	 * @return MaterialAuthorized
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	MaterialAuthorized getMaterialAuthorized(MaterialAuthorized authorized);

	
	/**
	 * @Description 新增、编辑素材授权信息
	 * @param user
	 * @param authorized
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	int saveMaterialAuthorized(AuthUser user, MaterialAuthorized authorized);

	int updateMaterialAuthorized(AuthUser user, MaterialAuthorized authorized);

	int auditMaterialAuthorized(AuthUser user, MaterialAuthorized authorized);

	
}
