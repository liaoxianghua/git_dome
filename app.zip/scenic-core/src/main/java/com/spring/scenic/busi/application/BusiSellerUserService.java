package com.spring.scenic.busi.application;

import javax.servlet.http.HttpServletRequest;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.domain.PasswordVo;
import com.spring.scenic.system.domain.AuthUser;

public interface BusiSellerUserService {
    
    BusiSellerUser getSellerByAccount(String username);
    //通过电话tel查询出用户和电话和id
    BusiSellerUser getUserNameByTel(HttpServletRequest request,PasswordVo vo);
    //通过tel对密码进行修改
    BusiSellerUser updatePwdByTel(PasswordVo vo, BusiSellerUser busiSellerUser,HttpServletRequest request);
    //通过ID修改密码
    BusiSellerUser updatePwdById(PasswordVo vo, BusiSellerUser busiSellerUser);
}
