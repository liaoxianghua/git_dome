package com.spring.scenic.sms.application.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.sms.application.SmsService;
import com.spring.scenic.sms.domain.MsgSms;
import com.spring.scenic.sms.infrastructure.MsgSmsMapper;

@Service
public class SmsServiceImpl implements SmsService {
    
    @Autowired
    private MsgSmsMapper msgSmsMapper;

    @Override
    public int saveMsgSmsRecord(String phone, String businessType, String sms) {
    	MsgSms msgSms = new MsgSms();
    	msgSms.setReceiverNo(phone);
    	msgSms.setMsgContent(sms);
    	msgSms.setBusinessType(businessType);
    	msgSms.setSendStatus(1);
    	msgSms.setCreateTime(new Date());
    	return msgSmsMapper.saveMsgSmsRecord(msgSms);
    }

    @Override
    public List<MsgSms> getSmsRecordList(MsgSms msgSms) {
        return msgSmsMapper.selectMsgSms(msgSms);
    }

    @Override
    public int validateCaptcha(MsgSms msgSms) {
        return msgSmsMapper.validateCaptcha(msgSms);
    }

    @Override
    public boolean validateTheCaptcha(MsgSms msgSms) {
        return msgSmsMapper.validateCaptcha(msgSms)>0;
    }



}
