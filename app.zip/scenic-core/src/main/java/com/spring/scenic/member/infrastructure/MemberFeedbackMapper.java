package com.spring.scenic.member.infrastructure;

import com.spring.scenic.member.domain.MemberFeedback;

public interface MemberFeedbackMapper {
  
    int deleteByPrimaryKey(Integer id);

    int addMemberFeedback(MemberFeedback memberFeedback);

    int insertSelective(MemberFeedback record);

    MemberFeedback selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MemberFeedback record);

    int updateByPrimaryKeyWithBLOBs(MemberFeedback record);

    int updateByPrimaryKey(MemberFeedback record);
}