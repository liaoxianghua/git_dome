package com.spring.scenic.product.domain.vo;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * 
 * 产品查询类
 * @author liaoxianghua
 * @date 2017年3月23日
 */
public class ProductQueryParams extends Entity<ProductQueryParams> {

	private Integer id;

	/**
	 * 上架开始时间
	 */
	private Date saleStartTime;

	/**
	 * 上架结束时间
	 */
	private Date saleEndTime;
	/**
	 * 创建开始时间
	 */
	private Date createStartTime;
	// 创建结束时间
	private Date createEndTime;
	// 商家名称
	private Integer sellerId;
	// 是否上架
	private Integer isSale;
	// 产品名称
	private String productName;
	// 产品一级类别
	private Integer productType;
	// 产品二级类别
	private Integer productSubType;
	//城市名称
	private String cityName;
	//搜索关键字
	private String keywordName;

	 
    public String getKeywordName() {
		return keywordName;
	}

	public void setKeywordName(String keywordName) {
		this.keywordName = keywordName;
	}

	public String getCityName() {
		return cityName;
	}

	public Integer getProductSubType() {
		return productSubType;
	}

	public void setProductSubType(Integer productSubType) {
		this.productSubType = productSubType;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public Integer getIsSale() {
		return isSale;
	}

	public void setIsSale(Integer isSale) {
		this.isSale = isSale;
	}

	public Date getSaleStartTime() {
		return saleStartTime;
	}

	public void setSaleStartTime(Date saleStartTime) {
		this.saleStartTime = saleStartTime;
	}

	public Date getSaleEndTime() {
		return saleEndTime;
	}

	public void setSaleEndTime(Date saleEndTime) {
		this.saleEndTime = saleEndTime;
	}

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}
}
