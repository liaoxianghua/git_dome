package com.spring.scenic.system.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class AuthResource extends Entity<AuthResource> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 855576223195228962L;
	
	private Integer id;
	private String name;//资源名称
	private String url;//资源地址
	private Integer parentId;//父级菜单 默认从0开始
	private String parentIdStr;
	private String parentName;//父菜单名称
	private Integer sort;//排序
	private Integer valid;//0 无效 1 有效
	private Integer type;//1： 菜单 2： 链接 3 ：按钮  
	private Integer systemid;//所属系统
	private String remarks;//备注
	private Date createTime;//创建时间
	private Integer createUser;//创建人信息
	private String createUserName;//创建人名称
	private Date updateTime;//修改时间
	private Integer updateUser;//修改人信息
	private String updateUserName;//修改人名称
	private String flag;//0禁用，1启用
	private String guid;
	private String roleName;
	private String code;//功能代码
	private String optType;//操作类型
	
	/**
	 * 业务字段：子级
	 */
	private List<AuthResource> children;
	
	/**
	 * 业务字段：父级
	 */
	private AuthResource parent;
	
	/**
	 * 业务字段：是否被授权（1：是，其他：否）
	 */
	private Integer assigned;
	
	
	public AuthResource getParent() {
		return parent;
	}
	public void setParent(AuthResource parent) {
		this.parent = parent;
	}
	public Integer getAssigned() {
		return assigned;
	}
	public void setAssigned(Integer assigned) {
		this.assigned = assigned;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getParentIdStr() {
		return parentIdStr;
	}
	public void setParentIdStr(String parentIdStr) {
		this.parentIdStr = parentIdStr;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getValid() {
		return valid;
	}
	public void setValid(Integer valid) {
		this.valid = valid;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	
	public Integer getSystemid() {
		return systemid;
	}
	public void setSystemid(Integer systemid) {
		this.systemid = systemid;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public String getCreateUserName() {
		return createUserName;
	}
	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateUserName() {
		return updateUserName;
	}
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}
	
	public List<AuthResource> getChildren() {
		return children;
	}
	public void setChildren(List<AuthResource> children) {
		this.children = children;
	}
	@Override
	public int hashCode() {
		String in = String.valueOf(id);
		return in.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		AuthResource temp=(AuthResource)obj;
		return id.equals(temp.id);
	}
	public String getOptType() {
		return optType;
	}
	public void setOptType(String optType) {
		this.optType = optType;
	}
	
	
}
