package com.spring.scenic.notice.application.impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.notice.application.NoticeService;
import com.spring.scenic.notice.domain.BusiNotice;
import com.spring.scenic.notice.infrastructure.BusiNoticeMapper;

@Service
public class NoticeServiceImpl implements NoticeService {
    
    @Autowired
    private BusiNoticeMapper busiNoticeMapper;

    @Override
    public List<BusiNotice> getNoticeList(BusiNotice notice, boolean page) {
        try {
            if(page){
                PageHelper.startPage(notice.getPageNum(), notice.getPageSize());
            }
            return busiNoticeMapper.getNoticeList(notice);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public BusiNotice getNotice(BusiNotice notice) {
        try {
            return busiNoticeMapper.getNotice(notice);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public BusiNotice getTop1Notice() {
        try {
            return busiNoticeMapper.getTop1Notice();
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public List<BusiNotice> getTop5Notice() {
        try {
            BusiNotice noticeExample = new BusiNotice();
            noticeExample.setIsTop(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
            BusiNotice top = busiNoticeMapper.getNotice(noticeExample);
            if(top==null){//没有置顶的按创建时间倒叙取6个，剔除第一个（置顶）
                List<BusiNotice> top5Notices = busiNoticeMapper.getTop5Notice(6);
                if(top5Notices!=null){
                    Iterator<BusiNotice> iterator = top5Notices.iterator();
                    while (iterator.hasNext()) {
                        iterator.next();
                        iterator.remove();
                        break;
                    }
                }
                return top5Notices;
            }else{//排除置顶后的
                return busiNoticeMapper.getTop5Notice(5); 
            }
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    
}
