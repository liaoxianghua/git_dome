package com.spring.scenic.notice.infrastructure;

import java.util.List;

import com.spring.scenic.notice.domain.BusiNotice;


public interface BusiNoticeMapper {

    List<BusiNotice> getNoticeList(BusiNotice notice);

    BusiNotice getNotice(BusiNotice notice);

    BusiNotice getTop1Notice();

    List<BusiNotice> getTop5Notice(int mxa);
    
} 