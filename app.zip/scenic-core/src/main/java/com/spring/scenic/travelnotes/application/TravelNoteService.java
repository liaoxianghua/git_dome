package com.spring.scenic.travelnotes.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.travelnotes.domain.TravelNotes;
import com.spring.scenic.travelnotes.domain.TravelNotesdetails;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesCountVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;


public interface TravelNoteService {
	List<TravelNotes> getTravelNoteList(TravelNotes travelNote, Boolean pageAble);

	int saveTravelNote(AuthUser user, TravelNotes travelNote, Map<String, List<MultipartFile>> filesMap,String coversImageFile);

	TravelNotes getTravelNoteWithDetail(TravelNotes travelNote);

	int saveAuditTravelNote(AuthUser user, TravelNotes travelNote);

	List<Keyword> getKeywordListById(Integer id);

	int updateTravelNote(AuthUser user, TravelNotes travelNote,Map<String, List<MultipartFile>> filesMap, String coversImageFile);


	public List<TravelNotesVo> selectmytravelsList(TravelNotesVo travelnotesvo, boolean page);

	public int addMytravel(Integer memerberid, String arryStr);

	public List<TravelNotes> searchTravelNoteList(TravelNotes travelNote, boolean b);

	public int updateMytravel(Integer memerberid, String arryStr);

	public int deleteMytravel(Integer id,Integer mememberid);
	public TravelNotes selectByPrimaryKey(Integer id);
	/**
	 * 
	 *  根据ID进行对用户详情进行操作
	 * @param id
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月3日下午9:19:08
	 */
//	public TravelNotesStrategyVo selectBydetailMytravel(Integer id);
	/**
	 * 
	 * 查找与攻略标签中的关键字相同城市对应的180天内出行量最大的4个产品显示，从大到小排列。
	 * @param id
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月17日下午2:03:23
	 */
	public List<TravelNotesDetailStrategyVo> selectByDetailStrategyVo(Integer id);
	/**
	 * 
	 * 描述:根据游记ID查找出首页游记信息
	 * @param id
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月4日下午8:52:50
	 */ 
	public TravelNotesVo getTravelNote(Integer id,String sessionId,Integer memberId);

	public List<IndexTravelNotesUserCommentslVo> selectByIndexTravelNotesUserCommentslVo(Integer id);
	 
	TravelNotesdetails getDefaultSubTitle(TravelNotes travelNote);
	/**
	 * 
	 * 此处为类方法说明
	 * @param travelnotesvo
	 * @param b
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月11日下午6:06:23
	 */
	List<MaterialtravelsVo> selectPassMytravelsList(MaterialtravelsVo materialtravelsVs,Boolean flag);
	/**
	 * 
	 *  增加阅读数
	 * @param id
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月12日下午2:32:42
	 */
	public int updateReadCountTravelNote(Integer id);
	/**
	 * 
	 * 此处为类方法说明 查询游记的个数
	 * @param id
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年5月19日下午4:52:05
	 */
	public TravelNotesCountVo selectTravelNoteCount(Integer id);

    /**   
     * 此处为类方法说明:我的第一篇游记查询
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月25日     
     * @memo ：   
     **
     */
    TravelNotesVo selectMyFirstTravelNote(String sessionId, Integer memberId);


}
