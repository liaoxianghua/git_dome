package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.vo.KeywordHolidayHotelVo;

public interface KeywordMapper {

    List<Keyword> getHotSearchKeyword();

    List<Keyword> getHotCityKeyword();
    
    List<KeywordHolidayHotelVo> selectHolidayHotel(KeywordHolidayHotelVo keywordholidayhotelvo);

    List<Keyword> getMatchKeywords(String keyword);
}
