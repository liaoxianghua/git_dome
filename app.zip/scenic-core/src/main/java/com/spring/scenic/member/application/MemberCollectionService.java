package com.spring.scenic.member.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.member.domain.vo.MyConllectionOfProduct;
import com.spring.scenic.member.domain.vo.MyConllectionOfTravel;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;

public interface MemberCollectionService {

	public List<MemberCollection> selectCollection(MemberCollection membercollection);//我的收藏

	/**
	 * 添加收藏方法
	 * 此处为类方法说明
	 * @param memberId 会员ID
	 * @param collectionType 收藏类型
	 * @param collectionContentId 收藏内容ID
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月1日下午4:08:22
	 */
	Integer add(Integer memberId,Integer collectionType,Integer collectionContentId);
	
	/**
	 * 取消收藏方法
	 * 此处为类方法说明
	 * @param memberId
	 * @param collectionType
	 * @param collectionContentId
	 * @return 成功失败
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月1日下午4:11:42
	 */
	Integer delete(Integer memberId,Integer collectionType,Integer collectionContentId);

	/**
	 * 我的收藏游记列表
	 * 此处为类方法说明
	 * @param memberId
	 * @return
	 * @creator ：xiangbin  
	 * @date ：2017年5月4日下午8:49:46
	 */
	public List<MyConllectionOfTravel> selectMyConllectionOfTravel(MaterialtravelsVo materialtravelsVo);

	public List<MyConllectionOfProduct> selectPushPraiseListOfProduct(Integer memberId);

    public int getMemberCollecttionCount(MemberCollection mcCollection);

	public List<TravelNotesVo> getTravelNoteViewHistory(Map<String,Object> param);

	public List<MyConllectionOfProduct> selectMyBrowserProduct(List<Integer> integerlist);

    public int getMemberCollectCount(MemberCollection membercollection);
	
}
