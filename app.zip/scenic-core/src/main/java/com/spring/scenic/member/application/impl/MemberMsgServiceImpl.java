package com.spring.scenic.member.application.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.content.domain.vo.MyCommentVo;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberMsg;
import com.spring.scenic.member.infrastructure.MemberMsgMapper;
@Service
public class MemberMsgServiceImpl implements MemberMsgService{
	
	@Autowired
	private MemberMsgMapper memberMsgMapper;
	/**
	 * 我的系统通知
	 */
	@Override
	public List<MemberMsg> selectMemberMsg(Integer memberId){
		return memberMsgMapper.selectMemberMsg(memberId);
	}
	/**
	 * 查询会员收到的系统通知列表
	 */
    @Override
    public List<MemberMsg> selectSystemNoticeList(Integer memberId) {
        try {
            List<MemberMsg> memberMsgList = new ArrayList<MemberMsg>();
            List<MemberMsg> list = memberMsgMapper.selectSystemNoticeList(memberId);
            if(null!=list&&list.size()>0) {
                for (MemberMsg memberMsg : list) {
                    Integer nowTime = Integer.valueOf(memberMsg.getNowTime().trim());
                    //计算
                    if(nowTime<0) {
                        memberMsg.setNowTime("1");
                    }
                    if(nowTime<=60*2){
                        memberMsg.setNowTime(String.valueOf(Integer.valueOf(memberMsg.getNowTime()))+"分钟前");
                    }
                    if(nowTime>60*2 && nowTime<=2*60*24){
                        memberMsg.setNowTime(String.valueOf(Integer.valueOf(memberMsg.getNowTime())/60)+"小时前");
                    }
                    if(nowTime>2*60*24 && nowTime<=3*24*30*60){
                        memberMsg.setNowTime(String.valueOf(Integer.valueOf(memberMsg.getNowTime())/60/24)+"天前");
                    }
                    if(nowTime>3*24*30*60){
                        memberMsg.setNowTime(String.valueOf(Integer.valueOf(memberMsg.getNowTime())/60/24/30)+"月前");
                    }
                    memberMsgList.add(memberMsg);
                }
            }
            return memberMsgList;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 查询会员收到的系统通知详情
     */
    @Override
    public MemberMsg selectSystemNoticeDetail(Integer noticeId) {
        try {
            MemberMsg systemNoticeDetail = memberMsgMapper.selectSystemNoticeDetail(noticeId);
            return systemNoticeDetail;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    @Override
    public void addMemberMsg(MemberMsg memberMsg) {
        try {
            memberMsgMapper.addMemberMsg(memberMsg);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    @Override
    public void deleteMemberSysMsgByBatch(List<String> idList) {
        try {
            memberMsgMapper.deleteMemberSysMsgByBatch(idList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

}
