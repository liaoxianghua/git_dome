package com.spring.scenic.comment.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.comment.domain.ProductCommentFile;
import com.spring.scenic.comment.infrastructure.ProductCommentFileMapper;
import com.spring.scenic.comment.infrastructure.ProductCommentMapper;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.product.domain.vo.ProductVo;

@Service
public class ProductCommentServiceImpl implements ProductCommentService {

	@Resource
	private ProductCommentMapper productCommentMapper;
	
	@Resource
	private ProductCommentFileMapper productCommentFileMapper;
	
	@Resource
	private MemberBasicService memberBasicService;
	
	@Override
	public List<ProductComment> getProductCommentList(ProductComment productCommentExample,boolean page) {
		try {
			if(page){
				PageHelper.startPage(productCommentExample.getPageNum(), productCommentExample.getPageSize());
			}
			
			List<ProductComment> productComments = productCommentMapper.getProductCommentList(productCommentExample);
	        if(productComments!=null && !productComments.isEmpty()){
              for (ProductComment productComment : productComments) {
                  MemberBasic memberBasic = memberBasicService.selectMemberInfo(productComment.getCreateUser());
                  if(memberBasic!=null){
                      if(memberBasic.getMemberDetail()!=null){
                          MemberDetailInfo memberDetail = memberBasic.getMemberDetail();
                          if(StringUtils.isBlank(memberDetail.getNameCh())){
                              if(StringUtils.isNotBlank(memberDetail.getPhoneCh())){
                                  memberDetail.setNameCh(memberBasic.getMemberAccount());
                                  memberBasic.setMemberDetail(memberDetail);
                              }
                          }
                      }
                      productComment.setMemberBasic(memberBasic);
                  }
              }
              return productComments;
	        }else{
	            return new ArrayList<ProductComment>();
	        }
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

    @Override
    public ProductComment getFirstProductComment(ProductComment productComment) {
        List<ProductComment> productComments = productCommentMapper.getProductCommentList(productComment);
        if(productComments!=null && !productComments.isEmpty()){
            ProductComment firstProductComment = productComments.get(0);
            MemberBasic memberBasic = memberBasicService.selectMemberInfo(firstProductComment.getCreateUser());
            if(memberBasic!=null){
                if(memberBasic.getMemberDetail()!=null){
                    MemberDetailInfo memberDetail = memberBasic.getMemberDetail();
                    if(StringUtils.isBlank(memberDetail.getNameCh())){
                        if(StringUtils.isNotBlank(memberDetail.getPhoneCh())){
                            memberDetail.setNameCh(memberDetail.getPhoneCh().substring(0,3)+"****"+memberDetail.getPhoneCh().substring(7, 11));
                            memberBasic.setMemberDetail(memberDetail);
                        }
                    }
                }
                firstProductComment.setMemberBasic(memberBasic);
            }
            return firstProductComment;
        }
        return null;
    }

    @Override
    public Map<String, Object> getCommentStatistic(ProductVo productExample) {
        Map<String, Object> commentStatistic = new HashMap<String, Object>();
        commentStatistic.put("A", productCommentMapper.getAComment(productExample));
        commentStatistic.put("B", productCommentMapper.getBComment(productExample));
        commentStatistic.put("C", productCommentMapper.getCComment(productExample));
        commentStatistic.put("D", productCommentMapper.getPicComment(productExample));
        return commentStatistic;
    }
    
    @Override
    public int insertProductComment(Integer orderId,String content,Integer gread,
        Integer sellerId,Integer productId,String productName,
        Integer src,String imgUrls,Integer parentId, Integer memberId) {
    	try{
    	    ProductComment productComment = new ProductComment();
    	    productComment.setOrderId(orderId);
    	    productComment.setContent(content);
    	    productComment.setGread(gread);
    	    
    	    productComment.setSellerId(sellerId);
    	    productComment.setProductId(productId);
    	    productComment.setProductName(productName);
    	    
    	    productComment.setSrc(Integer.valueOf(SysEnum.CONTENT_FROM_M.getCode()));
    	    productComment.setParenteId(parentId);
    	    productComment.setCreateUser(memberId);
    	    productComment.setCreateTime(new Date());
    	    productComment.setUpdateUser(memberId);
    	    productComment.setUpdateTime(new Date());
    	    productComment.setIsRecommend(0);
    	    
    	    int flag = productCommentMapper.insertProductComment(productComment);
    	    if(StringUtil.isNotEmpty(imgUrls)) {
    	        Integer productCommentId = productComment.getId();
    	        if(null!=productCommentId) {
    	            //组装反馈信息图片信息成为一个list 批量插入数据
    	            List <ProductCommentFile> productCommentFileList = new ArrayList<ProductCommentFile>();
        	        String imgUrlArray[] = null;
            	    imgUrlArray = imgUrls.split(",");
            	    for (String imgUrl : imgUrlArray) {
                	    ProductCommentFile productCommentFile = new ProductCommentFile();
                	    productCommentFile.setProductCommentId(productCommentId);
                	    productCommentFile.setFileUrl(imgUrl);
                	    productCommentFile.setCreateUser(memberId);
                	    productCommentFile.setCreateTime(new Date());
                	    productCommentFileList.add(productCommentFile);
            	    }
            	    productCommentFileMapper.insertProductComment(productCommentFileList);
        	    }
    	    }
    	    return flag;
    	} catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public boolean hasCommentedOrderProduct(Integer orderId, Integer memeberId) {
        ProductComment productComment = new ProductComment();
        productComment.setOrderId(orderId);
        productComment.setCreateUser(memeberId);
        int count = productCommentMapper.getProductCommentCount(productComment);
        return count>0;
    }

    /**
     * 通过主键查询该条产品评论信息
     */
    @Override
    public ProductComment selectByPrimaryKey(Integer id) {
        ProductComment productComment = productCommentMapper.selectByPrimaryKey(id);
        return productComment;
    }
    
    

}
