package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberAddress;

public interface MemberAddressMapper {
  
    int deleteByPrimaryKey(Integer id);

    int insert(MemberAddress record);

    int insertSelective(MemberAddress record);

    MemberAddress selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MemberAddress record);

    int updateByPrimaryKey(MemberAddress record);

    void addCommonAddress(MemberAddress memberAddress);

    void updateCommonAddress(MemberAddress memberAddressExample);

    List<MemberAddress> selectCommonAddressList(Integer memberId);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月25日     
     * @memo ：   
     **
     */
    int updateCommonAddressNotDefault(Integer memberId);
}