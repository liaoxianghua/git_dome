package com.spring.scenic.busi.application;

import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;

public interface BusiSellerService {
    
    BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser);

    BusiSeller getBusiSellerById(Integer sellerId);

    BusiSellerUser getBusiSellerUserBySellerId(Integer sellerId);

}
