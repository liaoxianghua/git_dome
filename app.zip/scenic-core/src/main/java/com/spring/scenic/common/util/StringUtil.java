package com.spring.scenic.common.util;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import sun.misc.BASE64Encoder;
/**
 * 
  * @ClassName: StringUtil
  * @Description: 
  * @author Comsys-sss
  * @date 2016-8-18 下午5:40:58
  *
 */
@SuppressWarnings("restriction")
public class StringUtil {
    
    public static String getMD5Str(String original) {
        MessageDigest md5;
        String encodeStr = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
            BASE64Encoder base64en = new BASE64Encoder(); 
            encodeStr = base64en.encode(md5.digest(original.getBytes("utf-8"))); 
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } 
        return encodeStr; 
    }
    
    
    public static String valueOf(Object obj){
    	return obj==null?null:String.valueOf(obj);
    }
   
    public static String toAppend(List<String> list){
        StringBuffer sb = new StringBuffer();
        if(null != list)
        {
            for(String obj : list){
                if(null != obj && !"".equals(obj)){
                    sb.append(obj).append(",");
                }
            }
            return sb.deleteCharAt(sb.length()-1).toString();
        }
        return null;
    }
    
    /**
     * 
      * toAddList(将String串转化成List)
      * @Title: toAddList
      * @Description:将String串转化成List
      * @param @param obj
      * @param @return    设定文件
      * @return List<String>    返回类型
      * @throws
     */
    
    public static List<String> toAddList(String obj) {
        if (null != obj && !"".equals(obj)) {
            List<String> list = new ArrayList<String>();
            String[] ob = obj.split(",");
            for (String o : ob) {
                list.add(o);
            }
            return list;
        }
        return null;
    }
    
    /**
     * 
      * @Title: isEmpty
      * @Description:  判断字符串是否为空
      * @param @param str
      * @param @return    设定文件
      * @return boolean    返回类型
      * @throws
     */
    public static boolean isEmpty(String str){
    	if (str == null || str.toString().trim().equals("")
                || str.toString().equalsIgnoreCase("null")) {
		        return true;
		} else {
		        return false;
		}
    }
    
    public static boolean isNotEmpty(String str){
    	if(str != null && !"".equals(str.trim())){
    		return true;
    	}
    	return false;
    }
    
    public static String toString(Object object, boolean includeSuperClassFields) {
    	StringBuffer buffer = new StringBuffer();
    	if (object instanceof Collection) {
    		Collection<?> collection = (Collection<?>) object;
    		buffer.append("[");
    		int i = 0;
    		for (Object obj : collection) {
    			buffer.append(toString(obj, includeSuperClassFields));
    			if (i < collection.size() - 1) {
    				buffer.append(", ");
    			}
    			i++;
    		}
    		buffer.append("]");
    	} else {
    		if (object == null) {
    			buffer.append(object);
    			return buffer.toString();
    		}
    		if (String.class.equals(object.getClass()) ||
    				Long.class.equals(object.getClass()) ||
    				BigDecimal.class.equals(object.getClass()) ||
    				Integer.class.equals(object.getClass()) ||
    				Double.class.equals(object.getClass()) ||
    				double.class.equals(object.getClass()) ||
    				Date.class.equals(object.getClass())) {
    			buffer.append(String.valueOf(object));
    			return buffer.toString();
    		}
    		if (Date.class.equals(object.getClass())) {
    			buffer.append(DateUtil.dateToString((Date) object));
    			return buffer.toString();
    		}
	    	buffer.append(object.getClass().getSimpleName());
	    	buffer.append("(");
	    	List<Field> fields = new ArrayList<Field>();
	    	if (includeSuperClassFields) {
	    		for (Field field : object.getClass().getSuperclass().getDeclaredFields()) {
	        		fields.add(field);
	        	}
	    	}
	    	for (Field field : object.getClass().getDeclaredFields()) {
	    		fields.add(field);
	    	}
	    	for (int i = 0;i < fields.size();i++) {
	    		try {
	    			Field field = fields.get(i);
	    			field.setAccessible(true);
	    			buffer.append(field.getName() + "=");
	    			Object value = field.get(object);
					buffer.append(toString(value, includeSuperClassFields));
					if (i < fields.size() - 1) {
						buffer.append(", ");
					}
				} catch (IllegalArgumentException e) {
					throw new RuntimeException(e);
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
	    	}
	    	buffer.append(")");
    	}
    	return buffer.toString();
    }
    
}
