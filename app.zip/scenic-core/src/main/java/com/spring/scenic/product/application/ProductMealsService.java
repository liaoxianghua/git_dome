package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.product.domain.ProductMeals;

public interface ProductMealsService {

	List<ProductMeals> selectAllByProductId(ProductMeals productMeals);
	
	public Integer addMeals(ProductMeals productMeals);

	ProductMeals selectByPrimaryKey(Integer id);

	Integer updateMeals(ProductMeals productMeals);
}
