package com.spring.scenic.system.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.system.domain.City;

public interface CityService {

    Map<String,List<City>> getGroupCitys();

}
