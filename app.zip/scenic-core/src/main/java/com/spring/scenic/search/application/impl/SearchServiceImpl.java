package com.spring.scenic.search.application.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.search.application.SearchService;
import com.spring.scenic.search.infrastructure.SearchMapper;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;

@Service
public class SearchServiceImpl implements SearchService {

    @Resource
    private ProductMapper productMapper;
    
    @Autowired
    private SearchMapper searchMapper;
    
    @Autowired
    private DictionaryService dictionaryService;
    
    @Resource
    private ProductPicRelService productPicRelService;
    
    @Override
    public List<Product> getProductList(Product product, boolean pageAble) {
        if (pageAble) {
            PageHelper.startPage(product.getPageNum(), product.getPageSize());
        }
        List<Product> searchList = searchMapper.getProductList(product);
        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
        for (Product pro: searchList) {
            ProductPicRel productPicRel = new ProductPicRel();
            productPicRel.setProductId(pro.getId());
            //主图
            List<BusiPictureLib> listPic = productPicRelService.getProductPicOrDefault(pro);
            if (listPic != null && listPic.size() > 0) {
                BusiPictureLib pic = listPic.get(0);
                pro.setMainPic(pic.getFileUrl());
            }
            //关键字
            KeywordRef keywordRef = new KeywordRef();
            keywordRef.setOutRelatedType(3);// 3产品类型
            keywordRef.setOutRelatedId(pro.getId());
            keywordRef.setType(2);// 标签类
            List<KeywordRef> listKeywordRef = productMapper.getRealtiveKeywordList(keywordRef);
            pro.setListKeyword(listKeywordRef);
            //二级类别名称
            if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
            }else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
                pro.setProductSubTypeName(getDicName(pro.getProductSubType()==null?null:pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
            }
            if(!pro.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
                pro.setPrice(productMapper.getProductMinPrice(pro.getId()));
            }
        }
        return searchList;
    }

    @Override
    public List<Product> searchProduct(Product product, boolean pageAble) {
        if (pageAble) {
            PageHelper.startPage(product.getPageNum(), product.getPageSize());
        }
        List<Product> searchList = searchMapper.searchProductList(product);
        Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
        for (Product pro: searchList) {
            ProductPicRel productPicRel = new ProductPicRel();
            productPicRel.setProductId(pro.getId());
            //主图
            List<BusiPictureLib> listPic = productPicRelService.getProductPicOrDefault(pro);
            if (listPic != null && listPic.size() > 0) {
                BusiPictureLib pic = listPic.get(0);
                pro.setMainPic(pic.getFileUrl());
            }
            //关键字
            KeywordRef keywordRef = new KeywordRef();
            keywordRef.setOutRelatedType(3);// 3产品类型
            keywordRef.setOutRelatedId(pro.getId());
            keywordRef.setType(2);// 标签类
            List<KeywordRef> listKeywordRef = productMapper.getRealtiveKeywordList(keywordRef);
            pro.setListKeyword(listKeywordRef);
            //二级类别名称
            if(pro!= null && pro.getProductType() != null && pro.getProductSubType() != null ){
            	if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
            		pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
            	}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
            		pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
            	}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
            		pro.setProductSubTypeName(getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
            	}
            	if(!pro.getProductType().equals(Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode()))){
            		pro.setPrice(productMapper.getProductMinPrice(pro.getId()));
            	}
            }
        }
        return searchList;
    }
    
    private String getDicName(String value, List<Dictionary> dics){
        if(StringUtils.isBlank(value)){
            return null;
        }
        if(dics != null && !dics.isEmpty()){
        	for (Dictionary dataDictionary : dics) {
        		if(dataDictionary.getValue().equals(value)){
        			return dataDictionary.getName();
        		}
        	}
        }
        return null;
    }
}
