package com.spring.scenic.product.application;


import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.domain.vo.ProductHolidayHotelVo;
import com.spring.scenic.product.domain.vo.ProductMoreImgVo;
import com.spring.scenic.product.domain.vo.ProductQueryParams;
import com.spring.scenic.product.domain.vo.ProductTouristVo;
import com.spring.scenic.product.domain.vo.ProductVo;
import com.spring.scenic.search.domain.vo.ProductCategoryVo;

public interface ProductService {

	/**
	 * 
	 * 此处为类方法说明
	 * @param product
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws Exception
	 * @creator ：lenovo  
	 * @date ：2017年4月21日下午5:17:47
	 */
    List<Product> getProductList(Product product, boolean page) throws Exception;

    ProductWithBLOBs selectByPrimaryKey(Integer id);
  
    int updateByPrimaryKeySelective(ProductWithBLOBs product);
    
    int updateBatch(String ids,Integer isSale,BusiSellerUser sellerUser);
    
    int saveProduct(ProductWithBLOBs productWithBLOBs);

    int update(ProductWithBLOBs product);

	int delete(Integer id);
	
	/**
     * 查询产品关联的关键字
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年4月21日     
     * @memo ：   
     */
    List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef);

    List<ProductWithBLOBs> getRecommendProductList(ProductVo product);
    /**
     * 
     * @param city
     * @return
     * @author ljz
     * 描述:根据城市切换当前度假酒店
     */
	public List<ProductHolidayHotelVo> selectHolidayHote(ProductHolidayHotelVo productholidayhotelvo);
	/**
	 * 
	 * @param productholidayhotelvo
	 * @return
	 * @author ljz
    * 描述:根据城市切换当前自由行
	 */
	public List<ProductTouristVo> selectProductTourist(ProductTouristVo productholidayhotelvo);

    /**
     * 搜索产品
     */
	public List<Product> searchProduct(Product param, boolean pageAble);

    /**
     * 初始化产品二级类别，默认选中为‘全部’，可根据productType、productSubType指定选中的Tab
     */
	public List<ProductCategoryVo> initProductCategorys(Integer productType, Integer productSubType);
	
    public List<ProductMoreImgVo> selectOfficialImgList(Integer productId);
	
	public List<ProductMoreImgVo> selectOnlineImgList(Integer productId);

}
