package com.spring.scenic.product.domain;

import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.picture.domain.BusiPictureLib;

@ApiModel(value = "产品实体")
public class Product extends Entity<Product>{
 
    private Integer id;
 
    private String productName;
 
    private String productCode;
 
    private Integer productType;
 
    private Integer productSubType;
 
    private Integer isSale;
 
    private Date salesTime;
 
    private Integer valid;
 
    private Integer minCount;
 
    private Integer maxCount;
 
    private Integer lastOrderDay;
 
    private Integer lastOrderTime;
 
    private Integer sellerId;
 
    private BigDecimal price;
 
    private Integer totalNum;
 
    private Integer saleNum;
 
    private Integer goodsType;
 
    private Integer cityId;
 
    private String takeAddress;
 
    private Integer confirmHour;
 
    private Date operateTime;
 
    private Integer operateUser;
 
    private Integer createUser;
 
    private Date createTime;
 
    private Integer updateUser;

    //搜索关键字
    private String keyword;
    
	//上架开始时间
	private Date saleStartTime;
	//上架结束时间
	private Date saleEndTime;
	// 创建开始时间
	private Date createStartTime;
	//创建结束时间
	private Date createEndTime; 
	//城市名称
	private String cityName;
	//搜索关键字
	private String keywordName;
	//主图
	private String mainPic;
	//产品关键字
	private List<KeywordRef> listKeyword;
	//二级类别名称
	private String productSubTypeName;
	//阅读数
	private Integer readCount;
	
	//产品图片
	private List<BusiPictureLib> productPics;
	
	//推荐产品
	private List<ProductWithBLOBs> recommendProducts;
	
	//是否收藏
	private boolean collected;
	
	//产品套餐
	private List<ProductMeals> productMeals;
	
	//产品首个评论
	private ProductComment firstComment;
	private List<ProductComment> listProductComment;
	
    public List<ProductComment> getListProductComment() {
		return listProductComment;
	}
	public void setListProductComment(List<ProductComment> listProductComment) {
		this.listProductComment = listProductComment;
	}
	public ProductComment getFirstComment() {
        return firstComment;
    }
    public void setFirstComment(ProductComment firstComment) {
        this.firstComment = firstComment;
    }
    public List<ProductMeals> getProductMeals() {
        return productMeals;
    }
    public void setProductMeals(List<ProductMeals> productMeals) {
        this.productMeals = productMeals;
    }
    public boolean isCollected() {
        return collected;
    }
    public void setCollected(boolean collected) {
        this.collected = collected;
    }
    public List<BusiPictureLib> getProductPics() {
        return productPics;
    }
    public void setProductPics(List<BusiPictureLib> productPics) {
        this.productPics = productPics;
    }
    public List<ProductWithBLOBs> getRecommendProducts() {
        return recommendProducts;
    }
    public void setRecommendProducts(List<ProductWithBLOBs> recommendProducts) {
        this.recommendProducts = recommendProducts;
    }
    public Integer getReadCount() {
		return readCount;
	}
	public void setReadCount(Integer readCount) {
		this.readCount = readCount;
	}
	private Date updateTime;
	
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getProductSubTypeName() {
		return productSubTypeName;
	}
	public void setProductSubTypeName(String productSubTypeName) {
		this.productSubTypeName = productSubTypeName;
	}
	public String getMainPic() {
		return mainPic;
	}
	public void setMainPic(String mainPic) {
		this.mainPic = mainPic;
	}
	public List<KeywordRef> getListKeyword() {
		return listKeyword;
	}
	public void setListKeyword(List<KeywordRef> listKeyword) {
		this.listKeyword = listKeyword;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Integer getProductType() {
		return productType;
	}
	public void setProductType(Integer productType) {
		this.productType = productType;
	}
	public Integer getProductSubType() {
		return productSubType;
	}
	public void setProductSubType(Integer productSubType) {
		this.productSubType = productSubType;
	}
	public Integer getIsSale() {
		return isSale;
	}
	public void setIsSale(Integer isSale) {
		this.isSale = isSale;
	}
	public Date getSalesTime() {
		return salesTime;
	}
	public void setSalesTime(Date salesTime) {
		this.salesTime = salesTime;
	}
	public Integer getValid() {
		return valid;
	}
	public void setValid(Integer valid) {
		this.valid = valid;
	}
	public Integer getMinCount() {
		return minCount;
	}
	public void setMinCount(Integer minCount) {
		this.minCount = minCount;
	}
	public Integer getMaxCount() {
		return maxCount;
	}
	public void setMaxCount(Integer maxCount) {
		this.maxCount = maxCount;
	}
	public Integer getLastOrderDay() {
		return lastOrderDay;
	}
	public void setLastOrderDay(Integer lastOrderDay) {
		this.lastOrderDay = lastOrderDay;
	}
	public Integer getLastOrderTime() {
		return lastOrderTime;
	}
	public void setLastOrderTime(Integer lastOrderTime) {
		this.lastOrderTime = lastOrderTime;
	}
	public Integer getSellerId() {
		return sellerId;
	}
	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public Integer getTotalNum() {
		return totalNum;
	}
	public void setTotalNum(Integer totalNum) {
		this.totalNum = totalNum;
	}
	public Integer getSaleNum() {
		return saleNum;
	}
	public void setSaleNum(Integer saleNum) {
		this.saleNum = saleNum;
	}
	public Integer getGoodsType() {
		return goodsType;
	}
	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}
	public Integer getCityId() {
		return cityId;
	}
	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
	public String getTakeAddress() {
		return takeAddress;
	}
	public void setTakeAddress(String takeAddress) {
		this.takeAddress = takeAddress;
	}
	public Integer getConfirmHour() {
		return confirmHour;
	}
	public void setConfirmHour(Integer confirmHour) {
		this.confirmHour = confirmHour;
	}
	public Date getOperateTime() {
		return operateTime;
	}
	public void setOperateTime(Date operateTime) {
		this.operateTime = operateTime;
	}
	public Integer getOperateUser() {
		return operateUser;
	}
	public void setOperateUser(Integer operateUser) {
		this.operateUser = operateUser;
	}
	public Integer getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public Date getSaleStartTime() {
		return saleStartTime;
	}
	public void setSaleStartTime(Date saleStartTime) {
		this.saleStartTime = saleStartTime;
	}
	public Date getSaleEndTime() {
		return saleEndTime;
	}
	public void setSaleEndTime(Date saleEndTime) {
		this.saleEndTime = saleEndTime;
	}
	public Date getCreateStartTime() {
		return createStartTime;
	}
	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}
	public Date getCreateEndTime() {
		return createEndTime;
	}
	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getKeywordName() {
		return keywordName;
	}
	public void setKeywordName(String keywordName) {
		this.keywordName = keywordName;
	}
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
	
}