package com.spring.scenic.common.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

@ApiModel(value="Entity",description="系统实体对象基类")
public class Entity<T>{
	
    @ApiModelProperty(name="数据库主键对应的序列，保存时将该序列（即主键）返回",dataType="Integer")
	private Integer sequence;
	
    @ApiModelProperty(name="插件参数（固定），前后台交互次数",dataType="Long")
	protected Long draw;
	
    @ApiModelProperty(name="开始页码",dataType="Integer")
	protected Integer pageNum; 
	
    @ApiModelProperty(name="分页大小",dataType="Integer")
	protected Integer pageSize; 
	
    @ApiModelProperty(name="排序字段",dataType="String")
	protected String orderField;
	
    @ApiModelProperty(name="排序方式",dataType="String")
	protected String orderDirection; 
	
    @ApiModelProperty(name="数据行号",dataType="Long")
	protected Long row_id;
	
    @ApiModelProperty(name="开始日期",dataType="Date")
	protected Date startDate; 
	
    @ApiModelProperty(name="结束日期",dataType="Date")
	protected Date endDate; 
	
    @ApiModelProperty(name="数据库中排序条件（数据库字段对应的实体属性需驼峰标示）",dataType="String")
	protected String orderByClause;
	

	

	public Integer getSequence() {
        return sequence;
    }




    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }




    public Long getDraw() {
        return draw;
    }




    public void setDraw(Long draw) {
        this.draw = draw;
    }




    public Integer getPageNum() {
        return pageNum;
    }




    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }




    public Integer getPageSize() {
        return pageSize;
    }




    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }




    public String getOrderField() {
        return orderField;
    }




    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }




    public String getOrderDirection() {
        return orderDirection;
    }




    public void setOrderDirection(String orderDirection) {
        this.orderDirection = orderDirection;
    }




    public Long getRow_id() {
        return row_id;
    }




    public void setRow_id(Long row_id) {
        this.row_id = row_id;
    }




    public Date getStartDate() {
        return startDate;
    }




    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }




    public Date getEndDate() {
        return endDate;
    }




    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }




    public String getOrderByClause() {
        return orderByClause;
    }




    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }


}
