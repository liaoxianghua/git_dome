package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberSharedAccount;

public interface MemberSharedAccountMapper {
    
    List<MemberSharedAccount> getMemberSharedAccountList(MemberSharedAccount memberSharedAccount);
}