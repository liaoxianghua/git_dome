package com.spring.scenic.member.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.ValidateUtil;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberDocument;
import com.spring.scenic.member.infrastructure.MemberDetailInfoMapper;
import com.spring.scenic.member.infrastructure.MemberDocumentMapper;
import com.spring.scenic.system.domain.AuthUser;

/** @Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:13:53 2017年1月17日
 *  @version:1.0
 *
 */
@Service
public class MemberDetailInfoServiceImpl implements MemberDetailInfoService{
	
    @Resource
    private MemberDetailInfoMapper memberDetailInfoMapper;
    @Resource
    private MemberDocumentMapper memberDocumentMapper;
	
	

	@Override
	public void addMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo) {}

	@Override
	public void updateMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo, AuthUser userInfo) {
		try {} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void deleteInfo(MemberDetailInfo memberDetailInfo) {
		//删除常出行人
		try {} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**
	 * 查询常旅客信息列表
	 */
    @Override
    public List<MemberDetailInfo> selectCommonTripManList(MemberBasic member) {

        //查询会员常出行人
        try {
            List<MemberDetailInfo> memberDetailInfos;
            MemberDetailInfo detailInfo = new MemberDetailInfo();
            List<Integer> passengerIdList = new ArrayList<Integer>();
            detailInfo.setFkId(member.getId());
            detailInfo.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
            memberDetailInfos = memberDetailInfoMapper.selectCommonTripManList(detailInfo);
            //拿到常出行人的idlist
            for (MemberDetailInfo memberDetailInfo : memberDetailInfos) {
                passengerIdList.add(memberDetailInfo.getId());
            }
            //查询常出行人证件信息
            List<MemberDocument> documents = new ArrayList<MemberDocument>();
            if (passengerIdList.size()>0) {
                documents = memberDocumentMapper.selectMemberDocumentList(passengerIdList);
            }
            List<MemberDocument> dList = null;
            for (MemberDetailInfo meDetailInfo : memberDetailInfos) {
                dList = new ArrayList<MemberDocument>();
                for (MemberDocument memberDocument : documents) {
                    if (memberDocument.getType() == 2 &&meDetailInfo.getId().equals(memberDocument.getFkId())) {
                        dList.add(memberDocument);
                    }
                }
                meDetailInfo.setDocuments(dList);
            }
            return memberDetailInfos;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    
    }

    @Override
    public MemberDetailInfo updateMemberCommonTripMan(MemberDetailInfo memberDetailInfo) {
        // TODO Auto-generated method stub
        return null;
    }
    
    /**
     * 根据id查询常旅客的信息
     */
    @Override
    public MemberDetailInfo selectcommonTripManInfo(MemberDetailInfo memberDetailInfo) {

        try {
            MemberDetailInfo commonTripMan = null;
            commonTripMan = memberDetailInfoMapper.selectCommonTripMan(memberDetailInfo);
            //根据外键id查询常出行人证件信息集合
            if(null!=commonTripMan) {
                List<MemberDocument> documents = memberDocumentMapper.selectCommonTripManDocumentList(memberDetailInfo.getId());
                //MemberDocument memberDocument = memberDocumentMapper.selectCommonTripManDocument(memberDetailInfo.getId());
                if(null!=documents&&documents.size()>0) {
                    commonTripMan.setDocuments(documents);
                }
            }
            return commonTripMan;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    
    }
    
    /**
     * 新增常旅客信息
     */
    @Override
    public MessageData addCommonTripMan(Integer memberId,String nameCh, String nameEnF, String nameEnS, Integer sex, String phoneCh,
        Integer nationality, Integer documentType, String documentNo, Integer isSelf,String birthdayDate) {
        
        try {
            MessageData messageData = new MessageData(null, null);
            messageData = validateMemberParam(memberId, nameCh, nameEnF, nameEnS, sex, phoneCh, nationality, documentType, documentNo, isSelf, birthdayDate);
            if(200!=messageData.getStatus()) {
                return messageData;
            }
            //如果isSelf==1 即将该旅客标志为会员本人，需要将之前的为会员本人的常旅客isSelf置为0
            //如果isSelf==0 直接作新增操作
            if(1==isSelf) {
                memberDetailInfoMapper.updateIsSelfStatus(memberId);
            }
            //保存常旅客信息，得到当前常旅客的id,然后将id作为外键保存在常旅客的证件信息表中
            MemberDetailInfo memberDetailInfo = new MemberDetailInfo();
            memberDetailInfo.setFkId(memberId);
            memberDetailInfo.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
            memberDetailInfo.setNameCh(nameCh);
            memberDetailInfo.setNameEnF(nameEnF);
            memberDetailInfo.setNameEnS(nameEnS);
            memberDetailInfo.setSex(sex);
            memberDetailInfo.setIsSelf(isSelf);
            memberDetailInfo.setPhoneCh(phoneCh);
            memberDetailInfo.setNationality(nationality);
            memberDetailInfo.setCreateUser(memberId);
            memberDetailInfo.setCreateTime(new Date());
            memberDetailInfo.setUpdateTime(new Date());
            memberDetailInfo.setUpdateUser(memberId);
            memberDetailInfo.setBirthday(DateUtil.stringToDate(birthdayDate));
            memberDetailInfoMapper.addMemberDetailInfo(memberDetailInfo);
            
            //保存常旅客证件信息
            if(null!=memberDetailInfo.getId()) {
                if(null!=documentType&&StringUtils.isNotBlank(documentNo)) {
                    MemberDocument memberDocument = new MemberDocument();
                    memberDocument.setFkId(memberDetailInfo.getId());
                    memberDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
                    memberDocument.setDocumentType(documentType);
                    memberDocument.setDocumentNo(documentNo);
                    memberDocument.setValid(1);
                    memberDocument.setCreateTime(new Date());
                    memberDocument.setCreateUser(memberId);
                    memberDocument.setUpdateTime(new Date());
                    memberDocument.setUpdateUser(memberId);
                    memberDocumentMapper.addMemberDocumenInfo(memberDocument);
                    memberDetailInfo.setMemberDocument(memberDocument);
                    //如果常旅客信息完整，返回出行人对象做前面默认选中常用出行人用
                    messageData.setObj(memberDetailInfo);
                }
            }
            messageData.setStatus(200);
            messageData.setMessage("新增成功！");
            return messageData;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 更新出行人信息
     */
    @Override
    public MessageData updateCommonTripMan(Integer passengerId, Integer documentId, Integer memberId, String nameCh,
        String nameEnF, String nameEnS, Integer sex, String phoneCh, Integer nationality, Integer documentType,
        String documentNo, Integer isSelf, String birthdayDate) {
        
        MessageData messageData = new MessageData(null, null);
        messageData = validateMemberParam(memberId, nameCh, nameEnF, nameEnS, sex, phoneCh, nationality, documentType, documentNo, isSelf, birthdayDate);
        if(200!=messageData.getStatus()) {
            return messageData;
        }
        if(null==passengerId) {
            messageData.setStatus(156);
            messageData.setMessage("常旅客id为空");
        }
        //根据passengerId查询常旅客信息
        MemberDetailInfo memberDetailInfoExample = memberDetailInfoMapper.selectByPrimaryKey(passengerId);
        if(null!=memberDetailInfoExample) {
            if(1==isSelf&&isSelf!=memberDetailInfoExample.getIsSelf()) {
                memberDetailInfoMapper.updateIsSelfStatus(memberId);
            }
            memberDetailInfoExample.setSex(sex);
            memberDetailInfoExample.setIsSelf(isSelf);
            memberDetailInfoExample.setNameCh(nameCh);
            memberDetailInfoExample.setNameEnF(nameEnF);
            memberDetailInfoExample.setNameEnS(nameEnS);
            memberDetailInfoExample.setPhoneCh(phoneCh);
            memberDetailInfoExample.setUpdateUser(memberId);
            memberDetailInfoExample.setUpdateTime(new Date());
            memberDetailInfoExample.setNationality(nationality);
            memberDetailInfoExample.setBirthday(DateUtil.stringToDate(birthdayDate));
            //修改常旅客信息
            memberDetailInfoMapper.updateByPrimaryKey(memberDetailInfoExample);
            //如果证件信息完整，且证件id不为空，修改证件信息
            //if(documentId!=-1) {
            if(null!=documentId) {
                if(null!=documentType&&StringUtils.isNotBlank(documentNo)) {
                    //根据documentId查询证件
                    MemberDocument memberDocumentExample =  memberDocumentMapper.selectByPrimaryKey(documentId);
                    if(null!=memberDocumentExample) {
                        memberDocumentExample.setDocumentType(documentType);
                        memberDocumentExample.setDocumentNo(documentNo);
                        memberDocumentExample.setUpdateTime(new Date());
                        memberDocumentExample.setUpdateUser(memberId);
                        //修改证件信息
                        memberDocumentMapper.updateByPrimaryKey(memberDocumentExample);
                    }
                }
            }else {
                if(null!=documentType&&StringUtils.isNotBlank(documentNo)) {
                    //如果证件信息完整，但证件id为空，新增一个证件信息
                    MemberDocument memberDocument = new MemberDocument();
                    memberDocument.setFkId(passengerId);
                    memberDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
                    memberDocument.setDocumentType(documentType);
                    memberDocument.setDocumentNo(documentNo);
                    memberDocument.setValid(1);
                    memberDocument.setCreateTime(new Date());
                    memberDocument.setCreateUser(memberId);
                    memberDocument.setUpdateTime(new Date());
                    memberDocument.setUpdateUser(memberId);
                    //新增证件信息
                    memberDocumentMapper.addMemberDocumenInfo(memberDocument);
                }
            }
        }
        messageData.setMessage("更新成功");
        return messageData;
    }
    
    /**
     * 
     * 此处为类方法说明:新增出行人时，校验
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    public MessageData validateMemberParam(Integer memberId,String nameCh, String nameEnF, String nameEnS, Integer sex, String phoneCh,
        Integer nationality, Integer documentType, String documentNo, Integer isSelf,String birthdayDate) {
        MessageData messageData = new MessageData(null, null);
        if(StringUtil.isEmpty(nameCh)) {
            messageData.setStatus(156);
            messageData.setMessage("姓名为空！");
            return messageData;
        }
//        if(StringUtil.isEmpty(nameEnF)) {
//            messageData.setStatus(102);
//            messageData.setMessage("英文姓为空！");
//            return messageData;
//        }
//        if(StringUtil.isEmpty(nameEnS)) {
//            messageData.setStatus(101);
//            messageData.setMessage("英文名为空！");
//            return messageData;
//        }
        if(null==sex) {
            messageData.setStatus(156);
            messageData.setMessage("性别为空！");
            return messageData;
        }
        if(StringUtil.isEmpty(phoneCh)) {
            messageData.setStatus(158);
            messageData.setMessage("手机号码为空！");
            return messageData;
        }
        if(StringUtil.isNotEmpty(phoneCh)) {
            if(!ValidateUtil.isCellPhone(phoneCh)) {
                messageData.setStatus(157);
                messageData.setMessage("手机号码格式不正确！");
                return messageData;
            }
        }
//        if(null==memberId) {
//            messageData.setStatus(101);
//            messageData.setMessage("会员id为空！");
//            return messageData;
//        }
//        if(null==nationality) {
//            messageData.setStatus(101);
//            messageData.setMessage("国籍为空！");
//            return messageData;
//        }
        //-1代表证件类型为空
        if((StringUtil.isEmpty(documentNo)&&null!=documentType)||(StringUtil.isNotEmpty(documentNo)&&null==documentType)) {
            messageData.setStatus(158);
            messageData.setMessage("证件信息不完整！");
            return messageData;
        }
        if(null==isSelf) {
            messageData.setStatus(159);
            messageData.setMessage("是否设置为本人为空！");
            return messageData;
        }
        messageData.setStatus(200);
        return messageData;
    }
    
    /**
     * 删除常旅客信息
     */
    @Override
    public MessageData deleteCommonTripMan(Integer passengerId) {
        try {
            MessageData messageData = new MessageData(null, null);
            if(null==passengerId) {
                messageData.setStatus(158);
                messageData.setMessage("常旅客id为空");
                return messageData;
            }
            //删除常旅客相关的证件信息
            MemberDocument memberDocument = new MemberDocument();
            memberDocument.setFkId(passengerId);
            memberDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
            memberDocumentMapper.deleteDocumentByParam(memberDocument);
            //删除常旅客信息
            memberDetailInfoMapper.deleteByPrimaryKey(passengerId);
            messageData.setStatus(200);
            messageData.setMessage("删除成功！");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    @Override
	public MemberDetailInfo selectByFkId(Integer fkId) {
		return memberDetailInfoMapper.selectByFkId(fkId);
	}

    @Override
    public void addMemberDetailInfo(MemberDetailInfo memberDetailInfo) {
        try {
            memberDetailInfoMapper.addMemberDetailInfo(memberDetailInfo);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

	
}
