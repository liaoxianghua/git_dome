package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberFeedbackImg;

public interface MemberFeedbackImgMapper {
   
    int deleteByPrimaryKey(Integer id);

    int insert(MemberFeedbackImg record);

    int insertSelective(MemberFeedbackImg record);

    MemberFeedbackImg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MemberFeedbackImg record);
    
    int updateByPrimaryKey(MemberFeedbackImg record);

    int addMemberFeedbackImgs(List<MemberFeedbackImg> feedbackImgList);
}