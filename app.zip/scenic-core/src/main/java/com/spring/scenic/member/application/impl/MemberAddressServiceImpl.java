package com.spring.scenic.member.application.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.ValidateUtil;
import com.spring.scenic.member.application.MemberAddressService;
import com.spring.scenic.member.domain.MemberAddress;
import com.spring.scenic.member.infrastructure.MemberAddressMapper;
@Service
public class MemberAddressServiceImpl implements MemberAddressService{
	
	@Autowired 
	MemberAddressMapper memberAddressMapper;
	
	/**
	 * 新增常用地址信息
	 */
    @Override
    public MessageData addCommonAddress(Integer memberId, String receiveName, String receivePhone,
        String addressDetail, String postCode, Integer countryId, Integer provinceId, Integer cityId, Integer isDefault) {
        try {
            MessageData messageData = new MessageData(null, null);
            messageData = validateCommonAddressParam(memberId, receiveName, receivePhone,
                     addressDetail, postCode, countryId, provinceId, cityId, isDefault);
            if(200!=messageData.getStatus()) {
                return messageData;
            }
            //如果isDefault==1 将之前的地址为默认地址的改为非默认地址，如果isDefault==0 直接作新增操作
            if(isDefault==1) {
                memberAddressMapper.updateCommonAddressNotDefault(memberId);
            }
            //新增常用地址信息
            MemberAddress memberAddress = new MemberAddress();
            memberAddress.setMemberId(memberId);
            memberAddress.setReceiveName(receiveName);
            memberAddress.setReceivePhone(receivePhone);
            memberAddress.setAddressDetail(addressDetail);
            memberAddress.setPostCode(postCode);
            memberAddress.setCountryId(countryId);
            memberAddress.setProvinceId(provinceId);
            memberAddress.setCityId(cityId);
            memberAddress.setValid(1);
            memberAddress.setIsDefault(isDefault);
            memberAddress.setCreateUser(memberId);
            memberAddress.setCreateTime(new Date());
            memberAddress.setUpdateUser(memberId);
            memberAddress.setUpdateTime(new Date());
            memberAddressMapper.addCommonAddress(memberAddress);
            messageData.setMessage("新增成功");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
   
    @Override
    public MessageData updateCommonAddress(Integer memberId,Integer addressId, String receiveName, String receivePhone,
        String addressDetail, String postCode, Integer countryId, Integer provinceId, Integer cityId, Integer isDefault) {
        try {
            MessageData messageData = new MessageData(null, null);
            messageData = validateCommonAddressParam(addressId, receiveName, receivePhone,
                     addressDetail, postCode, countryId, provinceId, cityId, isDefault);
            if(200!=messageData.getStatus()) {
                return messageData;
            }
            //根据id查询常用地址信息
            MemberAddress memberAddressExample = memberAddressMapper.selectByPrimaryKey(addressId);
            if(isDefault==1&&isDefault!=memberAddressExample.getIsDefault()) {
                memberAddressMapper.updateCommonAddressNotDefault(memberId);
            }
            memberAddressExample.setReceiveName(receiveName);
            memberAddressExample.setReceivePhone(receivePhone);
            memberAddressExample.setAddressDetail(addressDetail);
            memberAddressExample.setPostCode(postCode);
            memberAddressExample.setCountryId(countryId);
            memberAddressExample.setProvinceId(provinceId);
            memberAddressExample.setCityId(cityId);
            memberAddressExample.setIsDefault(isDefault);
            memberAddressExample.setUpdateUser(memberId);
            memberAddressExample.setUpdateTime(new Date());
            memberAddressMapper.updateCommonAddress(memberAddressExample);
            messageData.setMessage("更新成功");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public MemberAddress selectCommonAddressInfo(Integer addressId) {
        try {
            MemberAddress memberAddress = memberAddressMapper.selectByPrimaryKey(addressId);
            return memberAddress;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**   
     * 此处为类方法说明:验证会员常用地址参数
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    private MessageData validateCommonAddressParam(Integer memberId, String receiveName, String receivePhone,
        String addressDetail, String postCode, Integer countryId, Integer provinceId, Integer cityId, Integer isDefault) {
        try {
            MessageData messageData = new MessageData(null, null);
            if(null==memberId) {
                messageData.setStatus(109);
                messageData.setMessage("会员id为空");
                return messageData;
            }
            if(StringUtil.isEmpty(receiveName)) {
                messageData.setStatus(102);
                messageData.setMessage("收件人姓名为空！");
                return messageData;
            }
            if(StringUtil.isEmpty(receivePhone)) {
                messageData.setStatus(103);
                messageData.setMessage("联系手机为空！");
                return messageData;
            }
            if(!ValidateUtil.isCellPhone(receivePhone)) {
                messageData.setStatus(110);
                messageData.setMessage("手机号码格式不正确！");
                return messageData;
            }
            if(StringUtil.isEmpty(addressDetail)) {
                messageData.setStatus(111);
                messageData.setMessage("详细地址为空！");
                return messageData;
            }
            if(StringUtil.isEmpty(postCode)) {
                messageData.setStatus(106);
                messageData.setMessage("邮政编码为空！");
                return messageData;
            }
//            if(null==provinceId) {
//                messageData.setStatus(107);
//                messageData.setMessage("省份为空");
//                return messageData;
//            }
            if(null==cityId) {
                messageData.setStatus(108);
                messageData.setMessage("城市为空！");
                return messageData;
            }
            if(null==isDefault) {
                messageData.setStatus(112);
                messageData.setMessage("是否默认地址参数为空！");
                return messageData;
            }
            messageData.setStatus(200);
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    @Override
    public List<MemberAddress> selectCommonAddressList(Integer memberId) {
        try {
            List<MemberAddress> memberAddressList = memberAddressMapper.selectCommonAddressList(memberId);
            return memberAddressList;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public MessageData deleteCommonAddress(Integer addressId) {
        try {
            MessageData messageData = new MessageData(null, null);
            memberAddressMapper.deleteByPrimaryKey(addressId);
            messageData.setStatus(200);
            messageData.setMessage("删除成功");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
   

}
