package com.spring.scenic.sms.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for sendMessageResponse complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="sendMessageResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sendMessageResponseData" type="{http://webservice.spring.com/}retBeanOfSendMessage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sendMessageResponse", propOrder = { "sendMessageResponseData" })
public class SendMessageResponse {

    protected RetBeanOfSendMessage sendMessageResponseData;

    /**
     * Gets the value of the sendMessageResponseData property.
     * 
     * @return
     *         possible object is {@link RetBeanOfSendMessage }
     * 
     */
    public RetBeanOfSendMessage getSendMessageResponseData() {
        return sendMessageResponseData;
    }

    /**
     * Sets the value of the sendMessageResponseData property.
     * 
     * @param value
     *            allowed object is {@link RetBeanOfSendMessage }
     * 
     */
    public void setSendMessageResponseData(RetBeanOfSendMessage value) {
        this.sendMessageResponseData = value;
    }

}
