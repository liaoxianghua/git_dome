package com.spring.scenic.travelnotes.domain.vo;

import java.io.Serializable;

/** 
 *   
 * @author lzj
 *
 */ 
public class TravelNotesDetailsVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 主键
	 */
	private Integer id;

	/**
	 * 图片、视频、音频等链接地址
	 */
	private String url;

	/**
	 * 文件名称
	 */
	private String fileName;

	/**
	 * 1:文字 ;2:(2:图片 3:语音 4:视频 );5:段落标题
	 */
	private Integer type;

	/**
	 * 段落标题
	 */
	private String title;

	/**
	 * 游记、攻略外键
	 */
	private Integer travelNotesId;

	 

	/**
	 * 文字 图片 语音 视频 段落标题 的排序字段
	 */
	private Integer sortIndex;
	 /**
     * 文字
     */
    private String words;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getTravelNotesId() {
		return travelNotesId;
	}

	public void setTravelNotesId(Integer travelNotesId) {
		this.travelNotesId = travelNotesId;
	}


	public Integer getSortIndex() {
		return sortIndex;
	}

	public void setSortIndex(Integer sortIndex) {
		this.sortIndex = sortIndex;
	}

	public String getWords() {
		return words;
	}

	public void setWords(String words) {
		this.words = words;
	}

}