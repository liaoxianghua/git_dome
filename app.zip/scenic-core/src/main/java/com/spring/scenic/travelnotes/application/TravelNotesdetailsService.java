package com.spring.scenic.travelnotes.application;



public interface TravelNotesdetailsService {
	 

}
