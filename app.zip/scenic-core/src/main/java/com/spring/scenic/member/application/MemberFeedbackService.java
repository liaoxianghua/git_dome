package com.spring.scenic.member.application;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberFeedback;


public interface MemberFeedbackService {

	public void addMemberFeedback(MemberFeedback memberFeedback);//新增意见反馈

    /**   
     * 此处为类方法说明：用户意见反馈:文件名、文件url以字符串接收，用","隔开
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    public MessageData addMemberFeedback(Integer memberId,String feedbackContent, String linkPhone,String imgUrls);
}
