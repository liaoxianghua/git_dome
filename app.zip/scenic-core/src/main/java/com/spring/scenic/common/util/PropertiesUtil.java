package com.spring.scenic.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertiesUtil {
	
    private static Properties properties;
    private static Logger logger = LoggerFactory.getLogger(PropertiesUtil.class);
    private static final String DEFAULT_PROPERTIES = "properties/runtime.properties";
    	
	static{
		if(properties==null){
			properties = new Properties();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream inputStream = classLoader.getResourceAsStream(DEFAULT_PROPERTIES);
			try {
				properties.load(inputStream);
			} catch (IOException e) {
				logger.warn("PropertiesUtil init DEFAULT_PROPERTIES:"+DEFAULT_PROPERTIES+" failure....");
				e.printStackTrace();
			}
		}
	}

	
    protected Properties initProperties(String propertiesName) throws IOException {
    	try {
			Properties properties = new Properties();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			if (classLoader == null) {
			    classLoader = this.getClass().getClassLoader();
			}
			InputStream inputStream = classLoader.getResourceAsStream(propertiesName);
			properties.load(inputStream);
			inputStream.close();
		    return properties;
		} catch (IOException e) {
			throw e;
		}
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    public static void main(String agrs[]){
    	System.out.println(1);
    }

}
