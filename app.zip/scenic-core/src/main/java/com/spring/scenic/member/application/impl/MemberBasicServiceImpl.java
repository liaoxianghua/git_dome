/**
 * 
 */
package com.spring.scenic.member.application.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.ValidateUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberMsg;
import com.spring.scenic.member.infrastructure.MemberBasicMapper;
import com.spring.scenic.member.infrastructure.MemberCollectionMapper;
import com.spring.scenic.member.infrastructure.MemberDetailInfoMapper;
import com.spring.scenic.member.infrastructure.MemberMsgMapper;
import com.spring.scenic.sms.domain.MsgSms;
import com.spring.scenic.sms.infrastructure.MsgSmsMapper;

/** @Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:13:53 2017年1月17日
 *  @version:1.0
 *
 */
@Service
public class MemberBasicServiceImpl implements MemberBasicService{
    
    private Logger logger = LoggerFactory.getLogger(MemberBasicServiceImpl.class);
	
    @Autowired
	private MemberBasicMapper memberBasicMapper;
	@Autowired
	private MemberDetailInfoMapper memberDetailInfoMapper;
	@Autowired
    private MemberCollectionMapper memberCollectionMapper;
	@Autowired
	private MsgSmsMapper msgSmsMapper;
	@Autowired
    private MemberMsgMapper memberMsgMapper;
    @Autowired
    private MemberDetailInfoService memberDetailInfoService;
    @Autowired
    private MemberMsgService memberMsgService;
	
	
	@Override
	public MemberBasic getMemberDetailInfo(MemberBasic member) {
		try {
			//member.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
			MemberBasic memberDetail = memberBasicMapper.selectByPrimaryKey(member.getId());
			MemberDetailInfo tempVoDetailInfo = new MemberDetailInfo();
			tempVoDetailInfo.setFkId(member.getId());
			tempVoDetailInfo.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
			MemberDetailInfo memberDetailInfo = memberDetailInfoMapper.queryCommonTripMan(tempVoDetailInfo);
			memberDetail.setMemberDetail(memberDetailInfo);
			return memberDetail;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void saveMemberBasicInfo(MemberBasic member) {
		MemberBasic memberBasic = validata(member);
		try {
			//更新会员基本信息
			memberBasicMapper.updateMemberBasicInfo(memberBasic);
			//更新会员详情信息
			if(null!=memberBasic) {
				MemberDetailInfo  memberDetailInfo = memberBasic.getMemberDetail();
				memberDetailInfo.setUpdateTime(memberBasic.getUpdateTime());
				memberDetailInfo.setUpdateUser(memberBasic.getUpdateUser());
				memberBasicMapper.updateMemberDetailInfo(memberDetailInfo);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**校验国家省份城市是否有效
	 * @param member
	 * @return
	 */
	private MemberBasic validata(MemberBasic member) {
		if(null!=member.getMemberDetail()) {
			Integer countryId = member.getMemberDetail().getCountryId();
			Integer provinceId = member.getMemberDetail().getProvinceId();
			Integer cityId = member.getMemberDetail().getCityId();
			if(null==countryId) {
				throw new BussinessException(new BussinessExceptionBean("exception.countryIsInvalid"));
			}
			if(null==provinceId){
				throw new BussinessException(new BussinessExceptionBean("exception.provinceIsInvalid"));
			}
			if(null==cityId){
				throw new BussinessException(new BussinessExceptionBean("exception.cityIsInvalid"));	
			}
			if(countryId==-1) {
				member.getMemberDetail().setCountryId(null);
			}
			if(provinceId==-1) {
				member.getMemberDetail().setProvinceId(null);
			}
			if(cityId==-1) {
				member.getMemberDetail().setCityId(null);
			}
		}
		return member;
	}
	
    /**
     * 会员订单tab页展示
     */
    @Override
    public List<MemberCollection> getMemberCollections(MemberCollection memberCollection, boolean pageAble) {
        try {
            if(pageAble){
                PageHelper.startPage(memberCollection.getPageNum(), SysConstant.PAGE_PAGESIZE);
            }
            List<MemberCollection> collectionList = memberCollectionMapper.getMemberCollections(memberCollection);
            return collectionList;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
	
    /**
     * 登录方式总共有三种：
     * 1、普通登录（输入正确的手机号密码）; loginType=1
     * 2、快速登录（输入正确手机号和验证码登录）;loginType=2
     * 3、第三方账号登录（新浪微博、QQ、微信）loginType=3
     */
    @Override
    public MessageData login(HttpServletRequest request,String phone,String loginType,String password,String verifyCode,String verifyCodeType,String token) {
        try {
            MessageData messageData = new MessageData(null,null,null);
            //Map<String,Object> map = new HashMap<String,Object>();
            //用户注册手机号默认为会员账号，且唯一不可修改，会员手机号可以修改
            MemberBasic memberBasicInfo = memberBasicMapper.selectMemberDetailInfoByAccount(phone);
            if(StringUtil.isEmpty(loginType)) {
                messageData.setStatus(144);
                messageData.setMessage("登录方式参数为空！");
                return messageData;
            }
            if("1".equals(loginType)) {
                if(StringUtil.isEmpty(phone)) {
                    messageData.setStatus(155);
                    messageData.setMessage("手机号码为空！");
                    return messageData;
                }
                if(!ValidateUtil.isCellPhone(phone)) {
                    messageData.setStatus(102);
                    messageData.setMessage("手机号码格式不正确！");
                    return messageData;
                }
                if(null==memberBasicInfo) {
                    messageData.setStatus(105);
                    messageData.setMessage("会员登录失败:用户不存在");
                    return messageData;
                }
                if(StringUtil.isEmpty(password)) {
                    messageData.setStatus(175);
                    messageData.setMessage("密码为空！");
                    return messageData;
                }
                if(!(MD5.getMD5Encode(password)).equals(memberBasicInfo.getPassword())) {
                    messageData.setStatus(106);
                    messageData.setMessage("登录失败:账号或密码错误");
                    return messageData;
                }else{
                    messageData.setStatus(200);
                    messageData.setMessage("登录成功！");
                    memberBasicInfo.setPassword(null);
                    messageData.setObj(memberBasicInfo);
                    return messageData;
                }
            } 
            //验证码校验   
            if("2".equals(loginType)) {
                MessageData messageData1 = validateVerifyCode(phone, verifyCode, verifyCodeType, token);
                if(200==messageData1.getStatus()) {
                    memberBasicInfo.setPassword(null);
                    messageData1.setObj(memberBasicInfo);
                    messageData1.setMessage("登录成功！");
                    return messageData1;
                } else {
                    return messageData1;
                }
            } 
            if("3".equals(loginType)) {
                
            }else {
                messageData.setStatus(112);
                messageData.setMessage("不存在该登录方式！");
                return messageData;
            }
            return messageData;
        } catch (Exception e) {
        	e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    //获取验证码接口
    @Override
    public MessageData getVerifyCode(String phone, String verifyCodeType) {
        try {
            MsgSms msgSms = new MsgSms();
            MessageData messageData = new MessageData(null,null,null);
            if(StringUtil.isEmpty(phone)) {
                messageData.setStatus(155);
                messageData.setMessage("手机号码为空！");
                return messageData;
            }
            if(!ValidateUtil.isCellPhone(phone)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号码格式不正确！");
                return messageData;
            }
            
            //操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;
            //(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)6.只需要验证手机号是否为空和格式问题
            MemberBasic memberBasicInfo = memberBasicMapper.selectMemberDetailInfoByAccount(phone);
            if("1".equals(verifyCodeType)||"2".equals(verifyCodeType)) {
                if(null!=memberBasicInfo) {
                    messageData.setStatus(104);
                    messageData.setMessage("该手机号已注册！");
                    return messageData;
                }
            }
            if("3".equals(verifyCodeType)||"4".equals(verifyCodeType)||"5".equals(verifyCodeType)) {
                if(null==memberBasicInfo) {
                    messageData.setStatus(105);
                    messageData.setMessage("该手机号未注册");
                    return messageData;
                }
            }

            String verifyCode = initVerifyCode();
            logger.error("手机号："+phone+"，业务类别："+verifyCodeType+"，获取了验证码："+verifyCode);
            String businessType = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
            msgSms.setReceiverNo(phone);
            msgSms.setMsgContent(verifyCode);
            msgSms.setBusinessType(businessType);
            Map<String,String> map = new HashMap<String,String>();
            //调用接口 参数（verifyCode,phone）返回true/false 下面用1代表通过
            //RetBeanOfSendMessage retBeanOfSendMessage = SmsUtil.sendSms(BisConstant.SMS_BIS_ID, BisConstant.SMS_BIS_ID, BisConstant.SMS_TYPE, phone, verifyCode);
            //if(retBeanOfSendMessage.getIfSuccess().equals("Y")){
            if(true){
                msgSms.setSendStatus(1);
                msgSmsMapper.saveMsgSmsRecord(msgSms);
                map.put("token", businessType);
                messageData.setObj(map);
                messageData.setStatus(SysConstant.SUCCESS);
                messageData.setMessage(verifyCode);
            }else {
                msgSms.setSendStatus(0);
                msgSmsMapper.saveMsgSmsRecord(msgSms);
                messageData.setStatus(SysConstant.EXCEPTION);
                messageData.setMessage("短信发送失败！");
            }
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    /**
     * 
     * 此处为类方法说明：随机生成四位数字的验证码
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    public String initVerifyCode() {
        String chose = "123456789";
        char display[] = { '0', ' ', '0', ' ', '0', ' ', '0' };   
        char ran[] = {'0', '0', '0', '0' };   
        char temp;   
        Random rand = new Random();   
        for (int i = 0; i < 4; i++) {   
           temp = chose.charAt(rand.nextInt(chose.length()));   
           display[i * 2] = temp;   
           ran[i] = temp;   
        }   
        String random = String.valueOf(display); 
        String [] interceptString = random.split(" ");   
        String verifyCode = "";   
        for(int i = 0;i<interceptString.length;i++){   
            verifyCode += interceptString[i];   
        }
        return verifyCode;
    }
    
    @Override
    public MemberBasic getMemberBasicByPhone(String phone) {
        return memberBasicMapper.selectMemberDetailInfoByAccount(phone);
    }
    
    /**
     * 
     * 此处为类方法说明:校验验证码
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @Override
    public MessageData validateVerifyCode(String phone, String verifyCode, String verifyCodeType,String token) {
        try {
            MessageData messageData = new MessageData(null, null, null);
            if(StringUtil.isEmpty(phone)) {
                messageData.setStatus(155);
                messageData.setMessage("手机号码为空！");
                return messageData;
            }else if(!ValidateUtil.isCellPhone(phone)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号码格式不正确！");
                return messageData;
            }
            if(StringUtil.isEmpty(verifyCode)) {
              messageData.setStatus(103);
              messageData.setMessage("验证码为空！");
              return messageData;
            }else if(!ValidateUtil.isVerifyCode(verifyCode)) {
                messageData.setStatus(166);
                messageData.setMessage("验证码格式不正确！");
                return messageData;
            }
            if(StringUtil.isEmpty(verifyCodeType)) {
                messageData.setStatus(166);
                messageData.setMessage("验证码类型参数为空！");
                return messageData;
            }
            if(StringUtil.isEmpty(token)) {
                messageData.setStatus(166);
                messageData.setMessage("token参数为空！");
                return messageData;
            }
             MemberBasic memberBasicInfo = memberBasicMapper.selectMemberDetailInfoByAccount(phone);
             if("1".equals(verifyCodeType)||"2".equals(verifyCodeType)) {
                  if(null!=memberBasicInfo) {
                      messageData.setStatus(105);
                      messageData.setMessage("该手机号已注册！");
                      return messageData;
                  }
             }
             if("3".equals(verifyCodeType)||"4".equals(verifyCodeType)||"5".equals(verifyCodeType)) {
                  if(null==memberBasicInfo) {
                      messageData.setStatus(106);
                      messageData.setMessage("该手机号未注册");
                      return messageData;
                  }
             }
             
             MsgSms msgSms = new MsgSms();
             msgSms.setBusinessType(token);
             msgSms.setMsgContent(verifyCode);
             msgSms.setReceiverNo(phone);
             msgSms.setSendStatus(1);
             int count = msgSmsMapper.validateCaptcha(msgSms);
             if(count>0) {
                  messageData.setStatus(200);
                  messageData.setMessage("验证成功！");
                  return messageData;
             }else {
                  messageData.setStatus(120);
                  messageData.setMessage("验证失败！");
                  return messageData;
             }
            } catch (Exception e) {
                e.printStackTrace();
                throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
            }
        }
    
    @Override
	public MessageData AddCommonRegister(String phone,String verifyCode,String password,String confirmPassword,String token,String verifyCodeType) {
        try {
            MessageData messageData = new MessageData(null, null, null);
            //校验验证码是否通过
            messageData = validateVerifyCode(phone, verifyCode, verifyCodeType, token);
            if(200!=messageData.getStatus()) {
                return messageData;
            }
            if(StringUtil.isEmpty(password)) {
                messageData.setStatus(201);
                messageData.setMessage("密码为空！");
                return messageData;
            } 
            if(!ValidateUtil.isPassword(password)) {
                messageData.setStatus(202);
                messageData.setMessage("您的密码安全等级太弱，请设置6-16位数字和字母的组合！");
                return messageData;
            }
            if(!password.equals(confirmPassword)) {
                messageData.setStatus(203);
                messageData.setMessage("确认密码与登录密码不一致！");
                return messageData;
            }
            
            //保存会员基本信息，返回主键ID作为会员详细信息的外键
            MemberBasic memberBasic = new MemberBasic();
            //注册使用的手机号默认为会员账号，保证唯一，不可修改，会员信息的手机号也默认为注册使用的手机号，可以修改
            memberBasic.setMemberAccount(phone);
            memberBasic.setValid((short)1);
            memberBasic.setActivatedFlg((short)1);
            memberBasic.setCreateTime(new Date());
            memberBasic.setPassword(MD5.getMD5Encode(password));
            memberBasic.setReceiveComment(1);
            memberBasic.setReceiveCommentStart(new Date());
            memberBasic.setReceivePrasie(0);
            memberBasic.setReceivePrasieStart(new Date());
            //会员注册时，默认猴爸爸头像
            memberBasic.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
            memberBasicMapper.addMemberBasicInfo(memberBasic);
            //保存会员详细信息
            Integer memberId = memberBasic.getId();
            MemberDetailInfo memberDetailInfo = new MemberDetailInfo();
            memberDetailInfo.setPhoneCh(phone);
            memberDetailInfo.setFkId(memberId);
            memberDetailInfo.setType(1);
            memberDetailInfoService.addMemberDetailInfo(memberDetailInfo);
            
            //新增会员注册消息
            MemberMsg memberMsg = new MemberMsg();
            memberMsg.setMemberId(memberId);
            memberMsg.setMsgTitle("恭喜您,注册成功!");
            memberMsg.setMsgContent("恭喜您,注册成功!");
            //消息默认为未阅读状态
            memberMsg.setMsgStatus(0);
            //消息类别：1、首次注册；2、密码更改；3、订单状态更改；4、公共消息
            memberMsg.setMsgType(1);
            memberMsg.setCreateTime(new Date());
            memberMsgService.addMemberMsg(memberMsg);
            MemberBasic memberBasicInfo = memberBasicMapper.selectMemberDetailInfoByAccount(phone);
            if(null!=memberBasicInfo) {
                memberBasicInfo.setPassword(null);
            }
            messageData.setObj(memberBasicInfo);
            messageData.setStatus(200);
            messageData.setMessage("注册成功！");
            return messageData;
            
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
	}
    
    /**
     * 会员密码重置
     */
	@Override
	public MessageData updateMemberPassword(String phone, String verifyCode,String newPassword,String token,String verifyCodeType) {
		MessageData messageData = new MessageData(null, null, null);
		//校验验证码是否通过
		messageData = validateVerifyCode(phone, verifyCode, verifyCodeType, token);
		if(200!=messageData.getStatus()) {
		    return messageData;
		}
		if(StringUtil.isEmpty(newPassword)) {
            messageData.setStatus(201);
            messageData.setMessage("密码为空！");
            return messageData;
        } 
        if(!ValidateUtil.isPassword(newPassword)) {
            messageData.setStatus(202);
            messageData.setMessage("您的密码安全等级太弱，请设置6-16位数字和字母的组合！");
            return messageData;
        }
        MemberBasic memberBasic = memberBasicMapper.selectMemberDetailInfoByAccount(phone);
        memberBasic.setPassword(MD5.getMD5Encode(newPassword));
        int count = memberBasicMapper.updateMemberPassword(memberBasic);
		if(count>0) {
		    //会员修改密码保存到系统通知中去
            MemberMsg memberMsg = new MemberMsg();
            memberMsg.setMemberId(memberBasic.getId());
            memberMsg.setMsgTitle("恭喜您,密码修改成功!");
            memberMsg.setMsgContent("恭喜您,密码修改成功!");
            //消息默认为未阅读状态
            memberMsg.setMsgStatus(0);
            //消息类别：1、首次注册；2、密码更改；3、订单状态更改；4、公共消息
            memberMsg.setMsgType(2);
            memberMsg.setCreateTime(new Date());
            memberMsgService.addMemberMsg(memberMsg);
		    
		    messageData.setStatus(200);
	        messageData.setMessage("会员密码重置成功！");
	        return messageData;
		}else {
		    messageData.setStatus(204);
            messageData.setMessage("会员密码重置失败！");
            return messageData;
		}
	}

	@Override
	public MessageData resetPassword(String phone, String verifyCode,
			String newPassword, String repetitionPassword) {
		MessageData messageData = new MessageData(null, null, null);
		MemberBasic memberBasicInfo = memberBasicMapper
				.selectMemberDetailInfoByAccount(phone);
		if (StringUtil.isEmpty(phone)) {
			messageData.setStatus(155);
			messageData.setMessage("手机号码为空！");
			return messageData;
		} else {
			if (!ValidateUtil.isCellPhone(phone)) {
				messageData.setStatus(102);
				messageData.setMessage("手机号码格式不正确！");
				return messageData;
			} else if (null != memberBasicInfo) {
				boolean type1 = true;
				String type = String.valueOf(type1);
				this.getVerifyCode(phone, type);
				if (StringUtil.isEmpty(newPassword)) {
					messageData.setStatus(201);
					messageData.setMessage("密码为空！");
				} else {
					if (!ValidateUtil.isPassword(newPassword)) {
						messageData.setStatus(102);
						messageData.setMessage("密码格式不正确！");
						return messageData;
					}
				}
				if (StringUtil.isEmpty(repetitionPassword)) {
					messageData.setStatus(203);
					messageData.setMessage("重复密码为空！");
				} else {
					if (!ValidateUtil.isPassword(repetitionPassword)) {
						messageData.setStatus(204);
						messageData.setMessage("重复密码格式不正确！");
						return messageData;
					} else if (newPassword == repetitionPassword) {
						messageData.setStatus(205);
						messageData.setMessage("新密码与重复密码不匹配！");
						return messageData;
					}
					memberBasicInfo.setPassword(newPassword);
					memberBasicMapper.updatePassword(memberBasicInfo);
					messageData.setStatus(200);
					messageData.setMessage("密码设置成功！");
					return messageData;
				}
			}
			return messageData;
		}
	}

	@Override
	public MessageData memberBand(String phone) {
		MessageData messageData = new MessageData(null, null, null);
		MemberBasic memberBasicInfo = memberBasicMapper
				.selectMemberDetailInfoByAccount(phone);
		if (StringUtil.isEmpty(phone)) {
			messageData.setStatus(155);
			messageData.setMessage("手机号码为空！");
			return messageData;
		} else {
			if (!ValidateUtil.isCellPhone(phone)) {
				messageData.setStatus(102);
				messageData.setMessage("手机号码格式不正确！");
				return messageData;
			} else if (null == memberBasicInfo) {
				messageData.setStatus(301);
				messageData.setMessage("该手机号未绑定会员！");
				return messageData;
			} else if (null != memberBasicInfo) {
				messageData.setStatus(302);
				messageData.setMessage("该手机号已绑定会员！");
				return messageData;
			}
		}
		return messageData;
	}
    
    @Override
    public MessageData bookRegiste(String phone) {
        MessageData messageData = new MessageData(null, null, null);
        MemberBasic memberBasicInfo = memberBasicMapper
                .selectMemberDetailInfoByAccount(phone);
        if (StringUtil.isEmpty(phone)) {
            messageData.setStatus(155);
            messageData.setMessage("手机号码为空!");
            return messageData;
        } else {
            if (!ValidateUtil.isCellPhone(phone)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号码格式不正确！");
                return messageData;
            } else if (null != memberBasicInfo) {
                messageData.setStatus(103);
                messageData.setMessage("手机号码已注册！");
            } else if (memberBasicInfo == null) {
                MemberBasic memberBasic = new MemberBasic();
               // memberBasicMapper.insertSelective(memberBasic);
                String phoneCh = phone;
                MemberDetailInfo memberDetailInfo = new MemberDetailInfo();
                memberDetailInfo.setPhoneCh(phoneCh);
                memberDetailInfo.setFkId(memberBasic.getId());
               //.insertSelective(memberDetailInfo);
                messageData.setStatus(200);
                messageData.setMessage("注册成功！");
                return messageData;
            }
        }
        return messageData;
    }

    @Override
    public MemberBasic saveNewMemberBasicInfo(MemberBasic registMemberBasic) {
        memberBasicMapper.addMemberBasicInfo(registMemberBasic);
        MemberBasic newMemberBasic = new MemberBasic();
        newMemberBasic.setId(registMemberBasic.getId());
        MemberDetailInfo memberDetailInfo = registMemberBasic.getMemberDetail();
        memberDetailInfo.setFkId(newMemberBasic.getId());
        memberDetailInfo.setType(1);
        memberDetailInfoMapper.addMemberDetailInfo(memberDetailInfo);
        newMemberBasic.setMemberDetail(memberDetailInfo);
        
        MemberMsg memberMsg = new MemberMsg();
        memberMsg.setMemberId(newMemberBasic.getId());
        memberMsg.setMsgType(1);
        memberMsg.setMsgTitle("恭喜你,注册成功!");
        memberMsg.setMsgContent("恭喜你注册成功，您的密码是：123456，请妥善保管。");
        memberMsg.setMsgStatus(0);
        memberMsg.setBusinessId(newMemberBasic.getId());
        memberMsg.setCreateTime(new Date());
        memberMsg.setCreateUser(newMemberBasic.getId());
        memberMsgMapper.addMemberMsg(memberMsg);
        return newMemberBasic;
    }
    /**
     * 更新我的接受通知
     */
    @Override
    public MessageData updateCommentState(MemberBasic memberBasic){
    	MessageData messageData = new MessageData(null, null, null);
    	memberBasicMapper.updateCommentState(memberBasic);
    	return messageData;	
    }
    /**
     * 更新我的点赞通知
     */
    public MessageData updatePrasieState(MemberBasic memberBasic){
    	MessageData messageData = new MessageData(null, null, null);
    	memberBasicMapper.updatePrasieState(memberBasic);
    	return messageData;
    }

    @Override
    public MessageData updateMemberInfo(Integer memberId, String imageUrl, String nameCh, String phoneCh, Integer sex,
        String birthDay, Integer countryId, Integer provinceId, Integer cityId, String mail) {
        try {
            MessageData messageData = new MessageData(null, null);
//            if(StringUtil.isEmpty(nameCh)) {
//                messageData.setStatus(120);
//                messageData.setMessage("姓名不能为空！");
//                return messageData;
//            }
            if(StringUtil.isEmpty(phoneCh)) {
                messageData.setStatus(102);
                messageData.setMessage("手机号不能为空！");
                return messageData;
            }
            if(!ValidateUtil.isCellPhone(phoneCh)) {
                messageData.setStatus(103);
                messageData.setMessage("手机号格式不正确！");
                return messageData;
            }
            //根据手机号去查询该手机号是否已被绑定
//        MemberDetailInfo memberDetailInfo = new MemberDetailInfo();
//        memberDetailInfo.setFkId(memberId);
//        memberDetailInfo.setPhoneCh(phoneCh);
//        memberDetailInfo.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
//        int count = memberDetailInfoMapper.selectPhoneIsBand(memberDetailInfo);
//        if(count>0) {
//            messageData.setStatus(104);
//            messageData.setMessage("该手机号已注册！");
//            return messageData;
//        }
            //根据memberId查询会员基本信息
            MemberBasic memberBasicExample = memberBasicMapper.selectByPrimaryKey(memberId);
            //修改会员基本信息
            memberBasicExample.setImageUrl(imageUrl);
            memberBasicExample.setUpdateTime(new Date());
            memberBasicExample.setUpdateUser(memberId);
            memberBasicMapper.updateMemberBasicInfoById(memberBasicExample);
            //根据memberId查询会员详细信息
            MemberDetailInfo memberDetailInfoExample = memberDetailInfoMapper.selectByFkId(memberId);
            memberDetailInfoExample.setNameCh(nameCh);
            memberDetailInfoExample.setPhoneCh(phoneCh);
            memberDetailInfoExample.setSex(sex);
            memberDetailInfoExample.setBirthday(DateUtil.stringToDate(birthDay));
            memberDetailInfoExample.setCountryId(countryId);
            memberDetailInfoExample.setProvinceId(provinceId);
            memberDetailInfoExample.setCityId(cityId);
            memberDetailInfoExample.setMail(mail);
            //修改会员详情信息
            memberDetailInfoMapper.updateByPrimaryKey(memberDetailInfoExample);
            //修改成功后，更新session中的会员信息
            MemberBasic memberBasicInfo = memberBasicMapper.selectMemberInfo(memberId);
            messageData.setStatus(200);
            messageData.setMessage("更新成功！");
            messageData.setObj(memberBasicInfo);
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
	 * 根据memberId查询会员基本信息
	 */
	@Override
	public MemberBasic selectMemberInfo(Integer memberId) {
		try {
			// 根据memberId查询会员基本信息
			MemberBasic memberBasicInfo = memberBasicMapper.selectMemberInfo(memberId);
			memberBasicInfo.setPassword(null);
			return memberBasicInfo;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**
	 * 修改会员消息接收开关
	 */
    @Override
    public MessageData updateMessageReceiveStatus(Integer memberId, Integer receivePraise,Integer receiveComment) {
        try {
            MessageData messageData = new MessageData(null, null);
            //根据memberId查询会员基本信息
            MemberBasic memberBasicExample = memberBasicMapper.selectByPrimaryKey(memberId);
            //设置消息接收开关
            memberBasicExample.setReceiveComment(receiveComment);
            memberBasicExample.setReceiveCommentStart(new Date());
            memberBasicExample.setReceivePrasie(receivePraise);
            memberBasicExample.setReceivePrasieStart(new Date());
            memberBasicExample.setUpdateTime(new Date());
            memberBasicExample.setUpdateUser(memberId);
            memberBasicMapper.updateMemberBasicInfoById(memberBasicExample);
            messageData.setStatus(200);
            messageData.setMessage("消息开关设置成功！");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public void addMemberBasicInfo(MemberBasic memberBasic) {
        try {
            memberBasicMapper.addMemberBasicInfo(memberBasic);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public int updateMemberPassword(MemberBasic memberBasic) {
        try {
            return memberBasicMapper.updateMemberPassword(memberBasic);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public void updateMemberBasicInfoById(MemberBasic memberBasicExample) {
        try {
            memberBasicMapper.updateMemberBasicInfoById(memberBasicExample);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

}
