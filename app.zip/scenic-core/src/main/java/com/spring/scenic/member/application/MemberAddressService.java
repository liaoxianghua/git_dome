package com.spring.scenic.member.application;

import java.util.List;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.member.domain.MemberAddress;

public interface MemberAddressService {

    /**   
     * 此处为类方法说明:新增常用地址
     * @param isDefault 
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    public MessageData addCommonAddress(Integer memberId, String receiveName, String receivePhone,
        String addressDetail, String postCode, Integer countryId, Integer provinceId, Integer cityId, Integer isDefault);

    /**   
     * 此处为类方法说明：更新常用地址
     * @param isDefault 
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    public MessageData updateCommonAddress(Integer memberId,Integer addressId, String receiveName, String receivePhone,
        String addressDetail, String postCode, Integer countryId, Integer provinceId, Integer cityId, Integer isDefault);

    /**   
     * 此处为类方法说明:根据主键id查询常用地址信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    public MemberAddress selectCommonAddressInfo(Integer addressId);

    /**   
     * 此处为类方法说明:根据会员id查询常用地址信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    public List<MemberAddress> selectCommonAddressList(Integer memberId);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    public MessageData deleteCommonAddress(Integer addressId);

}
