package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.Province;

public interface ProvinceService {
	/**
	 * @return
	 */
	public List<Province> getCityList();



}
