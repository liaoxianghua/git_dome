package com.spring.scenic.search.domain.vo;

public class QuickSearchCategoryVo {
    
    /**
     * 类别：1、产品；2、游记攻略
     */
    private Integer type;
    
    /**
     * 名称
     */
    private String name;
    
    /**
     * 是否激活
     */
    private boolean active;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
    
}
