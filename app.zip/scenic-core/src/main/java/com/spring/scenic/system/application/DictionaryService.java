package com.spring.scenic.system.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;

public interface DictionaryService {

	List<Dictionary> getDictionaryList(Dictionary dictionary, boolean pageFalse);

	Map<String, List<Dictionary>> initDictionary(Dictionary dictionary);

	Map<String, Dictionary> initDictionaryMap(Dictionary dictionary);
	
	int saveDictionary(AuthUser user, Dictionary dictionary);

	Dictionary getDictionary(Dictionary dictionary);

	int deleteDictionary(Dictionary dictionary);

	List<Dictionary> getDictionaryListByCode(Dictionary dictionary);
	
	/**
	 * 获取字段的中文名
	 * 此处为类方法说明
	 * @param value
	 * @param dics
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月5日上午9:57:52
	 */
	String getDicName(String value, List<Dictionary> dics);

	
}
