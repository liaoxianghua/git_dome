package com.spring.scenic.storage.fastdfs.storage;

import java.util.Map;

import com.spring.scenic.storage.fastdfs.DistributedFileSystemException;


public interface StorageService {

	String uploadResource(String extension, byte[] resourceData, Map<String, String> metadata) throws DistributedFileSystemException;
	
	Map<String, String> getMetadataByPath(String resourcePath) throws DistributedFileSystemException;
	
	void deleteResourceByPath(String resourcePath) throws DistributedFileSystemException;
}
