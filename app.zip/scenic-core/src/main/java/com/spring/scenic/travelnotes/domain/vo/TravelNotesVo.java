package com.spring.scenic.travelnotes.domain.vo;

import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

/**
 * 游记Vo
 */
public class TravelNotesVo extends Entity<TravelNotesVo> {

	/** ID*/
	private Integer id;
	
	/** 会员ID*/
	private Integer mememberId;
	
	/** 类型*/
	private Integer type;
	
	/** 游记标题*/
	private String title;
	
	/** 创建时间*/
	private Date createTime;
	
	/** 封面图片*/
	private String coversImageUrl;
	
	/** 用户姓名 */
    private String name;

    /** 用户头像 */
    private String imageUrl;

    /** 用户发布时间 */
    private Date departureDate;

    /** 人均费用 */
    private String fee;
    /** 出游人群*/
    private String persons;

    /** 出行天数 */
    private String days;

    /** 游记点赞数 */
    private Integer praiseCount;

    /** 游记评论数 */
    private Integer commentCount;

    /** 游记收藏数 */
    private Integer collectionCount;
    
    /** 是否点赞*/
    private Integer praised;
    
    /** 是否收藏*/
    private Integer collected;
    
    /** 阅读数*/
    private Integer readCount;
    
    /** 距离现在多少时间 */
    private String nowTime;
    
    /** 用户ID*/
    private Integer userId;
    /** 用户类型    1为 系统会员 2 为普通会员*/
    private Integer createUserType;
    
    /** 回话ID*/
    private String sessionId;
    
    /**
     * 游记状态:0 草稿 1 未审核 2 已审核 3 未通过
     */
    private Integer status;
    
	private List<TravelNotesDetailsVo> travelnotesdetailsList;
	
	/**
	 * 游记详情的第一段文字
	 */
	private String subTitle;
	
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMememberId() {
        return mememberId;
    }

    public void setMememberId(Integer mememberId) {
        this.mememberId = mememberId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCoversImageUrl() {
        return coversImageUrl;
    }

    public void setCoversImageUrl(String coversImageUrl) {
        this.coversImageUrl = coversImageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(Date departureDate) {
        this.departureDate = departureDate;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public String getPersons() {
        return persons;
    }

    public void setPersons(String persons) {
        this.persons = persons;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public Integer getPraiseCount() {
        return praiseCount;
    }

    public void setPraiseCount(Integer praiseCount) {
        this.praiseCount = praiseCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getCollectionCount() {
        return collectionCount;
    }

    public void setCollectionCount(Integer collectionCount) {
        this.collectionCount = collectionCount;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public String getNowTime() {
        return nowTime;
    }

    public void setNowTime(String nowTime) {
        this.nowTime = nowTime;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getCreateUserType() {
        return createUserType;
    }

    public void setCreateUserType(Integer createUserType) {
        this.createUserType = createUserType;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getPraised() {
        return praised;
    }

    public void setPraised(Integer praised) {
        this.praised = praised;
    }

    public Integer getCollected() {
        return collected;
    }

    public void setCollected(Integer collected) {
        this.collected = collected;
    }

    public List<TravelNotesDetailsVo> getTravelnotesdetailsList() {
        return travelnotesdetailsList;
    }

    public void setTravelnotesdetailsList(List<TravelNotesDetailsVo> travelnotesdetailsList) {
        this.travelnotesdetailsList = travelnotesdetailsList;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }
    
    
    
}
