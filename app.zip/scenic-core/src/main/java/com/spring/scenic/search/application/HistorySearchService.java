package com.spring.scenic.search.application;

import java.util.List;

import com.spring.scenic.search.domain.HistorySearch;

public interface HistorySearchService {
    
    List<HistorySearch> getHistorySearchList(HistorySearch historySearchExample);

    int deleteHistorySearchBySession(HistorySearch historySearchExample);

    int deleteHistorySearch(HistorySearch historySearchExample);

    int saveHistorySearch(HistorySearch historySearch);
 
    

}
