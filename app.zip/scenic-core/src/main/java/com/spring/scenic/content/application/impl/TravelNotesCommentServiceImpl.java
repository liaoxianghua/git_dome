package com.spring.scenic.content.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.content.domain.TravelNotesComment;
import com.spring.scenic.content.domain.vo.MyCommentVo;
import com.spring.scenic.content.infrastructure.TravelNotesCommentMapper;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;

@Service
public class TravelNotesCommentServiceImpl implements TravelNotesCommentService {

	@Autowired
	private TravelNotesCommentMapper travelNotesCommentMapper;

	@Resource
	private TravelNoteService travelNoteService;
	@Resource
	private MemberBasicService memberBasicService;
	
	@Override
	public int selectTravelNotesCommentCount(Integer createUser) {
		MessageData messageData = new MessageData(null, null, null);
		Integer count = travelNotesCommentMapper
				.selectTravelNotesCommentCount(createUser);
		if (count == 0) {
			messageData.setStatus(101);
			messageData.setMessage("对不起没有人给你评论!");
		}else{
			messageData.setStatus(102);
			messageData.setMessage("你有"+count+"条评论");
		}
		return count;
	}
	/**
	 * 我的评论列表
	 */
	@Override
	public List<TravelNotesComment> selectTravelNotesComment(Integer createUser) {
		return travelNotesCommentMapper.selectTravelNotesComment(createUser);
	}
	@Override
	public List<MyCommentVo> selectCommentOfTravel(Integer commentUser) {
		try{
			List<MyCommentVo> lists = travelNotesCommentMapper.selectCommentOfTravel(commentUser);
			if(null==lists || lists.size()==0){
				return lists;
			}
			List<MyCommentVo> list = new ArrayList<MyCommentVo>();
			for(MyCommentVo myCommentVo : lists){
				MyCommentVo myCommentVos = myCommentVo;
				Integer votime=Integer.valueOf(myCommentVo.getNowTime().trim());
				if(votime<=120){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime()))+"分钟前");
				}
				if(votime>120 && votime<=2880){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60)+"小时前");
				}
				if(votime>2880 && votime<=129600){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60/24)+"天前");
				}
				if(votime>129600){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60/24/30)+"月前");
				}
				list.add(myCommentVos);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	@Override
	public List<MyCommentVo> selectCommentOfProduct(Integer commentUser) {
		try{
			List<MyCommentVo> lists = travelNotesCommentMapper.selectCommentOfProduct(commentUser);
			if(null==lists || lists.size()==0){
				return lists;
			}
			List<MyCommentVo> list = new ArrayList<MyCommentVo>();
			for(MyCommentVo myCommentVo : lists){
				MyCommentVo myCommentVos = myCommentVo;
				Integer votime=Integer.valueOf(myCommentVo.getNowTime().trim());
				if(votime<=120){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime()))+"分钟前");
				}
				if(votime>120 && votime<=2880){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60)+"小时前");
				}
				if(votime>2880 && votime<=129600){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60/24)+"天前");
				}
				if(votime>129600){
					myCommentVo.setNowTime(String.valueOf(Integer.valueOf(myCommentVo.getNowTime())/60/24/30)+"月前");
				}
				list.add(myCommentVos);
			}
			return list;
			}catch(Exception e){
				e.printStackTrace();
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}
	@Override
	public int insertIndexTraveNotesDetailComments(Integer id,String comments, Integer userId) {
		TravelNotesComment record=new TravelNotesComment();
		record.setComments(comments);
//		record.setCommentTime(new Date());
		record.setCommentUser(userId);//谁创建
		TravelNotes tn=travelNoteService.selectByPrimaryKey(id);
		
		if(tn.getCreateUserType() == 1){
			MemberBasic	memberBasic=memberBasicService.selectMemberInfo(tn.getCreateUser());
			if(1==(memberBasic.getReceiveComment()==null ? 1:memberBasic.getReceiveComment())){
				record.setValid(1);;//用户默认为使用期间可见
			}else{
				record.setValid(0);
			}
		}else{
			record.setValid(1);//后台管理使用可见
		}
		record.setTravelnoteId(id); 
		return travelNotesCommentMapper.insert(record);
	}
	@Override
	public MessageData deleteMyComment(List delList) {
		try {
            MessageData messageData = new MessageData(null, null);
            travelNotesCommentMapper.deleteMyComment(delList);
            messageData.setStatus(200);
            messageData.setMessage("删除成功");
            return messageData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
	}
	/**
	 * 查询会员游记被评论列表
	 */
    @Override
    public List<MyCommentVo> selectMemberCommentList(Integer memberId) {
        try {
            List<MyCommentVo> memberPraiseList = new ArrayList<MyCommentVo>();
            List<MyCommentVo> list = travelNotesCommentMapper.selectMemberCommentList(memberId);
            if(null!=list&&list.size()>0) {
                for (MyCommentVo myCommentVo : list) {
                    if(StringUtil.isEmpty(myCommentVo.getNameCh())) {
                        myCommentVo.setNameCh(myCommentVo.getMemberAccount().substring(0,3)+"****"+myCommentVo.getMemberAccount().substring(7, 11));
                    }
                    //调用计算时间的公共方法
                    String nowTime = DateUtil.currentDateToNowTime(myCommentVo.getNowTime());
                    myCommentVo.setNowTime(nowTime);
                    memberPraiseList.add(myCommentVo);
                }
                
            }
            return memberPraiseList;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    @Override
    public void deleteMemberCommentByBatch(List<String> idList) {
        try {
            travelNotesCommentMapper.deleteMemberCommentByBatch(idList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

}
