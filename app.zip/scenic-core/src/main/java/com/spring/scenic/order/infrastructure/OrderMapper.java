package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.vo.OrderStatistic;

public interface OrderMapper {

    List<Order> getOrderList(Order order);

    List<OrderStatistic> getOrderStatisticTotal(BusiSellerUser sellerUser);

    List<OrderStatistic> getOrderStatisticToday(BusiSellerUser sellerUser);

    Order getOrder(Order exampleOrder);

    List<Order> getOrderListWithWarn(Order order);

    int updateOrderStatus(Order order);

    int saveSellerRemark(Order order);

    int updateOrderPayPrice(Order order);
    /**
     * 保存订单 
     * @param order
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月5日上午9:11:25
     */
    int saveOrder(Order order);
    /**
     * 会员查询订单
     * @param order
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月4日上午11:05:14
     */
    List<Order> selectList(Order order);

    /**
     * 查询订单详情
     * 此处为类方法说明
     * @param i
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月5日下午1:46:53
     */
    Order selectOrderDetail(Integer i);

    int updateOrderPayInfo(Order order);
    
    /**
     * 获取订单号
     * 此处为类方法说明
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月16日下午8:53:43
     */
    String getOrderNo();
}
