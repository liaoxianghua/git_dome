package com.spring.scenic.product.domain.vo;
public class ProductMoreImgVo {

	private Integer officialImgId;
	
	private String officialImg;
	
	private Integer onlineImgId;
	
	private String onlineImg;

	public Integer getOfficialImgId() {
		return officialImgId;
	}

	public void setOfficialImgId(Integer officialImgId) {
		this.officialImgId = officialImgId;
	}

	public String getOfficialImg() {
		return officialImg;
	}

	public void setOfficialImg(String officialImg) {
		this.officialImg = officialImg;
	}

	public Integer getOnlineImgId() {
		return onlineImgId;
	}

	public void setOnlineImgId(Integer onlineImgId) {
		this.onlineImgId = onlineImgId;
	}

	public String getOnlineImg() {
		return onlineImg;
	}

	public void setOnlineImg(String onlineImg) {
		this.onlineImg = onlineImg;
	}
	
	
}
