package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.order.domain.OrderMoneyChangeRec;

public interface OrderMoneyChangeRecMapper {

    int saveOrderMoneyChange(OrderMoneyChangeRec order);

    List<OrderMoneyChangeRec> getOrderMoneyChangeList(OrderMoneyChangeRec orderMoneyChangeRec);

}
