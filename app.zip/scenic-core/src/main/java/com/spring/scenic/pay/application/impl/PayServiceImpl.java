package com.spring.scenic.pay.application.impl;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.SequenceTool;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderPayRecord;
import com.spring.scenic.order.infrastructure.OrderMapper;
import com.spring.scenic.order.infrastructure.OrderPayRecordMapper;
import com.spring.scenic.pay.application.PayService;
import com.spring.scenic.pay.domain.PayRecord;
import com.spring.scenic.pay.infrastructure.PayRecordMapper;

@Service
public class PayServiceImpl implements PayService{
    
    @Autowired
    private OrderMapper orderMapper;
    
    @Autowired
    private OrderPayRecordMapper orderPayRecordMapper;
    
    @Resource
    private OrderService orderService;

    @Override
    public void saveOrderSimplePay(MemberBasic member,Order order, BigDecimal payMoney, Integer payType) {
        if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode()) && 
                (order.getPayStatus()==Integer.parseInt(SysEnum.ORDER_PAY_STATUS_NO.getCode())
                        || order.getPayStatus()==Integer.parseInt(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()))
                        ){
            Order updateOrder = new Order();
            updateOrder.setId(order.getId());
            updateOrder.setOrderNo(order.getOrderNo());
            BigDecimal payPrice = order.getPayPrice();
            BigDecimal payedPrice = order.getPayedPrice();
            if(payedPrice==null){
                payedPrice = new BigDecimal(0);
            }
            
            if(payPrice!=null){//应付金额不为空
                if(payedPrice.compareTo(payPrice)==-1){//已付金额小于应付金额
                    payedPrice = payedPrice.add(payMoney);
                    updateOrder.setPayedPrice(payedPrice);
                    if(payedPrice.compareTo(payPrice)==0){//已付=应付 (付全款)
                        updateOrder.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
                    }else if(payedPrice.compareTo(payPrice)==1){//已付>应付 (超额全款)
                        updateOrder.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
                    }else if( payedPrice.compareTo(new BigDecimal(0))==1 && payedPrice.compareTo(payPrice)==-1 ){//付了点儿且未付完（部分付款）
                        updateOrder.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()));
                    }
//                    PayRecord payRecord = new PayRecord();
//                    payRecord.setOrderId(order.getId());
//                    payRecord.setOrderNo(order.getOrderNo());
//                    payRecord.setProductId(order.getProductId());
//                    payRecord.setProductName(order.getProductName());
//                    payRecord.setReceiveId(order.getSellerId());
//                    payRecord.setReceiveName(null);
//                    payRecord.setPayNo(SequenceTool.getInstance(0l, 1l).nextId()+"");
//                    payRecord.setPayMoney(payMoney);
//                    payRecord.setPayType(payType);
//                    payRecord.setPayStatus(1);
//                    payRecord.setPayUser(member.getId());
//                    payRecord.setPayUserName(member.getMemberDetail().getNameCh());
//                    payRecord.setPayDate(new Date());
//                    payRecordMapper.savePayRecord(payRecord);
                    Date date = new Date();
                    OrderPayRecord orderPayRecord = new OrderPayRecord();
                    orderPayRecord.setOrderNo(updateOrder.getOrderNo());
                    orderPayRecord.setPayTime(date);
                    orderPayRecord.setPayType(1);
                    orderPayRecord.setRemark("支付订单");
                    orderPayRecord.setTotalPrice(payMoney);
                    orderPayRecord.setPaySerialNo(SequenceTool.getInstance(0l, 1l).nextId()+"");
                    orderPayRecord.setCreateUser(member.getId());
                    orderPayRecord.setCreateTime(date);
                    orderPayRecordMapper.saveOrderPayRecord(orderPayRecord);
                    orderMapper.updateOrderPayInfo(updateOrder);
                }else{
                    throw new BussinessException(new BussinessExceptionBean("已付金额不小于应付金额")); 
                }
            }else{
                throw new BussinessException(new BussinessExceptionBean("应付金额为空")); 
            }
        }else{
            throw new BussinessException(new BussinessExceptionBean("支付条件不满足"));
        }
    }
    
    
    

}
