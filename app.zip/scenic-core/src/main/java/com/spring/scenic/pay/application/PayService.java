package com.spring.scenic.pay.application;

import java.math.BigDecimal;

import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.domain.Order;

public interface PayService {

    void saveOrderSimplePay(MemberBasic member, Order order, BigDecimal payMoney, Integer payType);

}
