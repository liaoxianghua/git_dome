package com.spring.scenic.order.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderInvoice;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductMealsService;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.sms.application.SmsService;
import com.spring.scenic.sms.domain.MsgSms;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;

@Controller
@RequestMapping(value = "/order")
@Api(value = "orderController", description = "订单接口")
public class OrderController {

	Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Resource
	private ProductService productService;

	@Resource
	private ProductPicRelService productPicRelService;

	@Resource
	private ProductStockService productStockService;

	@Resource
	private ProductMealsService productMealsService;

	@Resource
	private ProductCommentService productCommentService;

	@Resource
	private SmsService smsService;

	@Resource
	private MemberBasicService memberBasicService;

	@Resource
	private OrderService orderService;
	
	@Resource
	private DictionaryService dictionaryService;
	
    @Resource
    private BusiSellerService busiSellerService;
	


	/**
	 * 保存订单接口
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年5月2日下午7:40:34
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/saveOrder", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "预定", notes = "预定产品：旅游线路增加出行人，景点购物选择数量；还要快速注册;是否要发票由前段控制", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			// 产品
			@ApiImplicitParam(name = "productId", value = "产品Id", dataType = "Integer", paramType = "query", required = true),
			// 景点购物类产品信息
			@ApiImplicitParam(name = "orderCount", value = "购物、景点：订单数量", dataType = "Integer", paramType = "query", required = false),
			// 旅游线路类产品信息
			@ApiImplicitParam(name = "mealsId", value = "套餐ID", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "stockId", value = "库存ID", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "adultCount", value = "旅游线路：成人数量", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "childCount", value = "旅游线路：儿童数量", dataType = "Integer", paramType = "query", required = false),
			// 出行人
			@ApiImplicitParam(name = "passengers", value = "旅游线路：出行人", dataType = "String", paramType = "query", required = false),
			// 预订人
			@ApiImplicitParam(name = "linkMan", value = "联系人", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "phoneCh", value = "手机号", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "mail", value = "邮箱", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "weixin", value = "微信", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "captcha", value = "验证码", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "businessType", value = "验证码类型", dataType = "String", paramType = "query", required = false),
			// 订单备注
			@ApiImplicitParam(name = "remark", value = "备注", dataType = "String", paramType = "query", required = false),
			// 发票
			@ApiImplicitParam(name = "needInvoice", value = "是否需要发票", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "type", value = "发票类别", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "phone", value = "发票电话", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "title", value = "发票抬头", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "email", value = "发票邮箱", dataType = "String", paramType = "query", required = false),
			@ApiImplicitParam(name = "src", value = "来源", dataType = "Integer", paramType = "query", required = false, defaultValue = "1") })
	public MessageData saveOrder(HttpServletRequest request, HttpSession session,String weixin, Integer productId,
		Integer orderCount, String remark, Integer mealsId, Integer stockId, Integer adultCount, Integer childCount,
		String passengers, String linkMan, String phoneCh, String mail, String captcha, String businessType,
		Integer type, String phone, String title, String email, Integer src, Integer needInvoice) {
	    StringBuffer sb = new StringBuffer();
		sb.append("productId=").append(productId).append("，passengers=").append(passengers).append("，linkMan=")
				.append(linkMan).append("，stockId=").append(stockId).append("，orderCount=").append(orderCount)
				.append("，mealsId=").append(mealsId).append("，stockId=").append(stockId).append("，adultCount=")
				.append(adultCount).append("，type=").append(type).append("，phone=").append(phone)
				.append("，needInvoice=").append(needInvoice).append("，childCount=").append(childCount)
				.append("，remark=").append(remark).append(",weixin=").append(weixin);
		logger.info("下单请求参数：" + sb.toString());
		Order _order = new Order();
		
		Date date = new Date();
		if (productId == null) {
			return new MessageData(SysConstant.EXCEPTION, "产品ID不能为空");
		}
		// 产品
		ProductWithBLOBs product = productService.selectByPrimaryKey(productId);
		if (product == null) {
			return new MessageData(SysConstant.EXCEPTION, "产品不存在");
		}
		if (product.getIsSale() != null && 0 == product.getIsSale()) {
			return new MessageData(SysConstant.EXCEPTION, "产品已下架");
		}
		// 设置产品销量
		int saleNum = 0;
		Order order = new Order();
		ProductStock productStock = null;
		if (product.getProductType() != null && product.getProductType() != Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())) {// 非购物类才查套餐和库存
			// 套餐
			ProductMeals meals = productMealsService.selectByPrimaryKey(mealsId);
			if (meals == null) {
				return new MessageData(SysConstant.EXCEPTION, "套餐不存在");
			}
			if (!product.getId().equals(meals.getProductId())) {
				return new MessageData(SysConstant.EXCEPTION, "产品套餐错误");
			}
			// 库存
			productStock = productStockService.getProductStock(stockId);
			if (productStock == null) {
				return new MessageData(SysConstant.FAILURE, "产品库存不存在");
			}
			if (!meals.getId().equals(productStock.getMealsId())) {
				return new MessageData(SysConstant.FAILURE, "套餐库存错误");
			}
			if (product.getProductType() == 1) {// 景点
				if (product.getMaxCount() != null && product.getMaxCount() != -1) {// -1不售限制
					if (product.getMaxCount() < orderCount) {
						return new MessageData(500, "最多购买" + product.getMaxCount());
					}
					if (product.getMinCount() > orderCount) {
						return new MessageData(500, "最少购买" + product.getMinCount());
					}
					if ((saleNum > productStock.getTotalNum() - productStock.getSaleNum()) || productStock.getTotalNum() < 0) {
						return new MessageData(500, "库存不足");
					}
				}
				saleNum = orderCount;
			} else if (product.getProductType() == Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())) {// 旅游线路
				saleNum = childCount + adultCount;
				if (product.getMaxCount() != null && product.getMaxCount() != -1) {// -1不售限制
					if (product.getMaxCount() < childCount + adultCount) {
						return new MessageData(500, "最多购买" + product.getMaxCount());
					}
					if (product.getMinCount() > childCount + adultCount) {
						return new MessageData(500, "最少购买" + product.getMinCount());
					}
					if ((saleNum > productStock.getTotalNum() - productStock.getSaleNum()) || productStock.getTotalNum() < 0) {
						return new MessageData(500, "库存不足");
					}
				}
				if (StringUtils.isBlank(passengers)) {
					return new MessageData(500, "出行人不能为空");
				}
			}
			order =
					readyOrder(product, meals, productStock, type, phone, title,mail, weixin,email, linkMan, phoneCh, remark,
							orderCount, mealsId, stockId, passengers, adultCount, childCount, src, needInvoice);
			productStock.setSaleNum(productStock.getSaleNum() + saleNum);
		} else if (product.getProductType().equals(2)) {// 购物
			if ((saleNum > (product.getTotalNum() - product.getSaleNum())) || product.getTotalNum() < 0) {
				return new MessageData(500, "库存不足");
			}
			saleNum = orderCount;
			// 封装订单
			order =
					readyShoppingOrder(product, type, phone, title, mail,weixin,email, linkMan, phoneCh, remark,
							orderCount, mealsId, stockId, passengers, adultCount, childCount, src, needInvoice);
		} else {
			return new MessageData(500, "产品类型不对");
		}
		if (product.getProductType() != null) {
			if (product.getProductType().equals(1)) {
				if (orderCount == null) {
					return new MessageData(SysConstant.FAILURE, "订购数量不能为空");
				}
			} else if (product.getProductType().equals(3)) {
				if (adultCount == null) {
					return new MessageData(SysConstant.FAILURE, "成人数不能为空");
				}
				if (passengers == null) {
					new MessageData(SysConstant.FAILURE, "出行人不能为空");
				}
			}
		} else {
			return new MessageData(SysConstant.FAILURE, "产品类别为空");
		}
		product.setSaleNum(product.getSaleNum() + saleNum);
		
		// 验证会员
		MemberBasic memberBasicOnline = MemberAuthentiction.getOnlineMemeber(session);
		Map<String, Object> map = new HashMap<String, Object>();
		if (memberBasicOnline == null) {// 未登录快速预定
			// 验证填写手机号码 和 验证码 是否正确
			MsgSms msgSms = new MsgSms();
			msgSms.setReceiverNo(phoneCh);
			msgSms.setBusinessType(businessType);
			msgSms.setMsgContent(captcha);
			msgSms.setSendStatus(1);
			if (smsService.validateTheCaptcha(msgSms)) {// 验证通过
				MemberBasic memberBasicTemp = memberBasicService.getMemberBasicByPhone(phoneCh);
				if (memberBasicTemp!=null) {// 验证该手机号码是不是会员
					MemberBasic memberBasicExample = new MemberBasic();
					memberBasicExample.setId(memberBasicTemp.getId());
					// 订单发票
					if (needInvoice != null && needInvoice == 1) {
						OrderInvoice invoice = new OrderInvoice();
						invoice.setType(type);
						invoice.setPhone(phone);
						invoice.setTitle(title);
						invoice.setEmail(email);
						invoice.setCreateTime(date);
						invoice.setCreateUser(memberBasicTemp.getId());
						invoice.setUpdateTime(date);
						invoice.setUpdateUser(memberBasicTemp.getId());
						order.setInvoice(invoice);
						order.setNeedInvoice(needInvoice);
					} else {
						order.setNeedInvoice(0);
					}
					if(product.getProductType().equals(2)){
						order = orderService.saveShoppingOrder(order, memberBasicTemp, product);
					}else{
						order = orderService.saveOrder(order, memberBasicTemp, product, productStock, passengers);
					}
					session.setAttribute(BisConstant.SESSION_MEMBER, memberBasicTemp);
					map.put("member", memberBasicTemp);
					map.put("order", order);
					return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
				} else {// 不是会员注册新会员，再提交订单
					MemberDetailInfo registMemberDetail = new MemberDetailInfo();
					registMemberDetail.setNameCh(linkMan);
					registMemberDetail.setPhoneCh(phoneCh);
					registMemberDetail.setMail(email);
					registMemberDetail.setCreateTime(date);
					MemberBasic registMemberBasic = new MemberBasic();
					registMemberBasic.setMemberFrom(SysEnum.CONTENT_FROM_M.getCode());
					registMemberBasic.setValid(Short.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
					registMemberBasic.setActivatedFlg(Short.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
					registMemberBasic.setMemberAccount(phoneCh);
					registMemberBasic.setPassword(MD5.getMD5Encode(BisConstant.INITIAL_PASSWORD));
					registMemberBasic.setReceiveComment(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
					registMemberBasic.setCreateTime(date);
					registMemberBasic.setReceiveCommentStart(date);
					registMemberBasic.setLastLoginTime(date);
					registMemberBasic.setReceivePrasie(Integer.valueOf(SysEnum.COMMON_BOOL_NO.getCode()));
					registMemberBasic.setReceivePrasieStart(date);
					registMemberBasic.setImageUrl(PropertiesUtil.getProperty("scenic_default_user_img"));
					registMemberBasic.setMemberDetail(registMemberDetail);
					// 注册新会员，再提交订单
					MemberBasic registedMember = memberBasicService.saveNewMemberBasicInfo(registMemberBasic);
					// 订单发票
					if (needInvoice != null && needInvoice == 1) {
						OrderInvoice invoice = new OrderInvoice();
						invoice.setType(type);
						invoice.setPhone(phone);
						invoice.setTitle(title);
						invoice.setEmail(email);
						invoice.setCreateTime(date);
						invoice.setCreateUser(registedMember.getId());
						invoice.setUpdateTime(date);
						invoice.setUpdateUser(registedMember.getId());
						order.setInvoice(invoice);
						order.setNeedInvoice(needInvoice);
					} else {
						order.setNeedInvoice(0);
					}
					if(product.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
						order = orderService.saveShoppingOrder(order, registMemberBasic, product);
					}else{
						order = orderService.saveOrder(order, registMemberBasic, product, productStock, passengers);
					}
					session.setAttribute(BisConstant.SESSION_MEMBER, registedMember);
					map.put("member", registedMember);
					map.put("order", order);
					return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
				}
			} else {
				return new MessageData(SysConstant.FAILURE, "验证码填写不正确");
			}
		} else {// 会员订购
            // 是会员直接登录、提交订单
            // 订单发票
            if (needInvoice != null && needInvoice == 1) {
            	OrderInvoice invoice = new OrderInvoice();
            	invoice.setType(type);
            	invoice.setPhone(phone);
            	invoice.setTitle(title);
            	invoice.setEmail(email);
            	invoice.setCreateTime(date);
            	invoice.setCreateUser(memberBasicOnline.getId());
            	invoice.setUpdateTime(date);
            	invoice.setUpdateUser(memberBasicOnline.getId());
            	invoice.setOrderNo(order.getOrderNo());
            	order.setInvoice(invoice);
            	order.setNeedInvoice(needInvoice);
            } else {
            	order.setNeedInvoice(0);
            }
            if(product.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
            	order = orderService.saveShoppingOrder(order, memberBasicOnline, product);
            }else{
            	order = orderService.saveOrder(order, memberBasicOnline, product, productStock, passengers);
            }
            map.put("member", memberBasicOnline);
            map.put("order", order);
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
		}

	}
	public Order readyShoppingOrder(ProductWithBLOBs product, Integer type,
		String phone, String title,String mail,String weixin, String email, String linkMan, String phoneCh, String remark, Integer orderCount,
		Integer mealsId, Integer stockId, String passengers, Integer adultCount, Integer childCount, Integer src,
		Integer needInvoice){
		Order order = new Order();
		// 基础信息
		order.setSrc(Integer.valueOf(SysEnum.CONTENT_FROM_M.getCode()));
		order.setProductName(product.getProductName());
		order.setProductCode(product.getProductCode());
		order.setProductId(product.getId());
		order.setOrderStatus(Integer.valueOf(SysEnum.ORDER_STATUS_NEW.getCode()));
		order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_NO.getCode()));
		// 预订人
		order.setLinkMan(linkMan);
		order.setPhone(phoneCh);
		order.setEmail(mail);
		order.setWeixin(weixin);
		order.setOrderType(product.getProductType());
		order.setRemark(remark);
		order.setSellerId(product.getSellerId());
		order.setUserKnow(product.getOrderRule() + product.getReturnRule());
		if (Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())==product.getProductType()) {// 购物
			// 购物：订单数量、订单价格
			order.setOrderCount(orderCount);
			order.setOrderPrice(product.getPrice().multiply(new BigDecimal(orderCount)));
			order.setProductPrice(product.getPrice());
			order.setPayedPrice(BigDecimal.ZERO);
			order.setPayPrice(product.getPrice().multiply(new BigDecimal(orderCount)));
		}
		return order;
	}
	// 准备订单信息
	public Order readyOrder(ProductWithBLOBs product, ProductMeals meals, ProductStock productStock, Integer type,
		String phone, String title,String mail,String weixin, String email, String linkMan, String phoneCh, String remark, Integer orderCount,
		Integer mealsId, Integer stockId, String passengers, Integer adultCount, Integer childCount, Integer src,
		Integer needInvoice) {
		Order order = new Order();
		// 基础信息
		order.setSrc(Integer.valueOf(SysEnum.CONTENT_FROM_M.getCode()));
		order.setProductName(product.getProductName());
		order.setProductCode(product.getProductCode());
		order.setProductId(product.getId());
		order.setOrderStatus(Integer.valueOf(SysEnum.ORDER_STATUS_NEW.getCode()));
		order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_NO.getCode()));
		// 预订人
		order.setLinkMan(linkMan);
		order.setPhone(phoneCh);
		order.setEmail(mail);
		order.setWeixin(weixin);
		// 订单类别（景点、购物、旅游线路）
		order.setOrderType(product.getProductType());
		order.setRemark(remark);
		order.setSellerId(product.getSellerId());
		order.setUserKnow(product.getOrderRule() + product.getReturnRule());
		// 订单类型
		if (product.getProductType().equals(2)) {// 购物
			// 购物：订单数量、订单价格
			order.setOrderCount(orderCount);
			order.setOrderPrice(product.getPrice().multiply(new BigDecimal(orderCount)));
			order.setProductPrice(product.getPrice());
		} else if (product.getProductType() == 1 || product.getProductType() == 3) {// 景点、旅游线路
			BigDecimal orderPrice = BigDecimal.ZERO;
			if (product.getProductType() == 1) {// 景点
				order.setOrderCount(orderCount);
				order.setMealsId(mealsId);
				order.setMealsName(meals.getMealsName());
				orderPrice = productStock.getPrice().multiply(new BigDecimal(orderCount));
				order.setProductPrice(productStock.getPrice());
			}
			if (product.getProductType() == 3) {// 旅游线路
				order.setMealsId(meals.getId());
				order.setMealsName(meals.getMealsName());
				order.setAdultCount(adultCount);
				order.setAdultPrice(productStock.getAdultPrice());
				order.setChildCount(childCount);
				order.setChildPrice(productStock.getChildPrice());
				orderPrice = productStock.getAdultPrice().multiply(new BigDecimal(adultCount));
				if (adultCount % 2 == 1) {
					orderPrice = orderPrice.add(productStock.getSingleRoomPrice());
					order.setSingleroomPrice(productStock.getSingleRoomPrice());
				}
				if (childCount != null) {
					orderPrice = orderPrice.add(productStock.getChildPrice().multiply(new BigDecimal(childCount)));
				}
			}
			order.setOrderPrice(orderPrice);
			order.setPayPrice(orderPrice);
			order.setPayedPrice(BigDecimal.ZERO);
			order.setTravelTime(productStock.getPlayDay());
		}
		return order;
	}

	/**
	 * 查询订单列表
	 * @param memberId
	 * @param orderStatus
	 * @param pageNum
	 * @param pageSize
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年5月5日上午9:24:59
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectOrderList", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "我的订单", notes = "我的订单列表(全部、待支付（未支付或者部份支付 订单状态是已确认）、待完成（已支付或者超额支付 并且出行日期大于当前时间）、待点评（已支付或者超额支付 已完成 并且出行日期小于等于当前日期）)", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "pageNum", value = "第几页", dataType = "Integer", paramType = "query", required = true),
		@ApiImplicitParam(name = "pageSize", value = "每页大小", dataType = "Integer", paramType = "query", required = true),
		@ApiImplicitParam(name = "orderStatus", value = "查询类别(1、全部；2、待支付；3、待完成；4、待点评)", dataType = "Integer", paramType = "query", required = false)
	})
	public MessageData selectOrderList(HttpSession session, Integer orderStatus, Integer pageNum, Integer pageSize) {
		Map<String, Object> map = new HashMap<String, Object>();
		Order order = new Order();
		//会员
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
		if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
		}
		order.setMemberId(memberBasic.getId());
		order.setOrderStatus(orderStatus);
		order.setPageNum(pageNum);
		order.setPageSize(pageSize);
		List<Order> list = orderService.selectList(order, true);
		Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(new Dictionary());
		for (Order orderTemp : list) {
			ProductWithBLOBs pro = orderTemp.getProduct();
			//二级类别名称
			if(pro != null){
				if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SCENIC.getCode())){
					pro.setProductSubTypeName(dictionaryService.getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SCENIC")));
				}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){
					pro.setProductSubTypeName(dictionaryService.getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_SHOPPING"))); 
				}else if(pro.getProductType()==Integer.parseInt(SysEnum.PRODUCT_TYPE_LINE.getCode())){
					pro.setProductSubTypeName(dictionaryService.getDicName(pro.getProductSubType().toString(), dicMap.get("PRODUCT_TYPE_LINE")));
				}
			}
			orderTemp.setCommented(productCommentService.hasCommentedOrderProduct(orderTemp.getId(),memberBasic.getId()));
		}
		PageInfo<Order> pager = new PageInfo<Order>(list, order.getPageSize());
		map.put("orders", pager);
		return new MessageData(SysConstant.SUCCESS, "查询成功", map);
	}
	
	 /**
     * 订单详情接口
     * @param orderId
     * @return 订单详情
     * @creator ：liaoxianghua  
     * @date ：2017年5月5日上午9:10:07
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value = "/selectOrderDetail" ,method = { RequestMethod.POST })
    @ApiOperation(httpMethod = "POST", value = "查询订单详情", notes = "查询一个订单的信息 liaoxianghua", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orderId", value = "订单ID", dataType = "Integer", paramType = "query", required = true)
    })
    public MessageData selectOrderDetail(HttpSession session,Integer orderId) {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            //会员
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
            if(memberBasic == null){
                return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            Order order = orderService.selectOrderDetail(orderId);
            BusiSeller seller = busiSellerService.getBusiSellerById(order.getSellerId());
            if(seller!=null){
                order.setSeller(seller);
            }
            BusiSellerUser sellerUser = busiSellerService.getBusiSellerUserBySellerId(order.getSellerId());
            if(sellerUser!=null){
                order.setSellerUser(sellerUser);
            }
            if(order.getFileUrl()==null){
				// 基本属性
				ProductWithBLOBs product = productService.selectByPrimaryKey(order.getProductId());
				// 产品图片
				List<BusiPictureLib> productPicList = productPicRelService.getProductPicOrDefault(product);
				if(productPicList==null || productPicList.isEmpty()){//没图片给默认图片
				    product.setMainPic(PropertiesUtil.getProperty("scenic_default_user_img"));
				    order.setFileUrl(product.getMainPic());
				}else{//有图片取第一张
				    product.setMainPic(productPicList.get(0).getFileUrl());
				    product.setProductPics(productPicList);
				    order.setFileUrl(product.getMainPic());
				}
			}
            //应付金额 = 
            if(order.getPayPrice() != null && order.getPayedPrice() != null){
            	order.setPayPrice(order.getPayPrice().subtract(order.getPayedPrice()));
            }
            order.setCommented(productCommentService.hasCommentedOrderProduct(orderId,memberBasic.getId()));
            map.put("order", order);
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value = "/updateOrderStatus" , method = { RequestMethod.POST })
    @ApiOperation(httpMethod = "POST", value = "修改订单状态(取消)", notes = "修改订单状态", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orderId", value = "订单ID", dataType = "Integer", paramType = "query", required = true),
        @ApiImplicitParam(name = "orderStatus", value = "修改订单后的状态", dataType = "Integer", paramType = "query", required = true)
    })
    public MessageData updateOrderStatus(HttpSession session,Integer orderId,Integer orderStatus) {
        MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);

        if(orderId!=null && orderStatus!=null){
            try {
                //TODO 订单状态需增加程序验证
                Order order = new Order();
                order.setId(orderId);
                order.setOrderStatus(orderStatus);
                orderService.updateOrderStatus(order, memberBasic);
                return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
            } catch (Exception e) {
                e.printStackTrace();
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
        }else{
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
}
