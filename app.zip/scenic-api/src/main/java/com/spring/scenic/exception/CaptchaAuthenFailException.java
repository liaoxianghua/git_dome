package com.spring.scenic.exception;

public class CaptchaAuthenFailException extends RuntimeException {

    private static final long serialVersionUID = -1823174053534567132L;
    
    public CaptchaAuthenFailException(){
        super();
    }
    
    
    public CaptchaAuthenFailException(String msg){
        super(msg);
    }

}
