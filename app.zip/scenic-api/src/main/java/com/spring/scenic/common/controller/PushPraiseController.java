 
package com.spring.scenic.common.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.cms.application.SysConfigService;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.praise.application.PushPraiseService;
import com.spring.scenic.praise.domain.PushPraise;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;


/**
 * 点赞接口
 */
@Controller
@RequestMapping("praise")
@Api(value = "PushPraiseController", description = "点赞公共接口")
public class PushPraiseController extends BaseController{
    
    @Autowired
    private MemberBasicService memberBasicService;
    
    @Autowired
    private OrderService orderService;
    
    @Resource
    private BusiPictureLibService busipicturelibservice;
    
    @Resource
    private MaterialService materialservice;
    
    @Resource
    private ProductService productservice;
    
    @Resource
    private PushPraiseService pushPraiseService;
    
    @Resource
    private TravelNoteService travelNoteService;
    
    @Resource
    private TravelNotesCommentService travelNotesCommentService;
    
    @Resource
    private MemberCollectionService memberCollectionService;
    
    @Resource
    private SysConfigService sysConfigService;
    
    @Autowired
    private ProductCommentService productCommentService;
    
        
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="pushPraise",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "点赞或取消点赞", notes = "快速搜索：通过点击搜索或历史、热搜进入产品（无二级细分的所有产品）或游记攻略（无细分所有游记攻略）列表界面", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "praiseContentId", value = "被点赞业务数据的ID", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "praiseType", value = "被点赞业务数据类别(1、游记攻略；2、产品的评论；3、直播)", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData pushPraise(HttpSession session,Integer praiseContentId,Integer praiseType){
        try {
            if(praiseContentId==null || praiseType == null){
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_PARAMETER_ERROR);
            }
            Map<String,Object> map = new HashMap<String,Object>();
            PushPraise pushPraise = new PushPraise();
            pushPraise.setSessionId(session.getId());
            pushPraise.setPraiseContentId(praiseContentId);
            pushPraise.setPraiseType(praiseType);
            int pariseCount = pushPraiseService.getPushPraiseCount(pushPraise);
            if(pariseCount>0){//取消点赞
                pushPraiseService.deletePushPraise(pushPraise);
                map.put("praiseed",false);
                return new MessageData(SysConstant.SUCCESS, "取消成功！",map);
            }else{//点赞
                MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
                if(memberBasic!=null){
                    //点赞人
                    pushPraise.setMemberId(memberBasic.getId());
                    pushPraise.setCreateUser(memberBasic.getId());
                }
                if(praiseType==1){//1、游记攻略
                    TravelNotes travelNotes = travelNoteService.selectByPrimaryKey(praiseContentId);
                    if(travelNotes.getCreateUserType()==Integer.parseInt(SysEnum.SYSTEM_USER_MEMBER.getCode())){//是会员判断接不接收
                        memberBasic = memberBasicService.selectMemberInfo(travelNotes.getCreateUser());
                        //用户默认为使用期间可见
                        pushPraise.setIsView(memberBasic.getReceivePrasie()==null?Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()):memberBasic.getReceivePrasie());
                    }else{//其他默认接收
                        pushPraise.setIsView(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
                    }
                }else if(praiseType==2){//2、产品的评论：暂无
                    ProductComment productComment = productCommentService.selectByPrimaryKey(praiseContentId);
                    if(null!=productComment) {
                        memberBasic = memberBasicService.selectMemberInfo(productComment.getCreateUser());
                        if(null!=memberBasic) {
                          //用户默认为使用期间可见
                            pushPraise.setIsView(memberBasic.getReceivePrasie()==null?Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()):memberBasic.getReceivePrasie());
                        }else{//其他默认接收
                            pushPraise.setIsView(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
                        }
                    }
                    
                }else if(praiseType==3){//3、直播:默认发给后台用户
//                    SysConfigPic sysConfigPicExample = new SysConfigPic();
//                    sysConfigPicExample.setId(praiseContentId);
//                    SysConfigPic sysConfigPic = sysConfigService.getSysConfigPicById(sysConfigPicExample);
                    pushPraise.setIsView(Integer.parseInt(SysEnum.COMMON_BOOL_YES.getCode()));
                }
                pushPraiseService.savePushPraise(pushPraise);
                map.put("praiseed",true);
                return new MessageData(SysConstant.SUCCESS, "点赞成功！",map);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
        
}
