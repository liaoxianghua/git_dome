 
package com.spring.scenic.index.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.sms.domain.MsgSms;


/**
 * 登录、密码找回等模块接口
 */
@Controller
@RequestMapping("common")
@Api(value = "公共功能接口", description = "公共功能接口如登录、修改密码、找回密码等")
public class CommonController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(CommonController.class);
    @Autowired
    private MemberDetailInfoService memberDetailInfoService;
    @Autowired
    private MemberBasicService memberBasicService;
	@Resource
	private BusiPictureLibService busipicturelibservice;
    
    /**
     * 
     * 此处为类方法说明：会员登录
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="login",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端登录接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "loginType", value = "登录方式、1：普通登录，2：快速登录，3第三方登录", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "password", value = "登录密码", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码,服务器session为空时，表示不需要验证码，如果session获取有时则必须", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
        required = true, dataType = "String", paramType = "query")
        
    })
    public MessageData login(HttpServletRequest request,HttpSession session, String phone, String loginType, String password, String verifyCode,String verifyCodeType,String token){
        try {
            MessageData data = memberBasicService.login(request,phone,loginType,password,verifyCode,verifyCodeType,token);
            if(200==(data.getStatus())) {
                //登录成功，把会员对象存进session,会员所在城市存在session,如果会员没有城市，则默认为上海
                Map<String,Object> map = new HashMap<String,Object>();
                MemberBasic member = (MemberBasic) data.getObj();
                request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                map.put("memberBasic", member);
                String cityName = member.getCityName();
                if(StringUtil.isNotEmpty(cityName)) {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,cityName);
                }else {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,"上海");
                }
                data.setObj(map);
            }
            return data;
        } catch (Exception e) {
        	e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：查询会员详情信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月4日     
     * @memo ：   
     **
     */
    @CrossOrigin 
    @ResponseBody
    @RequestMapping(value="selectMemberDetailInfo",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终查询当前登录会员信息接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectMemberDetailInfo(HttpServletRequest request,HttpSession session){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic member =  (MemberBasic) request.getSession().getAttribute(BisConstant.SESSION_MEMBER);
            if(null==member) {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("该会员未登录");
                return messageData;
            }
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("memberBasic", member);
            messageData.setStatus(200);
            messageData.setMessage("查询成功");
            messageData.setObj(map);
            return messageData;
        } catch (Exception e) { 
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
        
    }
    /**
     * 
     * 此处为类方法说明：退出登录
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="logout",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端退出接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData logout(HttpServletRequest request,HttpSession session){
        try {
            request.getSession().removeAttribute(BisConstant.SESSION_MEMBER);
            request.getSession().removeAttribute(BisConstant.SESSION_LOCATION_CITY);
            request.getSession().invalidate();
            return new MessageData(200, "退出成功");
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:获取验证码
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="getVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端点击获取验证码接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型:1、会员注册,2、绑定手机号（第三方账号登录后）,3、快速登录,4、重置密码,5、修改密码,6、获取验证码【1、2需要验证手机号是否已注册；3、4、5需要验证手机号是否未注册；6、只需要验证手机号格式、是否为空】", 
                          required = true, dataType = "String", paramType = "query")
    })
    public MessageData getVerifyCode(HttpServletRequest request,HttpServletResponse response, HttpSession session, String phone, String verifyCodeType){
        try {
            logger.error("操作场景类型:1、会员注册,2、绑定手机号（第三方账号登录后）,3、快速登录,4、重置密码,5、修改密码,6、获取验证码【1、2需要验证手机号是否已注册；3、4、5需要验证手机号是否未注册；6、只需要验证手机号格式、是否为空】");
            MessageData data = memberBasicService.getVerifyCode(phone,verifyCodeType);
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 
     * 此处为类方法说明:重置密码之前验证码校验
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月24日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="validateVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端重置密码之前校验验证码是否正确接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册下单时获取验证码只需要验证手机号格式、是否为空)", 
        required = true, dataType = "String", paramType = "query")
    })
    public MessageData validateVerifyCode(HttpServletRequest request,HttpSession session, String phone, String verifyCode,String verifyCodeType,String token){
        try {
            MessageData data = memberBasicService.validateVerifyCode(phone,verifyCode,verifyCodeType,token);
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：用户普通注册
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月26日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="commonRegister",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "普通注册接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "password", value = "新密码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "confirmPassword", value = "新密码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
        required = true, dataType = "String", paramType = "query")
        })
    public MessageData commonRegister(HttpServletRequest request,HttpSession session, String phone,String verifyCode,String password,String confirmPassword,String token,String verifyCodeType){
        try {
            MessageData data = memberBasicService.AddCommonRegister(phone, verifyCode, password, confirmPassword, token, verifyCodeType);
            if(200==(data.getStatus())) {
                Map<String,Object> map = new HashMap<String,Object>();
                MemberBasic member = (MemberBasic) data.getObj();
                request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                map.put("memberBasic", member);
                data.setObj(map);
            }
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="bookRegiste",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "预订注册接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    })
    public MessageData bookRegiste(HttpServletRequest request,HttpSession session, String phone){
        try {
            MessageData data = memberBasicService.bookRegiste(phone);
            if(200==data.getStatus()) {
                request.getSession().setAttribute("phone",phone);
            }
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 重置会员密码
     */
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="resetMemberPassword",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员密码重置", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "newPassword", value = "新密码", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
    required = true, dataType = "String", paramType = "query")
    })
    public MessageData resetMemberPassword(HttpServletRequest request,HttpSession session, String phone,String verifyCode,String newPassword,String token,String verifyCodeType){
        try {
            MessageData data = memberBasicService.updateMemberPassword(phone,verifyCode,newPassword,token,verifyCodeType);
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
	/**
	 * 
	 * 此处为类方法说明：绑定手机号
	 * @param 
	 * @return
	 * @creator ：rmp  
	 * @date ：2017年4月26日     
	 * @memo ：   
	 **
	 */
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="memberBand",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "是否绑定会员", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    })
    public MessageData memberBand(HttpServletRequest request,HttpSession session, String phone){
        try {
            MessageData data = memberBasicService.memberBand(phone);
            if(200==data.getStatus()) {
            	request.getSession().setAttribute("phone",phone);   
            }
            return data;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
	// 上传文件
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/saveUploadFile", method = { RequestMethod.POST })
	@ApiOperation(value = "文件上传公共接口", notes = "文件上传公共接口")
	public MessageData saveUploadFile(HttpServletRequest request) {

		MessageData messageData = new MessageData(200, "上传成功");
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
	
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("busiPictureAttachvo", busipicturelibservice.saveUploadFile(filesMap));
			messageData.setStatus(200);
			messageData.setMessage("上传成功");
		} catch (Exception e) {
			messageData.setStatus(500);
			messageData.setMessage("上传失败");
		}
		messageData.setObj(map);
		return messageData;

	}
    
    
}
