 
package com.spring.scenic.travelNote.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;


/**
 * 
 * 此处为类说明: 游记攻略
 * @author lzj
 * @date  2017年5月3日18:32:18
 */
@Controller
@RequestMapping("mystrategy")
@Api(value = "TravelNoteController", description = "游记攻略接口")
public class TravelNoteController extends BaseController{
	
    @Resource
    private MaterialService materialservice;
    
    @Resource
    private TravelNoteService travelNoteservice;
 
	@ResponseBody
	@RequestMapping(value = "listMyStrategy", method = RequestMethod.POST)
	@ApiOperation(value = "我的游记攻略列表", notes = "我的游记攻略列表")
	@CrossOrigin
	public MessageData listMyStrategy(HttpServletRequest request, 
		    @ApiParam(name = "pageSize", value = "每页长度",required=true) @RequestParam Integer pageSize,
		    @ApiParam(name = "pageNum", value = "页码",required=true) @RequestParam Integer pageNum,
		    @ApiParam(name = "city", value = "城市名称",required=true) @RequestParam String city,HttpSession session){
		MessageData data=new MessageData(200, "成功");
		MaterialtravelsVo materialtravelsVo=new MaterialtravelsVo();
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
	    try {
	        if(StringUtils.isBlank(city)){
	            city = BisConstant.LOCATION_CITY_DEFAULT;
	        }
			materialtravelsVo.setCityName(city);
			materialtravelsVo.setStatus(1);
			materialtravelsVo.setPageNum(pageNum == null ? 1 :pageNum);
			materialtravelsVo.setPageSize(pageSize == null ? 10 :pageSize);
//			materialtravelsVo.setMissingCount(10);
//			materialtravelsVo.setMissingCountType(0);
			materialtravelsVo.setSessionId(session.getId());
	    	materialtravelsVo.setUserId(null!=memberBasic ? memberBasic.getId() :null);
			List<MaterialtravelsVo>  travels=materialservice.getTravelNotesList(materialtravelsVo,true);
			PageInfo<MaterialtravelsVo> page = new PageInfo<MaterialtravelsVo>(travels, 10);
	    	Map<String,Object> map=new HashMap<String,Object>();
//		    map.put("travelnotesvo",travels);
    		map.put("travelnotesvo", page);
		    data.setObj(map);
		    return data;
	    } catch (Exception e) {
	    	data.setMessage("查询失败");
	    	data.setStatus(500);
        }
	    return data;
	}
	
	
	
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="travelNoteDetail",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "游记攻略详情", notes = "游记攻略详情（包括首页等入口）", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "id", value = "游记攻略的列表传递过来的ID", required = true, dataType = "Integer", paramType = "query")
    })
	public MessageData travelNoteDetail(HttpServletRequest request, HttpSession session,Integer id){
		MessageData data=new MessageData(200, "成功");
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
		Map<String,Object> map=new HashMap<String,Object>();
		try {
			TravelNotesVo travelNote = travelNoteservice.getTravelNote(id,session.getId(),memberBasic==null ? null :memberBasic.getId());
			//游记及详情、点赞、浏览量、评论数、收藏数
    		map.put("travelNote", travelNote);
			//评论
    		List<IndexTravelNotesUserCommentslVo> travelNoteComments = travelNoteservice.selectByIndexTravelNotesUserCommentslVo(id);
    		map.put("travelNoteComments", travelNoteComments);
			//相关产品推荐
    		List<TravelNotesDetailStrategyVo> recommendProducts = travelNoteservice.selectByDetailStrategyVo(id);
			map.put("recommendProducts", recommendProducts );
			data.setObj(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
    
    /**
     * 
     * 此处为类方法说明:点击“我的”，进入页面加载该会员的一篇游记，
     * 加载规则为：有游记的 优先按已发表-待审-草稿-未通过 取创建时间最近那条，如果
     * 是已发表的要在游记下面显示点赞 、评论、收藏、浏览量 发表时间等
     * 一篇游记都没有的话：显示“亲，您还没有发表的游记，快来编写您的个人游记吧”。
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月25日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectMyFirstTravelNote",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的第一篇游记查询", notes = "我的第一篇游记查询", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectMyFirstTravelNote(HttpServletRequest request, HttpSession session){
        MessageData messageData = new MessageData(200, "查询成功");
        MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
        Map<String,Object> map = new HashMap<String,Object>();
        if(null!=memberBasic) {
            TravelNotesVo travelNote = travelNoteservice.selectMyFirstTravelNote(session.getId(),memberBasic.getId());
            //游记及详情、点赞、浏览量、评论数、收藏数
            map.put("travelNote", travelNote);
//            messageData.setStatus(200);
//            messageData.setMessage("查询成功");
            messageData.setObj(map);
        }else {
            messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
            messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
        }
        return messageData;
        
    }
}
