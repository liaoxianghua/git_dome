 
package com.spring.scenic.search.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.search.application.HistorySearchService;
import com.spring.scenic.search.application.SearchService;
import com.spring.scenic.search.domain.HistorySearch;
import com.spring.scenic.search.domain.vo.ProductCategoryVo;
import com.spring.scenic.search.domain.vo.QuickSearchCategoryVo;
import com.spring.scenic.search.domain.vo.SearhResult;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;


/**
 * 搜索接口
 */
@Controller
@RequestMapping("search")
@Api(value = "搜索页面", description = "搜索页面数据初始化")
public class SearchController extends BaseController{
	
    @Autowired
    private HistorySearchService historySearchService;
    
    @Autowired
    private KeywordService keywordService;
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private TravelNoteService travelNoteService;
    
    @Autowired
    private SearchService searchService;
    
    private Logger logger = LoggerFactory.getLogger(SearchController.class);
    
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value="init",method=RequestMethod.POST)
	@ApiOperation(httpMethod = "POST",value = "搜索页数据初始化", notes = "热搜、历史搜索", produces = MediaType.APPLICATION_JSON_VALUE)
	public MessageData init(HttpServletRequest request,HttpSession httpSession){
	    try {
	        logger.info(httpSession.getId());
	        Map<String,Object> map = new HashMap<String,Object>();
	        HistorySearch historySearchExample = new HistorySearch();
	        historySearchExample.setSessionId(httpSession.getId());
	        MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession);
	        if(onlineMember!=null){
	            historySearchExample.setMemberId(onlineMember.getId());
	        }
	        map.put("search_history", historySearchService.getHistorySearchList(historySearchExample));
	        map.put("search_hot", keywordService.getHotSearchKeyword());
	        //map.put("city_hot", keywordService.getHotCityKeyword());
	        return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
	    } catch (Exception e) {
	        e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
	}
	
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="destory",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "清空历史搜索", notes = "清空历史搜索未登陆的清空session，登陆的清空数据库", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData destory(HttpServletRequest request,HttpSession httpSession){
        try {
            logger.info(httpSession.getId());
            HistorySearch historySearchExample = new HistorySearch();
            MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(onlineMember!=null){
                historySearchExample.setMemberId(onlineMember.getId());
            }
            historySearchExample.setSessionId(httpSession==null?null:httpSession.getId());
            historySearchService.deleteHistorySearch(historySearchExample);
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
	
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="prepareSearch",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "首页搜索框预加载{keyword}联想的搜索结果（范围：城市的首字母、简拼、拼音、城市名、及关键字名称）", notes = "有结果按联想的格式显示；无结果显示“无”，提供“产品”、“游记攻略”参考项", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "keyword", value = "关键字：可为空，为空返回默认产品或游记攻略", required = false, dataType = "String", paramType = "query"),
    })
    public MessageData prepareSearch(HttpServletRequest request,HttpSession httpSession,String keyword){
        try {
            Map<String,Object> map = new HashMap<String,Object>();
            if(StringUtils.isNotBlank(keyword)){
                //查询搜索关键字匹配的词，再组合成产品、游记攻略分配
                keyword = keyword.trim().replace(" ", "");
                List<SearhResult> searhResults = new ArrayList<SearhResult>();
                List<Keyword> matchKeywords =  keywordService.getMatchKeywords(keyword);
                if(matchKeywords==null || matchKeywords.isEmpty()){
                    SearhResult productAllSearhResult = new SearhResult();
                    productAllSearhResult.setTitle(SysEnum.COMMON_TYPE_PRODUCT.getDescription());
                    productAllSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_PRODUCT.getCode()));
                    
                    SearhResult travelNoteAllSearhResult = new SearhResult();
                    travelNoteAllSearhResult.setTitle(SysEnum.COMMON_TYPE_TRAVELNOTE.getDescription());
                    travelNoteAllSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_TRAVELNOTE.getCode()));
                    
                    List<SearhResult> allSearhResults = new ArrayList<SearhResult>();
                    allSearhResults.add(productAllSearhResult);
                    allSearhResults.add(travelNoteAllSearhResult);
                    map.put("prepareSearch", null);
                    map.put("allSearch", allSearhResults);
                    return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
                }else{
                    for (Keyword matchKeyword : matchKeywords) {
                        SearhResult productSearhResult = new SearhResult();
                        productSearhResult.setName(matchKeyword.getName());
                        productSearhResult.setTitle("关于"+matchKeyword.getName()+"的全部产品");
                        productSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_PRODUCT.getCode()));
                        searhResults.add(productSearhResult);
                        SearhResult travelNoteSearhResult = new SearhResult();
                        travelNoteSearhResult.setName(matchKeyword.getName());
                        travelNoteSearhResult.setTitle("关于"+matchKeyword.getName()+"全部游记攻略");
                        travelNoteSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_TRAVELNOTE.getCode()));
                        searhResults.add(travelNoteSearhResult);
                    }
                    map.put("prepareSearch", searhResults);
                    map.put("allSearch", null);
                    return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
                }
            }else{
                SearhResult productAllSearhResult = new SearhResult();
                productAllSearhResult.setTitle(SysEnum.COMMON_TYPE_PRODUCT.getDescription());
                productAllSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_PRODUCT.getCode()));
                
                SearhResult travelNoteAllSearhResult = new SearhResult();
                travelNoteAllSearhResult.setTitle(SysEnum.COMMON_TYPE_TRAVELNOTE.getDescription());
                travelNoteAllSearhResult.setType(Integer.valueOf(SysEnum.COMMON_TYPE_TRAVELNOTE.getCode()));
                
                List<SearhResult> allSearhResults = new ArrayList<SearhResult>();
                allSearhResults.add(productAllSearhResult);
                allSearhResults.add(travelNoteAllSearhResult);
                map.put("prepareSearch", null);
                map.put("allSearch", allSearhResults);
                return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="quickSearch",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "快速搜索接口", notes = "快速搜索：通过点击搜索或历史、热搜进入产品（无二级细分的所有产品）或游记攻略（无细分所有游记攻略）列表界面", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "keyword", value = "关键字", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "pageNum", value = "第几页", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "pageSize", value = "每页显示多少", required = true, dataType = "Integer", paramType = "query")
        //@ApiImplicitParam(name = "type", value = "查询类别：1、产品（默认）；2：游记攻略(通过点击搜索关键字或者‘搜索’按钮进入，此时会存在产品和游记攻略的大分类,显示所有匹配的结果)", required = false, dataType = "Integer", paramType = "query"),
        //@ApiImplicitParam(name = "productType", value = "产品一级类别：type=1时才使用，可不传（即全部）", required = false, dataType = "Integer", paramType = "query"),
        //@ApiImplicitParam(name = "productSubType", value = "产品二级类别：productType不为空时必传", required = false, dataType = "Integer", paramType = "query")
    })
    public MessageData quickSearch(HttpServletRequest request,HttpSession httpSession,String keyword,Integer type,Integer productType,Integer productSubType,Integer pageNum,Integer pageSize,String cityName){
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("keyword", keyword);
            Product product = new Product();
            product.setPageNum(pageNum);
            product.setPageSize(pageSize);
            product.setKeyword(keyword);
            TravelNotes travelNote = new TravelNotes();
            travelNote.setPageNum(pageNum);
            travelNote.setPageSize(pageSize);
            travelNote.setKeyword(keyword);
            travelNote.setCityName(cityName);
            map.put("type", type);
            map.put("pagination", true);
            //初始化产品(及产品二级列表)、游记攻略Tab数据
            List<ProductCategoryVo> productCategorys = productService.initProductCategorys(productType,productSubType);
            map.put("productTypes", productCategorys);
            //无搜索条件默认普通分页
            if(StringUtils.isBlank(keyword)){
                List<Product> allProducts = searchService.getProductList(product, true);
                PageInfo<Product> productsPage = new PageInfo<Product>(allProducts, product.getPageSize());
                map.put("products", productsPage);
                List<TravelNotes> travelNotes = travelNoteService.searchTravelNoteList(travelNote, true);
                PageInfo<TravelNotes> travelNotesPage = new PageInfo<TravelNotes>(travelNotes, travelNote.getPageSize());
                map.put("travelnotes", travelNotesPage);
            }else{//有搜索条件，保存搜索历史，按搜索逻辑分页
                //关键字不为空：保存搜索历史
                MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession); 
                HistorySearch historySearch = new HistorySearch();
                historySearch.setCreateTime(new Date());
                historySearch.setKeyword(keyword.trim());
                if(onlineMember!=null){
                    historySearch.setMemberId(onlineMember.getId());
                }
                historySearch.setSessionId(httpSession.getId());
                historySearchService.saveHistorySearch(historySearch);
                //产品
                List<Product> allProducts = searchService.searchProduct(product,true);
                PageInfo<Product> searchProductsPage = new PageInfo<Product>(allProducts, product.getPageSize());
                map.put("products", searchProductsPage); 
                //游记攻略
                List<TravelNotes> travelNotes = travelNoteService.searchTravelNoteList(travelNote, true);
                PageInfo<TravelNotes> travelNotesPage = new PageInfo<TravelNotes>(travelNotes, travelNote.getPageSize());
                map.put("travelnotes", travelNotesPage);
            }
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 同一标签下的产品排列时当前城市的在最上面，按（180天内）销量从高到低排序
     * 游记或攻略的结果显示时当前城市的在最上面，浏览量从高到低排序。
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="indexSearch",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "产品、游记攻略页搜索接口", notes = "通过点击搜索提示栏进入搜索关键字分页搜索产品或游记攻略", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "cityName", value = "当前城市", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "keyword", value = "关键字", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "type", value = "查询类别：1、产品（默认）；2：游记攻略", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "productType", value = "产品一级类别：type=1时才使用，可不传（即全部）", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "productSubType", value = "产品二级类别：productType不为空时必传", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "pageNum", value = "第几页", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "pageSize", value = "每页显示多少", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData indexSearch(HttpServletRequest request,HttpSession httpSession,String cityName,String keyword,Integer type,Integer productType,Integer productSubType,Integer pageNum,Integer pageSize){
        try {
            if(StringUtils.isBlank(cityName)){
                cityName = BisConstant.LOCATION_CITY_DEFAULT;
            }
            keyword = keyword ==null ? null : keyword.trim();
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("keyword", keyword);
            map.put("productType", productType);
            map.put("productSubType", productSubType);
            map.put("pagination", true);
            map.put("type", type);
            Product product = new Product();
            product.setPageNum(pageNum);
            product.setPageSize(pageSize);
            product.setKeyword(keyword);
            product.setCityName(cityName);
            product.setProductType(productType);
            product.setProductSubType(productSubType);
            TravelNotes travelNote = new TravelNotes();
            travelNote.setSessionId(httpSession.getId());
            travelNote.setPageNum(pageNum);
            travelNote.setPageSize(pageSize);
            travelNote.setKeyword(keyword);
            travelNote.setCityName(cityName);
//            if(false){//未输入关键字：默认产品
//                if(type == 1){ //产品
//                    List<ProductCategoryVo> productCategorys = productService.initProductCategorys(productType,productSubType);
//                    map.put("productTypes", productCategorys);
//                    List<Product> allProducts = searchService.getProductList(product, true);
//                    PageInfo<Product> productsPage = new PageInfo<Product>(allProducts, product.getPageSize());
//                    map.put("products", productsPage);
//                }else if(type == 2){//游记攻略
//                    List<TravelNotes> travelNotes = travelNoteService.searchTravelNoteList(travelNote, true);
//                    PageInfo<TravelNotes> travelNotesPage = new PageInfo<TravelNotes>(travelNotes, travelNote.getPageSize());
//                    map.put("travelnotes", travelNotesPage);
//                }
//                return new MessageData(SysConstant.SUCCESS, SysConstant.SUCCESS_MESSAGE,map);
//            }else{//有搜索条件，保存搜索历史，按搜索逻辑分页
                //关键字不为空：保存搜索历史
            	MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession); 
                if(StringUtils.isNotBlank(keyword)){
                    HistorySearch historySearch = new HistorySearch();
                    historySearch.setCreateTime(new Date());
                    historySearch.setKeyword(keyword);
                    if(onlineMember!=null){
                        historySearch.setMemberId(onlineMember.getId());
                    }
                    historySearch.setSessionId(httpSession.getId());
                    historySearchService.saveHistorySearch(historySearch);
                }
                if(onlineMember != null){
                	travelNote.setUserId(String.valueOf(onlineMember.getId()));
                }
                List<ProductCategoryVo> productCategorys = productService.initProductCategorys(productType,productSubType);
                if(type==null){
                    map.put("productTypes", productCategorys);
                    List<Product> allProducts = searchService.searchProduct(product,true);
                    PageInfo<Product> searchProductsPage = new PageInfo<Product>(allProducts, product.getPageSize());
                    map.put("products", searchProductsPage); 
                    List<TravelNotes> travelNotes = travelNoteService.searchTravelNoteList(travelNote, true);
                    PageInfo<TravelNotes> travelNotesPage = new PageInfo<TravelNotes>(travelNotes, travelNote.getPageSize());
                    map.put("travelnotes", travelNotesPage);
                }else{
                    //产品
                    if(type==1){
                        map.put("productTypes", productCategorys);
                        List<Product> allProducts = searchService.searchProduct(product,true);
                        PageInfo<Product> searchProductsPage = new PageInfo<Product>(allProducts, product.getPageSize());
                        map.put("products", searchProductsPage); 
                    }else if(type==2){//游记攻略
                        List<TravelNotes> travelNotes = travelNoteService.searchTravelNoteList(travelNote, true);
                        PageInfo<TravelNotes> travelNotesPage = new PageInfo<TravelNotes>(travelNotes, travelNote.getPageSize());
                        map.put("travelnotes", travelNotesPage);
                    }
                }
                return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,map);
           // }
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }

    /**
     * 初始化产品、游记攻略大类别
     */
    private List<QuickSearchCategoryVo> initQuickSearchCategorys(Integer type) {
        List<QuickSearchCategoryVo> categoryVos = new ArrayList<QuickSearchCategoryVo>();
        QuickSearchCategoryVo product = new QuickSearchCategoryVo();
        product.setType(1);
        product.setName("产品");
        product.setActive((type!=null && type ==1)?true:false);
        categoryVos.add(product);
        QuickSearchCategoryVo travelNote = new QuickSearchCategoryVo();
        travelNote.setType(2);
        travelNote.setName("游记攻略");
        travelNote.setActive((type!=null && type ==2)?true:false);
        categoryVos.add(travelNote);
        
        return categoryVos;
    }

}
