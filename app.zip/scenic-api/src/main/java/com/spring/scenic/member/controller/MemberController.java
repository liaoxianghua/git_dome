 
package com.spring.scenic.member.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.basic.application.CountryService;
import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.content.domain.vo.MyCommentVo;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.application.MemberAddressService;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.application.MemberFeedbackService;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberAddress;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberMsg;
import com.spring.scenic.member.domain.vo.MyConllectionOfProduct;
import com.spring.scenic.member.domain.vo.MyConllectionOfTravel;
import com.spring.scenic.praise.application.PushPraiseService;
import com.spring.scenic.praise.domain.MyPushPraise;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;


/**
 * 会员模块接口
 */

@Controller
@RequestMapping("member")
@Api(value = "memberController", description = "会员模块接口")
public class MemberController extends BaseController{
	
	@Resource
	private TravelNotesCommentService travelNotesCommentService;
	@Resource
	private PushPraiseService pushPraiseService;
	@Resource
	private MemberCollectionService membercollectionService;
	@Resource
	private MemberMsgService memberMsgService;
	@Resource
	private MemberBasicService memberBasicService;
	@Resource
	private MemberFeedbackService memberFeedbackService;
	@Autowired
    MemberDetailInfoService memberDetailInfoService;
    @Autowired
    CountryService countryService;
    @Autowired
    DictionaryService dictionaryService;
    @Autowired
    MemberAddressService memberAddressService;
    
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateMemberInfo",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询单个会员常旅客信息", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "imageUrl", value = "会员头像", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nameCh", value = "会员姓名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "phoneCh", value = "会员手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "sex", value = "性别", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "birthDay", value = "生日", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "countryId", value = "国家id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "provinceId", value = "省份id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "cityId", value = "城市id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "mail", value = "邮箱", required = false, dataType = "String", paramType = "query")
    })
    public MessageData updateMemberInfo(HttpServletRequest request,HttpServletResponse response,String imageUrl,String nameCh,String phoneCh,Integer sex,String birthDay,Integer countryId,Integer provinceId,Integer cityId,String mail){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) { 
                Integer memberId = memberBasic.getId();
                messageData = memberBasicService.updateMemberInfo(memberId,imageUrl,nameCh,phoneCh,sex,birthDay,countryId,provinceId,cityId,mail);
                if(null!=messageData.getObj()) {
                    MemberBasic member = (MemberBasic) messageData.getObj();
                    request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                    String cityName = member.getCityName();
                    if(StringUtil.isNotEmpty(cityName)) {
                        request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,cityName);
                    }else {
                        request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,"上海");
                    }
                    messageData.setStatus(200);
                    messageData.setMessage("更新成功");
                }
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
	/**
	 * 	我的收藏
	 * 此处为类方法说明
	 * @param request
	 * @param session
	 * @param memberId
	 * @return
	 * @creator ：xiangbin 
	 * @date ：2017年5月4日下午8:50:24
	 */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="listMyCollection",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的收藏", notes = "产品内容、游记内容", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "collectionType", value = "收藏类型", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData collections(HttpServletRequest request,HttpSession session,Integer collectionType){
    	try {
    		MessageData data=new MessageData(200, "成功");
    		MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(session);
    		if(null!=onlineMember) {
    		    Map<String,Object> map=new HashMap<String,Object>();
    		    Integer memberId = onlineMember.getId();
    		    MaterialtravelsVo materialtravelsVo = new MaterialtravelsVo();
    		    materialtravelsVo.setUserId(memberId);
    		    materialtravelsVo.setSessionId(session.getId());
    		    if(collectionType==2){
    		        List<MyConllectionOfTravel> myConllectionOfTravel  = membercollectionService.selectMyConllectionOfTravel(materialtravelsVo);//我的收藏游记攻略列表
    		        map.put("myConllectionOfTravel", myConllectionOfTravel);
    		    }else if(collectionType==1){
    		        List<MyConllectionOfProduct> myPushPraiseOfProduct  = membercollectionService.selectPushPraiseListOfProduct(memberId);//我的收藏产品列表
    		        map.put("myPushPraiseOfProduct", myPushPraiseOfProduct);
    		    }
    		    data.setObj(map);
    		}else {
    		    data.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
    		    data.setMessage("该用户未登录");
    		}
    		return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="listMyLikeList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的点赞列表", notes = "点赞列表", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "memberId", value = "会员id", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData myLikeList(HttpServletRequest request,HttpSession httpSession,Integer memberId){
    	try {
    		MessageData data=new MessageData(200, "成功");
    		MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession);
    		//Integer memberId = onlineMember.getId();
    		Map<String,Object> map=new HashMap<String,Object>();
    		List<MyPushPraise> myPushPraiseOfTravle  = pushPraiseService.selectPushPraiseListOfTravle(memberId);//我的游记攻略点赞列表
    		map.put("myPushPraiseOfTravle", myPushPraiseOfTravle);
    		List<MyPushPraise> myPushPraiseOfProduct  = pushPraiseService.selectPushPraiseListOfProduct(memberId);//我的产品点赞列表
    		map.put("myPushPraiseOfProduct", myPushPraiseOfProduct);
    		data.setObj(map);
    		return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    /**
     * 
     * 此处为类方法说明
     * @param request
     * @param httpSession
     * @param ids
     * @return
     * @creator ：xiangbin  
     * @date ：2017年5月8日下午2:57:52
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="deleteMyLike",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "删除我的点赞", notes = "长按可以批量删除", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    })
    public MessageData deleteMyLike(HttpServletRequest request,HttpSession httpSession,String ids){
        List<String> delList = new ArrayList<String>();
        String[] strs = ids.split(",");
        for (String str : strs) {
            delList.add(str);
        }
    	try {
    		MessageData messageData=new MessageData(200, "成功");
    		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
            	messageData = pushPraiseService.deleteMyPushPraise(delList);
            }else{
            	messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
            	messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="listMyComment",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的评论列表", notes = "评论信息", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "commentUser", value = "会员", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData myComment(HttpServletRequest request,Integer commentUser){
    	try {
    		MessageData data=new MessageData(200, "成功");
    		Map<String,Object> map=new HashMap<String,Object>();
    		List<MyCommentVo> myCommentVoOfTravel = travelNotesCommentService.selectCommentOfTravel(commentUser);//我的游记攻略列表
    		map.put("myCommentVoOfTravel", myCommentVoOfTravel);
    		List<MyCommentVo> myCommentVoOfProduct = travelNotesCommentService.selectCommentOfProduct(commentUser);//我的产品评论列表
    		map.put("myCommentVoOfProduct", myCommentVoOfProduct);
    		data.setObj(map);
	    	return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }

    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="deleteMyComment",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "删除我的评论", notes = "长按可以批量删除", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    })
    public MessageData deleteMyComment(HttpServletRequest request,HttpSession httpSession,String ids){
        List<String> delList = new ArrayList<String>();
        String[] strs = ids.split(",");
        for (String str : strs) {
            delList.add(str);
        }
    	try {
    		MessageData messageData=new MessageData(200, "成功");
    		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
            	messageData = travelNotesCommentService.deleteMyComment(delList);
            }else{
            	messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
            	messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectMyReceiveInform",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我收到系统的通知", notes = "系统通知的标题和内容", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "memberId", value = "会员id", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData myReceiveInform(HttpServletRequest request,HttpSession httpSession,Integer memberId){
    	try {
    		MessageData data=new MessageData(200, "成功");
    		MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(httpSession);
    		//Integer memberId = onlineMember.getId();
    		Map<String,Object> map=new HashMap<String,Object>();
    		List<MemberMsg> memberMsgs = memberMsgService.selectMemberMsg(memberId);
    		map.put("memberMsg", memberMsgs);
    		data.setObj(map);
	    	return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectMyReceiveInformDetails",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我收到的系统通知详情", notes = "详细标题和内容", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "memberId", value = "会员id", required = true, dataType = "Integer", paramType = "query"),
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData myReceiveInformDetails(HttpServletRequest request,Integer memberId,Integer id){
    	MemberMsg memberMsg = new MemberMsg();
    	memberMsg.setId(id);
    	memberMsg.setMemberId(memberId);
    	try {
    		MessageData data=new MessageData(200, "成功");
    		Map<String,Object> map=new HashMap<String,Object>();
    		MemberMsg memberMsgDetails = memberMsgService.selectSystemNoticeDetail(id);
    		map.put("memberMsg", memberMsgDetails);
    		data.setObj(map);
	    	return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateMyCommentInform",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的评论通知", notes = "产品和游记攻略", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer", paramType = "query"),
    @ApiImplicitParam(name = "receiveComment", value = "接受、拒绝评论(1、接受；0：拒绝)", required = true, dataType = "Integer", paramType = "query"),
    })
    //新注册的会员的评论通知为默认的开启状态(1)
    public MessageData myCommentInform(HttpServletRequest request,Integer id,Integer receiveComment){
    	//通过更改状态(状态关闭)查询出的评论只能是之前的,(状态开启)查询出的评论就是数据最新的
    	MemberBasic memberBasic = new MemberBasic();
    	memberBasic.setId(id);
    	memberBasic.setReceiveComment(receiveComment);
    	memberBasic.setReceiveCommentStart(new Date());
    	try {
    		MessageData data=new MessageData(200, "成功");
    		Map<String,Object> map=new HashMap<String,Object>();
    		MessageData member = memberBasicService.updateCommentState(memberBasic);
    		map.put("memberBasic", member);
    		data.setObj(map);
	    	return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateMyLikeInform",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "我的点赞通知", notes = "产品和游记攻略", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer", paramType = "query"),
    @ApiImplicitParam(name = "receivePrasie", value = "接受、拒绝点赞(1、接受；0：拒绝)", required = true, dataType = "Integer", paramType = "query"),
    })
    //新注册的会员的点赞通知为默认的开启状态(1)
    public MessageData myLikeInform(HttpServletRequest request,Integer id,Integer receivePrasie){
    	//更改状态(状态关闭)然后查询出的点赞只能是之前的,(状态开启)查询出的点赞就是数据库最新的
    	MemberBasic memberBasic = new MemberBasic();
    	memberBasic.setId(id);
    	memberBasic.setReceivePrasie(receivePrasie);
    	memberBasic.setReceivePrasieStart(new Date());
    	try {
    		MessageData data=new MessageData(200, "成功");
    		Map<String,Object> map=new HashMap<String,Object>();
    		MessageData member = memberBasicService.updatePrasieState(memberBasic);
    		map.put("memberBasic", member);
    		data.setObj(map);
	    	return data;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    /**
     * 
     * 此处为类方法说明:用户意见反馈:文件名、文件url以字符串接收，用","隔开
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月4日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="addMemberfeedback",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员意见反馈", notes = "会员意见或建议及照片上传", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "feedbackContent", value = "反馈信息内容", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "linkPhone", value = "联系电话", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "imgUrls", value = "图片url以字符串接收，用逗号隔开", required = false, dataType = "String", paramType = "query")
    })
    public MessageData feedback(HttpServletRequest request,HttpSession httpSession,String feedbackContent,String linkPhone,String imgUrls){        
        try {
            MessageData messageData = new MessageData(null,null);
            Integer memberId = null;
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                memberId = memberBasic.getId();
            }
            messageData = memberFeedbackService.addMemberFeedback(memberId,feedbackContent,linkPhone,imgUrls);
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:查询会员常旅客信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCommonTripManList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询会员常旅客信息列表", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectCommonTripManList(HttpServletRequest request,HttpServletResponse response){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
                Map <String,Object> dataMap = new HashMap<String,Object>(); 
                List<MemberDetailInfo> commonTripManList = memberDetailInfoService.selectCommonTripManList(memberBasic);
                dataMap.put("commonTripManList", commonTripManList);
                messageData.setStatus(200);
                messageData.setMessage("查询成功");
                messageData.setObj(dataMap);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 
     * 此处为类方法说明：根据id查询单个会员常旅客信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCommonTripManInfo",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询单个会员常旅客信息", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "passengerId", value = "出行人id", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData selectCommonTripManInfo(HttpServletRequest request,HttpServletResponse response,Integer passengerId){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
                MemberDetailInfo memberDetailInfo = new MemberDetailInfo();
                Map <String,Object> dataMap = new HashMap<String,Object>(); 
                memberDetailInfo.setId(passengerId);
                MemberDetailInfo commonTripManInfo = memberDetailInfoService.selectcommonTripManInfo(memberDetailInfo);
                dataMap.put("commonTripManInfo", commonTripManInfo);
                messageData.setStatus(200);
                messageData.setMessage("查询成功");
                messageData.setObj(dataMap);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：会员常旅客页面国家信息下拉框查询
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCuntryList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询国家信息集合", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectCuntryList(HttpServletRequest request,HttpServletResponse response){
        try {
            MessageData messageData = new MessageData(null, null, null);
            Map <String,Object> dataMap = new HashMap<String,Object>(); 
            List<Country> countryList = countryService.selectCuntryList();
            dataMap.put("countryList", countryList);
            messageData.setStatus(200);
            messageData.setMessage("查询成功");
            messageData.setObj(dataMap);
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：会员常旅客页面证件类型下拉框查询
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCredentialTypes",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询证件类型集合", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectCredentialTypes(HttpServletRequest request,HttpServletResponse response){
        try {
            MessageData messageData = new MessageData(null, null, null);
            Map <String,Object> dataMap = new HashMap<String,Object>(); 
            Dictionary dictionary = new Dictionary();
            dictionary.setCode("CREDENTIALS_TYPE");
            List<Dictionary> credentialTypes = dictionaryService.getDictionaryListByCode(dictionary);
            dataMap.put("credentialTypes", credentialTypes);
            messageData.setStatus(200);
            messageData.setMessage("查询成功");
            messageData.setObj(dataMap);
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：新增常旅客信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="addCommonTripMan",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网新增常旅客接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "nameCh", value = "中文姓名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nameEnF", value = "英文姓", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nameEnS", value = "英文名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "sex", value = "性别1:男 0:女", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "phoneCh", value = "手机号码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nationality", value = "国籍", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "documentType", value = "证件类型", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "documentNo", value = "证件号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "isSelf", value = "设置为本人（1：是，0：否）", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "birthdayDate", value = "出生日期", required = true, dataType = "String", paramType = "query")
    })
    public MessageData addCommonTripMan(HttpServletRequest request,HttpServletResponse response,String nameCh,String nameEnF,
        String nameEnS,Integer sex,String phoneCh,Integer nationality,Integer documentType,String documentNo,Integer isSelf,String birthdayDate){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                messageData = memberDetailInfoService.addCommonTripMan(memberId, nameCh, nameEnF, nameEnS, sex, phoneCh,nationality, documentType, documentNo, isSelf, birthdayDate);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateCommonTripMan",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网新增常旅客接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "passengerId", value = "常旅客id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "nameCh", value = "中文姓名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nameEnF", value = "英文姓", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nameEnS", value = "英文名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "sex", value = "性别", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "phoneCh", value = "手机号码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "nationality", value = "国籍", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "isSelf", value = "设置为本人（1：是，0：否）", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "birthdayDate", value = "出生日期", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "documentId", value = "证件id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "documentType", value = "证件类型", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "documentNo", value = "证件号", required = true, dataType = "String", paramType = "query")
    })
    public MessageData updateCommonTripMan(HttpServletRequest request,HttpServletResponse response,Integer passengerId,Integer documentId,String nameCh,String nameEnF,
        String nameEnS,Integer sex,String phoneCh,Integer nationality,Integer documentType,String documentNo,Integer isSelf,String birthdayDate){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                messageData = memberDetailInfoService.updateCommonTripMan(passengerId,documentId,memberId,nameCh,nameEnF,nameEnS,sex,phoneCh,nationality,documentType,documentNo,isSelf,birthdayDate);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：删除常旅客信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月1日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="deleteCommonTripMan",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端删除常旅客接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "passengerId", value = "常旅客id", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData deleteCommonTripMan(HttpServletRequest request,HttpServletResponse response,Integer passengerId){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
                messageData = memberDetailInfoService.deleteCommonTripMan(passengerId);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：新增常用地址
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="addCommonAddress",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网新增会员常用地址接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "receiveName", value = "收件人姓名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "receivePhone", value = "联系手机", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "addressDetail", value = "详细地址", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "postCode", value = "邮政编码", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "countryId", value = "性别", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "provinceId", value = "省份id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "cityId", value = "出行人id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "isDefault", value = "是否设置为默认地址 1:是 0：否", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData addCommonAddress(HttpServletRequest request,HttpServletResponse response,String receiveName,String receivePhone,
        String addressDetail,String postCode,Integer countryId,Integer provinceId,Integer cityId,Integer isDefault){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                messageData = memberAddressService.addCommonAddress(memberId, receiveName, receivePhone, addressDetail, postCode, countryId, provinceId, cityId, isDefault);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }

    /**
     * 
     * 此处为类方法说明：更新常用地址
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateCommonAddress",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网新增会员常用地址接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "addressId", value = "常用地址ID", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "receiveName", value = "收件人姓名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "receivePhone", value = "联系手机", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "addressDetail", value = "详细地址", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "postCode", value = "邮政编码", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "countryId", value = "性别", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "provinceId", value = "省份id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "cityId", value = "出行人id", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "isDefault", value = "是否设置为默认地址 1:是 0：否", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData updateCommonAddress(HttpServletRequest request,HttpServletResponse response,Integer addressId,String receiveName,String receivePhone,
        String addressDetail,String postCode,Integer countryId,Integer provinceId,Integer cityId,Integer isDefault){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                messageData = memberAddressService.updateCommonAddress(memberId,addressId, receiveName, receivePhone, addressDetail, postCode, countryId, provinceId, cityId, isDefault);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：根据主键id查询常用地址信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCommonAddressInfo",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询单个会员常旅客信息", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "addressId", value = "出行人id", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData selectCommonAddressInfo(HttpServletRequest request,HttpServletResponse response,Integer addressId){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) { 
                Map <String,Object> dataMap = new HashMap<String,Object>(); 
                MemberAddress memberAddressInfo = memberAddressService.selectCommonAddressInfo(addressId);
                dataMap.put("memberAddressInfo", memberAddressInfo);
                messageData.setStatus(200);
                messageData.setMessage("查询成功");
                messageData.setObj(dataMap);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:根据会员id查询常用地址信息集合
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月2日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="selectCommonAddressList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端查询单个会员常旅客信息", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectCommonAddressList(HttpServletRequest request,HttpServletResponse response){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                Map <String,Object> dataMap = new HashMap<String,Object>(); 
                List<MemberAddress> memberAddressList = memberAddressService.selectCommonAddressList(memberId);
                dataMap.put("memberAddressList", memberAddressList);
                messageData.setStatus(200);
                messageData.setMessage("查询成功");
                messageData.setObj(dataMap);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="deleteCommonAddress",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端删除常旅客接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "addressId", value = "出行人id", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData deleteCommonAddress(HttpServletRequest request,HttpServletResponse response,Integer addressId){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic && null!=memberBasic.getId()) {
                messageData = memberAddressService.deleteCommonAddress(addressId);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            return messageData;
        } catch (Exception e) {
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 
     * 收藏方法
     * @param request
     * @param collectionType
     * @param collectionContentId
     * @param deleted
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月2日上午10:49:47
     */
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "myCollectionEdit", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "收藏方法", notes = "产品或者游记攻略 收藏或者取消收藏", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "collectionType", value = "收藏类别 1产品,2游记攻略", required = true, dataType = "Integer", paramType = "query"),
			@ApiImplicitParam(name = "collectionContentId", value = "收藏内容的ID", required = true, dataType = "Integer", paramType = "query"),
	})
	public MessageData memberCollection(HttpServletRequest request, Integer collectionType,Integer collectionContentId) {
		try {
		    if(collectionType==null || collectionContentId==null){
		        return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_PARAMETER_ERROR); 
		    }
            MemberBasic onlineMember = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if (onlineMember == null) {
            	return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
            }
            MemberCollection membercollection = new MemberCollection();
            membercollection.setMemberId(onlineMember.getId());
            membercollection.setCollectionType(collectionType);
            membercollection.setCollectionContentId(collectionContentId);
            int collectCount = membercollectionService.getMemberCollectCount(membercollection);
        	if(collectCount>0){//取消收藏
                membercollectionService.delete(onlineMember.getId(), collectionType, collectionContentId);
                return new MessageData(SysConstant.SUCCESS, "取消成功"); 
        	}else{//收藏
        	    membercollectionService.add(onlineMember.getId(), collectionType, collectionContentId);
                return new MessageData(SysConstant.SUCCESS, "收藏成功");
        	}
        } catch (Exception e) {
            e.printStackTrace();
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_EXCEPTION);
        }
	}
    
    /**
	 * 
	 * 此处为类方法说明:根据memberId查询会员基本信息
	 * @param request
	 * @param response
	 * @return
	 * @creator ：dengyan  
	 * @date ：2017年5月4日下午1:49:49
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "selectMemberInfo", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "M网终端查询单个会员基本信息", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
	public MessageData selectMemberInfo(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			MessageData messageData = new MessageData(null, null, null);
			MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
			if (null != memberBasic) {
				Integer memberId = memberBasic.getId();
				MemberBasic memberBasicInfo = memberBasicService.selectMemberInfo(memberId);
				messageData.setStatus(200);
				messageData.setMessage("查询成功");
				messageData.setObj(memberBasicInfo);
			} else {
				messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
				messageData.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
			}
			return messageData;
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
		}
	}

}

