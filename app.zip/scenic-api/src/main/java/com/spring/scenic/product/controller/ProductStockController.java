package com.spring.scenic.product.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.ProductStock;

/**
 * 产品套餐库存controller
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年4月28日
 */
@Controller
@RequestMapping(value = "/productStock")
@Api(value = "productStockController", description = "库存接口")
public class ProductStockController {

	Logger logger = LoggerFactory.getLogger(ProductStockController.class);

	@Resource
	private ProductStockService productStockService;

	/**
	 * 根据套餐ID和出行月查询库存
	 * @param playMonth
	 * @param mealsId
	 * @creator ：liaoxianghua  
	 * @date ：2017年4月28日下午5:09:46
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectListByParams",method=RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "通过参数查询产品列表", notes = "author liaoxianghua", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "mealsId", value = "套餐ID", dataType = "Integer", paramType = "query", required = true),
			@ApiImplicitParam(name = "playMonth", value = "出行月 YYYYMM", dataType = "Date", paramType = "query", required = true) })
	public MessageData selectListByParams(String playMonth, Integer mealsId) {
		if(mealsId == null){
			return new MessageData(SysConstant.FAILURE, "套餐ID不能为空");
		}
		if(StringUtil.isEmpty(playMonth)){
			return new MessageData(SysConstant.FAILURE, "出行月不能为空");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		ProductStock productStock = new ProductStock();
		productStock.setPlayDay(StringToDate(playMonth));
		productStock.setMealsId(mealsId);
		List<ProductStock> list = productStockService.selectMonthAll(productStock);
		map.put("listStock", list);
		return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
	}

	public Date StringToDate(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		Date date = null;
		try {
			String reg = "[\u4e00-\u9fa5]";
			Pattern pat = Pattern.compile(reg);
			Matcher mat = pat.matcher(time);
			String repickStr = mat.replaceAll("");
			date = sdf.parse(repickStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
