package com.spring.scenic.security;

import javax.servlet.http.HttpSession;

import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.member.domain.MemberBasic;

public class MemberAuthentiction {
    
    /**
     * 获取会话会员
     */
    public static MemberBasic getOnlineMemeber(HttpSession httpSession){
        try {
            Object object = httpSession.getAttribute(BisConstant.SESSION_MEMBER);
            return object == null ? null : (MemberBasic)object;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取用户城市，默认上海
     */
    public static String getDefaultCity(HttpSession httpSession) {
        Object object = httpSession.getAttribute(BisConstant.SESSION_LOCATION_CITY);
        return object == null ? "上海" : (String)object;
    }

}
