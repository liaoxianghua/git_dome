 
package com.spring.scenic.strategy.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesDetailVo;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesDetailStrategyVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesStrategyVo;


/**
 * 
 * 此处为类说明: 游记攻略
 * @author lzj
 * @date  2017年5月3日18:32:18
 */
@Controller
@RequestMapping("mystrategy")
@Api(value = "MyStrategyController", description = "游记攻略接口")
public class StrategyController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(StrategyController.class);
    
    @Resource
    private MaterialService materialservice;
    @Resource
    private TravelNoteService travelNoteservice;
 
 
    
	@ResponseBody
	@RequestMapping(value = "listMyStrategy", method = RequestMethod.GET)
	@ApiOperation(value = "我的游记攻略列表", notes = "我的游记攻略列表")
	@CrossOrigin
	public MessageData listMyStrategy(HttpServletRequest request, 
		    @ApiParam(name = "pageSize", value = "每页长度",required=true) @RequestParam Integer pageSize,
		    @ApiParam(name = "pageNum", value = "页码",required=true) @RequestParam Integer pageNum,
		    @ApiParam(name = "city", value = "城市名称",required=true) @RequestParam String city,HttpSession session){
		MessageData data=new MessageData(200, "成功");
		MaterialtravelsVo materialtravelsVo=new MaterialtravelsVo();
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
	    try {
	        //TODO
	        //if(StringUtils.isBlank(city)){
//	            city = BisConstant.LOCATION_CITY_DEFAULT;
	        //}

 
			materialtravelsVo.setCityName(city);
			materialtravelsVo.setStatus(1);
			materialtravelsVo.setPageNum(pageNum == null ? 1 :pageNum);
			materialtravelsVo.setPageSize(pageSize == null ? 10 :pageSize);
			materialtravelsVo.setMissingCount(10);
			materialtravelsVo.setMissingCountType(0);
			materialtravelsVo.setSessionId(session.getId());
	    	materialtravelsVo.setUserId(null!=memberBasic ? memberBasic.getId() :null);
			List<MaterialtravelsVo>  travels=materialservice.selectTravels(materialtravelsVo,true);
			PageInfo<MaterialtravelsVo> page = new PageInfo<MaterialtravelsVo>(travels, 10);
	    	Map<String,Object> map=new HashMap<String,Object>();
//		    map.put("travelnotesvo",travels);
    		map.put("travelnotesvo", page);
		    data.setObj(map);
		    return data;
	    } catch (Exception e) {
	    	data.setMessage("查询失败");
	    	data.setStatus(500);
        }
	    return data;
	}
	
	
	@ResponseBody
	@RequestMapping(value = "detailMytravel", method = RequestMethod.POST)
	@ApiOperation(value = "攻略详情", notes = "攻略详情")
	@CrossOrigin
	public MessageData detailMytravel(HttpServletRequest request, HttpSession session,
			 @ApiParam(name = "id", value = "游记攻略的列表传递过来的ID",required=true) @RequestParam Integer id){
		
		MessageData data=new MessageData(200, "成功");
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
//		commUserIsNoteLogin(memberBasic, data);//判断是否登录
		Map<String,Object> map=new HashMap<String,Object>();
		try {
		 
			TravelNotesStrategyVo travelNotesStrategyVo=travelNoteservice.selectBydetailMytravel(id);
			List<TravelNotesDetailStrategyVo> travelNotesDetailStrategyVo=travelNoteservice.selectByDetailStrategyVo(id);
			
			
			IndexTravelNotesDetailVo indexTravelNotesDetailVo=travelNoteservice.selectByIndexTraveNotesDetail(id,session.getId(),memberBasic==null ? null :memberBasic.getId());
    		List<IndexTravelNotesUserCommentslVo> indexTravelNotesUserCommentslVo=travelNoteservice.selectByIndexTravelNotesUserCommentslVo(id);
    		map.put("indexTravelNotesDetailVo", indexTravelNotesDetailVo);
    		map.put("indexTravelNotesUserCommentslVo", indexTravelNotesUserCommentslVo);
			map.put("travelNotesStrategyVo", travelNotesStrategyVo);
			map.put("travelNotesDetailStrategyVo", travelNotesDetailStrategyVo);
			data.setObj(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	 
		return data;
	}
	
	 
	 public MessageData commUserIsNoteLogin(MemberBasic memberBasic,MessageData data){
		 if(null==memberBasic || null==memberBasic.getId()){
				data.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
				data.setMessage(BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
				return data;
			} 
		 return  data;
	 }
    
}
