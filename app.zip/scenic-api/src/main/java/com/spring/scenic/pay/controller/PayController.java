package com.spring.scenic.pay.controller;

import java.math.BigDecimal;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.pay.application.PayService;
import com.spring.scenic.product.application.ProductMealsService;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.sms.application.SmsService;
import com.spring.scenic.system.application.DictionaryService;

@Controller
@RequestMapping(value = "pay")
@Api(value = "payController", description = "支付接口")
public class PayController {

	Logger logger = LoggerFactory.getLogger(PayController.class);

    @Resource
    private PayService payService;
	
	@Resource
	private ProductService productService;

	@Resource
	private ProductPicRelService productPicRelService;

	@Resource
	private ProductStockService productStockService;

	@Resource
	private ProductMealsService productMealsService;

	@Resource
	private ProductCommentService productCommentService;

	@Resource
	private SmsService smsService;

	@Resource
	private MemberBasicService memberBasicService;

	@Resource
	private OrderService orderService;
	
	@Resource
	private DictionaryService dictionaryService;
	
    @Resource
    private BusiSellerService busiSellerService;
	
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value = "simplepay" , method = { RequestMethod.POST })
    @ApiOperation(httpMethod = "POST", value = "简单支付接口", notes = "已确认且未支付、或部分支付才可支付", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orderId", value = "订单ID", dataType = "Integer", paramType = "query", required = true),
        @ApiImplicitParam(name = "payMoney", value = "支付金额", dataType = "BigDecimal", paramType = "query", required = false),
        @ApiImplicitParam(name = "payType", value = "支付类别（1、QQ；2：支付宝；3：银联；4、其他）", dataType = "Integer", paramType = "query", required = true)
    })
    public MessageData simplepay(HttpSession session,Integer orderId,BigDecimal payMoney,Integer payType) {
        if(orderId!=null && payMoney!=null && payType!=null){
            try {
                MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
                if(member==null){
                    return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
                }else{
                    if(payMoney!=null && payMoney.compareTo(new BigDecimal(0))==1){
                        Order order = orderService.selectOrderDetail(orderId);
                        if(order.getOrderStatus() != Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())){
                        	 return new MessageData(SysConstant.FAILURE, "您订购的产品需与商家进一步确认，我们会尽快告知您结果，您也可以到我的->订单中查询");
                        }
                        if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode()) &&
                                (order.getPayStatus()==Integer.parseInt(SysEnum.ORDER_PAY_STATUS_NO.getCode())
                                        || order.getPayStatus()==Integer.parseInt(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()))
                                        ){
                            payService.saveOrderSimplePay(member,order,payMoney,payType);
                            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
                        }
                        return new MessageData(SysConstant.FAILURE, "订单已支付，请不要重复支付！");
                    }else{
                        return new MessageData(SysConstant.FAILURE, "支付条件不完整");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return new MessageData(SysConstant.EXCEPTION, SysConstant.MESSAGE_FAILURE);
            }
        }else{
            return new MessageData(SysConstant.FAILURE, "支付条件不完整");
        }
    }
    
}
