package com.spring.scenic.product.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberCollection;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductMealsService;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.domain.vo.ProductMoreImgVo;
import com.spring.scenic.product.domain.vo.ProductVo;
import com.spring.scenic.search.domain.vo.ProductCategoryVo;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.sms.application.SmsService;

@Controller
@RequestMapping(value = "/product")
@Api(value = "productController", description = "产品接口")
public class ProductController {

	Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Resource
	private ProductService productService;

	@Resource
	private ProductPicRelService productPicRelService;

	@Resource
	private ProductStockService productStockService;

	@Resource
	private ProductMealsService productMealsService;

	@Resource
	private ProductCommentService productCommentService;

	@Resource
	private SmsService smsService;

	@Resource
	private MemberBasicService memberBasicService;

	@Resource
	private OrderService orderService;
	
    @Resource
    private MemberCollectionService memberCollectionService;
	

	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectProductTypes", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "查询产品类别集合", notes = "无", produces = MediaType.APPLICATION_JSON_VALUE)
	public MessageData selectProductTypes() {
		MessageData message = new MessageData(200, "成功");
		 
		List<ProductCategoryVo> productCategorys = productService.initProductCategorys(null,null);
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("productCategorys", productCategorys);
			message.setObj(map);
		} catch (Exception e) {
			message.setMessage("查询失败");
			message.setStatus(500);
			e.printStackTrace();
			logger.info("selectProductTypes接口失败：", e.getMessage());
		}
		return message;
	}
	
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectListByParams", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "通过参数查询产品列表", notes = "无", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cityName", value = "城市名称", dataType = "String", paramType = "query", required = true, defaultValue = "上海"),
			@ApiImplicitParam(name = "productType", value = "大类", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "productSubType", value = "二级类别", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "pageSize", value = "每页长度", dataType = "Integer", paramType = "query", required = true, defaultValue = "10"),
			@ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query", required = true, defaultValue = "1") })
	public MessageData selectListByParams(String cityName, Integer productType, Integer productSubType,
		Integer pageSize, Integer pageNum) {
		MessageData message = new MessageData(200, "成功");
		Product productQueryParams = new Product();
		productQueryParams.setPageNum(pageNum == null ? 1 :pageNum);
		productQueryParams.setPageSize(pageSize == null ? 10 :pageSize);
		productQueryParams.setIsSale(1);
		productQueryParams.setProductType(productType);
		productQueryParams.setProductSubType(productSubType);
		productQueryParams.setCityName(StringUtils.isBlank(cityName)?BisConstant.LOCATION_CITY_DEFAULT:cityName);
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<Product> list;
		try {
			list = productService.getProductList(productQueryParams, true);
			PageInfo<Product> page = new PageInfo<Product>(list, productQueryParams.getPageSize());
			map.put("proudcts", page);
			message.setObj(map);
		} catch (Exception e) {
			message.setMessage("查询失败");
			message.setStatus(500);
			e.printStackTrace();
			logger.info("selectListByParams接口失败：", e.getMessage());
		}
		return message;
	}

	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectProductById", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "通过ID查询产品", notes = "productId不能为空", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "productId", value = "产品Id", dataType = "Integer", paramType = "query", required = true),
			@ApiImplicitParam(name = "cityName", value = "城市", dataType = "String", paramType = "query", required = false) })
	public MessageData selectProductById(HttpSession session,Integer productId, String cityName) {
		try {
			if(productId==null){
			    return new MessageData(SysConstant.FAILURE, "参数不完整");
			}
			// 基本属性
			ProductWithBLOBs product = productService.selectByPrimaryKey(productId);
			if(product == null){
				return new MessageData(SysConstant.FAILURE, "产品不存在");
			}
			// 产品图片
			List<BusiPictureLib> productPicList = productPicRelService.getProductPicOrDefault(product);
			if(productPicList==null || productPicList.isEmpty()){//没图片给默认图片
			    product.setMainPic(PropertiesUtil.getProperty("scenic_default_user_img")); 
			}else{//有图片取第一张
			    product.setMainPic(productPicList.get(0).getFileUrl());
			    product.setProductPics(productPicList);
			}
			// 大家还在看的产品（大家还在看的产品）
            ProductVo productExample = new ProductVo();
            productExample.setId(productId);
            productExample.setProductType(product.getProductType());
            productExample.setProductSubType(product.getProductSubType());
            if (StringUtils.isNotBlank(cityName)) {
                productExample.setCityName(cityName);
            } else {
                productExample.setCityName(BisConstant.LOCATION_CITY_DEFAULT);
            }
			List<ProductWithBLOBs> recommendProducts = productService.getRecommendProductList(productExample);
			product.setRecommendProducts(recommendProducts);
			// 是否收藏
			MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
			if(memberBasic!=null){
			    MemberCollection mcCollection = new MemberCollection();
			    mcCollection.setCollectionType(Integer.parseInt(SysEnum.COMMON_TYPE_PRODUCT.getCode()));
			    mcCollection.setMemberId(memberBasic.getId());
			    mcCollection.setCollectionContentId(productId);
			    int collected = memberCollectionService.getMemberCollecttionCount(mcCollection);
			    product.setCollected(collected>0);
			}
			// 产品关键字
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setOutRelatedType(3);// 3产品类型
			keywordRef.setOutRelatedId(productId);
			keywordRef.setType(2);// 标签类
			List<KeywordRef> keywords = productService.getRealtiveKeywordList(keywordRef);
			product.setListKeyword(keywords);
			// 产品套餐
			ProductMeals productMealsExample = new ProductMeals();
			productMealsExample.setProductId(productId);
			productMealsExample.setValid(1);
			List<ProductMeals> productMeals = productMealsService.selectAllByProductId(productMealsExample);
			product.setProductMeals(productMeals);
			// 产品首个评论
			ProductComment productComment = new ProductComment();
			productComment.setProductId(productId);
			productComment.setPageNum(1);
			productComment.setPageSize(2);
		    //把当前登录的会员作为产品评论点赞的人
		    //productComment.setUserId(memberBasic ==null ? null : memberBasic.getId());
			List<ProductComment> listComment = productCommentService.getProductCommentList(productComment,true);
			PageInfo<ProductComment> page = new PageInfo<ProductComment>(listComment, productComment.getPageSize());
			// 产品页面只给一个最新评论 更多走评价分页查询接口
			product.setListProductComment(page.getList());
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("product", product);
			return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
		} catch (Exception e) {
		    e.printStackTrace();
			logger.info("selectProductById接口失败：", e.getMessage());
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
	}

	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/selectCommentByProductId", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "通过产品ID查询评论列表", notes = "带分页", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "gread", value = "评级、是否有图片", dataType = "Integer", paramType = "query", required = false),
			@ApiImplicitParam(name = "productId", value = "产品ID", dataType = "Integer", paramType = "query", required = true),
			@ApiImplicitParam(name = "pageSize", value = "每页长度", dataType = "Integer", paramType = "query", required = true, defaultValue = "10"),
			@ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query", required = true, defaultValue = "1") })
	public MessageData selectCommentByProductId(HttpSession session,Integer productId, Integer pageSize, Integer pageNum,Integer gread) {
	    MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
	    try {
    		if(productId==null||pageSize==null||pageNum==null){
    		    return new MessageData(SysConstant.FAILURE,"参数不完整");  
    		}
    		ProductComment productComment = new ProductComment();
    		productComment.setSessionId(session.getId());//判断是否点赞过
    		productComment.setUserId(memberBasic ==null ? null : memberBasic.getId());//判断是否收藏过
    		productComment.setPageNum(pageNum);
    		productComment.setPageSize(pageSize);
    		productComment.setProductId(productId);
    		productComment.setGread(gread);
    		List<ProductComment> productComments = productCommentService.getProductCommentList(productComment, true);
    		PageInfo<ProductComment> productCommentsPage = new PageInfo<ProductComment>(productComments, productComment.getPageSize());
	        Map<String, Object> map = new HashMap<String, Object>();
			map.put("proudctComments", productCommentsPage);
			ProductVo productVo = new ProductVo();
			productVo.setId(productId);
			Map<String, Object> commentStatistic = productCommentService.getCommentStatistic(productVo);
			map.put("commentStatistic", commentStatistic);
			return new MessageData(SysConstant.SUCCESS,SysConstant.MESSAGE_SUCCESS,map);
		} catch (Exception e) {
			logger.info("selectCommentByProductId接口失败：", e.getMessage());
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);  
		}
	}
	
	/**
	 * 
	 * 此处为类方法说明
	 * @param request
	 * @param httpSession
	 * @param content
	 * @param gread
	 * @param productName
	 * @param orderId
	 * @return
	 * @creator ：xiangbin  
	 * @date ：2017年5月8日下午5:40:32
	 */
	@CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/addProductComment",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "填写点评", notes = "评分、内容、图片", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orderId", value = "订单ID", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "content", value = "点评内容", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "gread", value = "评分", required = true, dataType = "Integer", paramType = "query"),
        
        @ApiImplicitParam(name = "sellerId", value = "商户ID", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "productId", value = "产品ID", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "productName", value = "产品名称", required = true, dataType = "String", paramType = "query"),
        
        @ApiImplicitParam(name = "src", value = "来源", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "imgUrls", value = "图片url以字符串接收，用逗号隔开", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "parentId", value = "评论的上级评论ID(暂无)", required = false, dataType = "Integer", paramType = "query")
    })
    public MessageData addProductComment(HttpSession session,Integer orderId,String content,Integer gread,
        Integer sellerId,Integer productId,String productName,
        Integer src,String imgUrls,Integer parentId){
    	try {
    	    MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(session);
    	    MessageData messageData = new MessageData(null, null);
    	    String imgUrlArray[] = null;
    	    imgUrlArray = imgUrls.split(",");
    	    if(memberBasic==null){
    	        return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
    	    }
    	    if(orderId!=null && StringUtils.isNotBlank(content) && gread !=null &&
    	            sellerId!=null && productId!=null && StringUtils.isNotBlank(productName) && src!=null ){
                if(imgUrlArray.length<11){
                	productCommentService.insertProductComment(orderId,content,gread,sellerId,productId,productName,src,imgUrls,parentId,memberBasic.getId());
                	return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
                }
                else{
                	messageData.setStatus(102);
                    messageData.setMessage("最多上传10张图片！");
                    return messageData;
                }
    	    }else{
    	        return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
    	    }
            
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
	
	/**
	 * 
	 * 此处为类方法说明
	 * @param session
	 * @param productId
	 * @return
	 * @creator ：xiangbin  
	 * @date ：2017年5月16日下午2:32:12
	 */
	@CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/selectProductMoreImgList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "产品更多图片", notes = "官方图片、网友晒图", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "productId", value = "产品ID", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData productMoreImg(HttpSession session,Integer productId){
    	try {
    		MessageData message = new MessageData(200, "成功");
    	    	Map<String, Object> map = new HashMap<String, Object>();
    	    	List<ProductMoreImgVo> officialImgList = productService.selectOfficialImgList(productId);//官方图片
    	    	List<ProductMoreImgVo> onlineImgList = productService.selectOnlineImgList(productId);//网友晒图
    	    	map.put("officialImgList", officialImgList);
    	    	map.put("onlineImgList", onlineImgList);
    	    	message.setObj(map);
    	    	message.setMessage("查询成功！");
    	    return message;   	    
		} catch (Exception e) {
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }

}
