window.config = {
 apiUrl: 'http://localhost:8088/dangkou-api', //接口地址
  //apiUrl: 'http://cqczy.cn/scenic-api',
  loginUrl: {
    weibo: 'https://api.weibo.com/oauth2/authorize?client_id=1672355790&client_secret=a789a8264d716ec4448baa70329b0166&redirect_uri=http://cqczy.cn/scenic-api/thirdlogin/sinaWBLoginCallBack&response_type=code&grant_type=authorization_code',//微博
    qq: 'http://localhost:8088/scenic-api/thirdlogin/qqLogin',//QQ
    wechat: 'http://localhost:8088/scenic-api/thirdlogin/wxMPLogin'//微信
  }
}
