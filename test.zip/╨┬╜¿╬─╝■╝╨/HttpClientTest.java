package com.spring.scenic.order;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.spring.scenic.common.util.Bean2Map;
import com.spring.scenic.common.util.IPUtil;
import com.spring.scenic.pay.controller.alipay.sign.Base64;
import com.spring.scenic.sandpay.domain.SandResponse;
import com.spring.scenic.sandpay.domain.SandResponseData;
import com.spring.scenic.sandpay.domain.SandResponseHead;
import com.spring.scenic.sandpay.domain.SandResponsePayBody;
import com.spring.scenic.sandpay.util.httpclinet.HttpClient;

public class HttpClientTest {
	 
	@Test
	public void refund() {
		JSONObject body = new JSONObject();
		body.put("orderCode", "20150320010101001");
		body.put("oriOrderCode", "20150320010101001");
		body.put("refundAmount", "000000000011");
		body.put("notifyUrl", "");
		body.put("refundReason", "20150320010101001");
		body.put("extend", "20150320010101001");
		SandResponseData srd = HttpClient.post(body, "refund", "/order/refund");
		System.out.println(srd.getHead());
		SandResponsePayBody srb = JSON.parseObject(srd.getBody(), SandResponsePayBody.class);
		System.out.println(srb.getTradeNo());
		SandResponseHead srh = JSON.parseObject(srd.getHead(), SandResponseHead.class);
		System.out.println(srh.getRespCode());

	}

	@Test
	public void pay() {

		JSONObject body = new JSONObject();
		// 必填
		body.put("orderCode", "20170803010101001");
		// 以分为单位 12位长度 不足用0补齐
		body.put("totalAmount", "000000000019");
		body.put("subject", "商城商品");
		body.put("payMode", "send_wx");
		body.put("clientIp", "222.180.199.2");
		body.put("notifyUrl", "http://houtrip.springtour.com/scenic-api/pay/payWxCallback.htm");
		body.put("frontUrl", "http://houtrip.springtour.com/scenic-api/pay/payBgCallBackSync.htm");
		// 以下选填
		// body.put("body", "这只是一个测试产品");
		// body.put("txnTimeOut", "");
		JSONObject _payExtra = new JSONObject();
		// appid
		_payExtra.put("subAppid", "wx1759de4405f7f1bf");
		// 用户在合作方的openID
		_payExtra.put("userId", "o5NDmw-NZo8m5HGReeC0QcfTvY90");
		body.put("payExtra", _payExtra);
		// body.put("storeId", "");
		// body.put("treminalId", "");
		// body.put("operatorId", "");
		// body.put("clearCycle", "");
		// body.put("royaltyInfo", "");
		// body.put("riskRateInfo", "");
		// body.put("bizExtendParams", "");
		// body.put("merchExtendParams", "");
		// body.put("extend", "");
		SandResponseData srd = HttpClient.post(body, "pay", "/order/pay");
		SandResponseHead srh = JSON.parseObject(srd.getHead(), SandResponseHead.class);
		System.out.println(srh.getRespCode());
		SandResponsePayBody srb = JSON.parseObject(srd.getBody(), SandResponsePayBody.class);
		System.out.println(srb.getTradeNo());
	}

 
	@Test
	public void notifyUrl() {
		JSONObject body = new JSONObject();
		body.put("orderCode", "20150320010101001");
		body.put("totalAmount", "000000000010");
		body.put("orderStatus", "1");
		body.put("tradeNo", "20150320010101001");
		body.put("buyerPayAmount", "000000011000");
		body.put("discAmount", "000000011000");
		body.put("payTime", "201708011340");
		body.put("clearDate", "20170801");
		body.put("refundAmount", "000000011000");
		body.put("surplusAmount", "000000011000");
		body.put("midFee", "000000011000");
		body.put("extend", "");
		HttpClient.notify(body);
	}
 
	@Test
	public void query() {
		JSONObject body = new JSONObject();
		body.put("orderCode", "20150320010101001");
		body.put("extend", "");
		SandResponseData srd = HttpClient.post(body, "query", "/order/query");
		SandResponseHead srh = JSON.parseObject(srd.getHead(), SandResponseHead.class);
		System.out.println(srh.getRespCode());
		SandResponsePayBody srb = JSON.parseObject(srd.getBody(), SandResponsePayBody.class);
		System.out.println(srb.getTradeNo());
	}
 
	@Test
	public void download() {
		JSONObject body = new JSONObject();
		body.put("orderCode", "20150320010101001");
		body.put("extend", "");
		HttpClient.download(body);
	}
}
