package com.spring.scenic.sandpay.util.httpclinet;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.spring.scenic.common.util.Bean2Map;
import com.spring.scenic.pay.controller.alipay.sign.Base64;
import com.spring.scenic.sandpay.domain.SandResponse;
import com.spring.scenic.sandpay.domain.SandResponseData;
import com.spring.scenic.sandpay.domain.SandResponseHead;
import com.spring.scenic.sandpay.domain.SandResponsePayBody;

public class HttpClient {
	static Logger logger = LoggerFactory.getLogger(HttpClient.class);

	private static String _url = "https://cashier.sandpay.com.cn/gateway/api";

	/**
	 * 杉德POST请求接口 json格式
	 * @param body 报文体
	 * @param method 接口方法
	 * @param apiurl 接口地址
	 * @return SandResponseData
	 * @creator liaoxianghua
	 * @date 2017年8月3日上午10:52:13
	 */
	public static SandResponseData post(JSONObject body, String method, String apiurl) {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = null;
		// 接收响应结果
		CloseableHttpResponse response = null;
		SandResponseData srd = null;
		try {
			// 创建httppost
			httpclient = HttpClients.createDefault();
			String url = _url + apiurl;
			HttpPost httpPost = new HttpPost(url);
			httpPost.addHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");
			JSONObject data = new JSONObject();
			data.put("head", initHead(method));
			data.put("body", body);
			StringBuffer str = new StringBuffer();
			str.append("charset=UTF-8&signType=01&sign=").append(Base64.encode(data.toString().getBytes()))
					.append("&data=").append(data);
			System.out.println(str.toString());
			StringEntity se = new StringEntity(str.toString());
			se.setContentEncoding("UTF-8");
			se.setContentType("application/json");// 发送json需要设置contentType
			httpPost.setEntity(se);
			response = httpclient.execute(httpPost);
			// 解析返结果
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String resStr = EntityUtils.toString(entity, "UTF-8");
				resStr = URLDecoder.decode(resStr, "UTF-8");
				logger.info("================" + method + "========返回参数String==" + resStr);
				String[] res = resStr.split("&");
				// System.out.println(JSONObject.parseObject(resStr));
				Map<String, Object> map = new HashMap<String, Object>();
				for (String string : res) {
					Matcher matcher = Pattern.compile("=").matcher(string);
					if (matcher.find()) {
						map.put(string.substring(0, matcher.start()), string.substring(matcher.start() + 1));
					}
				}
				logger.info("================" + method + "========返回参数JSON==" + JSONObject.toJSONString(map));
				SandResponse sr = (SandResponse) Bean2Map.toBean(SandResponse.class, map);
				System.out.println(JSONObject.parse(sr.getData()));
				srd = JSON.parseObject(sr.getData(), SandResponseData.class);
				System.out.println(srd.getHead());
				return srd;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
				response.close();
			} catch (RuntimeException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return srd;
	}

	public static void download(JSONObject body) {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = null;
		// 接收响应结果
		CloseableHttpResponse response = null;
		try {
			// 创建httppost
			httpclient = HttpClients.createDefault();
			String url = _url + "/chearFile/download";
			HttpPost httpPost = new HttpPost(url);
			httpPost.addHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");
			JSONObject user2 = new JSONObject();
			user2.put("head", initHead("download"));
			user2.put("body", body);
			StringBuffer str = new StringBuffer();
			str.append("charset=UTF-8&signType=01&sign=").append(Base64.encode(user2.toString().getBytes()))
					.append("&data=").append(user2);
			// System.out.println(str.toString());
			StringEntity se = new StringEntity(str.toString());
			se.setContentEncoding("UTF-8");
			se.setContentType("application/json");// 发送json需要设置contentType
			httpPost.setEntity(se);
			response = httpclient.execute(httpPost);
			// 解析返结果
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String resStr = EntityUtils.toString(entity, "UTF-8");
				resStr = URLDecoder.decode(resStr, "UTF-8");
				String[] res = resStr.split("&");
				// System.out.println(JSONObject.parseObject(resStr));
				Map<String, Object> map = new HashMap<String, Object>();
				for (String string : res) {
					Matcher matcher = Pattern.compile("=").matcher(string);
					if (matcher.find()) {
						map.put(string.substring(0, matcher.start()), string.substring(matcher.start() + 1));
					} else {
						System.out.println("null");
					}
				}
				SandResponse sr = (SandResponse) Bean2Map.toBean(SandResponse.class, map);
				System.out.println(JSONObject.parse(sr.getData()));
				SandResponseData srd = JSON.parseObject(sr.getData(), SandResponseData.class);
				System.out.println(srd.getHead());
				SandResponsePayBody srb = JSON.parseObject(srd.getBody(), SandResponsePayBody.class);
				System.out.println(srb.getTradeNo());
				SandResponseHead srh = JSON.parseObject(srd.getHead(), SandResponseHead.class);
				System.out.println(srh.getRespCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
				response.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void notify(JSONObject body) {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = null;
		// 接收响应结果
		CloseableHttpResponse response = null;
		try {
			// 创建httppost
			httpclient = HttpClients.createDefault();
			String url = "http://localhost:8080/scenic-api/pay/payWxCallback";
			HttpPost httpPost = new HttpPost(url);
			httpPost.addHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");
			JSONObject user2 = new JSONObject();
			user2.put("head", initHead(""));
			user2.put("body", body);
			StringBuffer str = new StringBuffer();
			str.append("charset=UTF-8&signType=01&sign=").append(Base64.encode(user2.toString().getBytes()))
					.append("&data=").append(user2);
			StringEntity se = new StringEntity(str.toString());
			se.setContentEncoding("UTF-8");
			se.setContentType("application/json");// 发送json需要设置contentType
			httpPost.setEntity(se);
			response = httpclient.execute(httpPost);
			// 解析返结果
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String resStr = EntityUtils.toString(entity, "UTF-8");
				resStr = URLDecoder.decode(resStr, "UTF-8");
				String[] res = resStr.split("&");
				Map<String, Object> map = new HashMap<String, Object>();
				for (String string : res) {
					Matcher matcher = Pattern.compile("=").matcher(string);
					if (matcher.find()) {
						map.put(string.substring(0, matcher.start()), string.substring(matcher.start() + 1));
					} else {
						System.out.println("null");
					}
				}
				System.out.println("============异步通知返回结果=========" + map.get("respCode")
						+ "=============================");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
				response.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 根据方法名生成报文头
	 * @param method
	 * @return 报文头
	 * @creator ：liaoxianghua
	 * @date ：2017年8月3日上午10:54:07
	 */
	private static JSONObject initHead(String method) {
		// 参数
		JSONObject _head = new JSONObject();
		_head.put("version", "1.0");
		_head.put("method", "sandpay.trade." + method);
		_head.put("mid", "11966909");
		_head.put("reqTime", new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
		_head.put("accessType", "1");
		_head.put("channelType", "07");
		_head.put("productId", "00000005");
		return _head;
	}
}
