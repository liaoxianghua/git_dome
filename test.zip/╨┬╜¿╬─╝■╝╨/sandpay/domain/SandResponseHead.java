package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

/**
 * 杉德返回head
 * @author liaoxianghua
 * 
 */
public class SandResponseHead implements Serializable {
	
	private static final long serialVersionUID = -2387357535500773571L;

	// 响应时间
	String respTime;

	// 响应描述
	String respMsg;

	// 版本号
	String version;

	// 响应码
	String respCode;

	public String getRespTime() {
		return respTime;
	}

	public void setRespTime(String respTime) {
		this.respTime = respTime;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

}
