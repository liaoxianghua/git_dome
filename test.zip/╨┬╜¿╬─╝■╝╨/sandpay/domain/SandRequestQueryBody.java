package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

public class SandRequestQueryBody implements Serializable {

	private static final long serialVersionUID = 9196188142533058233L;

	// 商户订单号
	String orderCode;

	// 扩展域
	String extend;

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

}
