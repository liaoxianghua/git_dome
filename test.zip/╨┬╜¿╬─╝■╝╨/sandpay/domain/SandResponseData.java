package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

/**
 * 报文data结构 用于解析
 * @author liaoxianghua
 * @date 2017年8月1日
 */
public class SandResponseData implements Serializable {

	private static final long serialVersionUID = -931796171852912695L;

	// 报文头
	private String head;

	// 报文体
	private String body;

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

}
