package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

public class SandResponse implements Serializable {

	private static final long serialVersionUID = 5500859239459137991L;

	// 签名 对data进行签名，签名结果采用base64编码
	private String sign;

	// 编码方式 默认utf-8
	private String charset;

	// 签名类型 默认01(SHA1+RSA)
	private String signType;

	// 交易报文
	private String data;

	// 扩展域
	private String extend;

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
