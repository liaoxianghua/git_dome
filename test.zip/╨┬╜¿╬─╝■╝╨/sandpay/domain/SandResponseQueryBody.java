package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

public class SandResponseQueryBody implements Serializable {
	private static final long serialVersionUID = -4790256974826659242L;

	// 原商户订单号
	String oriOrderCode;

	// 原交易应答码 000000表示成功
	String oriRespCode;

	// 原交易应答描述 oriRespMsg
	String oriRespMsg;

	// 订单金额 totalAmount
	String totalAmount;

	// 订单状态 00 成功 01 处理中 02 失败 03 已撤销 04 已退货 05 退款处理中
	String orderStatus;

	// 买家付款金额 支付成功返回
	String buyerPayAmount;

	// 优惠金额 支付成功返回
	String discAmount;

	// 支付时间 yyyyMMddhhmmss，支付成功返回
	String payTime;

	// 交易日期 yyyyMMdd，支付成功返回
	String clearDate;

	// 扩展域 extend
	String extend;

	public String getOriOrderCode() {
		return oriOrderCode;
	}

	public void setOriOrderCode(String oriOrderCode) {
		this.oriOrderCode = oriOrderCode;
	}

	public String getOriRespCode() {
		return oriRespCode;
	}

	public void setOriRespCode(String oriRespCode) {
		this.oriRespCode = oriRespCode;
	}

	public String getOriRespMsg() {
		return oriRespMsg;
	}

	public void setOriRespMsg(String oriRespMsg) {
		this.oriRespMsg = oriRespMsg;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getBuyerPayAmount() {
		return buyerPayAmount;
	}

	public void setBuyerPayAmount(String buyerPayAmount) {
		this.buyerPayAmount = buyerPayAmount;
	}

	public String getDiscAmount() {
		return discAmount;
	}

	public void setDiscAmount(String discAmount) {
		this.discAmount = discAmount;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public String getClearDate() {
		return clearDate;
	}

	public void setClearDate(String clearDate) {
		this.clearDate = clearDate;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

}
