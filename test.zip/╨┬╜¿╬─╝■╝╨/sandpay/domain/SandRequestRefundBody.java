package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

public class SandRequestRefundBody implements Serializable {
	private static final long serialVersionUID = 7107889838512752116L;

	// 商户订单号 商户唯一
	String orderCode;

	// 原商户订单号 要退货的订单
	String oriOrderCode;

	// 退货金额
	String refundAmount;

	// 异步通知地址
	String notifyUrl;

	// 退货原因
	String refundReason;

	// 扩展域
	String extend;

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getOriOrderCode() {
		return oriOrderCode;
	}

	public void setOriOrderCode(String oriOrderCode) {
		this.oriOrderCode = oriOrderCode;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getRefundReason() {
		return refundReason;
	}

	public void setRefundReason(String refundReason) {
		this.refundReason = refundReason;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

}
