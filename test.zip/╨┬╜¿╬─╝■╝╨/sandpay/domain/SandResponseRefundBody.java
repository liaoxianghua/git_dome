package com.spring.scenic.sandpay.domain;

import java.io.Serializable;
/**
 * 杉德退款返回报文
 * @author liaoxianghua
 * @date 2017年8月1日
 */
public class SandResponseRefundBody implements Serializable {
	
	private static final long serialVersionUID = 3493022430319670934L;

	// 商户订单号
	String orderCode;

	// 交易流水号 退货成功返回
	String tradeNo;

	// 实际退货金额 退货成功返回
	String refundAmount;

	// 剩余可退金额 退货成功返回
	String surplusAmount;

	// 退货时间 refundTime 退货成功返回
	String refundTime;

	// 退货日期 clearDate yyyyMMdd，退货成功返回
	String clearDate;

	// 扩展域 extend
	String extend;

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getTradeNo() {
		return tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getSurplusAmount() {
		return surplusAmount;
	}

	public void setSurplusAmount(String surplusAmount) {
		this.surplusAmount = surplusAmount;
	}

	public String getRefundTime() {
		return refundTime;
	}

	public void setRefundTime(String refundTime) {
		this.refundTime = refundTime;
	}

	public String getClearDate() {
		return clearDate;
	}

	public void setClearDate(String clearDate) {
		this.clearDate = clearDate;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}
}
