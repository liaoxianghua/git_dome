package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

/**
 * 杉德请求头
 * @author liaoxianghua
 */
public class SandRequestHead implements Serializable {

	private static final long serialVersionUID = -5702840397263882111L;

	// 版本号 默认1.0
	String version;

	// 接口名称
	String method;

	// 产品编码 1普通商户接入 2 平台商户接入
	String productId;

	// 接入类别
	Integer accessType;

	// 商户ID
	String mid;

	// 平台ID
	String plMid;

	// 渠道类型 07互联网 08 移动端
	String channelType;

	// 请求时间 yyyyMMddhhmmss
	Long reqTime;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Integer getAccessType() {
		return accessType;
	}

	public void setAccessType(Integer accessType) {
		this.accessType = accessType;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getPlMid() {
		return plMid;
	}

	public void setPlMid(String plMid) {
		this.plMid = plMid;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public Long getReqTime() {
		return reqTime;
	}

	public void setReqTime(Long reqTime) {
		this.reqTime = reqTime;
	}
}
