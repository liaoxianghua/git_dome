package com.spring.scenic.sandpay.domain;

public class SandResponseCallbackBody {
	// 商户订单号
	String orderCode;

	// 订单金额
	String totalAmount;

	// 订单状态
	String orderStatus;

	// 交易流水号
	String tradeNo;

	// 买家付款金额
	String buyerPayAmount;

	// 优惠金额
	String discAmount;

	// 支付时间
	String payTime;

	// 交易日期
	String clearDate;

	// 实际退货金额 退货成功返回
	String refundAmount;

	// 剩余可退金额 退货成功返回
	String surplusAmount;

	// 手续费 midFee
	String midFee;

	// 扩展域 extend
	String extend;

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getTradeNo() {
		return tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getBuyerPayAmount() {
		return buyerPayAmount;
	}

	public void setBuyerPayAmount(String buyerPayAmount) {
		this.buyerPayAmount = buyerPayAmount;
	}

	public String getDiscAmount() {
		return discAmount;
	}

	public void setDiscAmount(String discAmount) {
		this.discAmount = discAmount;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public String getClearDate() {
		return clearDate;
	}

	public void setClearDate(String clearDate) {
		this.clearDate = clearDate;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getSurplusAmount() {
		return surplusAmount;
	}

	public void setSurplusAmount(String surplusAmount) {
		this.surplusAmount = surplusAmount;
	}

	public String getMidFee() {
		return midFee;
	}

	public void setMidFee(String midFee) {
		this.midFee = midFee;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

}
