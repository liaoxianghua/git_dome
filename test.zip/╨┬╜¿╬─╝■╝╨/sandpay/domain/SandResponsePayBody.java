package com.spring.scenic.sandpay.domain;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 杉德支付返回报文体
 * @author liaoxianghua
 * @date 2017年8月1日
 */
public class SandResponsePayBody implements Serializable{
	
	private static final long serialVersionUID = 8908660192017234600L;
	//商户订单号
	String orderCode;
	//订单金额
	BigDecimal totalAmount;
	//支付作证
	String credential;
	//交易流水号
	String tradeNo;
	//买家付款金额
	BigDecimal buyerPayAmount;
	//优惠金额
	BigDecimal discAmount;
	//支付时间
	long payTime;
	//清算时间
	long clearDate;
	
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getCredential() {
		return credential;
	}
	public void setCredential(String credential) {
		this.credential = credential;
	}
	public String getTradeNo() {
		return tradeNo;
	}
	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}
	public BigDecimal getBuyerPayAmount() {
		return buyerPayAmount;
	}
	public void setBuyerPayAmount(BigDecimal buyerPayAmount) {
		this.buyerPayAmount = buyerPayAmount;
	}
	public BigDecimal getDiscAmount() {
		return discAmount;
	}
	public void setDiscAmount(BigDecimal discAmount) {
		this.discAmount = discAmount;
	}
	public long getPayTime() {
		return payTime;
	}
	public void setPayTime(long payTime) {
		this.payTime = payTime;
	}
	public long getClearDate() {
		return clearDate;
	}
	public void setClearDate(long clearDate) {
		this.clearDate = clearDate;
	}
 
}
