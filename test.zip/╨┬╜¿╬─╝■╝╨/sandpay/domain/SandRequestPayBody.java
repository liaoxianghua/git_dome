package com.spring.scenic.sandpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.JSONObject;

public class SandRequestPayBody implements Serializable {

	private static final long serialVersionUID = 7888162656877041186L;

	// 商户订单号
	String orderCode;

	// 订单金额 以分为单位 12位长度 不足用0补齐
	String totalAmount;

	// 订单标题
	String subject;

	// 支付模式
	String payMode;

	// 客户端IP
	String clientIp;

	// 异步通知地址
	String notifyUrl;

	// 前台通知地址
	String frontUrl;

	// 以下选填
	// 订单描述
	String body;

	// 订单超时时间
	String txnTimeOut;

	JSONObject _payExtra = new JSONObject();

	// appid
	// _payExtra.put("subAppid", "");
	// //用户在合作方的openID
	// _payExtra.put("userId", "");
	// 支付扩展域
	String payExtra;

	// 商户门店编号
	String storeId;

	// 商户终端编号
	String treminalId;

	// 操作员编号
	String operatorId;

	// 清算模式
	String clearCycle;

	// 分账信息
	String royaltyInfo;

	// 风控信息域
	String riskRateInfo;

	// 业务扩展参数
	String bizExtendParams;

	// 商户扩展参数
	String merchExtendParams;

	// 扩展域
	String extend;

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getFrontUrl() {
		return frontUrl;
	}

	public void setFrontUrl(String frontUrl) {
		this.frontUrl = frontUrl;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTxnTimeOut() {
		return txnTimeOut;
	}

	public void setTxnTimeOut(String txnTimeOut) {
		this.txnTimeOut = txnTimeOut;
	}

	public JSONObject get_payExtra() {
		return _payExtra;
	}

	public void set_payExtra(JSONObject _payExtra) {
		this._payExtra = _payExtra;
	}

	public String getPayExtra() {
		return payExtra;
	}

	public void setPayExtra(String payExtra) {
		this.payExtra = payExtra;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getTreminalId() {
		return treminalId;
	}

	public void setTreminalId(String treminalId) {
		this.treminalId = treminalId;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getClearCycle() {
		return clearCycle;
	}

	public void setClearCycle(String clearCycle) {
		this.clearCycle = clearCycle;
	}

	public String getRoyaltyInfo() {
		return royaltyInfo;
	}

	public void setRoyaltyInfo(String royaltyInfo) {
		this.royaltyInfo = royaltyInfo;
	}

	public String getRiskRateInfo() {
		return riskRateInfo;
	}

	public void setRiskRateInfo(String riskRateInfo) {
		this.riskRateInfo = riskRateInfo;
	}

	public String getBizExtendParams() {
		return bizExtendParams;
	}

	public void setBizExtendParams(String bizExtendParams) {
		this.bizExtendParams = bizExtendParams;
	}

	public String getMerchExtendParams() {
		return merchExtendParams;
	}

	public void setMerchExtendParams(String merchExtendParams) {
		this.merchExtendParams = merchExtendParams;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

}
