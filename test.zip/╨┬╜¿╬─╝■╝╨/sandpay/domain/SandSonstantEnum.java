package com.spring.scenic.sandpay.domain;
/**
 * 杉德常量
 * @author liaoxianghua
 * @date 2017年8月3日
 */
public enum SandSonstantEnum {
	
	SAND_WX("sand_wx","00000005","微信公众号支付"),
	SAND_ALIPAY("sand_alipay","00000006","支付宝支付"),
	SAND_H5("sand_h5","00000008","杉德H5银行卡支付"),
	BANK_PC("bank_pc","00000007","银行网关支付");
	//支付模式
	private String payMode;
	//产品编码
	private String productId;
	//描述
	private String description;
	SandSonstantEnum(String payMode,String productId,String description){
		this.payMode = payMode;
		this.productId = productId;
		this.description = description;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public static void main(String[] args) {
		System.out.println(SandSonstantEnum.SAND_WX.getPayMode());
		System.out.println(SandSonstantEnum.SAND_WX.getDescription());
		System.out.println(SandSonstantEnum.SAND_WX.getProductId());
	}
}
