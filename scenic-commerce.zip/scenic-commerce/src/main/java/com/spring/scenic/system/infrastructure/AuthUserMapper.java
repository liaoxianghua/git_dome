package com.spring.scenic.system.infrastructure;

import java.util.List;
import java.util.Map;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;

public interface AuthUserMapper {

	AuthUser getUserByAccount(String username);

	List<AuthRole> getUserRoleList(AuthUser authUser);

	List<AuthResource> getUserResourceList(AuthUser authUser);

	List<AuthResource> getUserResourceListByCode(Map<String, Object> map);

	List<AuthRole> getRoleList(AuthRole authRole);

	List<AuthRole> getRoleListByResource(AuthResource resource);

	List<AuthResource> getResourceList(AuthResource authResource);

}