package com.spring.scenic.common.util;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 日期转换属性编辑器
 * @version 1.0.0
 * 2016-07-15
 */
public class MyDateEditor extends PropertyEditorSupport{

	@Override
	public String getAsText() {
		
		return getValue().toString();
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		if(text==null||text.equals("")){
			setValue(null);
		}
		if(text.contains(":")){
			SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm");
			
			try {
				setValue(dateFormat.parse(text));
			} catch (ParseException e) {
				
				
			}
		}else{
			SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
			try {
				setValue(dateFormat.parse(text));
			} catch (ParseException e) {
				
			}
		}
	
	}

}
