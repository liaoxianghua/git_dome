package com.spring.scenic.common.extend;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

public class FileTypeTag extends SimpleTagSupport {

	private static final Logger logger = Logger.getLogger(FileTypeTag.class);
	
	private String jpgPattern = "jpeg、bmp";
	
	private String path;
	
	@Override
	public void doTag() throws JspException, IOException {
		try {
			if(StringUtils.isNotBlank(path) && path.contains(".")){
				JspWriter out = getJspContext().getOut();
				String surffix = path.substring(path.lastIndexOf(".")+1, path.length());
				if(jpgPattern.contains(surffix)){
					out.write("jpg");
				}else{
					out.write(surffix);
				}
			}
		} catch (Exception e) {
			logger.info("DictionaryTag hander for name: "+path+" raise an exception...");
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
}
