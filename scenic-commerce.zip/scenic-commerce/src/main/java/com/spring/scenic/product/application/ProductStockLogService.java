package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.product.domain.ProductStockLog;

public interface ProductStockLogService {
	
	public List<ProductStockLog> productStockLogList(ProductStockLog productStockLog,boolean page);
}
