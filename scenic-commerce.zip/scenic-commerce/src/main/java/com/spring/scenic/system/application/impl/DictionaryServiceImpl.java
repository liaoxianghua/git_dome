package com.spring.scenic.system.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;
import com.spring.scenic.system.infrastructure.DictionaryMapper;


/**
 * @Description TODO
 * @author 006568（shuchang）
 * @date 2016年12月29日
 */
@Service
public class DictionaryServiceImpl implements DictionaryService {

	@Resource
	private DictionaryMapper dictionaryMapper;

	@Override
	public List<Dictionary> getDictionaryList(Dictionary dictionary,boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(dictionary.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<Dictionary> dictionaryList = dictionaryMapper.getDictionaryList(dictionary);
			if(dictionaryList!=null && !dictionaryList.isEmpty()){
				dictionaryList = getDictionaryGridTreeList(dictionaryList);
			}
			return dictionaryList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public Map<String, Dictionary> initDictionaryMap(Dictionary dictionary) {
		try {
			Map<String, Dictionary> dicMap = new HashMap<String, Dictionary>();
			List<Dictionary> dictionaryList = dictionaryMapper.getDictionaryList(dictionary);
			for (Dictionary dic : dictionaryList) {
				if(dic.getParentId()==null){
					dicMap.put(dic.getCode(), dic);
				}else{
					dicMap.put((dic.getParentId()+"_"+dic.getValue()), dic);
				}
			}
			return dicMap;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Map<String, List<Dictionary>> initDictionary(Dictionary dictionary) {
		try {
			Map<String, List<Dictionary>> treeMap = new HashMap<String, List<Dictionary>>();
			List<Dictionary> dictionaryList = dictionaryMapper.getDictionaryList(dictionary);
			List<Dictionary> dictionaryTreeList = getDictionaryGridTreeList(dictionaryList);
			for (Dictionary dictionaryTree : dictionaryTreeList) {
				treeMap.put(dictionaryTree.getCode(), dictionaryTree.getChildren());
			}
			return treeMap;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * @Description 将所有包含子字典（包含二级或更多层次）的数据整合成一个平级的HASHMAP
	 * @param compare
	 * @return Dictionary
	 * @author lichangmao
	 * @date 2016年12月22日
	 */
	public Map<String, List<Dictionary>> initChildrens(Dictionary compare,
			List<Dictionary>  list, Map<String, List<Dictionary>> map) {
		List<Dictionary> children = new ArrayList<Dictionary>();
		if (!list.isEmpty()) {
			for (Dictionary dictionaryParam : list) {
				if (dictionaryParam.getParentId()!=null && dictionaryParam.getParentId().equals(compare.getId())) {
					children.add(dictionaryParam);
				}
			}
			map.put(compare.getCode(), children);
		}
		return map;
	}

	@Override
	public int saveDictionary(AuthUser user, Dictionary dictionary) {
	    if(StringUtil.isNotEmpty(dictionary.getCode())) {
	        validata(dictionary);
	    }
		try {
			if(dictionary.getId()==null){
				dictionary.setCreateUser(user.getId());
				dictionary.setCreateTime(new Date());
				dictionary.setValid(Short.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
				return dictionaryMapper.saveDictionary(dictionary);
			}else{
				Dictionary dictionaryExample = new Dictionary();
				dictionaryExample.setId(dictionary.getId());
				dictionaryExample.setCode(dictionary.getCode());
				dictionaryExample.setValue(dictionary.getValue());
				dictionaryExample.setName(dictionary.getName());
				dictionaryExample.setUpdateTime(new Date());
				dictionaryExample.setUpdateUser(user.getId());
				return dictionaryMapper.updateDictionary(dictionaryExample);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年4月10日     
     * @memo ：   
     **
     */
    private void validata(Dictionary dictionary) {
        int count = dictionaryMapper.getDictionnaryCountByCode(dictionary);
        if(count>0) {
            throw new BussinessException(new BussinessExceptionBean("exception.dictionaryCodeIsExisted"));
        }
        
    }

    @Override
	public int deleteDictionary(Dictionary dictionary) {
		try {
			return dictionaryMapper.deleteDictionary(dictionary);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * @Description 字典列表树
	 * @param dictionaryList
	 * @return List<Dictionary>
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	private List<Dictionary> getDictionaryGridTreeList(List<Dictionary> dictionaryList) {
		List<Dictionary> rootDictionary = new ArrayList<Dictionary>();
		if(dictionaryList!=null && !dictionaryList.isEmpty()){
			Iterator<Dictionary> dicIterator = dictionaryList.iterator();
			while (dicIterator.hasNext()) {
				Dictionary tempDic = dicIterator.next();
				if(tempDic.getParentId()==null){
					rootDictionary.add(tempDic);
					dicIterator.remove();
				}
			}
			for (Dictionary dictionary : rootDictionary) {
				dictionary.setChildren(recursionDictionary(dictionary,dictionaryList));
			}
		}
		return rootDictionary;
	}

	/**
	 * @Description 设置字典项children
	 * @param dictionary
	 * @param dictionaryList
	 * @return List<Dictionary>
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	private List<Dictionary> recursionDictionary(Dictionary dictionary,List<Dictionary> dictionaryList) {
		List<Dictionary> childrens = new ArrayList<Dictionary>(); 
		for (Dictionary tempDic : dictionaryList) {
			if(tempDic.getParentId().equals(dictionary.getId())){
				childrens.add(tempDic);
			}
		}
		return childrens;
	}

	@Override
	public Dictionary getDictionary(Dictionary dictionary) {
		try {
			return dictionaryMapper.getDictionaryById(dictionary);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Dictionary> getDictionaryListByCode(Dictionary dictionary) {
		try {
			return dictionaryMapper.getDictionaryListByCode(dictionary);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
