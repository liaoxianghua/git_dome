package com.spring.scenic.order.domain.vo;

import java.math.BigDecimal;
import java.util.Date;

public class OrderAndInvoice {
	

	private String orderNo;
	
	private Date createTime;
	
	private Integer orderStatus;
	
	private String productName;
	
	private String mealsName;
	
	private Date travelTime;
	
	private String linkMan;
	
	private String phone;
	
	private String email;
	
	private BigDecimal orderPrice;
	
	private BigDecimal payPrice;
	
	private BigDecimal payedPrice;
	
	private Integer needInvoice;
	
	private String invoicePhone;
	
	private String title;
	
	private String invoiceEmail;
	
	private Integer sellerId;
	
	private String memberAccount;
	
	private Integer productId;
	
	private Date createTimeStart;   
	
	private Date createTimeEnd;
	
	private Date travelTimeStart;
	
	private Date travelTimeEnd;
	
	private Integer[] statuses;
	
	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMealsName() {
		return mealsName;
	}

	public void setMealsName(String mealsName) {
		this.mealsName = mealsName;
	}

	public Date getTravelTime() {
		return travelTime;
	}

	public void setTravelTime(Date travelTime) {
		this.travelTime = travelTime;
	}

	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

	public BigDecimal getPayPrice() {
		return payPrice;
	}

	public void setPayPrice(BigDecimal payPrice) {
		this.payPrice = payPrice;
	}

	public BigDecimal getPayedPrice() {
		return payedPrice;
	}

	public void setPayedPrice(BigDecimal payedPrice) {
		this.payedPrice = payedPrice;
	}

	public Integer getNeedInvoice() {
		return needInvoice;
	}

	public void setNeedInvoice(Integer needInvoice) {
		this.needInvoice = needInvoice;
	}

	public String getInvoicePhone() {
		return invoicePhone;
	}

	public void setInvoicePhone(String invoicePhone) {
		this.invoicePhone = invoicePhone;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getInvoiceEmail() {
		return invoiceEmail;
	}

	public void setInvoiceEmail(String invoiceEmail) {
		this.invoiceEmail = invoiceEmail;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getMemberAccount() {
		return memberAccount;
	}

	public void setMemberAccount(String memberAccount) {
		this.memberAccount = memberAccount;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Date getCreateTimeStart() {
		return createTimeStart;
	}

	public void setCreateTimeStart(Date createTimeStart) {
		this.createTimeStart = createTimeStart;
	}

	public Date getCreateTimeEnd() {
		return createTimeEnd;
	}

	public void setCreateTimeEnd(Date createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}

	public Date getTravelTimeStart() {
		return travelTimeStart;
	}

	public void setTravelTimeStart(Date travelTimeStart) {
		this.travelTimeStart = travelTimeStart;
	}

	public Date getTravelTimeEnd() {
		return travelTimeEnd;
	}

	public void setTravelTimeEnd(Date travelTimeEnd) {
		this.travelTimeEnd = travelTimeEnd;
	}

	public Integer[] getStatuses() {
		return statuses;
	}

	public void setStatuses(Integer[] statuses) {
		this.statuses = statuses;
	}
	
	
}

