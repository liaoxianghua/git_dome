package com.spring.scenic.product.application.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductStockLog;
import com.spring.scenic.product.domain.vo.ProductStockMounthVo;
import com.spring.scenic.product.domain.vo.ProductStockVo;
import com.spring.scenic.product.infrastructure.ProductStockLogMapper;
import com.spring.scenic.product.infrastructure.ProductStockMapper;

@Service
public class ProductStockServiceImpl implements ProductStockService {

	private static Logger logger = LoggerFactory.getLogger(ProductStockServiceImpl.class);
	@Resource
	private ProductStockMapper productStockMapper;
	@Resource
	private ProductStockLogMapper productStockLogMapper;

	@Override
	public int addStock(ProductStockVo productStockVo) {
		logger.info("库存添加参数------{}",readyStockLog(productStockVo));
		
		List<Date> list =
				DateUtil.getBetweenDates(productStockVo.getCreateStartTime(), productStockVo.getCreateEndTime());
		for (Date date : list) {
			ProductStock productStock = new ProductStock();
			productStock.setPlayDay(date);
			productStock.setAdultPrice(productStockVo.getAdultPrice());
			productStock.setChildPrice(productStockVo.getChildPrice());
			productStock.setCreateUser(productStockVo.getCreateUser());
			productStock.setUpdateUser(productStockVo.getUpdateUser());
			productStock.setMealsId(productStockVo.getMealsId());
			productStock.setSingleRoomPrice(productStockVo.getSingleRoomPrice());
			productStock.setProductType(productStockVo.getProductType());
			productStock.setPrice(productStockVo.getPrice());
			productStock.setTotalNum(productStockVo.getTotalNum());
			productStock.setCreateTime(new Date());
			productStock.setUpdateTime(new Date());
			productStock.setSaleNum(0);
			productStockMapper.insert(productStock);
		}
		//添加库存修改日志
		insertStockLog(productStockVo);
		return 1;
	}

	@Override
	public List<ProductStockMounthVo> selectMonthAll(ProductStock productStock) {
		
		List<ProductStock> list = productStockMapper.selectMonthAll(productStock);
		List<ProductStock> listTemp = new ArrayList<ProductStock>();
		List<ProductStockMounthVo> listProductStockMounthVo = new ArrayList<ProductStockMounthVo>();
		ProductStockMounthVo result = new ProductStockMounthVo();
		for (int i = 0; i < list.size(); i++) {
			Calendar first = Calendar.getInstance();
			first.setTime(list.get(0).getPlayDay());
			//月第一天不为星期天 前几天补空
			if(i == 0 && first.get(Calendar.DAY_OF_WEEK) !=1){
				for (int j = 0; j < first.get(Calendar.DAY_OF_WEEK)-1; j++) {
					listTemp.add(new ProductStock());
				}
			}
			listTemp.add(list.get(i));
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(list.get(i).getPlayDay());
			//满一个星期就放进一个list
			if ((calendar.get(Calendar.DAY_OF_WEEK)) % 7 == 0) {
				result.setStocks(listTemp);
				listProductStockMounthVo.add(result);
				listTemp = new ArrayList<ProductStock>();
				result = new ProductStockMounthVo();
			}
		}
		//判断最后几天
		if (listTemp.size() > 0) {
			result.setStocks(listTemp);
			listProductStockMounthVo.add(result);
		}
		return listProductStockMounthVo;
	}

	@Override
	public List<ProductStock> selectList(ProductStockVo productStockVo) {
		 
		return productStockMapper.selectList(productStockVo);
	}

	@Override
	public int batchUpdateStock(ProductStockVo productStockVo) {
		List<ProductStock> list = productStockMapper.selectList(productStockVo);
		if (list.isEmpty()) {
			return 2;
		}
		for (ProductStock productStock : list) {
			productStock.setAdultPrice(productStockVo.getAdultPrice());
			productStock.setChildPrice(productStockVo.getChildPrice());
			productStock.setPrice(productStockVo.getPrice());
			productStock.setSingleRoomPrice(productStockVo.getSingleRoomPrice());
			productStock.setTotalNum(productStockVo.getTotalNum());
		}
		productStockMapper.batchUpdate(list);
		insertStockLog(productStockVo);
		return 1;
	}

	@Override
	public int updateStock(ProductStockVo productStockVo) {
		int result = productStockMapper.updateByPrimaryKeySelective(productStockVo);
		ProductStock stock = productStockMapper.selectByPrimaryKey(productStockVo.getId());
		if(stock != null){
			productStockVo.setMealsId(stock.getMealsId());
		}
		productStockVo.setType(3);
		insertStockLog(productStockVo);
		return result;
	}
	
	public String readyStockLog(ProductStockVo productStockVo){
		StringBuilder sb = new StringBuilder();
			if(null != productStockVo.getType()){
				if(1 == productStockVo.getType()){
					sb.append("添加库存:");
				}else if(2 == productStockVo.getType()){
					sb.append("批量更新库存:");
				}else if(3 == productStockVo.getType()){
					sb.append("更新库存:");
				}
			}
			if(productStockVo.getCreateStartTime() != null){
				sb.append(" 开始时间=").append(DateUtil.formatDate(productStockVo.getCreateStartTime(), DateUtil.YYYY_MM_DD) );
			}
			if(productStockVo.getCreateEndTime() != null){
				sb.append(" 结束时间=").append(DateUtil.formatDate(productStockVo.getCreateEndTime(), DateUtil.YYYY_MM_DD) );
			}
			if(productStockVo.getPrice() != null){
				sb.append(" 单价=").append(productStockVo.getPrice());
			}
			if(productStockVo.getAdultPrice() != null){
				sb.append(" 成人价=").append(productStockVo.getAdultPrice());
			}
			if(productStockVo.getChildPrice() != null){
				sb.append(" 儿童价=").append(productStockVo.getChildPrice());
			}
			if(productStockVo.getSingleRoomPrice() != null){
				sb.append(" 单房差=").append(productStockVo.getSingleRoomPrice());
			}
			if(productStockVo.getTotalNum() != null){
				sb.append(" 总库存=").append(productStockVo.getTotalNum());
			}
			if(productStockVo.getCreateTime() != null){
				sb.append(" 创建时间=").append(productStockVo.getCreateTime());
			}
			if(productStockVo.getUpdateTime() != null){
				sb.append(" 更新时间=").append(productStockVo.getUpdateTime());
			}
		return sb.toString();
	}
	//添加库存日志
	public int insertStockLog(ProductStockVo productStockVo){
		ProductStockLog psl = new ProductStockLog();
		psl.setMealsId(productStockVo.getMealsId());
		psl.setRemark(readyStockLog(productStockVo));
		psl.setCreateTime(new Date());
		psl.setCreateUser(productStockVo.getCreateUser());
		psl.setUpdateTime(new Date());
		psl.setUpdateUser(productStockVo.getUpdateUser());
		psl.setUpdateType(productStockVo.getType());
		return productStockLogMapper.insertSelective(psl);
	}
}
