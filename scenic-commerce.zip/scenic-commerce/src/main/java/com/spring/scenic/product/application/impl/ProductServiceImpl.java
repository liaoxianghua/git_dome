package com.spring.scenic.product.application.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.infrastructure.KeywordMapper;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductMealsMapper;
import com.spring.scenic.system.domain.City;

@Service
public class ProductServiceImpl implements ProductService {

	@Resource
	private ProductMapper productMapper;

	@Resource
	private KeywordMapper keywordMapper;

	@Resource
	private ProductMealsMapper productMealsMapper;

	@Override
	public List<Product> list(Product product, boolean page, Integer pageSize) {
		try {
			if (page) {
				PageHelper.startPage(product.getPageNum(), product.getPageSize());
			}
			if (StringUtil.isEmpty(product.getOrderField())) {
				if (product.getIsSale() != null) {
					if (product.getIsSale() == 1) {
						product.setOrderByClause(" a.sales_time DESC, a.sale_num desc ");
					} else {
						product.setOrderByClause(" a.create_time DESC , a.sale_num desc");
					}
				}
			} else {
				product.setOrderByClause(product.getOrderField() + " " + product.getOrderDirection() + " , "
						+ product.getOrderField2() + " " + product.getOrderDirection2());
			}
			return productMapper.getProductList(product);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	@Override
	public ProductWithBLOBs selectByPrimaryKey(Integer id) {
		return productMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ProductWithBLOBs product) {
		if (product != null) {
			ProductWithBLOBs productWithBLOBs = productMapper.selectByPrimaryKey(product.getId());
			if (productWithBLOBs == null) {
				return 0;
			} else {
				if (product.getValid() != null) {
					productWithBLOBs.setValid(product.getValid());
					productWithBLOBs.setUpdateUser(product.getUpdateUser());
					productWithBLOBs.setUpdateTime(new Date());
				}
				if (product.getIsSale() != null) {
					productWithBLOBs.setIsSale(product.getIsSale());
					productWithBLOBs.setSalesTime(new Date());
					productWithBLOBs.setOperateUser(product.getUpdateUser());
				}
				return productMapper.updateByPrimaryKeySelective(productWithBLOBs);
			}
		} else {
			return 0;
		}
	}

	@Override
	public int update(ProductWithBLOBs product) {
		// 修改产品无效 同时将产品下架
		if (product != null && product.getValid() != null && product.getValid() == 0) {
			product.setIsSale(0);
		}
		return productMapper.updateByPrimaryKeySelective(product);
	}

	@Override
	public int updateBatch(String ids, Integer isSale, BusiSellerUser sellerUser) {
		List<Product> list = new ArrayList<Product>();
		if (StringUtil.isNotEmpty(ids)) {
			List<String> listIds = Arrays.asList(ids.split(","));
			Product p = null;

			for (String id : listIds) {
				p = new Product();
				p.setId(Integer.valueOf(id));
				p.setUpdateTime(new Date());
				p.setUpdateUser(sellerUser.getId());
				if (isSale == 1) {
					p.setSalesTime(new Date());
					p.setOperateUser(sellerUser.getId());
				}
				p.setIsSale(isSale);
				p.setSellerId(sellerUser.getSellerId());
				list.add(p);
			}
		} else {
			return 0;
		}
		return productMapper.batchUpdate(list);
	}

	@Override
	public int saveProduct(ProductWithBLOBs productWithBLOBs) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		productWithBLOBs.setIsSale(0);
		productWithBLOBs.setCreateTime(new Date());
		productWithBLOBs.setUpdateTime(new Date());
		productWithBLOBs.setSalesTime(new Date());
		productWithBLOBs.setProductCode("P" + sdf.format(new Date()));
		productWithBLOBs.setSaleNum(0);
		productWithBLOBs.setMinCount(1);
		productWithBLOBs.setMaxCount(-1);
		if (productWithBLOBs.getProductType() == 2) {
			productWithBLOBs.setGoodsType(1);// 默认电子产品
		}
		int result = productMapper.insert(productWithBLOBs);
		if (result > 0 && 2 != productWithBLOBs.getProductType()) {
			// 添加一个默认的套餐 不显示 且没有对接ID 不为购物类
			ProductMeals record = new ProductMeals();
			record.setMealsName(productWithBLOBs.getProductName());
			record.setProductId(productWithBLOBs.getId());
			record.setValid(0);
			record.setCreateTime(new Date());
			record.setUpdateTime(new Date());
			record.setCreateUser(productWithBLOBs.getCreateUser());
			record.setUpdateUser(productWithBLOBs.getUpdateUser());
			result = productMealsMapper.insert(record);
		}
		return result;
	}

	@Override
	public List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef) {
		return productMapper.getRealtiveKeywordList(keywordRef);
	}

	@Override
	public List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword) {
		try {
			keyword.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			// keyword.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_PRODUCT.getCode()));
			List<Keyword> list = productMapper.getSysConfigKeywordsByImagine(keyword);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
     * 系统配置关键字拖拽排序
     */
    @Override
    public void updateSysConfigKeywordOrder(KeywordRef keywordRef) {
       String [] idArray;
       String ids = keywordRef.getIds();
       if(StringUtil.isNotEmpty(ids)) {
           List<KeywordRef> list = new ArrayList<KeywordRef>();
           idArray = ids.split(",");
           for (int i = 0; i < idArray.length; i++) {
               KeywordRef keywordRefDto = new KeywordRef();
               String id = idArray[i];
               keywordRefDto.setId(Integer.valueOf(id));
               keywordRefDto.setOrd(i+1);
               list.add(keywordRefDto);
        }
           keywordMapper.updateSysConfigKeywordOrder(list);
       }
        
    }
    
	@Override
	public KeywordRef productKeyWordSave(BusiSellerUser user, KeywordRef keywordRef, Keyword keyword) {
		try {
			// 查询系统配置关键字的数量,用于得到排序序号
			keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_PRODUCT.getCode()));
			int currentOrd = keywordMapper.getSysConfigKeywordCount(keywordRef);
			keywordRef.setOrd((currentOrd + 1));
			keywordRef.setCreateTime(new Date());
			keywordRef.setCreateUser(user.getId());
			keywordRef.setUpdateTime(new Date());
			keywordRef.setUpdateUser(user.getId());
			// 系统有该关键字
			if (null != keywordRef.getKeywordId() && null != keywordRef.getOutRelatedId()) {
				// 查询系统配置当前keywordId的数量，如果>0 ,则重复，返回
				int currentKeywordIdCount = keywordMapper.getCurrentKeywordIdCount(keywordRef);
				if (currentKeywordIdCount > 0) {
					keywordRef.setFlag(SysConstant.OPT_FAIL);
					return keywordRef;
				} else {
					keywordMapper.addTravelNoteKeyword(keywordRef);
					int type = keywordMapper.getkeywordTypeByid(keyword);
					keyword.setType(type);
					keywordRef.setKeyword(keyword);
					keywordRef.setFlag(SysConstant.OPT_SUCCESS);
					// return keywordRef;
				}
			}
			// 系统无该关键字
			// int i = keywordMapper.getCurrentKeywordIdCountByName(keyword);
			// if(i > 0){
			// return keywordRef;
			// }
			if (null == keywordRef.getKeywordId() && null != keywordRef.getOutRelatedId()) {
				if (null != keyword.getName()) {
					keyword.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
					keyword.setCreateTime(new Date());
					keyword.setCreateUser(user.getId());
					keyword.setUpdateTime(new Date());
					keyword.setUpdateUser(user.getId());
					keyword.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_PRODUCT.getCode()));
					keyword.setType(1);// 产品添加的都是普通类标签
					keyword.setName(keyword.getName().trim());
					keywordMapper.insertSelective(keyword);
					int id = keyword.getId();
					keywordRef.setKeywordId(id);
					keywordMapper.addTravelNoteKeyword(keywordRef);
					keywordRef.setFlag(SysConstant.OPT_SUCCESS);
					keywordRef.setKeyword(keyword);
					// return keywordRef;
				}
			}
			return keywordRef;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int deleteSysConfigKeyword(Integer id) {
		KeywordRef keywordRef = new KeywordRef();
		keywordRef.setId(id);
		return keywordMapper.deleteSysConfigKeyword(keywordRef);
	}

	@Override
	public List<City> getCityList() {
		List<City> cityList = productMapper.getCityList();
		return cityList;
	}
}
