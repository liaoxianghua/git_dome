package com.spring.scenic.comment.application.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.comment.domain.vo.ProductCommentVo;
import com.spring.scenic.comment.infrastructure.ProductCommentMapper;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.memberMsg.domain.MemberMsg;
import com.spring.scenic.memberMsg.infrastructure.MemberMsgMapper;

@Service
public class ProductCommentServiceImpl implements ProductCommentService {

	@Resource
	private ProductCommentMapper productCommentMapper;
	
    @Resource
    private MemberMsgMapper memberMsgMapper;
	
	@Override
	public List<ProductComment> list(ProductCommentVo productCommentVo,boolean page) {
		
		try {
			if(page){
				PageHelper.startPage(productCommentVo.getPageNum(), productCommentVo.getPageSize());
			}
//			if(StringUtil.isEmpty(productComment.getOrderByClause())){
//				productComment.setOrderByClause("T.");
//				
//			}
			return productCommentMapper.productCommentVolist(productCommentVo);
			
		} catch (Exception e) {
			e.printStackTrace();
			 throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
 
	@Override
	public int updatestatus(ProductCommentVo productCommentVo) {
		int flag=0;
		if(null==productCommentVo){
			return 0;
		}
		
		ProductComment	productComment=productCommentMapper.selectByPrimaryKey(productCommentVo.getId());
		 if(null==productComment){
			 return 0;
		 }
		 if(null==productComment.getIsRecommend()){
			 productComment.setIsRecommend(0);
		 }
		 if(productComment.getIsRecommend()==1){
			 productComment.setIsRecommend(0); //修改为取消推荐
		 }else{
			 productComment.setIsRecommend(1);//修改为推荐
		 }
		 productComment.setUpdateTime(new Date());
		 
		 try {
			  flag=productCommentMapper.updateByPrimaryKey(productComment);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public ProductComment findByIdProductComment( ProductCommentVo productCommentVo) {
		 return productCommentMapper.selectByPrimaryKey(productCommentVo.getId());
	}

	@Override
	public int updateReply(ProductCommentVo productCommentVo) {
		
		ProductComment	productComment=productCommentMapper.selectByPrimaryKey(productCommentVo.getId());
		int flag=0;
		productComment.setSellerComtent(productCommentVo.getSellerComtent() !=null ? productCommentVo.getSellerComtent().trim():null);
		try {
			flag = productCommentMapper.updateByPrimaryKey(productComment);
			//新增会员游记审核通过/不通过提示消息
            MemberMsg memberMsg = new MemberMsg();
            memberMsg.setMemberId(productComment.getCreateUser());
            //消息默认为未阅读状态
            memberMsg.setMsgStatus(0);
            //消息类别：1、首次注册；2、密码更改；3、订单状态更改；4、商户回复评论
            memberMsg.setMsgType(4);
            memberMsg.setCreateTime(new Date());  
            memberMsg.setMsgTitle("商户对你进行了回复");
            memberMsg.setMsgContent("商户对你的评论进行了回复!"); 
            memberMsg.setCreateUser(productComment.getSellerId());//商户ID
            memberMsgMapper.addMemberMsg(memberMsg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
