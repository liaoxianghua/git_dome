@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.spring.com/")
package com.spring.scenic.sms.ws;

