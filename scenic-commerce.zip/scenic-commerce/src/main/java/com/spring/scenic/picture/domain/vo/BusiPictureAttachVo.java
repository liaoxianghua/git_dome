package com.spring.scenic.picture.domain.vo;

import java.io.Serializable;

public class BusiPictureAttachVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String urlAttach;// 图片地址
	private String name;// 图片名称

	public String getUrlAttach() {
		return urlAttach;
	}

	public void setUrlAttach(String urlAttach) {
		this.urlAttach = urlAttach;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
