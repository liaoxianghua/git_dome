package com.spring.scenic.product.infrastructure;

import java.util.List;

import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.KeywordRef;

public interface KeywordMapper {
	
	
    int insert(Keyword record);

    int insertSelective(Keyword record);

    Keyword selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Keyword record);

    int updateByPrimaryKey(Keyword record);

	List<Keyword> queryKeywordList(Keyword keyword);

	void updateKeywordById(Keyword keyword);

	List<Keyword> selectKeywordList(Keyword keyword);

	int addTravelNoteKeyword(KeywordRef keywordRef);

	int getTravelKeywordRef(KeywordRef keywordRef);

	List<Keyword> selectByTravelNoteKeywordList(KeywordRef keywordRef);

	void delTravelNoteKeyword(Keyword keyword);

	List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword);

	int getSysConfigKeywordCount(KeywordRef keywordRef);

    List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef);

    int deleteSysConfigKeyword(KeywordRef keywordRef);

    void updateSysConfigKeywordOrder(List<KeywordRef> list);

    int getCurrentKeywordIdCount(KeywordRef keywordRef);

    int getkeywordTypeByid(Keyword keyword);
    
    int getCurrentKeywordIdCountByName(Keyword keyword);
}