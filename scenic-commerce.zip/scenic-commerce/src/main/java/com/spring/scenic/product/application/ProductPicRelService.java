package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;

public interface ProductPicRelService {
    
    List<ProductPicRel> list(ProductPicRel productPicRel, boolean page, Integer pageSize);
    
    List<ProductPicRel> updateIsLogo(ProductPicRel productPicRel);

    int delete(Integer id);
    
    boolean productLibSave(Product product,String ids,BusiSellerUser sellerUser);
}
