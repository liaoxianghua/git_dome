package com.spring.scenic.schedule.application.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.memberMsg.domain.MemberMsg;
import com.spring.scenic.memberMsg.infrastructure.MemberMsgMapper;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.infrastructure.OrderMapper;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductStockMapper;
import com.spring.scenic.schedule.application.SchedulerService;

public class SchedulerServiceImpl implements SchedulerService {
    
    private Logger logger = LoggerFactory.getLogger(SchedulerServiceImpl.class);
    
    @Resource
    private OrderMapper orderMapper;
    @Resource
    private MemberMsgMapper memberMsgMapper;
    @Resource
    private ProductMapper productMapper;
    @Resource
    private ProductStockMapper productStockMapper;
    
    /**
     * 支付完成和超额支付 过了出行日期 变为已完成
     * @creator ：liaoxianghua  
     * @date ：2017年5月17日下午4:24:30
     */
    public void saveChangeOrderStatus(){
        logger.info("支付完成和超额支付 过了出行日期 变为已完成定时任务开始----"+DateUtil.formatDate(new Date(), "yyyy-mm-dd hh:mm:ss"));
        List<Order> list = orderMapper.getOrderListForQuartz();
        if(list != null && !list.isEmpty() && list.size() > 0){
        	for (Order order : list) {
        		order.setOrderStatus(6);//订单状态变为已完成
        	}
        	orderMapper.updateOrderStatusForQuartz(list);
        	logger.info("支付完成和超额支付 过了出行日期 变为已完成执行"+list.size()+"条数据");
        	for (Order order : list) {
        		MemberMsg memberMsg = new MemberMsg();
        		memberMsg.setMemberId(order.getCreateUser());
        		//消息默认为未阅读状态
        		memberMsg.setMsgStatus(0);
        		memberMsg.setMsgType(3);
        		memberMsg.setCreateTime(new Date()); 
        		memberMsg.setMsgTitle("订单状态变更");
        		memberMsg.setMsgContent("你的订单"+order.getOrderNo()+"订单状态已完成!");  
        		memberMsgMapper.addMemberMsg(memberMsg);
        	}
        }
    	logger.info("支付完成和超额支付 过了出行日期 变为已完成任务结束----"+DateUtil.formatDate(new Date(), "yyyy-mm-dd hh:mm:ss"));
    }
    
    
    /**
     * 订单状态新单，过了确认时间  变为已取消
     * @creator ：liaoxianghua  
     * @date ：2017年5月17日下午4:24:30
     */
    public void updateUnConfirmOrderStatus(){
        logger.info("订单状态新单，过了确认时间  变为已取消任务开始----"+DateUtil.formatDate(new Date(), "yyyy-mm-dd hh:mm:ss"));
        List<Order> list = orderMapper.selectUnConfirm();
        if(list != null && !list.isEmpty() && list.size() > 0){
        	for (Order order : list) {
        		order.setOrderStatus(2);//订单状态变为已完成
        	}
        	orderMapper.updateOrderStatusForQuartz(list);
        	for (Order  order: list) {
        		//是否需要退库存
            	Product product = productMapper.selectByPrimaryKey(order.getProductId());
            	product.setUpdateTime(new Date());
//            	product.setUpdateUser(sellerUser.getId());
            	if (order.getOrderType().equals(SysEnum.PRODUCT_TYPE_SCENIC.getCode())) {//景区
            		product.setSaleNum(product.getSaleNum()
            				- (order.getOrderCount() == null ? 0 : order.getOrderCount()));
            		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
            		ProductStock productStock = new ProductStock();
            		productStock.setPlayDay(order.getTravelTime());
            		productStock.setMealsId(order.getMealsId());
            		productStock = productStockMapper.selectByPrimaryParam(productStock);
            		if(null != productStock){
            			productStock.setUpdateTime(new Date());
//            			productStock.setUpdateUser(sellerUser.getId());
            			productStock.setSaleNum(productStock.getSaleNum()
            					- (order.getOrderCount() == null ? 0 : order.getOrderCount()));
            			productStockMapper.updateByPrimaryKeySelective(productStock);
            		}
            	} else if (order.getOrderType().equals(SysEnum.PRODUCT_TYPE_LINE.getCode())) {//线路
            		product.setSaleNum(product.getSaleNum()
            				- (order.getAdultCount() == null ? 0 : order.getAdultCount())
            				- (order.getChildCount() == null ? 0 : order.getChildCount()));
            		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
            		ProductStock productStock = new ProductStock();
            		productStock.setPlayDay(order.getTravelTime());
            		productStock.setMealsId(order.getMealsId());
            		productStock = productStockMapper.selectByPrimaryParam(productStock);
            		if(null != productStock){
            			productStock.setUpdateTime(new Date());
//            			productStock.setUpdateUser(sellerUser.getId());
            			productStock.setSaleNum(productStock.getSaleNum()
            					- (order.getAdultCount() == null ? 0 : order.getAdultCount())
            					- (order.getChildCount() == null ? 0 : order.getChildCount()));
            			productStockMapper.updateByPrimaryKeySelective(productStock);
            		}
            	} else if (order.getOrderType().equals(SysEnum.PRODUCT_TYPE_SHOPPING.getCode())){//购物
            		product.setSaleNum(product.getSaleNum()
            				- (order.getOrderCount() == null ? 0 : order.getOrderCount()));
            		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
            	}
            
			}
        	logger.info("订单状态新单，过了确认时间  变为已取消执行"+list.size()+"条数据");
        	for (Order order : list) {
        		MemberMsg memberMsg = new MemberMsg();
        		memberMsg.setMemberId(order.getCreateUser());
        		//消息默认为未阅读状态
        		memberMsg.setMsgStatus(0);
        		memberMsg.setMsgType(3);
        		memberMsg.setCreateTime(new Date()); 
        		memberMsg.setMsgTitle("订单状态变更");
        		memberMsg.setMsgContent("你的订单"+order.getOrderNo()+"订单状态已取消!");  
        		memberMsgMapper.addMemberMsg(memberMsg);
        	}
        }
    	logger.info("订单状态新单，过了确认时间  变为已取消任务结束----"+DateUtil.formatDate(new Date(), "yyyy-mm-dd hh:mm:ss"));
    }
 

}
