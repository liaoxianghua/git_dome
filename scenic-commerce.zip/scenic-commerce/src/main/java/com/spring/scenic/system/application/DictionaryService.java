package com.spring.scenic.system.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;

public interface DictionaryService {

	List<Dictionary> getDictionaryList(Dictionary dictionary, boolean pageFalse);

	Map<String, List<Dictionary>> initDictionary(Dictionary dictionary);

	Map<String, Dictionary> initDictionaryMap(Dictionary dictionary);
	
	int saveDictionary(AuthUser user, Dictionary dictionary);

	Dictionary getDictionary(Dictionary dictionary);

	int deleteDictionary(Dictionary dictionary);

	List<Dictionary> getDictionaryListByCode(Dictionary dictionary);

	
}
