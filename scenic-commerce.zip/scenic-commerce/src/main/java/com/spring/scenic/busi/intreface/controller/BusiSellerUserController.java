package com.spring.scenic.busi.intreface.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.scenic.common.extend.BaseController;

@Controller
@RequestMapping("user")
public class BusiSellerUserController extends BaseController {
    
    public String userInfo(){
        
        return "user/userInfo";
    }
    
    
    

}
