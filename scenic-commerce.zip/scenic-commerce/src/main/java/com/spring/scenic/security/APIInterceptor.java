package com.spring.scenic.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 对接口需要登录的方法进行拦截
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年5月27日
 */
public class APIInterceptor extends HandlerInterceptorAdapter {

	Logger logger = LoggerFactory.getLogger(APIInterceptor.class);
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		logger.info("进入拦截器------------------------" +request.getRequestURI() +"---------------------------------------");
		HttpSession session = request.getSession();
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
		ModelAndView modelAndView) throws Exception {
		logger.info("requestUrl = " +request.getRequestURI());
		super.postHandle(request, response, handler, modelAndView);
	}
}
