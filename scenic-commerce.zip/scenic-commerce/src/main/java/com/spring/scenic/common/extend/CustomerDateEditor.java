package com.spring.scenic.common.extend;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.util.StringUtils;

/**
 * @Description DATE类型属性编辑器
 * @author 006568（shuchang）
 * @date 2016年12月23日
 */
public class CustomerDateEditor extends CustomDateEditor {
	
	private DateFormat dateFormat;
	
	private final DateFormat defaultDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	public CustomerDateEditor(DateFormat dateFormat, boolean allowEmpty) {
		super(dateFormat,allowEmpty);
		this.dateFormat = dateFormat;
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		if(!StringUtils.hasText(text)){
			setValue(null);
		}else{
			try {
				if(text.length()>10){
					setValue(this.dateFormat.parse(text));
				}else{
					setValue(this.defaultDateFormat.parse(text));
				}
			} catch (ParseException ex) {
				throw new IllegalArgumentException("Could not parse date: " + ex.getMessage(), ex);
			}
		}
	}
	
	

}
