package com.spring.scenic.sms.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for emailParamBean complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="emailParamBean">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountMarket" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="base64string" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="content" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="subject" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targets" type="{http://webservice.spring.com/}sendTargets" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "emailParamBean", propOrder = { "accountMarket", "base64String", "content", "dataCode", "fileName",
        "subject", "targets" })
public class EmailParamBean {

    protected String accountMarket;

    @XmlElement(name = "base64string")
    protected String base64String;

    protected String content;

    protected String dataCode;

    protected String fileName;

    protected String subject;

    protected SendTargets targets;

    /**
     * Gets the value of the accountMarket property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getAccountMarket() {
        return accountMarket;
    }

    /**
     * Sets the value of the accountMarket property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAccountMarket(String value) {
        this.accountMarket = value;
    }

    /**
     * Gets the value of the base64String property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getBase64String() {
        return base64String;
    }

    /**
     * Sets the value of the base64String property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setBase64String(String value) {
        this.base64String = value;
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setContent(String value) {
        this.content = value;
    }

    /**
     * Gets the value of the dataCode property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getDataCode() {
        return dataCode;
    }

    /**
     * Sets the value of the dataCode property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setDataCode(String value) {
        this.dataCode = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the subject property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of the subject property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setSubject(String value) {
        this.subject = value;
    }

    /**
     * Gets the value of the targets property.
     * 
     * @return
     *         possible object is {@link SendTargets }
     * 
     */
    public SendTargets getTargets() {
        return targets;
    }

    /**
     * Sets the value of the targets property.
     * 
     * @param value
     *            allowed object is {@link SendTargets }
     * 
     */
    public void setTargets(SendTargets value) {
        this.targets = value;
    }

}
