package com.spring.scenic.order.intreface.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderMoneyChangeRec;
import com.spring.scenic.order.domain.vo.OrderAndInvoice;

@Controller
@RequestMapping("order")
public class OrderController extends BaseController {

    @Autowired
    private OrderService orderService;

    /**
     * 订单列表
     */
    @RequestMapping(value = "orders", method = {RequestMethod.GET})
    public String orderList(HttpServletRequest request, Order order) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
//        request.setAttribute("order-new", true);
//        request.setAttribute("order-sure", true);
//        request.setAttribute("order-chargeback", true);
        request.setAttribute("orderStatisic", orderStatisic);
        request.setAttribute("active", 1);
        request.setAttribute("sellerUser", sellerUser);
        return "order/orderList";
    }
    
    /**
     * 订单详细页
     */
    @RequestMapping(value = "detail/{id}", method = {RequestMethod.GET})
    public String detail(HttpServletRequest request, @PathVariable Integer id) {
    	Order exampleOrder = new Order();
        exampleOrder.setId(id);
        Order order = orderService.getOrder(exampleOrder);
        request.setAttribute("order", order);
        request.setAttribute("active", 1);
        return "order/detail";
    }
    
    /**
     * 取消、确认操作修改订单状态
     */
    @RequestMapping(value = "detail/status/{id}/{status}", method = {RequestMethod.GET})
    public String detail(HttpServletRequest request, @PathVariable Integer id, @PathVariable Integer status) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        Order exampleOrder = new Order();
        exampleOrder.setId(id);
        exampleOrder.setOrderStatus(status);
        orderService.updateOrderStatus(exampleOrder,sellerUser);
        Order order = orderService.getOrder(exampleOrder);
        request.setAttribute("order", order);
        request.setAttribute("active", 1);
        return "order/detail";
    }
    
    /**
     * 首页进入订单列表
     */
    @RequestMapping(value = "orderList/{status}", method = {RequestMethod.GET})
    public String orderList(HttpServletRequest request, Order order,@PathVariable String status) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if(StringUtils.isNotBlank(status)){
            if(status.equals("today_all")){
                request.setAttribute("createTimeStart", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("createTimeEnd", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("active", 1);
            }else if(status.equals("total_new")){
                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_NEW.getCode()));
                request.setAttribute("active", 6);
            }else if(status.equals("total_chargeback")){
            	request.setAttribute("active", 7);
                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_CHARGEBACK.getCode()));
            }else if(status.equals("today_canceled")){
            	request.setAttribute("active", 1);
                request.setAttribute("createTimeStart", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("createTimeEnd", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_CANCELED.getCode()));
            }
        }
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
        request.setAttribute("orderStatisic", orderStatisic);
        request.setAttribute("sellerUser", sellerUser);
        return "order/orderList";
    }
    
    /**
     * 查询订单数据
     */
    @ResponseBody
    @RequestMapping(value = "getOrderListData", method = {RequestMethod.POST})
    public MessageData getOrderListData(HttpServletRequest request, Order order) {
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);   	
    	Integer sellerId = sellerUser.getSellerId();
    	order.setSellerId(sellerId);
        List<Order> list = orderService.getOrderListWithWarn(order, true);
        PageInfo<Order> page = new PageInfo<Order>(list, order.getPageSize());
        MessageData message = new MessageData(200, "查询成功");
        Map<String, Object> map = new HashMap<String,Object>();
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
        map.put("page", page);
        map.put("orderStatisic", orderStatisic);
        message.setAttachObj(map);
        return message;
    }
    
    /**
     * 更改订单状态
     */
    @ResponseBody
    @RequestMapping(value = "changeOrderStatus", method = {RequestMethod.POST})
    public MessageData changeOrderStatus(HttpServletRequest request, Order order) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        orderService.updateOrderStatus(order,sellerUser);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
    }
    
    /**
     * 保存订单数据
     */
    @ResponseBody
    @RequestMapping(value = "saveSellerRemark", method = {RequestMethod.POST})
    public MessageData saveSellerRemark(HttpServletRequest request, Order order) {
        orderService.saveSellerRemark(order);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
    }
    
    /**
     * 保存订单金额调整记录
     */
    @ResponseBody
    @RequestMapping(value = "saveOrderMoneyChange", method = {RequestMethod.POST})
    public MessageData saveOrderMoneyChange(HttpServletRequest request, OrderMoneyChangeRec orderMoneyChangeRec) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        orderService.saveOrderMoneyChange(sellerUser,orderMoneyChangeRec);
        List<OrderMoneyChangeRec> orderMoneyChangeRecs = orderService.getOrderMoneyChangeList(orderMoneyChangeRec);
        
        //更新订单应付金额
        Order exampleOrder = new Order();
        exampleOrder.setOrderNo(orderMoneyChangeRec.getOrderNo());
        Order order = orderService.getOrder(exampleOrder);
        //最新应付金额=应付金额+调整后的金额
        BigDecimal payPrice = order.getPayPrice().add(orderMoneyChangeRec.getMoney());
        order.setPayPrice(payPrice);
        
        BigDecimal payedPrice = order.getPayedPrice();
        if(payedPrice==null){
            payedPrice = BigDecimal.ZERO;
        }
        
        //付款金额为0：未付款
        if(payedPrice.compareTo(BigDecimal.ZERO)==0){
            order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_NO.getCode()));
        }else{
            if(payedPrice.compareTo(payPrice)==-1){
                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()));
            }else if(payedPrice.compareTo(payPrice)==0){
                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
            }else if(payedPrice.compareTo(payPrice)==1){
                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
            }
        }
        orderService.updateOrderPayPrice(order);
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("moenychanges", orderMoneyChangeRecs);
        map.put("payPrice", payPrice);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, map);
    }
    /**
     * 订单导出
     */
    @ResponseBody
    @RequestMapping(value = "downOrderFile", method = {RequestMethod.GET})
    public void downOrderFile(HttpServletResponse response,HttpServletRequest request,@RequestParam String orderNo,@RequestParam String memberAccount,
    		@RequestParam String linkMan,@RequestParam Integer productId,@RequestParam String productName,@RequestParam Date createTimeStart,
    		@RequestParam Date createTimeEnd,@RequestParam Date travelTimeStart,@RequestParam Date travelTimeEnd,@RequestParam String os,@RequestParam String phone
    		) {
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
    	OrderAndInvoice orderAndInvoice = new OrderAndInvoice();
		orderAndInvoice.setSellerId(sellerUser.getSellerId());
		orderAndInvoice.setMemberAccount(memberAccount);
		orderAndInvoice.setPhone(phone);
		orderAndInvoice.setLinkMan(linkMan);
		orderAndInvoice.setProductId(productId);
		orderAndInvoice.setProductName(productName);
		if(createTimeStart!=null){
			orderAndInvoice.setCreateTimeStart(DateUtil.getDayMinTime(createTimeStart));
		}
        if(createTimeEnd!=null){
	        orderAndInvoice.setCreateTimeEnd(DateUtil.getDayMaxTime(createTimeEnd));
		}
        if(travelTimeStart!=null){
			orderAndInvoice.setTravelTimeStart(DateUtil.getDayMinTime(travelTimeStart));
		}
        if(travelTimeEnd!=null){
			orderAndInvoice.setTravelTimeEnd(DateUtil.getDayMaxTime(travelTimeEnd));
		}
		orderAndInvoice.setOrderNo(orderNo);
		if(StringUtils.isNotBlank(os)){
			String[] strStatus = os.split(",");
			Integer[] status = new Integer[strStatus.length];
			for (int j = 0; j < strStatus.length; j++) {
				status[j] = Integer.valueOf(strStatus[j]);
			}
			orderAndInvoice.setStatuses(status);
		}
        orderService.downOrderFile(response,request,orderAndInvoice);
    }
}
