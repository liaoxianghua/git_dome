package com.spring.scenic.common.util;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.MessageSource;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 获取国际化文字
 * 2016-07-15
 */
public class MessageUtil{
	private static ResourceBundle resourceBundle;
	/**
	 * 获取国际化文字(不带参数)
	 * @author HP
	 * @param code
	 *
	 */	
	public static String getMessage(String code){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		
		String message="";
		MessageSource messageSource = (MessageSource)ApplicationContentUtil.getBean("messageSource");
        String[] args = null;
        Object language= request.getSession().getAttribute("language");
        if(language!=null && language.toString().equals("zh")){
        	message = messageSource.getMessage(code, args, Locale.CHINA);
        }else if(language!=null && language.toString().equals("en")){
        	message = messageSource.getMessage(code, args, Locale.US);
        }else{
        	message = messageSource.getMessage(code, args, Locale.CHINA);
        }
        
        return message;
	}
	/**
	 * 获取国际化文字(带参数)
	 * @author HP
	 * @param code
	 * @param args
	 *
	 */	
	public static String getMessage(String code,String[] args){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		String message="";
		MessageSource messageSource = (MessageSource)ApplicationContentUtil.getBean("messageSource");
		Object language= request.getSession().getAttribute("language");
        if(language!=null && language.toString().equals("zh")){
        	message = messageSource.getMessage(code, args, Locale.CHINA);
        }else if(language!=null && language.toString().equals("en")){
        	message = messageSource.getMessage(code, args, Locale.US);
        }else{
        	message = messageSource.getMessage(code, args, Locale.CHINA);
        }
		
        return message;
	}
	public static String getSysKey(String code){
		if(resourceBundle==null){
			resourceBundle=ResourceBundle.getBundle("system");
		}
		return resourceBundle.getString(code);
	}
}
