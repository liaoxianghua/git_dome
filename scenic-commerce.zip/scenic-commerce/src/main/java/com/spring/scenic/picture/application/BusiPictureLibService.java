package com.spring.scenic.picture.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.picture.domain.vo.BusiPictureAttachVo;
import com.spring.scenic.picture.domain.vo.BusiPictureLibVo;

public interface BusiPictureLibService {

    public List<BusiPictureLib> list(BusiPictureLibVo pictureLib, boolean page);


	/**
	 * 
	 * @param filesMap
	 * @return 文件上传后直接,调取返回的URL地址
	 */
	public BusiPictureAttachVo saveUploadFile(Map<String, List<MultipartFile>> filesMap);
	/**
	 * 
	 * @param picName
	 * @param useType
	 * @param url
	 */
	public int saveData(String picName, String useType, String url,Integer userid);

	/**
	 * 
	 * @param id
	 * @param userid
	 * @return
	 *  根据传递过来的图片ID删除数据
	 */
	public int delPicture(Integer id, Integer userid);
}
