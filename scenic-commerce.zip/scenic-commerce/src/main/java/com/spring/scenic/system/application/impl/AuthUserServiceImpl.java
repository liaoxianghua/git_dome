package com.spring.scenic.system.application.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.infrastructure.AuthUserMapper;

@Service
public class AuthUserServiceImpl implements AuthUserService {
	
	@Autowired
	private AuthUserMapper authUserMapper;

	@Override
	public boolean havePermission(String code, AuthUser user) {
		try {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("code", code);
			map.put("userId", user.getId());
			List<AuthResource> userResouces = authUserMapper.getUserResourceListByCode(map);
			return userResouces!=null && !userResouces.isEmpty() ;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public AuthUser getUserByAccount(String username) {
		try {
			return authUserMapper.getUserByAccount(username);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<AuthRole> getUserRoleList(AuthUser authUser) {
		try {
			return authUserMapper.getUserRoleList(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<AuthResource> getUserResourceList(AuthUser authUser) {
		try {
			return authUserMapper.getUserResourceList(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<AuthRole> getRoleList(AuthRole authRole) {
		try {
			return authUserMapper.getRoleList(authRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public List<AuthRole> getRoleListByResource(AuthResource resource) {
		try {
			return authUserMapper.getRoleListByResource(resource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<AuthResource> getResourceList(AuthResource authResource) {
		try {
			return authUserMapper.getResourceList(authResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
