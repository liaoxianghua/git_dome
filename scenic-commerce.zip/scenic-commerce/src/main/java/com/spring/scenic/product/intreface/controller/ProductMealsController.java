package com.spring.scenic.product.intreface.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.StringUtil;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.intreface.controller.CommonController;
import com.spring.scenic.product.application.ProductMealsService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.product.domain.vo.ProductStockMounthVo;

/**
 * 套餐控制类
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年4月10日
 */
@Controller
@RequestMapping(value = "/productMeals")
public class ProductMealsController extends CommonController {

	@Resource
	private ProductService productService;

	@Resource
	private ProductMealsService productMealsService;

	@Resource
	private ProductStockService productStockService;

	/**
	 * 根据套餐ID查询库存
	 * 此处为类方法说明
	 * @param flag 1 or 0 1 下一个月 0 上一个月
	 * @param date yyyymm
	 * @return
	 ** 
	 */
	@ResponseBody
	@RequestMapping(value = "/getStockByMealsId")
	public MessageData getStockByMealsId(ProductStock params, String date, Integer flag, HttpServletRequest request) {
		MessageData data = new MessageData(200, "查询成功");
		ProductMeals productMeals = productMealsService.selectByPrimaryKey(params.getMealsId());
		if (productMeals == null) {
			return new MessageData(500, "套餐不存在");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("productMeals", productMeals);
		Product product = productService.selectByPrimaryKey(productMeals.getProductId());
		map.put("product", product);
		// 默认当前月
		if (StringUtil.isEmpty(date)) {
			params.setPlayDay(new Date());
		} else {
			params.setPlayDay(StringToDate(date));
		}
		// 库存
		List<ProductStockMounthVo> listProductStocks = productStockService.selectMonthAll(params);
		map.put("productStocks", listProductStocks);
		List<String> listMonth = this.getLast8Months(params.getPlayDay(), flag);
		// 时间tab
		map.put("listMonth", listMonth);
		data.setAttachObj(map);
		return data;
	}

	// 查询产品套餐列表
	@ResponseBody
	@RequestMapping(value = "/productMealsList", method = { RequestMethod.POST })
	public MessageData productMealsList(Integer productId, HttpServletRequest request) {
		if (null == productId) {
			return new MessageData(500, "产品ID不能为空");
		}

		ProductWithBLOBs productWithBLOBs = productService.selectByPrimaryKey(productId);
		MessageData data = new MessageData(200, "查询成功");
		Map<String, Object> map = new HashMap<String, Object>();
		if (productWithBLOBs != null) {
			map.put("product", productWithBLOBs);
		}
		// 产品下的套餐
		ProductMeals productMeals = new ProductMeals();
		productMeals.setProductId(productId);
		List<ProductMeals> list = productMealsService.selectAllByProductId(productMeals);
		map.put("meals", list);
		if (list != null && list.size() > 0) {
			map.put("productMeal", list.get(0));
		} else {
			map.put("productMeal", new ProductMeals());
		}
		List<String> listMonth = this.getLast8Months(new Date(), null);
		map.put("listMonth", listMonth);
		data.setAttachObj(map);
		return data;
	}

	// 保存套餐
	@ResponseBody
	@RequestMapping(value = "/productMealsSave")
	public MessageData productMealsSave(ProductMeals productMeals, HttpServletRequest request) {
		MessageData data = new MessageData(200, "查询成功");
		if (productMeals != null) {
			if (productMeals.getId() != null) {
				productMealsService.updateMeals(productMeals);
			} else {
				productMealsService.addMeals(productMeals);
			}
		} else {
			return new MessageData(500, "产品不能为空");
		}
		return data;
	}

	// 编辑套餐
	@ResponseBody
	@RequestMapping(value = "/toEditMeals")
	public MessageData toEditMeals(Integer id, HttpServletRequest request) {
		MessageData data = new MessageData(200, "查询成功");
		ProductMeals productMeal = productMealsService.selectByPrimaryKey(id);
		data.setAttachObj(productMeal);
		return data;
	}

	// 查询套餐
	@Deprecated
	@ResponseBody
	@RequestMapping(value = "/toAddMeals")
	public MessageData toAddMeals(Integer productId, HttpServletRequest request) {
		MessageData data = new MessageData(200, "查询成功");
		ProductMeals productMeals = new ProductMeals();
		productMeals.setProductId(productId);
		data.setAttachObj(productMeals);
		return data;
	}

	// 获取时间的就8个月份
	public List<String> getLast8Months(Date date, Integer flag) {
		List<String> last8Months = new ArrayList<String>();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.DATE, 1);//设置为当前1号
		if (flag != null && flag == 1) {
			cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 7); // 要先-7,往前推7个月
		} else {
			cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 2); // 要先-2,才能把本月和上月算进去的算进去
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月");
		for (int i = 0; i < 8; i++) {
			cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) + 1); // 逐次往后推1个月
			try {
				last8Months
						.add(sdf.format(sdf.parse(cal.get(Calendar.YEAR) + "年" + (cal.get(Calendar.MONTH) + 1) + "月")));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return last8Months;
	}

	// 2017年03月 ---date
	public Date StringToDate(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		Date date = null;
		try {
			String reg = "[\u4e00-\u9fa5]";
			Pattern pat = Pattern.compile(reg);
			Matcher mat = pat.matcher(time);
			String repickStr = mat.replaceAll("");
			date = sdf.parse(repickStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
