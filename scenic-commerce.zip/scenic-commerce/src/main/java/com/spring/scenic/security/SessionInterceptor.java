package com.spring.scenic.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;

public class SessionInterceptor extends HandlerInterceptorAdapter{
	
	@Override
	public void afterCompletion(HttpServletRequest req,HttpServletResponse rsp, Object obj, Exception e) throws Exception {
	
	}

	@Override
	public void postHandle(HttpServletRequest req, HttpServletResponse rsp,Object obj, ModelAndView mode) throws Exception {
	
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,Object obj) throws Exception {
		BusiSellerUser user = (BusiSellerUser)request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(user==null){
		    response.setHeader("sessionstatus", "timeout");
		}
	    return true;
	}
	
}
