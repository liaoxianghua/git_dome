package com.spring.scenic.notice.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.notice.application.NoticeService;
import com.spring.scenic.notice.domain.BusiNotice;

@Controller
@RequestMapping("notice")
public class NoticeController extends BaseController {

    @Autowired
    private NoticeService noticeService;

    @RequestMapping(value = "notices", method = {RequestMethod.GET})
    public String orderList(HttpServletRequest request, BusiNotice notice) {
//        List<Order> list = orderService.getOrderListData(order, true, order.getPageSize());
//        PageInfo<Order> page = new PageInfo<Order>(list, order.getPageSize());
//        request.setAttribute("page", page);
        request.setAttribute("active", 0);
        return "notice/notices";
    }
    
    @ResponseBody
    @RequestMapping(value = "getNoticeListData", method = {RequestMethod.POST})
    public PageInfo<BusiNotice> getNoticeListData(HttpServletRequest request, BusiNotice notice) {
        List<BusiNotice> list = noticeService.getNoticeList(notice, true);
        PageInfo<BusiNotice> page = new PageInfo<BusiNotice>(list, notice.getPageSize());
        return page;
    }
    
    @RequestMapping(value = "noticeDetail/{id}", method = {RequestMethod.GET})
    public String getNotice(HttpServletRequest request, BusiNotice notice,@PathVariable Integer id) {
        notice.setId(id);
        BusiNotice exsitedNotice = noticeService.getNotice(notice);
        if(null!=id){
        	exsitedNotice.setReadCount(exsitedNotice.getReadCount()+1);//阅读数量的增加
        	noticeService.updateReadCountById(exsitedNotice);//通过id更新阅读数
        }
        request.setAttribute("exsitedNotice", exsitedNotice);
        request.setAttribute("active", 0);
        return "notice/noticeDetail";
    }
    
    @RequestMapping(value = "noticeAttachDownload", method = RequestMethod.GET)
    public void noticeAttachDownload(HttpServletResponse response, BusiNotice busiNotice) {
        noticeService.noticeAttachDownload(response, busiNotice);
    }
}
