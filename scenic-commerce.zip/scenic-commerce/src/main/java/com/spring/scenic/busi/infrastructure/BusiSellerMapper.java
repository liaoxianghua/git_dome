package com.spring.scenic.busi.infrastructure;

import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;

public interface BusiSellerMapper {

    BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser);
    
}