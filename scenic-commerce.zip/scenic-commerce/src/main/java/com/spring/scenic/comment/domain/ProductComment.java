package com.spring.scenic.comment.domain;

import java.util.Date;

import com.spring.scenic.comment.domain.vo.ProductCommentVo;
import com.spring.scenic.common.domain.Entity;

public class ProductComment extends Entity<ProductComment> {

	private Integer id;

	private String orderId;

	private String content;

	private Integer gread;

	private Integer isRecommend;

	private Integer sellerId;

	private Integer productId;

	private String productName;

	private Integer src;

	private String sellerComtent;

	private Integer createUser;

	private Date createTime;

	private Integer updateUser;

	private Date updateTime;

	private ProductCommentVo ProductCommentVo;
	 

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId == null ? null : orderId.trim();
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public Integer getGread() {
		return gread;
	}

	public void setGread(Integer gread) {
		this.gread = gread;
	}

	public Integer getIsRecommend() {
		return isRecommend;
	}

	public void setIsRecommend(Integer isRecommend) {
		this.isRecommend = isRecommend;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName == null ? null : productName.trim();
	}

	public Integer getSrc() {
		return src;
	}

	public void setSrc(Integer src) {
		this.src = src;
	}

	public String getSellerComtent() {
		return sellerComtent;
	}

	public void setSellerComtent(String sellerComtent) {
		this.sellerComtent = sellerComtent == null ? null : sellerComtent
				.trim();
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public ProductCommentVo getProductCommentVo() {
		return ProductCommentVo;
	}

	public void setProductCommentVo(ProductCommentVo productCommentVo) {
		ProductCommentVo = productCommentVo;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

}