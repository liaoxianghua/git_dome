package com.spring.scenic.product.application;

import java.util.List;

import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.vo.ProductStockMounthVo;
import com.spring.scenic.product.domain.vo.ProductStockVo;

public interface ProductStockService {

	/**
	 * 添加库存
	 * @param 
	 * @return  
	 **
	 */
	public int addStock(ProductStockVo productStockVo);
	
	/**
	 * 批量更新库存
	 * @param 
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年4月17日     
	 * @memo ：   
	 **
	 */
	public int batchUpdateStock(ProductStockVo productStockVo);
	/**
	 * 更新库存日
	 * 此处为类方法说明
	 * @param 
	 * @creator ：lenovo  
	 * @date ：2017年4月17日     
	 **
	 */
	public int updateStock(ProductStockVo productStockVo);
	
	/**
	 * 此处为类方法说明
	 * @param 
	 * @return
	 */
	public List<ProductStock> selectList(ProductStockVo productStockVo);
	/**
	 * 根据套餐ID 月份查询库存
	 * @param 
	 * @return
	 */
	public List<ProductStockMounthVo> selectMonthAll(ProductStock productStock);
}
