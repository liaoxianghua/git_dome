package com.spring.scenic.sms.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for retBeanOfSendMessage complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="retBeanOfSendMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ifSuccess" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retBeanOfSendMessage", propOrder = { "errCode", "ifSuccess" })
public class RetBeanOfSendMessage {

    protected String errCode;

    protected String ifSuccess;

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the ifSuccess property.
     * 
     * @return
     *         possible object is {@link String }
     * 
     */
    public String getIfSuccess() {
        return ifSuccess;
    }

    /**
     * Sets the value of the ifSuccess property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setIfSuccess(String value) {
        this.ifSuccess = value;
    }

}
