
//保存备注
function saveSellerRemark(id){
	var remark=$("#sellerRemark").val();
	if(remark==''){
		bootbox.alert("请输入备注!");
		return;
	}
	if(remark.length>4000){
		bootbox.alert("备注在4000字以内!");
		return;
	}
	$.ajax({
		url: basePath+"/order/saveSellerRemark",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"sellerRemark":$("#sellerRemark").val()},
	})
	.done(function(data) {
		bootbox.alert(data.message);
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
	});
}

//改变订单状态
function changeOrderStatus(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				$(obj).attr("disabled",true);
				$(obj).css("display","none");
				$(".order-genre").css("display","none");
				if(orderStatus==2){
					$("#orderSure").css("display","none");
				}
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}

//保存调整金额
function saveOrderMoneyChange(orderNo){
	var money = $("#adjust-money").val();
	var payMoney = $("#money-should").attr("data-val");
	var moneyF = /^([-][1-9]{1}|[-][0-9]{1}\.\d{1,2}|[-][1-9]{1}[0-9]{1,7}|[-][1-9]{1}[0-9]{1,5}\.\d{1,2}|[1-9]{1}|[0-9]{1}\.\d{1,2}|[1-9]{1}[0-9]{1,7}|[1-9]{1}[0-9]{1,5}\.\d{1,2})$/;
	var mRemark = $("#adjust-remark").val();
	if(money==''){
		bootbox.alert("请输入金额!");
		return;
	}
	if(!moneyF.test(money)){
		bootbox.alert("请输入有效的金额!");
		return;
	}
	if(mRemark.length>4000){
		bootbox.alert("备注在4000以内!");
		return;
	}
	payMoney = $("#money-should").attr("data-val");
	if(payMoney==0){
		if(parseFloat(money)<0){
			bootbox.alert("调整后金额不能为小于0！");
			return;
		}
	}else{
		//alert(money+'~~payMoney:'+payMoney);
		//alert(parseFloat(money)+parseFloat(payMoney));
		if((parseFloat(money)+parseFloat(payMoney))<0){
			bootbox.alert("调整后金额不能为小于0！");
			return;
		}
	}
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$("#order_sub").attr("disabled", true);
			$.ajax({
				url: basePath+"/order/saveOrderMoneyChange",
				type: 'POST',
				dataType: 'json',
				data: {"orderNo":orderNo,"money":$("#adjust-money").val(),"remark":$("#adjust-remark").val()},
			})
			.done(function(data) {
				//bootbox.alert(data.message);
				var html = template("orderMoneyChanges",{items:data.attachObj.moenychanges});
				$("#money-should").attr("data-val",data.attachObj.payPrice);
				$("#money-should").html('¥ '+data.attachObj.payPrice);
				$("#adjustOrderPrice").html(html);
				$("#adjust-money").val(null);
				$("#adjust-remark").val(null);
				//$('#adjust-money-modal').modal('toggle');
				$(".close-adjust-money-modal").click();
				$("#order_sub").attr("disabled", false);
			})
			.fail(function(data) {
				$("#order_sub").attr("disabled", false);
				bootbox.alert(data.responseText);
			});
		}
	});
}

$(".close-adjust-money-modal").click(function(){
	 $("#moneyAdjust")[0].reset();
});

$("#order_cancel").click(function(){
	 $("#moneyAdjust")[0].reset();
});