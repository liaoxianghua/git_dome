/**
 * Created by lenovo on 2017/3/21.
 */
define(function(require,exports,module){
    var $ = require('jquery');
    var Modal = function(element,obj){
        this.$element = element;
        this.activateBtn = null;
        this.$current = null;
    }

    Modal.prototype = {
        init:function(){
            this.activateBtn = this.gainBtn();
            this.event();
            //this.setZIndex();
        },
       /*获取点击按钮*/
        gainBtn:function(){
            var activeBth = this.$element.find('[data-target]');
            if(activeBth){
                return activeBth;
            }else{
                return null;
            }
        },
        /*设置zindex*/
        setZIndex:function(){
            window.setTimeout(function(){
                console.log(this.$current.hasClass('in'));
                if(this.$current.hasClass('in')){
                    console.log(1);
                    this.$element.css('zIndex','1040');

                }else{
                    console.log(2);
                    this.$element.css('zIndex','1050');
                }
            }.bind(this),200);
        },
        event:function(){
            var thit = this;
            this.activateBtn.on('click',function(e){
                    e.preventDefault();
                    thit.$current = $(body).find($(this).attr('data-target'));
                    thit.setZIndex();
                    if(thit.$current){
                        thit.$current.on('click',function(){
                            thit.setZIndex();
                        })
                    }
            });

        }
    }

    exports.modal = Modal;
});