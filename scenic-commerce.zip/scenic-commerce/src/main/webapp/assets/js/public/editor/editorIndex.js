/**
 * Created by lenovo on 2017/3/22.
 */
define(function(require,exports,module){
    var $ = require('jquery');
     
    function Editor(obj){
        this.$editorBth = obj.$editorBth;
        this.$modalEle = obj.$modalEle;
        this.$fullBtn = null;
        this.$editorBlock = null;
        this.isClick = false;
        this.offsetLeft = 0;
        this.offsetTop = 30;
    }
    Editor.prototype={

        init:function(){
            this.event();
        },

        /*获取值*/
        gain:function(){
            /*获取模态框距离上面和左边的距离*/
            var offsetObj = this.$modalEle.find('.modal-content').offset();
            //this.offsetTop =  offsetObj.top;
            this.offsetLeft =offsetObj.left;
            /*获取全屏按钮*/
            this.$fullBtn = $('.edui-for-fullscreen .edui-button-body');
        },

        /*设置定位*/
        setPosition:function(){
            this.$modalEle.css('position','fixed');
            if(this.$editorBlock){
                this.$editorBlock.css({
                    top:-this.offsetTop+'px',
                    left:-this.offsetLeft+'px'
                });
            }
        },

        /*事件方法*/
        event:function(){
            var thit = this;
            this.$editorBth.on('click',function(){
                /*预测bootstrap效果和编辑器执行时间过后执行的代码*/
                setTimeout(function(){
                    thit.gain();
                    if(thit.$fullBtn){
                        thit.$fullBtn.on('click',function(){
                            thit.isClick = !thit.isClick;
                            thit.$editorBlock = $(this).parents('.edui-editor.edui-default');
                            if(thit.isClick){
                                thit.setPosition();
                            }else{
                                thit.$editorBlock.css('position','static');
                            }
                        });
                    }
                },460);
            })
        }
    }

    exports.Editor = Editor;
});