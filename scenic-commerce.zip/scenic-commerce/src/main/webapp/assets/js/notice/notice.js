$(function(){
	function init(params){
		$("#loadDiv").show();
		$.post(noticeListDataUrl,params,function(data){
			$("#loadDiv").hide();
			if(data && data.list&& data.list.length>0){
				var html = template("searchList",{items:data.list});
				$("#notices").html(html);
				var pagerHtml = template("pager",{page:data});
				$("#pagerData").html(pagerHtml);
			}else{
				$("#notices").html("<tr><td colspan=\"4\">没有查询到数据</td></tr>");
				$("#pagerData").html(null);
			}
		},"JSON");
	}
	
	init(null);
});

//分页
var pagerIndex = function(v){
	$("#loadDiv").show();
	var queryParams = {pageNum:v,pageSize:$("#pageSize").val()};
	$.post(noticeListDataUrl,queryParams,function(data){
		$("#loadDiv").hide();
		if(data && data.list&& data.list.length>0){
			var html = template("searchList",{items:data.list});
			$("#notices").html(html);
			var pagerHtml = template("pager",{page:data});
			$("#pagerData").html(pagerHtml);
		}else{
			$("#notices").html("<tr><td colspan=\"4\">没有查询到数据</td></tr>");
			$("#pagerData").html(null);
		}
	},"json");
};

//分页条数变化
var pageSizeChange = function(){
	pagerIndex(1);
};

//点击确定
var pageNumChange = function(){
	pagerIndex($("#pageNum").val());
};

//更换页码
function changePageNum(pag,max,pageNum){
	var reg = /^[1-9]\d*$/;
	if(pag.value==""||pag.value==null){
		$("#pageNum").val(pageNum);
	}
	if(!reg.test(pag.value)){
		$("#pageNum").val(pageNum);
	}else{
		if(pag.value>max){
			$("#pageNum").val(max);
		}
	}
}




template.helper("formatYYYYMMDDHHMISS", function(dateTime) {
	var format = 'yyyy-MM-dd HH:mm:ss';
	if(dateTime==null||dateTime==""){
		return "";
	}else{
		var dates = new Date(dateTime);
		var date = {
	            "M+": dates.getMonth() + 1,
	            "d+": dates.getDate(),
	            "H+": dates.getHours(),
	            "m+": dates.getMinutes(),
	            "s+": dates.getSeconds(),
	            "q+": Math.floor((dates.getMonth() + 3) / 3),
	            "S+": dates.getMilliseconds()
	     };
	     if (/(y+)/i.test(format)) {
	            format = format.replace(RegExp.$1, (dates.getFullYear() + '').substr(4 - RegExp.$1.length));
	     }

	     for (var k in date) {
	            if (new RegExp("(" + k + ")").test(format)) {
	            	console.log(RegExp.$1);
	                   format = format.replace(RegExp.$1, RegExp.$1.length == 1
	                          ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
	            }
	     }
	     return format;
	}
});












