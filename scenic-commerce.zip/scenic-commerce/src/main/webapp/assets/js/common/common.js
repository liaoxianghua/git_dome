template.helper("formatYYYYMMDDHHMISS", function(dateTime) {
		var format = 'yyyy-MM-dd HH:mm:ss';
		if(dateTime==null||dateTime==""){
			return "";
		}else{
			var dates = new Date(dateTime);
			var date = {
		            "M+": dates.getMonth() + 1,
		            "d+": dates.getDate(),
		            "H+": dates.getHours(),
		            "m+": dates.getMinutes(),
		            "s+": dates.getSeconds(),
		            "q+": Math.floor((dates.getMonth() + 3) / 3),
		            "S+": dates.getMilliseconds()
		     };
		     if (/(y+)/i.test(format)) {
		            format = format.replace(RegExp.$1, (dates.getFullYear() + '').substr(4 - RegExp.$1.length));
		     }

		     for (var k in date) {
		            if (new RegExp("(" + k + ")").test(format)) {
		                   format = format.replace(RegExp.$1, RegExp.$1.length == 1
		                          ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
		            }
		     }
		     return format;
		}
});
template.helper("formatYYYYMMDD", function(dateTime) {
		var format = 'YYYY-MM-dd'
		if(dateTime==null||dateTime==""){
			return "";
		}else{
			var dates = new Date(dateTime);
			var date = {
		            "M+": dates.getMonth() + 1,
		            "d+": dates.getDate(),
		            "H+": dates.getHours(),
		            "m+": dates.getMinutes(),
		            "s+": dates.getSeconds(),
		            "q+": Math.floor((dates.getMonth() + 3) / 3),
		            "S+": dates.getMilliseconds()
		     };
		     if (/(y+)/i.test(format)) {
		            format = format.replace(RegExp.$1, (dates.getFullYear() + '').substr(4 - RegExp.$1.length));
		     }
		     for (var k in date) {
		            if (new RegExp("(" + k + ")").test(format)) {
		                   format = format.replace(RegExp.$1, RegExp.$1.length == 1
		                          ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
		            }
		     }
		     return format;
		}
});

$.fn.serializeObject = function()    
{    
   var o = {};    
   var a = this.serializeArray();    
   $.each(a, function() {    
       if (o[this.name]) {    
           if (!o[this.name].push) {    
               o[this.name] = [o[this.name]];    
           }    
           o[this.name].push(this.value || null);    
       } else {    
           o[this.name] = this.value || null;    
       }    
   });    
   return o;    
};
template.helper('currencyFormat',function (currency){
	if(currency == null){
		return "";
	}
	return parseFloat(currency).toFixed(2);
})
