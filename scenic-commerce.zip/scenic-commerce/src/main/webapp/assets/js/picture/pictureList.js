
$(function(){
	init($("#searchForm").serialize());
});

$("#searchButton").click(function(){
	var createStartTime = $("#createStartTime").val();
	var createEndTime = $("#createEndTime").val();
	var cst = Date.parse(createStartTime.replace(/-/g,   "/"));
    var cet = Date.parse(createEndTime.replace(/-/g,   "/"));
    var ct = cet - cst;
    if(createStartTime.length>0 && createEndTime.length>0){
        if(ct<0){
        	bootbox.alert("创建时间止应大于创建时间起");
           return false;
        }
    } 
    init($("#searchForm").serialize());
})
//调用回车键进行对数据的插叙
 $(document).on("keyup", function(event){
	   if(event.keyCode==13){
		   init($("#searchForm").serialize());
	    }
 }); 

$(document).on("keyup", function(event){
	if(event.keyCode==46){
		$("#pictureid input[type='text']").val("");
		$("#pictureid .form-control").val("");
		init(null);
	}
});


function init(params){
	$.post(picturesListDataUrl,params,function(returndata){
		var data = returndata.attachObj;
		if(data && data.list&& data.list.length>0){
			var html = template("searchList",{items:data.list});
			$("#searchListData").html(html);
			var pagerHtml = template("pager",{page:data});
			$("#pagerData").html(pagerHtml);
		}else{
			$("#searchListData").html("没有查询到数据");
			$("#pagerData").html("");
		}
	},"JSON");
}

//$("#install").click(function(){
	$("#install").jUploader({name:"install", limit:5, width:800, height:600,auto:"auto"});
//})

$("#saveBtn").click(function(){
	var picName=$("#product-name").val();
	
	if(null==picName || ""==$.trim(picName)){
		bootbox.alert("请填写图片名称");
		return;
	}
	var install = $("input[name=install]");
	if(!install.val()){
		bootbox.alert("请选择文件");
		return;
	}
	var installUrlArr = [];
	$("input[name='install']").each(function(){
		installUrlArr.push($(this).val());
	});
	var url = installUrlArr.toString()
	var params={"url":url,"picName":picName,"useType":$("#scenic-select").val()}
	 $.post(picturessaveDataFileUrl,params,function(data){
		if(data.statusCode == 200){
			bootbox.alert(data.message);
			init($("#searchForm").serialize());
			window.location.reload();
			$("#product-name").val("");
			return ;
		}else{ 
			bootbox.alert(data.message);
//			window.location.reload();
			return ;
		}
	 },"JSON");
})

function delPicture(id){
	 bootbox.confirm("确定要删除么?",function(result){
		 if(result){
			 $.post(delPictureUrl,{"id":id},function(data){
				 if(data.statusCode == 200){
						bootbox.alert(data.message);
						init($("#searchForm").serialize());
						window.location.reload();
					}else{
						bootbox.alert(data.message);
						window.location.reload();
					} 
			 },"json")
		 }
	 })
}

$('.close').click(function(){ 
	$("#biaodanid")[0].reset();
	window.location.reload();
});
