//saleStatus销售状态  1 在售 0 下架
//checkAllStatus 全选状态 1 全选中 0 取消全选中
var global = {
	saleStatus : 1,
	checkAllStatus : 0
};
$(function() {
	// 查询
	$("#searchButton").click(function() {
		var saleStartTime = $("#saleStartTime").val();
		var saleEndTime = $("#saleEndTime").val();
		var createStartTime = $("#createStartTime").val();
		var createEndTime = $("#createEndTime").val();
		var sst = Date.parse(saleStartTime.replace(/-/g,   "/"));
	    var set = Date.parse(saleEndTime.replace(/-/g,   "/"));
	    var cst = Date.parse(createStartTime.replace(/-/g,   "/"));
	    var cet = Date.parse(createEndTime.replace(/-/g,   "/"));
	    var tt = set - sst;
	    var ct = cet - cst;
		if(saleStartTime.length>0 && saleEndTime.length>0){
	        if(tt<0){
	           bootbox.alert("上架时间止应大于上架时间起");
	           return false;
	        }
	    } 
		if(createStartTime.length>0 && createEndTime.length>0){
	        if(ct<0){
	           bootbox.alert("创建时间止应大于创建时间起");
	           return false;
	        }
	    } 
		var params = $("#searchForm").serializeObject();
		if(params != null && params.id != null ){
			if(!/^[0-9]*$/.test(params.id)){
				bootbox.alert("产品ID必须是数字")
				return false;
			}
		}
		init(params,"","");
	})
	// 销售状态更改
	$("li a.product_sales").click(function() {
		$("input[name='checkbox']").prop("checked", false);
		$("#searchForm")[0].reset()
		var _saleStatus = $(this).attr("data-status");
		if (_saleStatus == 0) {
			$("#saleTimeDiv").hide();
			$("#createTimeDiv").show();
			$("#batchUpSale").show();
			$("#batchDownSale").hide();
			global.saleStatus = 0;
			$("#orderField").val("CREATE_TIME")
			$("#orderDirection").val("DESC")
			$("#orderField2").val("SALE_NUM")
			$("#orderDirection2").val("DESC")
			$(".isSale1").hide();
			$(".isSale0").show();
			$(".isSale0").children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
		}
		if (_saleStatus == 1) {
			$("#saleTimeDiv").show();
			$("#createTimeDiv").hide();
			$("#batchUpSale").hide();
			$("#batchDownSale").show();
			global.saleStatus = 1;
			$("#orderField").val("SALES_TIME")
			$("#orderDirection").val("DESC")
			$("#orderField2").val("SALE_NUM")
			$("#orderDirection2").val("DESC")
			$(".isSale0").hide();
			$(".isSale1").show();
			$(".isSale1").children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");

		}
		$("#isSale").val(_saleStatus);
		$(".saleNum").children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
		init($("#searchForm").serialize(),"","");
	});
	$(".isSale0").hide();
	$(".isSale1").show();
	// 批量上架
	$("#batchUpSale").click(function() {
		updateIsSale($(this).attr("data-isSale"));
	})
	// 批量下架
	$("#batchDownSale").click(function() {
		updateIsSale($(this).attr("data-isSale"))
	})
	var updateIsSale = function(isSale) {
		var valArr = new Array;
		$("input[name='sub_checkbox']:checked").each(function(i) {
			valArr[i] = $(this).val();
		});
		if (valArr.length == 0) {
			bootbox.alert("至少选择一个")
			return;
		}
		var vals = valArr.join(',');// 转换为逗号隔开的字符串
		$.post(productUpdateBatchIsSaleUrl, {
			ids : vals,
			isSale : isSale
		}, function(data) {
			if (data.statusCode == 200) {
				bootbox.alert(data.message)
				$("#isSale").val(global.saleStatus)
				init($("#searchForm").serialize(),"","");
			} else {
				bootbox.alert(data.message)
			}
		}, "JSON");
	}
	init($("#searchForm").serialize(),"","");

	// 保存编辑
	$("#productEdtiBtnSave").click(function() {
		var params = $("#productEdtiBtnSaveForm").serializeObject();
		var flag = false;
		if(params.productType == 1 || params.productType == 3){
			if(!params.lastOrderDay){
				$("#lastOrderDaySpanId").show();
				$("#lastOrderDaySpanId").html("必填");
				flag = true;
			}else if(!/^[0-9]*$/.test(params.lastOrderDay)){
				$("#lastOrderDaySpanId").show();
				$("#lastOrderDaySpanId").html("只能是整数");
				flag = true;
			}else if(params.lastOrderDay > 99999999){
				$("#lastOrderDaySpanId").show();
				$("#lastOrderDaySpanId").html("超出最大限制");
				flag = true;
			}else{
				$("#lastOrderDaySpanId").hide();
			}
			if(!params.lastOrderTime){
				$("#lastOrderTimeSpanId").html("必填");
				$("#lastOrderTimeSpanId").show();
				flag = true;
			}else if(!/^[0-9]*$/.test(params.lastOrderTime)){
				$("#lastOrderTimeSpanId").html("请填入正整数");
				$("#lastOrderTimeSpanId").show();
				flag = true;
			}else if((parseInt(params.lastOrderTime)<1 || parseInt(params.lastOrderTime) > 24 ) ){
				$("#lastOrderTimeSpanId").html("必须为1-24的正整数");
				$("#lastOrderTimeSpanId").show();
				flag = true;
			}else{
				$("#lastOrderTimeSpanId").hide();
			}
		}else if(params.productType == 2){
			if(!params.totalNum){
				$("#goodsTotalNumSpanId").show();
				$("#goodsTotalNumSpanId").html("必填");
				flag = true;
			}else if(!/^[0-9]*$/.test(params.totalNum)){
				$("#goodsTotalNumSpanId").show();
				$("#goodsTotalNumSpanId").html("请填入正整数");
				flag = true;
			}else if(params.totalNum > 9999){
				$("#goodsTotalNumSpanId").show();
				$("#goodsTotalNumSpanId").html("超出最大限制");
				flag = true;
			}else if(params.totalNum < 1){
				$("#goodsTotalNumSpanId").show();
				$("#goodsTotalNumSpanId").html("请填入正整数");
				flag = true;
			}else{
				$("#goodsTotalNumSpanId").hide();
			}
			if(!params.price){
				$("#goodsPriceSpanId").show();
				$("#goodsPriceSpanId").html("必填");
				flag = true;
			}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(params.price)){
				$("#goodsPriceSpanId").show();
				$("#goodsPriceSpanId").html("请填入正数,精确到小数点后2位");
				flag = true;
			}else if(params.price.length > 5){
				$("#goodsPriceSpanId").show();
				$("#goodsPriceSpanId").html("超出最大限制");
				flag = true;
			}else{
				$("#goodsPriceSpanId").hide();
			}
		}
		
		if(!params.productSubType){
			$("#productSubTypeSpanId").show();
			flag = true;
		}else{
			$("#productSubTypeSpanId").hide();
		}
		if(!params.productName){
			$("#editProductNameSpanId").show();
			flag = true;
		}else{
			$("#editProductNameSpanId").hide();
		}
		if(!params.confirmHour){
			$("#confirmHourSpanId").show();
			$("#confirmHourSpanId").html("必填");
			flag = true;
		}else if(!/^[0-9]*$/.test(params.confirmHour)){
			$("#confirmHourSpanId").show();
			$("#confirmHourSpanId").html("请填入整数");
			flag = true;
		}else if(params.confirmHour > 99999999){
			$("#confirmHourSpanId").show();
			$("#confirmHourSpanId").html("超出最大限制");
			flag = true;
		}else{
			$("#confirmHourSpanId").hide();
		}
		if(!params.minCount){
			$("#minCountSpanId").show();
			$("#minCountSpanId").html("必填");
			flag = true;
		}else if(!/^[0-9]*$/.test(params.minCount)){
			$("#minCountSpanId").show();
			$("#minCountSpanId").html("请填入正整数");
			flag = true;
		}else if(params.minCount < 1){
			$("#minCountSpanId").show();
			$("#minCountSpanId").html("最少预定1份");
			flag = true;
			return false;
		}else if(params.minCount > 99999999){
			$("#minCountSpanId").show();
			$("#minCountSpanId").html("超出最大限制");
			flag = true;
		}else{
			$("#minCountSpanId").hide();
		} 
		if(!params.maxCount){
			$("#maxCountSpanId").show();
			$("#maxCountSpanId").html("必填");
			flag = true;return false;
		}else if(!/^[0-9]*$/.test(params.maxCount) && params.maxCount != -1){
			$("#maxCountSpanId").show();
			$("#maxCountSpanId").html("只能是正整数或-1");
			flag = true;return false;
		}else if(params.maxCount == 0){
			$("#maxCountSpanId").show();
			$("#maxCountSpanId").html("最少预定1份");
			flag = true;
		}else if(params.maxCount > 99999999){
			$("#maxCountSpanId").show();
			$("#maxCountSpanId").html("超出最大限制");
			flag = true;
		}else{
			$("#maxCountSpanId").hide();
		}
		if(params.goodsType == 0){
			if(params.takeAddress == null || params.takeAddress == '' || params.takeAddress.trim() == 0 ){
				$("#takeAddressSpanId").html("必填");
				$("#takeAddressSpanId").show();
				return false;
			}if(params.takeAddress.length > 200 ){
				$("#takeAddressSpanId").html("最多200字");
				$("#takeAddressSpanId").show();
				return false;
			}else{
				$("#takeAddressSpanId").hide();
			}
		}
		if(!flag){
			params = readyParams(params);
			if(params){
				$.post(productEdtiBtnSaveUrl, params, function(data) {
					if (data.statusCode == 200) {
						$("#isSale").val(global.saleStatus)
						bootbox.alert(data.message)
						init($("#searchForm").serialize(),"","");
						$("#closeEditButton").click();
					} else {
						bootbox.alert(data.message)
					}
				}, "json");
			}
		}else{
			$("#tab-1").click();
			return false;
		}
		
		// 获取富文本内容
		function readyParams(params) {
			var _recommend = UE.getEditor('container-recommend');
			var flag2 = true;
			if(!_recommend.getContent()){
				$("#containerRecommendSpanId").show()
				flag2 =  false;
			}else{
				$("#containerRecommendSpanId").hide()
			}
			params["recommend"] = _recommend.getContent();
			var _remark = UE.getEditor('container-img-text');
			if(!_remark.getContent()){
				$("#containerImgTextSpanId").show();
				flag2 =  false;
			}else{
				$("#containerImgTextSpanId").hide()
			}
			if(!flag2){
				$("#tab-2").click();
				bootbox.alert("请完成商品介绍")
				return false;
			}
			params["remark"] = _remark.getContent();
			var _traffic = UE.getEditor('container-trffic');
			var flag3 = true;
			params["traffic"] = _traffic.getContent();
			var _orderRule = UE.getEditor('container-reserve');
			if(!_orderRule.getContent()){
				$("#containerReserveSpanId").show()
				bootbox.alert("请完成预定/退改规则")
				flag3 = false;
			}else{
				$("#containerReserveSpanId").hide()
				
			}
			params["orderRule"] = _orderRule.getContent();
			var _returnRule = UE.getEditor('container-retreat');
			if(!_returnRule.getContent()){
				$("#containerRetreatSpanId").show()
				
				flag3 =  false;
			}else{
				$("#containerRetreatSpanId").hide()
			}
			if(!flag3){
				$("#tab-3").click();
				return false;
			}
			params["returnRule"] = _returnRule.getContent();
			return params;
		}
	});
});
// 联想功能
var t = [];
var selectIndex = "";
function mind() {
	// 定义一个数组，用于装载联想输入得到的关键字名和id,
	// 以键值对的形式储存，key:关键字名，value:关键字id
	
	var selectIndex = "";
	// 通过输入数据，联想显示相关数据
	$("#keywordName").typeahead({
		source : function(query, process) {
			// query是输入的值,name是当前输入框的name属性的值
			$.post(keyWordListDataUrl, {
				name : query
			}, function(r) {
				var e = r;
				if (e.statusCode == 200) {
					if (e.attachObj.length == 0) {
						$(".dropdown-menu").hide();
						return;
					}
					var array = [];
					$.each(e.attachObj, function(index, ele) {
						t[ele.name] = ele.id;
						t[ele.name + index] = ele.id;
						array.push(ele.name);
					});
					process(array);
				}
			}, "JSON");
		},
		displayText : function(item) {
			return item;// 返回字符串
		},
		afterSelect : function(item) {
			selectIndex = this.$menu.find(".active").index();
		},
		items : 20,
		delay : 500
	});
}
// 更新状态 上下架
function updateValid(param) {
	$.post(productUpdateUrl, param, function(data) {
		if (data.statusCode == 200) {
			bootbox.alert(data.message)
			$("#isSale").val(global.saleStatus)
			init($("#searchForm").serialize(),"","");
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
// 产品关键字列表
function toProductKeyWord(param) {
	$.post(productKeyWordUrl, {
		productId : param
	}, function(data) {
		if (data.statusCode == 200) {
			var html = template("productKeyWordScript", {
				items : data.attachObj.keywords,
				productId : param
			})
			console.log(data.attachObj.keywords)
			$("#productKeyWordData").html(html);
			

				//关键字拖拽排序,当拖拽结束，即释放鼠标左键后，遍历当前页面的关键字的id,
				Sortable.create(document.getElementById('foo'), 
						  {
						  animation: 150, //动画参数
						  onEnd: function(evt) { //拖拽完毕之后发生该事件
							   //console.log('onEnd.foo:', [evt.item, evt.from]);
							   var ids=''
							   for(var i=0, len=evt.from.children.length; i<len; i++){
								   ids+=','+ evt.from.children[i].getAttribute('id');
							   }
							   ids=ids.substr(1);
							   $.ajax({
									url: updateSysConfigKeywordOrderUrl,
									type: 'POST',
									dataType: 'json',
									data: {ids:ids},
								})
								.done(function(data) {
								})
								.fail(function(data) {
									bootbox.alert(data.message);
								});
						}
					});
			
			mind();
			$("#saveProductKeyWordBtn").click(
					function() {
						if ($("#keywordName").val() == null
								|| $("#keywordName").val() == ''
								|| $("#keywordName").val() == undefined || $("#keywordName").val().trim() == 0) {
							bootbox.alert("关键字不能为空")
							return false;
						}
						if ($("#keywordName").val().trim().length > 20) {
							bootbox.alert("关键字不能大于20个字")
							return false;
						}
						var tempparams = {
							name : $("#keywordName").val().trim(),
							outRelatedId : $("#productId").val()
						}
						saveKeyword(tempparams)
					});
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}

// 添加产品关键字
function saveKeyword(params) {
	var keywordId = t[$("#keywordName").val()+selectIndex];
	$("#keywordId").val("");
	$("#keywordId").val(keywordId);
	var params={outRelatedId:$("#productId").val(),keywordId:$("#keywordId").val(),name:$("#keywordName").val()}
	$.post(productKeyWordSaveUrl, params, function(data) {
		if (data.statusCode == 200) {
			toProductKeyWord(params.outRelatedId)
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
// 删除产品关键字
function deleteKeyword(param, productId) {
	$.post(productKeyWordDeleteUrl, {
		id : param
	}, function(data) {
		if (data.statusCode == 200) {
			toProductKeyWord(productId)
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
// 全选
function selectAll() {
	if ($("input[name='checkbox']").prop("checked")) {
		$("input[name='sub_checkbox']").prop("checked", true);
	} else {
		$("input[name='sub_checkbox']").prop("checked", false);
	}

	$("input[name='sub_checkbox']").click(
			function() {
				var $subs = $("input[name='sub_checkbox']");
				$("#selectAll").prop(
						"checked",
						$subs.length == $subs.filter(":checked").length ? true
								: false);
			});
}
// 初始化
function init(params,orderbyFiled,orderBy) {
	$.post(productListDataUrl, params, function(returndata) {
		var data = returndata.attachObj;
		if(returndata != null && returndata.statusCode == 200){
			if (data && data.list && data.list.length > 0) {
				var html = template("searchList", {
					items : data.list,
					saleStatus : global.saleStatus,
					orderBy:orderBy
				});
				$("#searchListData").html(html)
				var pagerHtml = template("pager", {
					page : data
				});
				$("#pagerData").html(pagerHtml)
				$("#noData").hide();
			} else {						 
				$("#searchListData").html("");
				$("#noData").show();
				$("#pagerData").html("");
			}
		}else{
			bootbox.alert(returndata.message)
		}
	}, "JSON");
	
	 //        配置
    seajs.config({
        base:"../assets/plugins/",
        alias:{
            'jquery':'jquery/jquery/1.10.1/jquery.js'
        }
    });
    //激活
    seajs.use(['jquery','../assets/js/product/main.js'],function($,main){
        $(function(){
            main.init();
          }
        );
    });

}
var preOrderFiled = "SALES_TIME";
// 排序
function orderbyfunc(a, orderbyFiled,orderFiled,orderDirection) {
	var orderBy = $(a).attr("role");
	if($("#isSale").val() == 1){//上架
		$("#orderField").val(orderFiled)
		if(preOrderFiled == orderFiled){
			if (orderBy == "DESC") {
				$(a).attr("role", "ASC");
				$("#orderDirection").val("DESC");
				$(a).children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
			}else{
				$(a).attr("role", "DESC");
				$("#orderDirection").val("ASC");
				$(a).children("span").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
			}
			if(orderFiled == "SALE_NUM"){//销量
				$("#orderField2").val("SALES_TIME");
			}else{//上架时间
				$("#orderField2").val("SALE_NUM");
			}
		}else{
			preOrderFiled = orderFiled;
			$("#orderDirection2").val($("#orderDirection").val());
			if(orderFiled == "SALE_NUM"){//销量
				$("#orderField2").val("SALES_TIME")
			}else{//上架时间
				$("#orderField2").val("SALE_NUM")
			}
			if (orderBy == "DESC") {
				$(a).attr("role", "ASC");
				$("#orderDirection").val("DESC");
				$(a).children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
			}else{
				$(a).attr("role", "DESC");
				$("#orderDirection").val("ASC");
				$(a).children("span").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
			}
		}
		
	}else{//下架
		$("#orderField").val(orderFiled)
		if(preOrderFiled == orderFiled){
			if (orderBy == "DESC") {
				$(a).attr("role", "ASC");
				$("#orderDirection").val("DESC");
				$(a).children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
			}else{
				$(a).attr("role", "DESC");
				$("#orderDirection").val("ASC");
				$(a).children("span").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
			}
			if(orderFiled == "CREATE_TIME"){//销量
				$("#orderField2").val("CREATE_TIME");
			}else{//上架时间
				$("#orderField2").val("SALE_NUM");
			}
		}else{
			preOrderFiled = orderFiled;
			$("#orderDirection2").val($("#orderDirection").val());
			if(orderFiled == "SALE_NUM"){//销量
				$("#orderField2").val("CREATE_TIME")
			}else{//上架时间
				$("#orderField2").val("SALE_NUM")
			}
			if (orderBy == "DESC") {
				$(a).attr("role", "ASC");
				$("#orderDirection").val("DESC");
				$(a).children("span").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
			}else{
				$(a).attr("role", "DESC");
				$("#orderDirection").val("ASC");
				$(a).children("span").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
			}
		}
		
	
	}
	var params = $("#searchForm").serialize();
	init(params,orderbyFiled,orderDirection)
}
// 设置logo
function setIsLogo(id, productId) {
	$.post(isLogoUpdateUrl, {
		id : id,
		productId : productId
	}, function(data) {
		if (data && data.statusCode == 200) {
			productPicList(productId)
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
// 删除图片
function deleted(id, productId) {
	$.post(deletePicRelUrl, {
		id : id
	}, function(data) {
		if (data && data.statusCode == 200) {
			productPicList(productId)
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
// 编辑产品 获取图片列表
function productPicList(productId) {
	$.post(productPicListUrl, {
		productId : productId
	}, function(data) {
		if (data && data.attachObj != null) {
			var picHtml = template("picEditScript", {
				picList : data.attachObj.listProductPic,
				product : data.attachObj.product
			});
			$("#product-pic-editor").html(picHtml)
		} else {
			bootbox.alert(data.message)
		}
	}, "JSON");
}
function editProduct(id) {
// 编辑产品
	$.post(toProductEditUrl, {
		id : id
	}, function(data) {
		if (data && data.attachObj != null) {
			var _product = data.attachObj.productWithBLOBs;
			var _productPic = data.attachObj.listProductPic;
			$("#productIdAndProductName").html(_product.id+":"+_product.productName)
			var html = template("productEditScript", {
				product : _product,productSubTypes:data.attachObj.productSubTypesDictionary
			});
			$("#productEditData").html(html);
			$("#productEdtiBtnSaveForm .goodsType0").click(function(){
				$("#takeAddressDivId").show()
			})
			$("#productEdtiBtnSaveForm .goodsType1").click(function(){
				$("#takeAddressDivId").hide()
				$("#takeAddress").val("")
			})
			
	    	countWords('productName','title_shownum',200);
	    	initCityData("edit-city",_product.cityId);
			var picHtml = template("picEditScript", {
				picList : _productPic,
				product : _product
			});
			$("#product-pic-editor").html(picHtml);
			editProductText(_product);
		}else{
			bootbox.alert(data.message)
		}
	}, "JSON");
	// set富文本
	function editProductText(_product) {
		if(_product.productType == 2){
			$("#container-trffic-div").hide()
		}else{
			$("#container-trffic-div").show()
			var traffic = UE.getEditor('container-trffic');
			traffic.setContent(_product.traffic)
		}
		var recommend = UE.getEditor('container-recommend');
	        recommend.setContent(_product.recommend)
		var remark = UE.getEditor('container-img-text');
	        remark.setContent(_product.remark)
		var orderRule = UE.getEditor('container-reserve');
	        orderRule.setContent(_product.orderRule)
		var returnRule = UE.getEditor('container-retreat');
	        returnRule.setContent(_product.returnRule)
	}
}
//获取城市下拉列表
function initCityData(param,cityId) { 
	$.ajax({
	    url: cityListDataUrl,
	    type: 'POST',
	    dataType: 'json',
	    success: function(result) {
	  	  $.each(result,function(index,data){
	  		  if(data.valid==0) {
	  			  $("#"+param).append('<option style=\'font-size:12px;background:#BEBEBE\' disabled=\'disabled\' value='+data.id+'>'+data.name+'</option>'); 
	  		  }else{
	  			  if(data.id == cityId){
	  				  $("#"+param).append('<option style=\'font-size:12px\' selected value='+data.id+'>'+data.name+'</option>');
	  			  }else{
	  				  $("#"+param).append('<option style=\'font-size:12px\' value='+data.id+'>'+data.name+'</option>');
	  			  }
	  		  }
	  	  });
	  	  if(cityId != ""){
	  		  $("#"+param+" option").each(function(){
	  			  if($(this).val()==cityId){
	  				  cityId = ($(this).val());
	  				  $(this).attr("selected", "selected");
	  				  $("#"+param).selectpicker("refresh");
	  			  }
	  		  }); 
	  	  }
	  	  $("#"+param).selectpicker("refresh");
	    }
	});
}