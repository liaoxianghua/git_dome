$(function() {
});
// 去套餐库存页面
function toProductMeals(id) {
	$.post(productMealsListUrl, {
		productId : id
	}, function(data) {
		if (data && data.attachObj != null) {
			var _product = data.attachObj;
			var html = template("productMealsScript", {
				attachObj : _product,
				productMeal : _product.productMeal
			});
			$("#repertory-Modal").html(html);
			var html = template("productMealsStockScript", {
				productMeal : _product.productMeal,
				product : _product.product,
				listMonth : _product.listMonth
			});
			$("#productMealsStock").html(html);
			var monthHtml = template("listMonthScript",{product : _product.product,productMeal:_product.productMeal,listMonth:_product.listMonth});
			$("#listMonthData").html(monthHtml);
			showStockTable("", _product.productMeal.id, "");
			addClick();
		}
	}, "JSON");
}
// 显示库存信息
function showStock(a, id, playDay) {
	$(a).parent().siblings().removeClass("active");
	$(a).parent().attr("class", "active");
	$.post(getStockByMealsIdUrl, {
		mealsId : id,
		date : playDay
	}, function(data) {
		if (data && data.attachObj != null) {
			var result = data.attachObj;
			var html = template("productMealsStockScript", {
				productMeal : result.productMeals,
				product : result.product,
				listMonth : result.listMonth
			});
			$("#productMealsStock").html(html);
			var monthHtml = template("listMonthScript",{
				productMeal:result.productMeals,
				product:result.product,
				listMonth:result.listMonth,
				flag:0
				});
			$("#listMonthData").html(monthHtml);
			var stockHtml = template("stockTableScript", {
				productStocks : result.productStocks,
				product : result.product,
				yearMonth : result.listMonth[1]
			});
			$("#stockTable").html(stockHtml);
			initUpdateStockInput();
			addClick();
		}
	}, "JSON");
}
//显示前后日历 套餐ID、月份、 是上月还是下月
function showPreSufStockTable(a, id, playDay,flag) {
	$.post(getStockByMealsIdUrl, {
		mealsId : id,
		date : playDay,
		flag:flag
	}, function(data) {
		if (data && data.attachObj != null) {
			var result = data.attachObj;
			var stockHtml = template("stockTableScript", {
				productStocks : result.productStocks,
				product : result.product,
				yearMonth : playDay
			});
			$("#stockTable").html(stockHtml);
			initUpdateStockInput();
			var monthHtml = template("listMonthScript",{
				productMeal:result.productMeals,
				product:result.product,
				listMonth:result.listMonth,
				flag:flag
			});
			$("#listMonthData").html(monthHtml);
			$(a).parent().siblings().removeClass("active");
			$(a).parent().attr("class", "active");
			addClick();
		}
	}, "JSON");
}
//显示库存日历 
function showStockTable(a, id, playDay) {
	$(a).parent().siblings().removeClass("active");
	$(a).parent().attr("class", "active");
	$.post(getStockByMealsIdUrl, {
		mealsId : id,
		date : playDay
	}, function(data) {
		if (data && data.attachObj != null) {
			var result = data.attachObj;
			var stockHtml = template("stockTableScript", {
				productStocks : result.productStocks,
				product : result.product,
				yearMonth : playDay
			});
			$("#stockTable").html(stockHtml);
			initUpdateStockInput();
			addClick();
		}
	}, "JSON");
}
/**
 * 初始化点击更新库存方法
 */
function initUpdateStockInput(){
	//价格
	$(".stockPrice").dblclick(function(){
		$(this).html("￥<input   type='text' value='"+$(this).attr("data-val")+"' style='width: 55px;'>");
		$('input',this).focus();
		var that =this;
		$('input',this).blur(function(){
			$(that).html('￥'+parseFloat($(that).attr("data-val")));
		});
		$('input',this).bind('keyup', function(event) {
			if (event.keyCode == "13") {
				var params = {};//参数集合
				var id = $(that).attr("data-id");
				params.id = id;
				var inputprice = $(this).val();
				var flag = false;
				if(!inputprice){
					bootbox.alert("价格不能为空");
					flag =true;
				}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(inputprice)){
					bootbox.alert("请填入正数,精确到小数点后2位");
					flag = true;
				}else if(inputprice.length > 5){
					bootbox.alert("超出最大限制");
					flag = true;
				}
				if(flag){
					return false;
				}
				//修改的列
				var column = $(that).attr("data-column");
				if("price" == column){
					var price = inputprice;
					params.price = price;
				}else if("singleRoomPrice" == column){
					var singleRoomPrice = inputprice;
					params.singleRoomPrice = singleRoomPrice;
				}else if("childPrice" == column){
					var childPrice = inputprice;
					params.childPrice = childPrice;
				}else if("adultPrice" == column){
					var adultPrice = inputprice;
					params.adultPrice = adultPrice;
				}
				$.post(updateStockByIdUrl,params,function(data){
					if(data!=null && data.statusCode == 200){
						bootbox.alert(data.message);
						$(that).attr("data-val",inputprice);
						$(that).html('￥'+inputprice);
					}else{
						bootbox.alert("更新失败");
					}
				},"JSON");
			}
		});
	});
	//库存
	$(".stockTotalNum").dblclick(function(){
		var preTotalNum = $(this).attr("data-val");
		var _saleNum = $(this).attr("data-saleNum");
		var flag = false;
		$(this).html("<input   type='text' value='"+$(this).attr("data-val")+"' style='width: 65px;'>");
		$('input',this).focus();
		var that =this;
		$('input',this).blur(function(){
			if(preTotalNum.length > 4){
				$(that).html(preTotalNum - _saleNum +"</br>("+_saleNum+"/"+preTotalNum+")");
			}else{
				$(that).html(preTotalNum - _saleNum +"("+_saleNum+"/"+preTotalNum+")");
			}
		});
		$('input',this).bind('keyup', function(event) {
			console.log($(this).val())
			if (event.keyCode == "13") {
				var params = {};//参数集合
				var id = $(that).attr("data-id");
				params.id = id;
				var _totalNum = $(this).val();
				if(!_totalNum){
					bootbox.alert("数量不能为空");
					flag =true;
				}else if(!/^[0-9]*$/.test(_totalNum)){
					bootbox.alert("请填入正整数");
					flag = true;
				}else if(_totalNum < 1){
					bootbox.alert("请填入正整数");
					flag = true;
				}else if(_totalNum > 9999){
					bootbox.alert("超出库存最大限制");
					flag = true;
				}
				if(flag){
					return false;
				}
				//修改的列
				params.totalNum = _totalNum;
				$.post(updateStockByIdUrl,params,function(data){
					if(data!=null && data.statusCode == 200){
						bootbox.alert(data.message);
						$(that).attr("data-val",_totalNum);
						if(_totalNum.length > 4){
							$(that).html(_totalNum - _saleNum +"</br>("+_saleNum+"/"+_totalNum+")");
						}else{
							$(that).html(_totalNum - _saleNum +"("+_saleNum+"/"+_totalNum+")");
						}
					}else{
						bootbox.alert("更新失败");
					}
				},"JSON");
			}
		});
	});
}
// 添加套餐
function addMeals(id) {
	$.post(toAddMealsUrl, {
		productId : id
	}, function(data) {
		if (data.statusCode == 200) {
			var html = template("addProductMealsScript", {
				productMeals : data.attachObj
			});
			$("#addProductMeals").html(html);
			$("#addProductMeals").show();
			$("#mealsList").hide();
			addClick();
		}
	}, "JSON");

};
// 编辑套餐
function editMeals(id) {
	$.post(toEditMealsUrl, {
		id : id
	}, function(data) {
		if (data.statusCode == 200) {
			var html = template("addProductMealsScript", {
				productMeals : data.attachObj
			});
			$("#addProductMeals").html(html);
			$("#addProductMeals").show();
			addClick();
		}
	}, "JSON");
};
// 保存套餐
function saveMeals() {
	var param = $("#addProductMealsForm").serializeObject();
	var flag = true;
	if(param.mealsName == null
			|| param.mealsName == ''
				|| param.mealsName == undefined || param.mealsName.trim() == 0){
		$("#mealsNameSpan").show()
		$("#mealsNameSpan").html("必填")
		flag = false;
	}else if(param.mealsName.length>200){
		$("#mealsNameSpan").show()
		$("#mealsNameSpan").html("最大长度200字")
		flag = false;
	}else{
		$("#mealsNameSpan").hide()
	}
	 
	 if(param.mealsCode != null && param.mealsCode != '' && param.mealsCode != undefined  && param.mealsCode.length>20){
		$("#mealsCodeSpan").show()
		$("#mealsCodeSpan").html("最大长度20")
		flag = false;
	}else{
		$("#mealsCodeSpan").hide()
	}

	if(!flag){
		return false;
	}
	$.post(productMealsSaveUrl, param, function(data) {
		toProductMeals(param.productId);
	}, "JSON");
}
// 根据选中套餐显示库存
function toShowStock(a, mealsId, playDay) {
	$("#mealsList").children("ul").removeClass("modal-ul").addClass(
			"modal-ul-no")
	$(a).attr("class", "modal-ul")
	$("#mealsId").attr("data-val", mealsId)
	showStock("", mealsId, "");
}
function addClick() {
	// 取消事件
	$("#cancelMealsBtn").click(function() {
		$("#addProductMeals").hide();
		$("#mealsList").show();
	})
	// 保存事件
	$("#saveMealsBtn").click(function() {
		saveMeals();
	})

	// 编辑套餐按钮
	$("#mealsId").click(function() {
		editMeals($(this).attr("data-val"))
		$("#mealsList").hide();
	})
}
