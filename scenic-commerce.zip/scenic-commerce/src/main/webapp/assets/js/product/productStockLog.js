$(function(){  
}); 

var pagerLogIndex = function(v){
	var pagerParams = {pageNum:v,pageSize:$("#pageStockLogSize").val(),mealsId:$("#stockLogMealsid").val()} 
	$.post(productStockLogListDataUrl,pagerParams,function(data){
		var html = template("productStockLogListScript",{items:data.attachObj.list,mealsId:$("#stockLogMealsid").val(),page:data.attachObj});
		$("#productStockLogListData").html(html);
	},"json");
}
var pageLogSizeChange = function(){
	pagerLogIndex(1);
}
var pageLogNumChange = function(){
	console.log($("#pageStockNum").val())
	pagerLogIndex($("#pageStockNum").val());
}
//to修改库存记录
function stockLog($this,mealsId){
	$.post(productStockLogListDataUrl,{mealsId:mealsId,pageSize:20},function(data){
		if(data && data.statusCode == 200){
			var html = template("productStockLogListScript",{items:data.attachObj.list,mealsId:mealsId,page:data.attachObj});
			$("#productStockLogListData").html(html);
		}else{
			bootbox.alert(data.message)
		}
	},"JSON");
}
 