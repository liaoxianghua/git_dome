/**
 * Created by lenovo on 2017/3/10.
 */
(function(){
var scenic = {
    init:function(){
        /*编辑器*/
        var recommend=UE.getEditor('container-recommend',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','simpleupload','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:1000,
            initialFrameHeight:60
        });
        var imgText=UE.getEditor('container-img-text',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','simpleupload','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:60
        });
        var trffic=UE.getEditor('container-trffic',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','simpleupload','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:60
        });
        var reserve=UE.getEditor('container-reserve',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','simpleupload','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:60
        });
        var retreat=UE.getEditor('container-retreat',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','simpleupload','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:60
        });
 
 
    },
    /*产品库存页的modal设置*/
    adjustModal:function(){
        var reptyControl = $('.modal-show-title');
        var modal1 = $('#repertory-Modal');
        var modal2 = $('#add-repertory-modal');
        if(!modal1){
            return ;
        }
        reptyControl.on('click','a',function(e){
            e.preventDefault();
            modal1.css('z-index','1040');
        });
        modal2.on('click','#repertory-Modal,[data-dismiss="modal"],.modal-dialog',function(){
            modal1.css('z-index','1050');
        })
    },

    /*库存日期选择*/
    selectdate:function(){
        var prevBtn = $('.prev-btn'),
            nextBtn = $('.next-btn'),
            monthWrapper = $('.month-wrapper');
            monthLi =monthWrapper.children();
    }
}

//调用初始化
$(function(){
   scenic.init();
});
})();




