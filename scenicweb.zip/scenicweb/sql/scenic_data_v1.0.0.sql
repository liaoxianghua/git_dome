--初始化数据和序列
--初始化系统用户
prompt Loading TB_AUTH_USER...
insert into TB_AUTH_USER (id, username, password, truename, tel, phone, email, fax, valid, sex, login_ip, login_date, remarks, guid, qq, weixin, type, department_id, create_user, create_time, modify_user, modify_time)
values (1, 'admin', 'E10ADC3949BA59ABBE56E057F20F883E', '超级管理员', null, null, null, null, 1, 1, null, to_date('31-08-2016', 'dd-mm-yyyy'), null, null, null, null, 1, 1, null, null, null, null);
insert into TB_AUTH_USER (id, username, password, truename, tel, phone, email, fax, valid, sex, login_ip, login_date, remarks, guid, qq, weixin, type, department_id, create_user, create_time, modify_user, modify_time)
values (2, 'ordermaker', 'E10ADC3949BA59ABBE56E057F20F883E', '制单人', null, null, null, null, 1, 1, null, to_date('31-08-2016', 'dd-mm-yyyy'), null, null, null, null, 1, 1, null, null, null, null);
commit;


--初始化系统角色数据
prompt Loading TB_AUTH_ROLE...
insert into TB_AUTH_ROLE (id, role_name, valid, remarks, guid, role_code, create_time, create_user, update_time, update_user)
values (1, '超级管理员', 1, '超级管理员', null, 'SUP-ADMIN', to_date('08-09-2016', 'dd-mm-yyyy'), 1, to_date('14-02-2017 15:01:53', 'dd-mm-yyyy hh24:mi:ss'), 1);
commit;


--初始化用户角色数据
prompt Loading TB_AUTH_USERROLE...
insert into TB_AUTH_USERROLE (id, user_id, role_id, create_time, create_user, update_time, update_user)
values (1, 1, 1, to_date('15-02-2017 13:22:24', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('15-02-2017 13:22:24', 'dd-mm-yyyy hh24:mi:ss'), 1);
commit;


--初始化系统部门数据
prompt Loading TB_AUTH_DEPARTMENT...
insert into TB_AUTH_DEPARTMENT (id, name, parent_id, remarks, type, valid, create_user, create_time, update_user, update_time, guid)
values (1, '信息技术部', null, '信息技术部', 1, '1', 1, to_date('16-02-2017 15:36:21', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
commit;


--初始化系资源
prompt Loading TB_AUTH_RESOURCE...
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (1, '系统管理', 'R01', null, null, 1, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (2, '基础信息', 'R02', null, null, 2, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (3, '资源管理', 'R03', null, null, 3, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (4, '内容管理', 'R04', null, null, 4, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (5, '素材库', 'R05', null, null, 5, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (6, '会员管理', 'R06', null, null, 6, 1, 0, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (7, '部门管理', 'R0101', '/system/department/departmentManagement', 1, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (8, '菜单管理', 'R0102', '/system/menu/menuManagement', 1, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (9, '角色管理', 'R0103', '/system/role/roleManagement', 1, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (10, '用户管理', 'R0104', '/system/user/userManagement', 1, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:35', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (11, '数据字典', 'R0105', '/system/dictionary/dictionaryList', 1, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (12, '国家管理', 'R0201', '/basic/country/countryManagement', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (13, '省份管理', 'R0202', '/basic/province/provincePage', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (14, '城市管理', 'R0203', '/basic/city/cityPage', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (15, '地标管理', 'R0204', '/basic/cityLandMark/cityLandMarkPage', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (16, '景区商户管理', 'R0205', '/basic/scenicCommercial/scenicCommercialManage', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (17, '关键字管理', 'R0206', '/basic/keyword/keywordList', 2, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (18, '供应商管理', 'R0301', '/resource/suppliers/suppliersPage', 3, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (19, '游记攻略管理', 'R0401', '/content/travelNote/travelNoteList', 4, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (20, '点评管理', 'R0402', '/content/evaluate/evaluateList', 4, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (21, '素材上传', 'R0501', '/material/material/materialUpload', 5, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (22, '素材查询', 'R0502', '/material/material/materialList', 5, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (23, '授权管理', 'R0503', '/material/authorized/authorizedList', 5, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (24, '会员管理', 'R0601', '/member/member/memberList', 6, null, 1, 1, 1, null, null, to_date('13-02-2017 21:23:36', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (33, '新增', 'R010101', null, 7, null, 1, 2, 1, null, null, to_date('13-02-2017 16:15:54', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (34, '修改', 'R010102', null, 7, null, 1, 2, 1, null, null, to_date('13-02-2017 16:19:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (35, '查询', 'R010103', null, 7, null, 1, 2, 1, null, null, to_date('13-02-2017 16:21:01', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('14-02-2017 00:14:08', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (36, '重置', 'R010104', null, 7, null, 1, 2, 1, null, null, to_date('13-02-2017 16:25:10', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (37, '启用/禁用', 'R010105', null, 7, null, 1, 2, 1, null, null, to_date('13-02-2017 16:26:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (38, '新增', 'R010201', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:36:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (39, '修改', 'R010202', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:36:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (40, '查询', 'R010203', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:36:37', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (41, '重置', 'R010204', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:36:48', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (42, '设为有效/设为无效', 'R010205', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:37:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (43, '添加菜单', 'R010206', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:38:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (44, '查看功能', 'R010207', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:38:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (45, '新增', 'R010401', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 16:39:13', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:02:34', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (46, '修改', 'R010402', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 16:39:22', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:02:29', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (47, '启用/禁用', 'R010403', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 16:39:29', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:05:47', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (48, '修改功能', 'R010208', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:42:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (49, '启用/禁用功能', 'R010209', null, 8, null, 1, 2, 1, null, null, to_date('13-02-2017 16:42:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (50, '新增', 'R010301', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:45:13', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (51, '修改', 'R010302', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:45:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (52, '查询', 'R010303', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:45:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (53, '重置', 'R010304', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:45:58', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (54, '启用/禁用', 'R010305', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:46:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (55, '权限管理', 'R010306', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:46:29', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (56, '权限菜单添加', 'R010307', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (57, '权限菜单移除', 'R010308', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:47:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (58, '查看用户', 'R010309', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:48:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (59, '移除用户', 'R010310', null, 9, null, 1, 2, 1, null, null, to_date('13-02-2017 16:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (60, '查询', 'R010404', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 16:49:08', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (62, '查询', 'R020201', null, 13, null, 1, 2, 1, null, null, to_date('13-02-2017 16:56:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (63, '新增', 'R020202', null, 13, null, 1, 2, 1, null, null, to_date('13-02-2017 16:56:48', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (64, '编辑', 'R020203', null, 13, null, 1, 2, 1, null, null, to_date('13-02-2017 16:57:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (65, '启用/禁用', 'R020204', null, 13, null, 1, 2, 1, null, null, to_date('13-02-2017 16:57:22', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:09:42', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (66, '重置', 'R020205', null, 13, null, 1, 2, 1, null, null, to_date('13-02-2017 16:57:28', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:31:27', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (68, '重置', 'R010405', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 17:05:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (70, '查看权限', 'R010406', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 17:05:58', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('13-02-2017 17:06:31', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (71, '查看权限添加角色', 'R010407', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 17:06:53', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (72, '查看权限移除角色', 'R010408', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 17:07:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (73, '日志查看', 'R010409', null, 10, null, 1, 2, 1, null, null, to_date('13-02-2017 17:07:29', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (74, '添加分类', 'R010501', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:07:54', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (75, '添加参数', 'R010502', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:08:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (76, '查询', 'R010503', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:08:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (77, '修改分类', 'R010504', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:08:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (78, '修改参数', 'R010505', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:08:51', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (79, '重置', 'R010506', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:08:59', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (80, '设为有效/设为无效', 'R010507', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:09:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (82, '删除', 'R010508', null, 11, null, 1, 2, 1, null, null, to_date('13-02-2017 17:10:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (83, '新增', 'R020101', null, 12, null, 1, 2, 1, null, null, to_date('13-02-2017 17:12:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (84, '修改', 'R020102', null, 12, null, 1, 2, 1, null, null, to_date('13-02-2017 17:12:20', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (85, '查询', 'R020103', null, 12, null, 1, 2, 1, null, null, to_date('13-02-2017 17:12:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (86, '启用/禁用', 'R020104', null, 12, null, 1, 2, 1, null, null, to_date('13-02-2017 17:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (87, '重置', 'R020105', null, 12, null, 1, 2, 1, null, null, to_date('13-02-2017 17:12:45', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (88, '新增', 'R020501', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:13:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (89, '修改', 'R020502', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:13:19', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (90, '查询', 'R020503', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:13:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (91, '重置', 'R020504', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:14:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (92, '启用/禁用', 'R020505', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:14:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (93, '详情', 'R020506', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:14:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (94, '详情页面修改', 'R020507', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:14:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (95, '详情页面添加图片', 'R020508', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:15:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (96, '详情页面删除图片', 'R020509', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:15:53', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (97, '详情页面置为LOGO', 'R020510', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:16:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (98, '详情页面添加地图', 'R020511', null, 16, null, 1, 2, 1, null, null, to_date('13-02-2017 17:16:46', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (99, '新增', 'R020601', null, 17, null, 1, 2, 1, null, null, to_date('13-02-2017 17:17:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (100, '修改', 'R020602', null, 17, null, 1, 2, 1, null, null, to_date('13-02-2017 17:17:21', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (101, '查询', 'R020603', null, 17, null, 1, 2, 1, null, null, to_date('13-02-2017 17:17:27', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (102, '启用/禁用', 'R020604', null, 17, null, 1, 2, 1, null, null, to_date('13-02-2017 17:17:36', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (103, '重置', 'R020605', null, 17, null, 1, 2, 1, null, null, to_date('13-02-2017 17:17:45', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (104, '查询', 'R020301', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:14:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (105, '新增', 'R020302', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:14:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (106, '重置', 'R020303', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:14:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (107, '编辑', 'R020304', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:14:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (108, '启用/禁用', 'R020305', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:14:57', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (109, '查看区域', 'R020306', null, 14, null, 1, 2, 1, null, null, to_date('13-02-2017 18:15:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (110, '新增', 'R040101', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:31:45', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (111, '修改', 'R040102', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:32:05', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (112, '查询', 'R040103', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:32:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (113, '审核', 'R040104', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:32:27', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (114, '关键字', 'R040105', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:32:34', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (115, '重置', 'R040106', null, 19, null, 1, 2, 1, null, null, to_date('14-02-2017 09:32:40', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (116, '下载模板', 'R040201', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:33:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (117, '导入数据', 'R040202', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:33:37', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (118, '评分项管理', 'R040203', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:33:50', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (119, '查询', 'R040204', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:33:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (120, '重置', 'R040205', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:34:03', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (121, '通过', 'R040206', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:34:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (122, '拒绝', 'R040207', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:34:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (123, '评分项管理新增', 'R040208', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:35:13', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (124, '评分项管理修改', 'R040209', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:35:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (125, '评分项管理查询', 'R040210', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:35:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (126, '评分项管理启用/禁用', 'R040211', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:35:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (127, '评分项管理重置', 'R040212', null, 20, null, 1, 2, 1, null, null, to_date('14-02-2017 09:36:13', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (128, '添加素材', 'R050101', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:36:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (129, '我的上传历史', 'R050102', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:37:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (130, '批量上传', 'R050103', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:37:27', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (131, '全部重置', 'R050104', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:37:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (132, '我的上传历史查询', 'R050105', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:37:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (133, '我的上传历史查看', 'R050106', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:38:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (134, '我的上传历史删除', 'R050107', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:38:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (135, '我的上传历史重置', 'R050108', null, 21, null, 1, 2, 1, null, null, to_date('14-02-2017 09:38:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (136, '查询', 'R020401', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (137, '新增', 'R020402', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:36', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (138, '重置', 'R020403', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:42', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (139, '编辑', 'R020404', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:50', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (140, '启用/禁用', 'R020405', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (141, '查看', 'R020406', null, 15, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (142, '查询', 'R050201', null, 22, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (143, '查看', 'R050202', null, 22, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (144, '审核', 'R050203', null, 22, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:31', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (145, '删除', 'R050204', null, 22, null, 1, 2, 1, null, null, to_date('14-02-2017 09:41:40', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (146, '新增', 'R050301', null, 23, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (147, '修改', 'R050302', null, 23, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:35', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (148, '查询', 'R050303', null, 23, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (149, '启用/禁用', 'R050304', null, 23, null, 1, 2, 1, null, null, to_date('14-02-2017 09:42:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (150, '重置', 'R050305', null, 23, null, 1, 2, 1, null, null, to_date('14-02-2017 09:43:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (151, '查询', 'R060101', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:43:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (152, '查看', 'R060102', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:43:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (153, '重置', 'R060103', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:43:50', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (154, '基本信息保存', 'R060104', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:44:28', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (155, '常用出行人新增', 'R060105', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:44:53', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (156, '常用出行人编辑', 'R060106', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:45:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (157, '常用出行人删除', 'R060107', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:45:19', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (158, '常用出行人保存', 'R060108', null, 24, null, 1, 2, 1, null, null, to_date('14-02-2017 09:45:28', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (159, '查询', 'R030101', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:03:57', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (160, '新增', 'R030102', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:04:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (161, '重置', 'R030103', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:04:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (162, '编辑', 'R030104', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:05:03', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (163, '启用/禁用', 'R030105', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:05:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (164, '产品', 'R030106', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:05:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (165, '合同', 'R030107', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:05:53', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (166, '证照管理', 'R030108', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 10:06:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (167, '查看角色', 'R010410', null, 10, null, 1, 2, 1, null, null, to_date('14-02-2017 10:57:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (168, '查看角色移除', 'R010411', null, 10, null, 1, 2, 1, null, null, to_date('14-02-2017 10:58:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (169, '查看角色批量保存', 'R010412', null, 10, null, 1, 2, 1, null, null, to_date('14-02-2017 10:58:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (170, '重置密码', 'R010413', null, 10, null, 1, 2, 1, null, null, to_date('14-02-2017 10:59:54', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (171, '详情页面查询图片', 'R020512', null, 16, null, 1, 2, 1, null, null, to_date('14-02-2017 13:09:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (172, '详情页面重置图片查询', 'R020513', null, 16, null, 1, 2, 1, null, null, to_date('14-02-2017 13:09:20', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (173, '详情功能图片保存', 'R020514', null, 16, null, 1, 2, 1, null, null, to_date('14-02-2017 13:11:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (174, '城市区域查询', 'R020307', null, 14, null, 1, 2, 1, null, null, to_date('14-02-2017 14:26:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (175, '城市区域新增', 'R020308', null, 14, null, 1, 2, 1, null, null, to_date('14-02-2017 14:26:42', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (176, '城市区域重置', 'R020309', null, 14, null, 1, 2, 1, null, null, to_date('14-02-2017 14:26:58', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (177, '城市区域编辑', 'R020310', null, 14, null, 1, 2, 1, null, null, to_date('14-02-2017 14:28:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (178, '城市区域启用/禁用', 'R020311', null, 14, null, 1, 2, 1, null, null, to_date('14-02-2017 14:29:13', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (179, '合同新增', 'R030109', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:42:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (180, '合同编辑', 'R030110', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:42:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (181, '合同下载', 'R030111', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:42:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (182, '证照新增', 'R030112', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:44:36', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (183, '证照查看附件', 'R030113', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:44:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (184, '证照删除', 'R030114', null, 18, null, 1, 2, 1, null, null, to_date('14-02-2017 14:45:03', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
commit;


insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (185, 'CMS管理', 'R07', null, null, null, 1, 0, 1, null, null, to_date('03-03-2017 13:47:18', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('03-03-2017 14:18:44', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (186, '系统配置', 'R0701', '/cms/sysConfig/sysConfigPage', 185, null, 1, 1, 1, null, null, to_date('03-03-2017 14:02:46', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('06-03-2017 15:02:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (187, '内容配置', 'R0702', '/cms/sysConfig/contentConfigPage', 185, null, 1, 1, 1, null, null, to_date('03-03-2017 14:09:07', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('07-03-2017 13:59:28', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (225, '入驻管理', 'R09', null, null, null, 1, 0, 1, null, null, to_date('20-03-2017 13:56:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (226, '商户管理', 'R0901', '/busi/busiSeller/busiSellerList', 225, null, 1, 1, 1, null, null, to_date('20-03-2017 14:01:29', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('20-03-2017 15:06:21', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (227, '商户中心公告', 'R0902', '/busi/busiNotice/busiNoticeList', 225, null, 1, 1, 1, null, null, to_date('20-03-2017 14:05:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('22-03-2017 15:13:11', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (245, '会员订单号点击', 'R060109', null, 24, null, 1, 2, 1, null, null, to_date('01-01-2017 17:37:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (246, '新增', 'R070101', null, 186, null, 1, 2, 1, null, null, to_date('01-01-2017 17:38:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (247, '查询', 'R070102', null, 186, null, 1, 2, 1, null, null, to_date('01-01-2017 17:39:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (248, '重置', 'R070103', null, 186, null, 1, 2, 1, null, null, to_date('01-01-2017 17:39:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (249, '启用/禁用', 'R070104', null, 186, null, 1, 2, 1, null, null, to_date('01-01-2017 17:39:58', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (250, '编辑', 'R070105', null, 186, null, 1, 2, 1, null, null, to_date('01-01-2017 17:40:34', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (251, '查询', 'R070201', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:40:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (252, '重置', 'R070202', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:41:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (253, '内容管理', 'R070203', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:41:19', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (254, '添加关键字', 'R070204', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:41:51', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (255, '图文链接新增', 'R070205', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:42:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (256, '图文链接编辑', 'R070206', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:42:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (257, '图文链接删除', 'R070207', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:42:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (258, '图文链接编辑页面选择图片', 'R070208', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:43:35', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (259, '图文链接编辑页面保存', 'R070209', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:43:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (260, '图片选择页面查询', 'R070210', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:44:29', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (261, '图片选择页面重置', 'R070211', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:44:36', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (262, '图片选择页面确定', 'R070212', null, 187, null, 1, 2, 1, null, null, to_date('01-01-2017 17:44:57', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (263, '新增', 'R090101', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:46:45', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (264, '查询', 'R090102', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:46:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (265, '重置', 'R090103', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:46:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (266, '编辑', 'R090104', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (267, '启用/禁用', 'R090105', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:47:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (268, '账号信息', 'R090106', null, 226, null, 1, 2, 1, null, null, to_date('01-01-2017 17:48:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (269, '新增', 'R090201', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:53:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (270, '查询', 'R090202', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:53:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (271, '重置', 'R090203', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:53:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (272, '编辑', 'R090204', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:53:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (273, '启用/禁用', 'R090205', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:54:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_AUTH_RESOURCE (ID, NAME, CODE, URL, PARENT_ID, SORT, VALID, TYPE, SYSTEMID, GUID, REMARKS, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (274, '置顶', 'R090206', null, 227, null, 1, 2, 1, null, null, to_date('01-01-2017 17:54:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
commit;

--初始化系统权限数据
prompt Loading TB_AUTH_PERMISSION...
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (1, null, 1, 1, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (2, null, 1, 2, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (3, null, 1, 3, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (4, null, 1, 4, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (5, null, 1, 5, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (6, null, 1, 6, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (7, null, 1, 7, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (8, null, 1, 8, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (9, null, 1, 9, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (10, null, 1, 10, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (11, null, 1, 11, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (12, null, 1, 12, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (13, null, 1, 13, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (14, null, 1, 14, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (15, null, 1, 15, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (16, null, 1, 16, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (17, null, 1, 17, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (18, null, 1, 18, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (19, null, 1, 19, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (20, null, 1, 20, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (21, null, 1, 21, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (22, null, 1, 22, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (23, null, 1, 23, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (24, null, 1, 24, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (25, null, 1, 33, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (26, null, 1, 34, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (27, null, 1, 35, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (28, null, 1, 36, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (29, null, 1, 37, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (30, null, 1, 38, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (31, null, 1, 39, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (32, null, 1, 40, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (33, null, 1, 41, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (34, null, 1, 42, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (35, null, 1, 43, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (36, null, 1, 44, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (37, null, 1, 45, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (38, null, 1, 46, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (39, null, 1, 47, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (40, null, 1, 48, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (41, null, 1, 49, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (42, null, 1, 50, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (43, null, 1, 51, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (44, null, 1, 52, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (45, null, 1, 53, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (46, null, 1, 54, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (47, null, 1, 55, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (48, null, 1, 56, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (49, null, 1, 57, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (50, null, 1, 58, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (51, null, 1, 59, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (52, null, 1, 60, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (53, null, 1, 62, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (54, null, 1, 63, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (55, null, 1, 64, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (56, null, 1, 65, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (57, null, 1, 66, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (58, null, 1, 68, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (59, null, 1, 70, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (60, null, 1, 71, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (61, null, 1, 72, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (62, null, 1, 73, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (63, null, 1, 74, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (64, null, 1, 75, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (65, null, 1, 76, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (66, null, 1, 77, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (67, null, 1, 78, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (68, null, 1, 79, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (69, null, 1, 80, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (70, null, 1, 82, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (71, null, 1, 83, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (72, null, 1, 84, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (73, null, 1, 85, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (74, null, 1, 86, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (75, null, 1, 87, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (76, null, 1, 88, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (77, null, 1, 89, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (78, null, 1, 90, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (79, null, 1, 91, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (80, null, 1, 92, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (81, null, 1, 93, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (82, null, 1, 94, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (83, null, 1, 95, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (84, null, 1, 96, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (85, null, 1, 97, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (86, null, 1, 98, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (87, null, 1, 99, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (88, null, 1, 100, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (89, null, 1, 101, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (90, null, 1, 102, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (91, null, 1, 103, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (92, null, 1, 104, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (93, null, 1, 105, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (94, null, 1, 106, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (95, null, 1, 107, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (96, null, 1, 108, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (97, null, 1, 109, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (98, null, 1, 110, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (99, null, 1, 111, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (100, null, 1, 112, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (101, null, 1, 113, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (102, null, 1, 114, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (103, null, 1, 115, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (104, null, 1, 116, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (105, null, 1, 117, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (106, null, 1, 118, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (107, null, 1, 119, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (108, null, 1, 120, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (109, null, 1, 121, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (110, null, 1, 122, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (111, null, 1, 123, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (112, null, 1, 124, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (113, null, 1, 125, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (114, null, 1, 126, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (115, null, 1, 127, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (116, null, 1, 128, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (117, null, 1, 129, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (118, null, 1, 130, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (119, null, 1, 131, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (120, null, 1, 132, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (121, null, 1, 133, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (122, null, 1, 134, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (123, null, 1, 135, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (124, null, 1, 136, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (125, null, 1, 137, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (126, null, 1, 138, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (127, null, 1, 139, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (128, null, 1, 140, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (129, null, 1, 141, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (130, null, 1, 142, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (131, null, 1, 143, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (132, null, 1, 144, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (133, null, 1, 145, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (134, null, 1, 146, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (135, null, 1, 147, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (136, null, 1, 148, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (137, null, 1, 149, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (138, null, 1, 150, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (139, null, 1, 151, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (140, null, 1, 152, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (141, null, 1, 153, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (142, null, 1, 154, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (143, null, 1, 155, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (144, null, 1, 156, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (145, null, 1, 157, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (146, null, 1, 158, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (147, null, 1, 159, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (148, null, 1, 160, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (149, null, 1, 161, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (150, null, 1, 162, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (151, null, 1, 163, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (152, null, 1, 164, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (153, null, 1, 165, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (154, null, 1, 166, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (155, null, 1, 167, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (156, null, 1, 168, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (157, null, 1, 169, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (158, null, 1, 170, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (159, null, 1, 171, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (160, null, 1, 172, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (161, null, 1, 173, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (162, null, 1, 174, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (163, null, 1, 175, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (164, null, 1, 176, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (165, null, 1, 177, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (166, null, 1, 178, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (167, null, 1, 179, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (168, null, 1, 180, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (169, null, 1, 181, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (170, null, 1, 182, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (171, null, 1, 183, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (172, null, 1, 184, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (173, null, 1, 185, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (174, null, 1, 186, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (175, null, 1, 187, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (176, null, 1, 225, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (177, null, 1, 226, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (178, null, 1, 227, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (179, null, 1, 245, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (180, null, 1, 246, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (181, null, 1, 247, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (182, null, 1, 248, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (183, null, 1, 249, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (184, null, 1, 250, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (185, null, 1, 251, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (186, null, 1, 252, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (187, null, 1, 253, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (188, null, 1, 254, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (189, null, 1, 255, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (190, null, 1, 256, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (191, null, 1, 257, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (192, null, 1, 258, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (193, null, 1, 259, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (194, null, 1, 260, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (195, null, 1, 261, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (196, null, 1, 262, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (197, null, 1, 263, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (198, null, 1, 264, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (199, null, 1, 265, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (200, null, 1, 266, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (201, null, 1, 267, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (202, null, 1, 268, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (203, null, 1, 269, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (204, null, 1, 270, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (205, null, 1, 271, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (206, null, 1, 272, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (207, null, 1, 273, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_AUTH_PERMISSION (ID, USER_ID, ROLE_ID, RESOURCE_ID, GUID, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (208, null, 1, 274, null, 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('11-04-2017 14:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
commit;


--创建数据字典数据
prompt Loading TB_DICTIONARY...
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (1, null, 'EFFECTIVE_TYPE', '时效类型', null, null, 1, to_date('03-11-2016 09:39:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (2, null, 'CAREER_TYPE', '职业', null, null, 1, to_date('15-02-2017 13:56:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (3, null, 'SUPPLIERS_PRODUCT_TYPE', '产品类型', null, null, 1, to_date('04-11-2016 15:30:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (4, null, 'KEYWORD_TYPE', '关键字类型', null, null, 1, to_date('26-01-2017 10:40:11', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (5, null, 'STATION_TYPE', '交通站类别', null, null, 1, to_date('13-01-2017 15:57:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (6, null, 'SCENIC_TYPE', '景区类型', null, null, 1, to_date('13-01-2017 16:11:13', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (7, null, 'SELLER_TYPE', '商户类型', null, null, 1, to_date('13-01-2017 16:12:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (8, null, 'SCENIC_LEVEL', '景区星级', null, null, 1, to_date('13-01-2017 16:12:57', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (9, null, 'MAIN_TYPE', '主体类别', null, null, 1, to_date('13-01-2017 16:13:43', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (10, null, 'COMMON_BOOL', '是否', null, null, 1, to_date('01-01-2017 10:56:51', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (11, null, 'COMMON_VALID', '有效性', null, null, 1, to_date('01-01-2017 10:57:03', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (12, null, 'COMMON_USEABLE', '可用状态', null, null, 1, to_date('01-01-2017 11:00:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (13, null, 'CONTENT_STATUS', '游记状态', null, null, 1, to_date('01-01-2017 11:06:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (14, null, 'CONTENT_TYPE', '内容类型', null, null, 1, to_date('01-01-2017 11:08:50', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (15, null, 'CONTENT_FROM', '数据来源', null, null, 1, to_date('01-01-2017 11:10:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (16, null, 'MATERIAL_STATUS', '素材状态', null, null, 1, to_date('01-01-2017 11:12:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (17, null, 'MATERIAL_TYPE', '素材类型', null, null, 1, to_date('01-01-2017 11:13:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (18, null, 'MATERIAL_USETYPE', '使用类型', null, null, 1, to_date('01-01-2017 11:14:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (19, null, 'POSITION_TYPE', '坐标类型', null, null, 1, to_date('01-01-2017 11:15:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (20, null, 'AREA_TYPE', '区域类型', null, null, 1, to_date('01-01-2017 11:16:21', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (21, null, 'RESOURCE_TYPE', '资源类型', null, null, 1, to_date('01-01-2017 11:19:03', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (22, null, 'TRAVELNOTE_TYPE', '游记类别', null, null, 1, to_date('01-01-2017 14:12:37', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (23, null, 'CREDENTIALS_TYPE', '证件类型', null, null, 1, to_date('20-01-2017 13:10:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (24, null, 'USER_LOG_TYPE', '用户日志类型', null, null, 1, to_date('04-02-2017 14:01:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (25, null, 'MENU_SYSTEM_ID', '菜单所属系统', null, null, 1, to_date('07-02-2017 16:10:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (26, null, 'MAP_TYPE', '地图类型', null, null, 1, to_date('08-01-2017 15:51:28', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (27, null, 'ACTIVATED_FLG', '是否激活', null, null, 1, to_date('15-02-2017 13:46:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (28, null, 'MEMBER_FROM', '账号类型', null, null, 1, to_date('15-02-2017 13:50:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (29, null, 'EDUCATE_TYPE', '文化程度', null, null, 1, to_date('15-02-2017 13:52:16', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('15-02-2017 13:56:36', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (30, null, 'KEYWORD_RELEVANCE_TYPE', '关键字所属模块', null, null, 1, to_date('26-01-2017 10:37:50', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('15-02-2017 13:19:29', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (31, 5, null, '机场', '1', null, 1, to_date('13-01-2017 16:03:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (32, 5, null, '火车站', '2', null, 1, to_date('13-01-2017 16:03:37', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (33, 5, null, '地铁站', '3', null, 1, to_date('13-01-2017 16:03:48', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (34, 6, null, '古镇', '1', null, 1, to_date('13-01-2017 16:11:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (35, 6, null, '自然山水', '2', null, 1, to_date('13-01-2017 16:11:57', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (36, 6, null, '人造园林', '3', null, 1, to_date('13-01-2017 16:12:05', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (37, 7, null, '餐饮', '1', null, 1, to_date('13-01-2017 16:12:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (38, 7, null, '住宿', '2', null, 1, to_date('13-01-2017 16:12:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (39, 8, null, '1A', '1', null, 1, to_date('13-01-2017 16:13:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (40, 8, null, '2A', '2', null, 1, to_date('13-01-2017 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (41, 8, null, '3A', '3', null, 1, to_date('13-01-2017 16:13:20', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (42, 8, null, '4A', '4', null, 1, to_date('13-01-2017 16:13:27', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (43, 8, null, '5A', '5', null, 1, to_date('13-01-2017 16:13:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (44, 9, null, '景区', '1', null, 1, to_date('13-01-2017 16:14:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (45, 9, null, '商户', '2', null, 1, to_date('13-01-2017 16:14:06', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (46, 11, null, '有效', '1', null, 1, to_date('01-01-2017 10:57:59', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (47, 11, null, '无效', '0', null, 1, to_date('01-01-2017 10:58:10', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (48, 10, null, '是', '1', null, 1, to_date('01-01-2017 10:59:07', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (49, 10, null, '否', '0', null, 1, to_date('01-01-2017 10:59:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (50, 12, null, '禁用', '0', null, 1, to_date('01-01-2017 11:02:59', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (51, 12, null, '可用', '1', null, 1, to_date('01-01-2017 11:03:10', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (52, 13, null, '未审核', '1', null, 1, to_date('01-01-2017 11:07:10', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (53, 13, null, '已通过', '2', null, 1, to_date('01-01-2017 11:07:17', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (54, 13, null, '未通过', '3', null, 1, to_date('01-01-2017 11:07:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (55, 14, null, '文字', '1', null, 1, to_date('01-01-2017 11:09:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (56, 14, null, '图片', '2', null, 1, to_date('01-01-2017 11:09:08', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (57, 14, null, '语音', '3', null, 1, to_date('01-01-2017 11:09:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (58, 14, null, '视频', '4', null, 1, to_date('01-01-2017 11:09:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (59, 14, null, '标题', '5', null, 1, to_date('01-01-2017 11:09:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (60, 15, null, '微信', '1', null, 1, to_date('01-01-2017 11:11:08', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (61, 15, null, 'M网', '2', null, 1, to_date('01-01-2017 11:11:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (62, 15, null, '安卓', '3', null, 1, to_date('01-01-2017 11:11:21', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (63, 15, null, 'IOS', '4', null, 1, to_date('01-01-2017 11:11:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (64, 15, null, 'PC', '5', null, 1, to_date('01-01-2017 11:11:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (65, 15, null, '系统导入', '6', null, 1, to_date('01-01-2017 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (66, 16, null, '未审核', '1', null, 1, to_date('01-01-2017 11:12:31', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (67, 16, null, '已通过', '2', null, 1, to_date('01-01-2017 11:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (68, 16, null, '未通过', '3', null, 1, to_date('01-01-2017 11:12:47', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (69, 17, null, '图片', '1', null, 1, to_date('01-01-2017 11:13:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (70, 17, null, '音频', '2', null, 1, to_date('01-01-2017 11:13:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (71, 17, null, '视频', '3', null, 1, to_date('01-01-2017 11:13:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (72, 18, null, '产品', '1', null, 1, to_date('01-01-2017 11:14:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (73, 18, null, '专题', '2', null, 1, to_date('01-01-2017 11:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (74, 18, null, '微信', '3', null, 1, to_date('01-01-2017 11:14:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (75, 18, null, '其他', '4', null, 1, to_date('01-01-2017 11:14:43', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (76, 19, null, '地标', '1', null, 1, to_date('01-01-2017 11:15:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (77, 19, null, '城市', '2', null, 1, to_date('01-01-2017 11:15:39', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (78, 19, null, '景区商户', '3', null, 1, to_date('01-01-2017 11:15:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (79, 20, null, '行政区', '1', null, 1, to_date('01-01-2017 11:16:33', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (80, 20, null, '商业区', '2', null, 1, to_date('01-01-2017 11:16:40', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (81, 21, null, '菜单', '1', null, 1, to_date('01-01-2017 11:19:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (82, 21, null, '链接', '2', null, 1, to_date('01-01-2017 11:19:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (83, 21, null, '按钮', '3', null, 1, to_date('01-01-2017 11:19:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (84, 22, null, '游记', '1', null, 1, to_date('01-01-2017 14:13:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (85, 22, null, '攻略', '2', null, 1, to_date('01-01-2017 14:13:16', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (86, 23, null, '身份证', '1', null, 1, to_date('20-01-2017 13:10:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (87, 23, null, '护照', '2', null, 1, to_date('20-01-2017 13:10:48', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (88, 23, null, '台胞证', '3', null, 1, to_date('20-01-2017 13:10:58', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (89, 23, null, '军官证', '4', null, 1, to_date('20-01-2017 13:11:07', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (90, 23, null, '警官证', '5', null, 1, to_date('20-01-2017 13:11:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (91, 23, null, '士兵证', '6', null, 1, to_date('20-01-2017 13:11:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (92, 23, null, '回乡证', '7', null, 1, to_date('20-01-2017 13:11:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (93, 23, null, '港澳通行证', '8', null, 1, to_date('20-01-2017 13:11:37', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (94, 23, null, '大陆通行证（国内航班）', '9', null, 1, to_date('20-01-2017 13:11:44', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (95, 23, null, '大陆居民往来台湾通行证', '10', null, 1, to_date('20-01-2017 13:11:51', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (96, 1, null, '临时', '1', null, 1, to_date('03-11-2016 09:39:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (97, 1, null, '合格', '2', null, 1, to_date('03-11-2016 09:40:07', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (98, 26, null, '百度', '1', null, 1, to_date('08-01-2017 15:51:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (99, 26, null, '谷歌', '2', null, 1, to_date('08-01-2017 15:52:59', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (100, 26, null, '高德', '3', null, 1, to_date('08-01-2017 15:53:08', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (101, 26, null, '腾讯', '4', null, 1, to_date('08-01-2017 15:53:45', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (102, 30, null, '游记攻略', '1', null, 1, to_date('26-01-2017 10:38:00', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (103, 4, null, '普通', '1', null, 1, to_date('26-01-2017 10:40:21', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (104, 4, null, '标签', '2', null, 1, to_date('26-01-2017 10:40:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (105, 24, null, '新增', '1', null, 1, to_date('04-02-2017 14:01:52', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (106, 24, null, '修改', '2', null, 1, to_date('04-02-2017 14:01:59', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (107, 24, null, '删除', '3', null, 1, to_date('04-02-2017 14:02:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (108, 24, null, '重置密码', '4', null, 1, to_date('04-02-2017 14:02:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (109, 24, null, '修改权限', '5', null, 1, to_date('04-02-2017 14:02:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (110, 25, null, '景区平台后台', '1', null, 1, to_date('07-02-2017 16:10:36', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('15-02-2017 13:17:22', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (111, 3, null, '土豆', '1', null, 1, to_date('04-11-2016 15:31:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (112, 27, null, '未激活', '0', null, 1, to_date('15-02-2017 13:47:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (113, 27, null, '已激活', '1', null, 1, to_date('15-02-2017 13:47:31', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (114, 28, null, '微信', '1', null, 1, to_date('15-02-2017 13:51:12', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (115, 28, null, 'QQ', '2', null, 1, to_date('15-02-2017 13:51:21', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (116, 28, null, '支付宝', '3', null, 1, to_date('15-02-2017 13:51:35', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (117, 28, null, '新浪微博', '4', null, 1, to_date('15-02-2017 13:51:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (118, 29, null, '小学', '0', null, 1, to_date('15-02-2017 13:52:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (119, 29, null, '初中', '1', null, 1, to_date('15-02-2017 13:53:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (120, 29, null, '高中', '2', null, 1, to_date('15-02-2017 13:53:15', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (121, 29, null, '大专', '3', null, 1, to_date('15-02-2017 13:53:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (122, 29, null, '大学本科', '4', null, 1, to_date('15-02-2017 13:53:39', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('15-02-2017 13:53:53', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (123, 29, null, '硕士', '5', null, 1, to_date('15-02-2017 13:54:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (124, 29, null, '博士', '6', null, 1, to_date('15-02-2017 13:54:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (125, 29, null, '博士后', '7', null, 1, to_date('15-02-2017 13:54:46', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (126, 29, null, '其他', '8', null, 1, to_date('15-02-2017 13:55:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (127, 2, null, '计算机业', '0', null, 1, to_date('15-02-2017 13:57:01', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (128, 2, null, '制造业', '1', null, 1, to_date('15-02-2017 13:57:23', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (129, 2, null, '工农业', '2', null, 1, to_date('15-02-2017 13:57:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (130, null, 'SCENIC_CLASSES', '景区类别', null, null, 1, to_date('15-02-2017 18:07:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (131, 130, null, '景区', '1', null, 1, to_date('15-02-2017 18:07:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (132, 130, null, '商户', '2', null, 1, to_date('15-02-2017 18:08:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
commit;

insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (133, null, 'SYSTEM_TYPE', '系统类别', null, null, 1, to_date('06-03-2017 16:16:18', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('06-03-2017 16:20:34', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (134, 133, null, '景区管理后台系统', '1', null, 1, to_date('06-03-2017 16:16:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (135, 133, null, '景区管理后台APP（供应商版）', '2', null, 1, to_date('06-03-2017 16:17:09', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (136, 133, null, '景区平台APP', '3', null, 1, to_date('06-03-2017 16:17:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (137, 133, null, '景区平台M网', '4', null, 1, to_date('06-03-2017 16:17:33', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('06-03-2017 16:18:42', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (138, 133, null, '景区平台PC端', '5', null, 1, to_date('06-03-2017 16:18:30', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (139, null, 'LOCATION_TYPE', '位置类型', null, null, 1, to_date('06-03-2017 17:24:58', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('07-03-2017 14:17:00', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (140, 139, null, '图文链接', '1', null, 1, to_date('06-03-2017 17:25:18', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (141, 139, null, '产品推荐', '2', null, 1, to_date('06-03-2017 17:25:29', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (142, 139, null, '搜索关键字', '3', null, 1, to_date('06-03-2017 17:25:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (175, null, 'PRODUCT_TYPE', '产品一级类别', null, null, 1, to_date('30-03-2017 17:59:15', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 17:04:22', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (176, 175, null, '景点', '1', null, 1, to_date('30-03-2017 17:59:29', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (177, 175, null, '购物', '2', null, 1, to_date('30-03-2017 17:59:48', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('06-04-2017 16:57:23', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (178, 175, null, '旅游线路', '3', null, 1, to_date('30-03-2017 17:59:40', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('06-04-2017 16:57:14', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (179, null, 'PRODUCT_TYPE_SCENIC', '产品二级类别-景点类', null, null, 1, to_date('30-03-2017 18:01:13', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 17:05:09', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (180, 179, null, '门票', '1', null, 1, to_date('30-03-2017 18:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (181, 179, null, '古镇', '2', null, 1, to_date('30-03-2017 18:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (182, 179, null, '温泉', '3', null, 1, to_date('30-03-2017 18:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (183, 179, null, '乐园', '4', null, 1, to_date('30-03-2017 18:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (184, null, 'PRODUCT_TYPE_LINE', '产品二级类别-旅游线路类', null, null, 1, to_date('30-03-2017 18:05:21', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 17:05:04', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (185, 184, null, '度假酒店', '1', null, 1, to_date('30-03-2017 18:05:31', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (186, 184, null, '自由行', '2', null, 1, to_date('30-03-2017 18:05:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (187, 184, null, '直通车', '3', null, 1, to_date('30-03-2017 18:06:05', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (188, null, 'PRODUCT_TYPE_SHOPPING', '产品二级类别-购物类', null, null, 1, to_date('30-03-2017 18:06:57', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 17:04:57', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (244, 188, null, '土特产', '1', null, 1, to_date('30-03-2017 18:07:24', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (189, null, 'MEMBER_ORDER_STATUS', '订单状态', null, null, 1, to_date('30-03-2017 18:53:34', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (190, 189, null, '新单', '1', null, 1, to_date('30-03-2017 18:53:51', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (191, 189, null, '已取消', '2', null, 1, to_date('30-03-2017 18:54:09', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 15:36:32', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (192, 189, null, '已确认', '3', null, 1, to_date('30-03-2017 18:54:22', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (193, 189, null, '已完成', '6', null, 1, to_date('30-03-2017 18:54:32', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 15:37:15', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (194, 189, null, '申请退单', '4', null, 1, to_date('30-03-2017 18:54:46', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 15:36:47', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (195, 189, null, '已退单', '5', null, 1, to_date('30-03-2017 18:54:57', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('01-04-2017 15:37:03', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (196, null, 'ORDER_PAY_STATUS', '付款状态', null, null, 1, to_date('30-03-2017 18:55:20', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (197, 196, null, '未付款', '1', null, 1, to_date('30-03-2017 18:55:38', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (198, 196, null, '部分付款', '2', null, 1, to_date('30-03-2017 18:55:48', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (199, 196, null, '已全款', '3', null, 1, to_date('30-03-2017 18:56:00', 'dd-mm-yyyy hh24:mi:ss'), 1, to_date('31-03-2017 16:20:39', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (200, 196, null, '超额付款', '4', null, 1, to_date('30-03-2017 18:56:11', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (213, null, 'COMMENT_PRAISE_SRC', '评价点赞来源', null, null, 1, to_date('01-04-2017 17:12:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (233, null, 'COLLECTION_TYPE', '收藏类别', null, null, 1, to_date('06-04-2017 15:09:26', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (234, 233, null, '产品', '1', null, 1, to_date('06-04-2017 15:09:41', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (235, 233, null, '游记攻略', '2', null, 1, to_date('06-04-2017 15:09:55', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (236, null, 'SHARED_ACCOUNT_TYPE', '共享账号类型', null, null, 1, to_date('07-04-2017 16:53:49', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (237, 236, null, '微信', '1', null, 1, to_date('07-04-2017 16:54:02', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (238, 236, null, 'QQ', '2', null, 1, to_date('07-04-2017 16:54:14', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (239, 236, null, '新浪微博', '3', null, 1, to_date('07-04-2017 16:54:25', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (241, 240, null, '2', '2', null, 1, to_date('10-04-2017 15:23:43', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (242, 3, null, '门票', '1', null, 1, to_date('10-04-2017 18:21:34', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (243, 3, null, '景点', '2', null, 1, to_date('10-04-2017 18:21:46', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (245, null, 'ORDER_PAY_WAY', '支付方式', null, null, 1, to_date('01-04-2017 15:52:32', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (246, 245, null, '微信', '1', null, 1, to_date('01-04-2017 15:52:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (247, 245, null, '支付宝', '2', null, 1, to_date('01-04-2017 15:53:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (248, 245, null, 'QQ支付', '3', null, 1, to_date('01-04-2017 15:52:56', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
insert into TB_DICTIONARY (ID, PARENT_ID, CODE, NAME, VALUE, SORT, VALID, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER)
values (249, 245, null, '银联', '4', null, 1, to_date('01-04-2017 15:53:04', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null);
commit;

------------------------------------------------------------------------------------------------------------------------
--创建序列----------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
--一期开始----------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE SEQ_TB_SUPPLIERS_PRODUCT_TYPE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_SCENIC_SELLER_SUPPLIERS_RE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_CITY MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_CITY_AREA MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_CITY_LAND_MARK MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COUNTRY MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MATERIAL MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MATERIAL_AUTHORIZED MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PICTURES MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_POSITION MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PROVINCE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SCENIC_SELLER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SCENIC_SELLER_AUTH MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SUPPLIERS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SUPPLIERS_CONTRACT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SUPPLIERS_DOCUMENT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_TRAVEL_NOTES MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_TRAVEL_NOTES_DETAILS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENTS_IMAGE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENTS_OPTION MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENTS_SCORE_ITEMS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENTS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_KEYWORD MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_KEYWORD_REF MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_USER_LOG MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_BASIC MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_DETAIL_INFO MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_DOCUMENT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_PASSENGER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;

--select max(id)+1 from tb_auth_permission ;
CREATE SEQUENCE SEQ_TB_AUTH_PERMISSION MINVALUE 209 MAXVALUE 999999999 START WITH 209 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from tb_auth_resource ;
CREATE SEQUENCE SEQ_TB_AUTH_RESOURCE MINVALUE 275 MAXVALUE 999999999 START WITH 275 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from tb_auth_role ;
CREATE SEQUENCE SEQ_TB_AUTH_ROLE MINVALUE 2 MAXVALUE 999999999 START WITH 2 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from tb_auth_user ;
CREATE SEQUENCE SEQ_TB_AUTH_USER MINVALUE 3 MAXVALUE 999999999 START WITH 3 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from tb_auth_userrole ;
CREATE SEQUENCE SEQ_TB_AUTH_USERROLE MINVALUE 2 MAXVALUE 999999999 START WITH 2 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from tb_dictionary ;
CREATE SEQUENCE SEQ_TB_DICTIONARY MINVALUE 244 MAXVALUE 999999999 START WITH 250 INCREMENT BY 1 CACHE 20 ORDER ;
--select max(id)+1 from TB_AUTH_DEPARTMENT;
CREATE SEQUENCE SEQ_TB_AUTH_DEPARTMENT MINVALUE 2 MAXVALUE 999999999 START WITH 2 INCREMENT BY 1 CACHE 20 ORDER ;
--一期结束----------------------------------------------------------------------------------------------------------------
--二期开始----------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE SEQ_TB_SUPPLIERS_SINGLE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SUPPLIERS_RESOURCE_RE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SUPPLIERS_DEPARTMENT_RE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SCENIC_SELLER_SUPPLIERS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_RESOURCE_SALES_PRICE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_RESOURCE_INVENTORYS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENT_OPTION MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_BUSI_NOTICE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_BUSI_PICTURE_LIB MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_BUSI_SELLER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_BUSI_SELLER_USER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_ORDER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_ORDER_MONEY_CHANGE_REC MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_ORDER_PAY_RECORD MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_COMMENT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_COMMENT_FILE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_MEALS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_PIC_REL MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_RESO_FLIGHT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_RESO_HOTEL MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_RESO_REFER MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_STOCK MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PRODUCT_STOCK_LOG MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS_CONFIG MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS_CONFIG_KEYWORD MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS_CONFIG_PIC MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS_CONFIG_PRODUCT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SYS_NOTICE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_SHARES MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_PUSH_PRAISE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MSG_SMS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_BROWSER_HISTORY MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_COLLECTION MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_SHARED_ACCOUNT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_ORDER_INVOICE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_HISTORY_SEARCH MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;

CREATE SEQUENCE SEQ_TB_SCENIC_SELLER_SUP_RE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENT_TOPIC MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_COMMENT_REASON MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_TRAVELNOTES_COMMENTFILE MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_TRAVEL_NOTES_COMMENT MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_MSG MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_FEEDBACK MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_FEEDBACK_IMG MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
CREATE SEQUENCE SEQ_TB_MEMBER_ADDRESS MINVALUE 1 MAXVALUE 999999999 START WITH 1 INCREMENT BY 1 CACHE 20 ORDER ;
create sequence SEQ_TB_ORDER_LINKMAN_REF minvalue 1 maxvalue 99999999999999 start with 1 increment by 1 cache 20;
create sequence SEQ_TB_ORDER_LINKMAN_DOC minvalue 1 maxvalue 99999999999999 start with 1 increment by 1 cache 20;
create sequence SEQ_TB_PAY_RECORD minvalue 1 maxvalue 99999999999999 start with 1 increment by 1 cache 20;
--二期结束----------------------------------------------------------------------------------------------------------------


