package com.baidu.ueditor.upload;

import java.io.IOException;
import java.net.SocketException;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.baidu.ueditor.PathFormat;
import com.baidu.ueditor.define.AppInfo;
import com.baidu.ueditor.define.BaseState;
import com.baidu.ueditor.define.FileType;
import com.baidu.ueditor.define.State;

public final class Base64Uploader {

	public static State save(String content, Map<String, Object> conf) throws SocketException, IOException {
		
		byte[] data = decode(content);

		long maxSize = ((Long) conf.get("maxSize")).longValue();

		if (!validSize(data, maxSize)) {
			return new BaseState(false, AppInfo.MAX_SIZE);
		}

		String suffix = FileType.getSuffix("JPG");

		String savePath = PathFormat.parse((String) conf.get("savePath"),
				(String) conf.get("filename"));
		
		savePath = savePath + suffix;
		//无用
//		String physicalPath = PropertiesUtil.getValue("imageUrlRootPath") + savePath;
//		String physicalPath = (String) conf.get("imageUrlRootPath") + savePath;

//		State storageState = StorageManager.saveBinaryFile(data, physicalPath);
//		File file = new File(physicalPath);
//		InputStream input = new FileInputStream(file);
//		FtpProxy.upload(input, Constants.FILE_PATH_HEAD_URL+"operateManual/", getFileName(savePath));
		State storageState = new BaseState(true);
		if (storageState.isSuccess()) {
			storageState.putInfo("url", PathFormat.format(savePath));
			storageState.putInfo("type", suffix);
			storageState.putInfo("original", "");
		}

		return storageState;
	}

	private static byte[] decode(String content) {
		return Base64.decodeBase64(content);
	}
	private static  String getFileName(String filePath){
		String[] n1 = filePath.split("\\.");
		String[] n2 = n1[0].split("\\/");
		if(n2.length==1){
			return n2[0]+"."+n1[n1.length-1];
		}else{
			return n2[n2.length-1]+"."+n1[n1.length-1];
		}
	}

	private static boolean validSize(byte[] data, long length) {
		return data.length <= length;
	}
	
}