package com.spring.scenic.system.intreface.controller;

import java.security.interfaces.RSAPublicKey;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Hex;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.util.RSAUtils;
import com.spring.scenic.common.util.RSAkey;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 系统登录、退出等基础接口
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
@Controller
@RequestMapping("index")
public class IndexController {
	
	/**
	 * 安全验证通过后进入容器主界面
	 */
	@RequestMapping(value = "welcome", method = RequestMethod.GET)
	public String welcome(HttpServletRequest request,HttpServletResponse response) {
		AuthUser authUser = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(authUser == null){
			request.getSession().removeAttribute("user");
			request.getSession().invalidate();
			return "index/login";
		}
		return "index/welcome";
	}
    
	/**
	 * 根据用户登录角色加载菜单
	 */
	@ResponseBody
	@RequestMapping(value = "initMenu", method = RequestMethod.GET)
	public String initMenu(HttpServletRequest request,HttpServletResponse response) {
		//String menu = this.commonService.loadMenu(request);
		return "";
	}
	
	/**
	 * 登出
	 */
	@RequestMapping(value="logout",method=RequestMethod.GET)
	public String logoutUser(HttpServletRequest request,HttpServletResponse response){
		request.getSession().removeAttribute(SysConstant.SESSION_USER);
		request.getSession().invalidate();
		return "index/login";
	} 
	
	/**
	 * 获取RSA公钥
	 */
	@ResponseBody
	@RequestMapping(value="getPublicKey",method=RequestMethod.POST)
	public RSAkey getPublicKey(HttpServletRequest request,HttpServletResponse response){
		RSAPublicKey publicKey = RSAUtils.getDefaultPublicKey();
		String modules=new String(Hex.encodeHex(publicKey.getModulus().toByteArray()));
		String exponent=new String(Hex.encodeHex(publicKey.getPublicExponent().toByteArray()));
		return new RSAkey(modules,exponent);
	}
	
	/**
	 * 验证用户是否首次登陆
	 */
	@ResponseBody
	@RequestMapping(value="validateFirstLogin",method=RequestMethod.POST)
	public boolean validateFirstLogin(HttpServletRequest request,HttpServletResponse response){
		return true;
	}
	
}
