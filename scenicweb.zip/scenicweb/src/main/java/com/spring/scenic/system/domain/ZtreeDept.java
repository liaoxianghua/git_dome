package com.spring.scenic.system.domain;

import java.io.Serializable;

import com.spring.scenic.common.domain.Entity;

/**
 * 使用ztree实现的下拉部门，用于部门树形结构，所属景区树形结构
 * */
public class ZtreeDept extends Entity<AuthUser> implements Serializable {

    private static final long serialVersionUID = 4952766550146842292L;
    /**
     * 部门ID
     */
    private Integer id;

    /**
     * 上级部门ID
     */
    private Integer pId;

    /**
     * 部门名称
     */
    private String name;

    /**
     * 是否禁用('true':禁用,'false':启用)
     */
    private String chkDisabled;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChkDisabled() {
        return chkDisabled;
    }

    public void setChkDisabled(String chkDisabled) {
        this.chkDisabled = chkDisabled;
    }


}
