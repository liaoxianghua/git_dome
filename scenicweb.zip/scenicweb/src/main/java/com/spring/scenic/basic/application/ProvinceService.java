package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.Province;

public interface ProvinceService {

	/**
	 * @param province
	 * @param pageTrue 
	 * @return
	 */
	public List<Province> getProvinceList(Province province, boolean pageAble);

	/**
	 * @param province
	 * @return
	 */
	public Province getProvinceInfoById(Province province);

	/**
	 * @param province
	 */
	public void saveProvince(Province province);

	/**
	 * @param province
	 */
	public void updateProvinceStatus(Province province);

	/**
	 * @return
	 */
	public List<Province> getCountryList();

	/**
	 * @param countryId
	 * @return
	 */
	public List<Province> getProvinceList(Integer countryId);

	/**
	 * @return
	 */
	public List<Province> getCityList();

	/**
	 * @return
	 */
	public List<Province> getAllProvinceList();

	/**
	 * @param province
	 * @return
	 */
	public List<Province> getCityListByIdParam(Province province);

}
