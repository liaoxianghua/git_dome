package com.spring.scenic.basic.application.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.basic.domain.KeywordRef;
import com.spring.scenic.basic.infrastructure.KeywordMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.domain.AuthUser;

@Service
public class KeywordServiceImpl  implements KeywordService{
	
	@Resource
	private KeywordMapper keywordMapper;
	

	@Override
	public List<Keyword> queryKeywordList(Keyword keyword, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(keyword.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<Keyword> resultList = keywordMapper.queryKeywordList(keyword);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int addKeyword(Keyword keyword, AuthUser user) {
		try {
			int count = 0;
			try {
				keyword.setCreateUser(user.getId());
				keyword.setCreateTime(new Date());
				count = keywordMapper.insertSelective(keyword);
				
			} catch (Exception e) {
				e.printStackTrace();
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
			return count;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int updateByPrimaryKey(Keyword keyword, AuthUser user) {
		int count = 0;
		try {
			keyword.setUpdateTime(new Date());
			keyword.setUpdateUser(user.getId());
			count = keywordMapper.updateByPrimaryKeySelective(keyword);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		return count;
	}

	@Override
	public Keyword selectByPrimaryKey(Integer id) {
		try {
			return keywordMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateKeywordById(Keyword keyword, AuthUser user) {
		try {
			try {
				keyword.setUpdateTime(new Date());
				keyword.setUpdateUser(user.getId());
				keywordMapper.updateKeywordById(keyword);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Keyword> selectKeywordList(Keyword keyword) {
		try {
			List<Keyword> reList = keywordMapper.selectKeywordList(keyword);
			return reList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Keyword addTravelNoteKeyword(Keyword keyword,AuthUser authUser) {
		Keyword resultKeyword = new Keyword();
		try {
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setCreateTime(new Date());
			keywordRef.setCreateUser(authUser.getId());
			keywordRef.setOutRelatedId(keyword.getTravelNoteId());
			keywordRef.setKeywordId(keyword.getId());
			
			resultKeyword.setKeywordId(keyword.getId());
			resultKeyword.setOutRelatedId(keyword.getTravelNoteId());
			resultKeyword.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_TRAVEL.getCode()));
			
			keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_TRAVEL.getCode()));
			@SuppressWarnings("unused")
			int id = keywordMapper.addTravelNoteKeyword(keywordRef);
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		return resultKeyword;
	}

	@Override
	public int getTravelKeywordRef(Keyword keyword) {
		try {
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setOutRelatedId(keyword.getTravelNoteId());
			keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_TRAVEL.getCode()));
			keywordRef.setKeywordId(keyword.getId());
			int count = keywordMapper.getTravelKeywordRef(keywordRef);
			return count;
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Keyword> selectByTravelNoteKeywordList(Keyword keyword) {
		try {
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setOutRelatedId(keyword.getId());
			keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_TRAVEL.getCode()));
			return keywordMapper.selectByTravelNoteKeywordList(keywordRef);
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void delTravelNoteKeyword(Keyword keyword) {
		try {
			keyword.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_TRAVEL.getCode()));
			keywordMapper.delTravelNoteKeyword(keyword);
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
