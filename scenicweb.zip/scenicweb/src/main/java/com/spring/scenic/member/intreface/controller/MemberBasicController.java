/**
 * 
 */
package com.spring.scenic.member.intreface.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.domain.Collection;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.Order;
import com.spring.scenic.system.domain.AuthUser;

/**
 *  @Description：会员管理
 *  @author：ranmaoping
 *  @date:下午3:08:48 2017年1月17日
 *  @version:1.0
 *
 */
@Controller
@RequestMapping("member/member")
public class MemberBasicController extends BaseController{
	
	@Autowired
	private MemberBasicService memberBasicService;
	@Autowired
	private MemberDetailInfoService memberDetailInfoService;
	
	@RequestMapping("memberList")
	public String memberList() {
		return "member/member/memberList";
	}
	
	/**
	 * @Description 会员信息查询
	 * @param request
	 * @param travelNote
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2016年12月30日
	 */
	@ResponseBody
	@RequestMapping(value="getMemberList",method=RequestMethod.POST)
	public EntityData getMemberList(HttpServletRequest request,MemberBasic member){
		member.initDataTableParam(request);
		List<MemberBasic> members = memberBasicService.getMemberList(member,SysConstant.PAGE_TRUE);
		PageInfo<MemberBasic> page = new PageInfo<MemberBasic>(members);
		EntityData data = new EntityData(member,page);
		return data;
	}
	
	/**
	 * 跳转到会员基本信息页面
	 * @param request
	 * @param response
	 * @param member
	 * @return
	 */
	@RequestMapping(value = "memberDetail",method=RequestMethod.GET )
	public String memberDetailEdit(HttpServletRequest request, HttpServletResponse response,MemberBasic member) {
		member = memberBasicService.getMemberDetailInfo(member);
		request.setAttribute("operate", "edit");
		request.setAttribute("memberDetail", member);
		/*
		 * 查询常用出行人信息
		 */
		List<MemberDetailInfo> memberDetailInfo = new ArrayList<MemberDetailInfo>();
		if (member!=null) {
			memberDetailInfo = memberDetailInfoService.queryCommonTripManList(member);
		}
		request.setAttribute("memberDetailInfo", memberDetailInfo);
		return "member/member/memberDetail";
	}
	
	@ResponseBody
	@RequestMapping(value = "addMemberCommonPassengerInfo" ,method=RequestMethod.POST)
	public  List<MemberDetailInfo> addMemberCommonPassengerInfo(HttpServletRequest request, HttpServletResponse response,MemberDetailInfo memberDetailInfo) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (memberDetailInfo.getId()==null || "".equals(memberDetailInfo.getId())) {
			memberDetailInfoService.addMemberCommonPassengerInfo(memberDetailInfo,userInfo);
		}else {
			memberDetailInfoService.updateMemberCommonPassengerInfo(memberDetailInfo,userInfo);
		}
		MemberBasic memberBasic = new MemberBasic();
		memberBasic.setId(memberDetailInfo.getFkId());
		List<MemberDetailInfo> resultData = memberDetailInfoService.queryCommonTripManList(memberBasic);
		
		return resultData;
	}
	
	@ResponseBody
	@RequestMapping(value = "updateMemberCommonTripMan" ,method=RequestMethod.POST)
	public  MemberDetailInfo updateMemberCommonTripMan(HttpServletRequest request, HttpServletResponse response,MemberDetailInfo memberDetailInfo) throws Exception{
		MemberDetailInfo mDetailInfo = memberDetailInfoService.updateMemberCommonTripMan(memberDetailInfo);
		return mDetailInfo;
	}
	
	@ResponseBody
	@RequestMapping(value = "deleteInfo" ,method=RequestMethod.POST)
	public  List<MemberDetailInfo> deleteInfo(HttpServletRequest request, HttpServletResponse response,MemberDetailInfo memberDetailInfo) throws Exception{
		memberDetailInfoService.deleteInfo(memberDetailInfo);
		MemberBasic memberBasic = new MemberBasic();
		memberBasic.setId(memberDetailInfo.getMemberId());
		List<MemberDetailInfo> resultData = memberDetailInfoService.queryCommonTripManList(memberBasic);
		return resultData;
	}
	
	
	
	/**
	 * 保存修改的会员基本信息
	 * @param request
	 * @param response
	 * @param member
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="saveMemberBasicInfo",method=RequestMethod.POST)
	public MessageData saveMemberBasicInfo(HttpServletRequest request,HttpServletResponse response,MemberBasic member){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		member.setUpdateTime(new Date());
		member.setUpdateUser(userInfo.getId());
		this.memberBasicService.saveMemberBasicInfo(member);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	
	/**
     * @Description 会员订单tab页展示
     * @param request
     * @param order
     * @return EntityData
     * @author 004225（ranmaoping）
     * @date 2017年03月29日
     */
    @ResponseBody
    @RequestMapping(value="getMemberOrders",method=RequestMethod.POST)
    public EntityData getMemberOrders(HttpServletRequest request,Order order){
        order.initDataTableParam(request);
        List<Order> orderList = memberBasicService.getMemberOrders(order,SysConstant.PAGE_TRUE);
        PageInfo<Order> page = new PageInfo<Order>(orderList);
        EntityData data = new EntityData(order,page);
        return data;
    }
    
    /**
     * @Description 会员收藏tab页展示
     * @param request
     * @param travelNote
     * @return EntityData
     * @author 004225（ranmaoping）
     * @date 2017年03月29日
     */
    @ResponseBody
    @RequestMapping(value="getMemberCollections",method=RequestMethod.POST)
    public EntityData getMemberCollections(HttpServletRequest request,Collection collection){
        collection.initDataTableParam(request);
        List<Collection> collectionList = memberBasicService.getMemberCollections(collection,SysConstant.PAGE_TRUE);
        PageInfo<Collection> page = new PageInfo<Collection>(collectionList);
        EntityData data = new EntityData(collection,page);
        return data;
    }
    
    /**
     * 跳转到会员订单详情页面
     * @param request
     * @param response
     * @param member
     * @return
     */
    @RequestMapping(value = "getMemberOrderDetail",method=RequestMethod.GET )
    public String getMemberOrderDetail(HttpServletRequest request, HttpServletResponse response,Order order) {
        String orderNo = order.getOrderNo();
        if(StringUtil.isNotEmpty(orderNo)) {
            //查询订单基本信息
            Order orderDetailInfo = memberBasicService.getMemberOrderDetail(order);
            //查询发票信息
            //OrderInvoice orderInvoiceInfo = memberBasicService.getOrderInvoiceInfo(orderNo);
            //查询订单金额调整记录
            //List<OrderMoneyChangeRec> changeRecList = memberBasicService.getChangeRecList(orderNo);
            //查询支付记录
            //List<OrderPayRecord> payRecList = memberBasicService.getPayRecListList(orderNo);
            request.setAttribute("orderDetailInfo", orderDetailInfo);
            //request.setAttribute("orderInvoiceInfo", orderInvoiceInfo);
            //request.setAttribute("changeRecList", changeRecList);
            //request.setAttribute("payRecList", payRecList);
        }
        return "member/member/memberOrderDetail";
    }
}
