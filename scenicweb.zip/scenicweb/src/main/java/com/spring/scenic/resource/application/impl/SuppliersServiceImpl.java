/**
 * 
 */
package com.spring.scenic.resource.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.MultiPartUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.resource.application.SuppliersService;
import com.spring.scenic.resource.domain.Suppliers;
import com.spring.scenic.resource.domain.SuppliersContract;
import com.spring.scenic.resource.domain.SuppliersLicense;
import com.spring.scenic.resource.domain.SuppliersProductType;
import com.spring.scenic.resource.infrastructure.SuppliersContractMapper;
import com.spring.scenic.resource.infrastructure.SuppliersLicenseMapper;
import com.spring.scenic.resource.infrastructure.SuppliersMapper;
import com.spring.scenic.resource.infrastructure.SuppliersProductTypeMapper;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;
import com.spring.scenic.system.infrastructure.DictionaryMapper;

/**
 * @descriptipn:供应商管理接口实现类
 * @author：ranmaoping
 * @date:上午11:05:14 2016年11月2日
 * @version:1.0
 * 
 */
@Service
public class SuppliersServiceImpl implements SuppliersService {

	@Autowired
	SuppliersMapper suppliersMapper;
	@Autowired
	SuppliersProductTypeMapper suppliersProductTypeMapper;
	@Autowired
	SuppliersContractMapper suppliersContractMapper;
	@Autowired
	SuppliersLicenseMapper suppliersLicenseMapper;
	@Autowired
	DictionaryMapper dictionaryMapper;
	@Resource(name = "fastDFSStorageService")
	private StorageService fastDFSStorageService;

	/**
	 * 查询供应商信息
	 */
	@Override
	public List<Suppliers> getSuppliersList(Suppliers suppliers,
			boolean pageAble) {
		try {
			if (pageAble) {
				PageHelper.startPage(suppliers.getPageNum(),
						SysConstant.PAGE_PAGESIZE);
			}
			List<Suppliers> suppliersList = suppliersMapper
					.getSuppliersList(suppliers);
			return suppliersList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 通过id查询供应商信息
	 */
	@Override
	public Suppliers getSuppliersInfoById(Suppliers suppliers) {
		try {
			Suppliers supplier = suppliersMapper
					.getSuppliersInfoById(suppliers);
			return supplier;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 保存供应商信息
	 */
	@Override
	public void saveSuppliers(AuthUser userInfo, Suppliers suppliers) {
		validata(suppliers);
		try {
			if (null == suppliers.getId() || "".equals(suppliers.getId())) {
				suppliers.setCreateTime(new Date());
				suppliers.setCreateUser(userInfo.getId());
				suppliers.setUpdateTime(new Date());
				suppliers.setUpdateUser(userInfo.getId());
				suppliersMapper.addSuppliers(suppliers);
			} else {
				Suppliers supplierExample = suppliersMapper
						.getSuppliersInfoById(suppliers);
				supplierExample.setId(suppliers.getId());
				supplierExample.setName(suppliers.getName());
				supplierExample.setCode(suppliers.getCode());
				supplierExample.setRemarks(suppliers.getRemarks());
				supplierExample.setValid(suppliers.getValid());
				supplierExample.setStatus(suppliers.getStatus());
				supplierExample.setUpdateTime(new Date());
				supplierExample.setUpdateUser(userInfo.getId());
				suppliersMapper.updateByPrimaryKey(supplierExample);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 校验供应熵编码是否重复
	 * 
	 * @param suppliers
	 */
	public void validata(Suppliers suppliers) {
		int count=0;
		try {
			count = suppliersMapper.getSuppliersCodeCount(suppliers);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		if (count > 0) {
			throw new BussinessException(new BussinessExceptionBean("exception.suppliersCodeIsExisted"));
		}
	}

	@Override
	public void updateSuppliersStatus(AuthUser userInfo, Suppliers suppliers) {
		try {
			suppliers.setUpdateTime(new Date());
			suppliers.setUpdateUser(userInfo.getId());
			suppliersMapper.updateSuppliersStatus(suppliers);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * 保存供应商信息
	 */
	@Override
	public List<SuppliersProductType> getProductTypeList(Suppliers suppliers) {
		try {
			// 查询数据字典所有的产品集合
			List<Dictionary> dictionaryList = dictionaryMapper
					.getProductTypeList();
			// 查询该供应商已有的产品集合
			List<SuppliersProductType> productList = suppliersProductTypeMapper
					.getProductList(suppliers);
			// 创建新的产品集合，装载组装的数据
			List<SuppliersProductType> productTypeList = new ArrayList<SuppliersProductType>();
			// 遍历产品集合，给该供应商已有的商品在前端设置选中（checked）状态
			if (null != dictionaryList && dictionaryList.size() > 0) {
				for (Dictionary dictionary : dictionaryList) {
					boolean flag = true;
					SuppliersProductType dto = new SuppliersProductType();
					if (null != productList && productList.size() > 0) {
						for (SuppliersProductType suppliersProductType : productList) {
							if (dictionary.getValue().equals(
									suppliersProductType.getType())) {
								flag = false;
								dto.setId(suppliersProductType.getId());
								dto.setName(dictionary.getName());
								dto.setSuppliersId(suppliers.getId());
								dto.setType(suppliersProductType.getType());
								dto.setCheckStatus("checked");
								productTypeList.add(dto);
								break;
							}
						}
						if (flag) {
							dto.setName(dictionary.getName());
							dto.setType(dictionary.getValue());
							dto.setCheckStatus("");
							dto.setSuppliersId(suppliers.getId());
							productTypeList.add(dto);
						}
					} else {
						dto.setName(dictionary.getName());
						dto.setType(dictionary.getValue());
						dto.setCheckStatus("");
						dto.setSuppliersId(suppliers.getId());
						productTypeList.add(dto);
					}
				}
			}
			return productTypeList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 保存供应商产品信息
	 */
	@Override
	public void saveSuppliersProduct(AuthUser userInfo, Suppliers suppliers) {
		try {
			if (null != suppliers) {
				List<SuppliersProductType> list = suppliers.getProductType();
				if (null != list && list.size() > 0) {
					// 保存供应商之前删除该供应商已有的产品集合
					suppliersProductTypeMapper.deleteBysuppliersId(suppliers);
					// 新建一个productList用于组装新增的数据
					List<SuppliersProductType> productList = new ArrayList<SuppliersProductType>();
					// 当SuppliersProductType中的type不为空时，存入productList中
					for (SuppliersProductType dto : list) {
						if (StringUtil.isNotEmpty(dto.getType())) {
							SuppliersProductType productDto = new SuppliersProductType();
							productDto.setSuppliersId(suppliers.getId());
							productDto.setType(dto.getType());
							productDto.setCreateTime(new Date());
							productDto.setCreateUser(userInfo.getId());
							productDto.setUpdateTime(new Date());
							productDto.setUpdateUser(userInfo.getId());
							productList.add(productDto);
						}
					}
					// 批量新增供应商产品
					if (null != productList && productList.size() > 0) {
						suppliersProductTypeMapper
								.insertProductByBatch(productList);
					}
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}

	}

	/**
	 * 查询供应商合同信息列表
	 */
	@Override
	public List<SuppliersContract> getSuppliersContrctList(
			SuppliersContract suppliersContract, boolean pageAble) {
		List<SuppliersContract> suppliersContrctList;
		try {
			if (pageAble) {
				PageHelper.startPage(suppliersContract.getPageNum(),
						SysConstant.PAGE_PAGESIZE);
			}
			suppliersContrctList = suppliersContractMapper
					.getSuppliersContrctList(suppliersContract);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		return suppliersContrctList;
	}

	/**
	 * 保存供应商合同信息
	 */
	@Override
	public void saveSuppliersContract(AuthUser user,
			Map<String, List<MultipartFile>> filesMap, String key,
			SuppliersContract suppliersContract) {
		try {
			// 合同附件上传服务器，返回附件地址
			if (filesMap != null && !filesMap.isEmpty()) {
				List<MultipartFile> multipartFiles = filesMap.get(key);
				if (multipartFiles != null && !multipartFiles.isEmpty()) {
					MultipartFile multipartFile = multipartFiles.get(0);
					if (null != suppliersContract.getId()
							&& null != suppliersContract.getContractUrl()) {
						fastDFSStorageService.deleteResourceByPath(suppliersContract.getContractUrl().replace(
											PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL),
												""));
					}
					String fileType = FilenameUtils.getExtension(multipartFile
							.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(
							fileType, multipartFile.getBytes(), null);
					suppliersContract.setContractUrl(PropertiesUtil
							.getProperty(SysConstant.ATTACHMENT_VISIT_URL)
							+ fileUrl);
				}
			}
			// 新增合同信息
			if (null == suppliersContract.getId()
					|| "".equals(suppliersContract.getId())) {
				suppliersContract.setCreateTime(new Date());
				suppliersContract.setCreateUser(user.getId());
				suppliersContract.setUpdateTime(new Date());
				suppliersContract.setUpdateUser(user.getId());
				suppliersContractMapper.addSuppliersContract(suppliersContract);
			} else {
				// 修改合同信息
				SuppliersContract contractExample = suppliersContractMapper
						.getSuppliersContractInfoById(suppliersContract);
				contractExample.setId(suppliersContract.getId());
				contractExample.setName(suppliersContract.getName());
				contractExample.setCode(suppliersContract.getCode());
				contractExample.setSigndate(suppliersContract.getSigndate());
				contractExample.setValiddate(suppliersContract.getValiddate());
				if (filesMap != null && !filesMap.isEmpty()) {
					contractExample.setContractUrl(suppliersContract.getContractUrl());
				}
				contractExample.setUpdateTime(new Date());
				contractExample.setUpdateUser(user.getId());
				suppliersContractMapper
						.updateSuppliersContract(contractExample);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 根据id查询供应商合同信息
	 */
	@Override
	public SuppliersContract getSuppliersContractInfoById(
			SuppliersContract suppliersContract) {
		try {
			SuppliersContract dto = suppliersContractMapper
					.getSuppliersContractInfoById(suppliersContract);
			if(null!=dto) {
				//附件地址
				String fileUrl = dto.getContractUrl();
				//把合同名称作为附件名称
				String name = dto.getName();
				if(null!=fileUrl&&!"".equals(fileUrl)) {
					String suffix = fileUrl.substring(fileUrl.lastIndexOf("."),fileUrl.length());
					dto.setFileName(name+suffix);
				}
			}
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 供应商合同附件下载
	 */
	@Override
	public void contractAttachDownload(HttpServletResponse response,SuppliersContract suppliersContract) {
		try {
			SuppliersContract dto = suppliersContractMapper.getSuppliersContractInfoById(suppliersContract);
			if(dto!=null) {
				String fileUrl = dto.getContractUrl();
				String name = dto.getName().trim();
				if(StringUtils.isNotBlank(fileUrl)) {
					String suffix = fileUrl.substring(fileUrl.lastIndexOf("."),fileUrl.length());
					dto.setFileName(name+suffix);
					String groupId = PropertiesUtil.getProperty(SysConstant.FASTDFS_GROUP_ID);
					String remoteUrl =  fileUrl.substring(fileUrl.indexOf(groupId)+(groupId.length()+1),fileUrl.length());
					MultiPartUtil.downloadFromFastDfs(response, groupId, remoteUrl, dto.getFileName());			
				}
			}else{
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}

	}

	/**
	 * 查询供应商证件信息
	 * 
	 * @param suppliersLicense
	 * @param pageAble
	 * @return
	 */
	@Override
	public List<SuppliersLicense> getSuppliersLicenseList(
			SuppliersLicense suppliersLicense, boolean pageAble) {
		if (pageAble) {
			PageHelper.startPage(suppliersLicense.getPageNum(),
					SysConstant.PAGE_PAGESIZE);
		}
		List<SuppliersLicense> suppliersLicenses;
		try {
			suppliersLicenses = suppliersLicenseMapper
					.getSuppliersLicenseList(suppliersLicense);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
		return suppliersLicenses;
	}

	/**
	 * 保存供应商证件信息
	 * 
	 * @param userInfo
	 * @param suppliersLicense
	 * @param filesMap
	 * @param coversImageFile
	 */
	@Override
	public void saveSuppliersLicense(AuthUser userInfo,
			SuppliersLicense suppliersLicense,
			Map<String, List<MultipartFile>> filesMap, String coversImageFile) {
		try {
			suppliersLicense.setCreateTime(new Date());
			suppliersLicense.setCreateUser(userInfo.getId());
			suppliersLicense.setUpdateTime(new Date());
			suppliersLicense.setUpdateUser(userInfo.getId());
			// 图片上传
			if (filesMap != null && !filesMap.isEmpty()) {
				List<MultipartFile> coversImageFiles = filesMap
						.get(coversImageFile);
				if (coversImageFiles != null && !coversImageFiles.isEmpty()) {
					MultipartFile coversImage = coversImageFiles.get(0);
					String coversImageExtensionName = FilenameUtils
							.getExtension(coversImage.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(
							coversImageExtensionName, coversImage.getBytes(),
							null);
					suppliersLicense.setDocumentUrl(PropertiesUtil
							.getProperty(SysConstant.ATTACHMENT_VISIT_URL)
							+ fileUrl);
				}
			}
			suppliersLicenseMapper.addSuppliersLicense(suppliersLicense);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 删除供应商证件信息
	 * 
	 * @param userInfo
	 * @param suppliersLicense
	 */
	@Override
	public void deleteSuppliersLicense(AuthUser userInfo,
			SuppliersLicense suppliersLicense) {
		try {
			String documentUrl = null;
			List<SuppliersLicense> suppliersLicenseList = suppliersLicenseMapper
					.getSuppliersLicenseList(suppliersLicense);
			if (suppliersLicenseList != null && suppliersLicenseList.size() > 0) {
				documentUrl = suppliersLicenseList.get(0).getDocumentUrl();
			}
			if (documentUrl != null && documentUrl != "") {
				fastDFSStorageService.deleteResourceByPath(documentUrl.replace(
						PropertiesUtil
								.getProperty(SysConstant.ATTACHMENT_VISIT_URL),
						""));
			}
			suppliersLicenseMapper.deleteSuppliersLicense(suppliersLicense);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

	/**
	 * 删除供应商证件附件图片
	 * 
	 * @param userInfo
	 * @param suppliersLicense
	 */
	@Override
	public void deleteSuppliersLicenseAttached(AuthUser userInfo,
			SuppliersLicense suppliersLicense) {
		try {
			fastDFSStorageService
					.deleteResourceByPath(suppliersLicense
							.getDocumentUrl()
							.replace(
									PropertiesUtil
											.getProperty(SysConstant.ATTACHMENT_VISIT_URL),
									""));
			suppliersLicenseMapper.updateSuppliersLicense(suppliersLicense);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.syserror"),e);
		}
	}

}
