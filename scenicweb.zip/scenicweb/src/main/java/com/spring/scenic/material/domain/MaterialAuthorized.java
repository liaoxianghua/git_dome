package com.spring.scenic.material.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description 素材授权信息
 * @author 006568（shuchang）
 * @date 2017年1月12日
 */
public class MaterialAuthorized extends Entity<MaterialAuthorized>{
    /**
     * 主键
     */
    private Integer id;

    /**
     * 授权代码
     */
    private String code;

    /**
     * 授权机构
     */
    private String authOrg;

    /**
     * 授权人
     */
    private String authPerson;

    /**
     * 授权开始日期
     */
    private Date authStartDate;

    /**
     * 授权结束日期
     */
    private Date authEndDate;

    /**
     * 签约时间
     */
    private Date signDate;

    /**
     * 有效、无效
     */
    private Short valid;

    /**
     * uuid
     */
    private String guid;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private Integer updateUser;
    /**
     * 业务字段：修改人名
     */
    private String updateUserName;
    
    /**
     * 业务字段：创建人
     */
    private String createUserName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getAuthOrg() {
		return authOrg;
	}

	public void setAuthOrg(String authOrg) {
		this.authOrg = authOrg;
	}

	public String getAuthPerson() {
		return authPerson;
	}

	public void setAuthPerson(String authPerson) {
		this.authPerson = authPerson;
	}

	public Date getAuthStartDate() {
		return authStartDate;
	}

	public void setAuthStartDate(Date authStartDate) {
		this.authStartDate = authStartDate;
	}

	public Date getAuthEndDate() {
		return authEndDate;
	}

	public void setAuthEndDate(Date authEndDate) {
		this.authEndDate = authEndDate;
	}

	public Date getSignDate() {
		return signDate;
	}

	public void setSignDate(Date signDate) {
		this.signDate = signDate;
	}

	public Short getValid() {
		return valid;
	}

	public void setValid(Short valid) {
		this.valid = valid;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	
	
}