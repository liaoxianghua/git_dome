package com.spring.scenic.basic.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.basic.application.ScenicCommercialService;
import com.spring.scenic.basic.domain.CommercialApprove;
import com.spring.scenic.basic.domain.MapMessage;
import com.spring.scenic.basic.domain.Position;
import com.spring.scenic.basic.domain.ScenicCommercial;
import com.spring.scenic.basic.domain.ScenicCommercialApprove;
import com.spring.scenic.basic.infrastructure.CommercialApproveMapper;
import com.spring.scenic.basic.infrastructure.PositionMapper;
import com.spring.scenic.basic.infrastructure.ScenicCommercialMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.material.domain.Material;
import com.spring.scenic.material.domain.Pictures;
import com.spring.scenic.material.infrastructure.MaterialMapper;
import com.spring.scenic.material.infrastructure.PicturesMapper;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;

@Service
public class ScenicCommercialServiceImpl implements ScenicCommercialService {

	@Autowired
	private PositionMapper positionMapper;
	
	@Autowired
	private PicturesMapper picturesMapper;
	
	@Autowired
	private MaterialMapper materialMapper;
	
	@Resource
	private ScenicCommercialMapper scenicCommercialMapper;
	
	@Resource
	private CommercialApproveMapper commercialApproveMapper;
	
	@Resource(name="fastDFSStorageService")
	private StorageService fastDFSStorageService;

	public List<ScenicCommercial> queryScenicCommercial(ScenicCommercial scenicCommercial,boolean pageAble) {
		
		try {
			if(pageAble){
				PageHelper.startPage(scenicCommercial.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<ScenicCommercial> resultList = scenicCommercialMapper.queryScenicCommercial(scenicCommercial);
			Set<ScenicCommercial> set=new HashSet<ScenicCommercial>();
			set.addAll(resultList);
			resultList.clear();
			resultList.addAll(set);
			List<ScenicCommercial> rootResources = new ArrayList<ScenicCommercial>();
			if(resultList!=null && !resultList.isEmpty()){
				for (ScenicCommercial sCommercial : resultList) {
					recursionScenicCommercial(sCommercial,resultList);
				}
				for (ScenicCommercial currentVo : resultList) {
					if(currentVo.getParentId()==null){
						rootResources.add(currentVo);
					}
				}
			}
			return rootResources;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	
	public void recursionScenicCommercial(ScenicCommercial compareScenicCommercial,List<ScenicCommercial> scenicCommercials){
		try {
			List<ScenicCommercial> sCommercials = new ArrayList<ScenicCommercial>();
			for (ScenicCommercial scenicCommercial : scenicCommercials) {
				if(scenicCommercial.getParentId()!=null && scenicCommercial.getParentId().equals(compareScenicCommercial.getId())){
					sCommercials.add(scenicCommercial);
				}
			}
			compareScenicCommercial.setChildren(sCommercials.isEmpty()?null:sCommercials);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public int addScenicCommercial(ScenicCommercial scenicCommercial,AuthUser user) {
		try {
			try {
				scenicCommercial.setCreateUser(user.getId());
				scenicCommercial.setCreateTime(new Date());
				int count = scenicCommercialMapper.addScenicCommercial(scenicCommercial);
				return count;
			} catch (Exception e) {
				e.printStackTrace();
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public int updateByPrimaryKey(ScenicCommercial scenicCommercial,AuthUser user,
			Map<String, List<MultipartFile>> filesMap,String coversImageFile) {
		try {
			try {
				scenicCommercial.setUpdateUser(user.getId());
				scenicCommercial.setUpdateTime(new Date());
				//封面图片上传
				if(filesMap!=null && !filesMap.isEmpty()){
					List<MultipartFile> coversImageFiles = filesMap.get(coversImageFile);
					if(coversImageFiles!=null && !coversImageFiles.isEmpty()){
						MultipartFile coversImage = coversImageFiles.get(0);
						String coversImageExtensionName = FilenameUtils.getExtension(coversImage.getOriginalFilename());
						String fileUrl = fastDFSStorageService.uploadResource(coversImageExtensionName, coversImage.getBytes(), null);
						scenicCommercial.setCoversImageUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
						scenicCommercial.setCoversImageName(coversImage.getOriginalFilename());
					}
				}
				ScenicCommercial updateCommercial = scenicCommercialMapper.selectByPrimaryKey(scenicCommercial.getId());
				updateCommercial.setName(scenicCommercial.getName());
				updateCommercial.setType(scenicCommercial.getType());
				updateCommercial.setTypeCategory(scenicCommercial.getTypeCategory());
				updateCommercial.setStarLevel(scenicCommercial.getStarLevel());
				updateCommercial.setParentId(scenicCommercial.getParentId());
				updateCommercial.setCityId(scenicCommercial.getCityId());
				updateCommercial.setAddress(scenicCommercial.getAddress());
				updateCommercial.setCityAreaId(scenicCommercial.getCityAreaId());
				updateCommercial.setTel(scenicCommercial.getTel());
				updateCommercial.setValid(scenicCommercial.getValid());
				updateCommercial.setUpdateUser(user.getId());
				updateCommercial.setUpdateTime(new Date());
				int count = scenicCommercialMapper.updateScenicCommercial(updateCommercial);
				return count;
			} catch (Exception e) {
				e.printStackTrace();
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public ScenicCommercial selectByPrimaryKey(Integer id) {
		try {
			ScenicCommercial resultVo = scenicCommercialMapper.selectByPrimaryKey(id);
			//查询商户地图信息
			List<MapMessage> liMapMessages = scenicCommercialMapper.selectScenicMapListById(id);
			resultVo.setLiMapMessages(liMapMessages);
			return resultVo;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int addCommercialApprove(CommercialApprove commercialApprove,AuthUser user) {
		try {
			return commercialApproveMapper.addCommercialApprove(commercialApprove);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateValid(ScenicCommercial scenicCommercial, AuthUser user) {
		try {
			scenicCommercial.setUpdateUser(user.getId());
			scenicCommercialMapper.updateValid(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateCommercialInfo(ScenicCommercial scenicCommercial,
			AuthUser userInfo) {
		try {
			scenicCommercial.setUpdateUser(userInfo.getId());
			
			scenicCommercial.setTraffics(scenicCommercial.getTraffics().trim());
			scenicCommercial.setTips(scenicCommercial.getTips().trim());
			scenicCommercial.setIntroduce(scenicCommercial.getIntroduce().trim());
			//得到地图信息
			List<MapMessage> mapMessages = scenicCommercial.getLiMapMessages();
			//通过商户id查询数据中中已经存在的地图信息
			List<MapMessage> oldMaps = scenicCommercialMapper.selectScenicMapListById(scenicCommercial.getId());
			List<MapMessage> insertMaps = new ArrayList<MapMessage>();//新增list
			List<MapMessage> updateMaps = new ArrayList<MapMessage>();//修改lit
			List<MapMessage> deleteMaps = new ArrayList<MapMessage>();//删除list
			MapMessage insertMessage = null;
			MapMessage updatetMessage = null;
			//找出新增数据和更新数据
			if (mapMessages!=null && !"".equals(mapMessages)) {
				for (MapMessage mapMessage : mapMessages) {
					if (mapMessage.getMapType() != null &&StringUtil.isNotEmpty(String.valueOf(mapMessage.getMapType())) && mapMessage.getMapType()!=0) {
						if (mapMessage.getId()==null) {
							insertMessage = new MapMessage();
							insertMessage.setScenicId(scenicCommercial.getId());
							insertMessage.setMapType(mapMessage.getMapType());
							insertMessage.setMapLat(mapMessage.getMapLat());
							insertMessage.setMapLgn(mapMessage.getMapLgn());
							insertMessage.setCreateUser(userInfo.getId());
							insertMessage.setValid(Integer.valueOf(SysConstant.VALITY_YES));
							insertMessage.setOutRelatedType(3);
							insertMaps.add(insertMessage);
						}else {
							updatetMessage = new MapMessage();
							updatetMessage.setId(mapMessage.getId());
							updatetMessage.setScenicId(scenicCommercial.getId());
							updatetMessage.setMapType(mapMessage.getMapType());
							updatetMessage.setMapLat(mapMessage.getMapLat());
							updatetMessage.setMapLgn(mapMessage.getMapLgn());
							updatetMessage.setUpdateUser(userInfo.getId());
							updatetMessage.setValid(Integer.valueOf(SysConstant.VALITY_YES));
							updatetMessage.setOutRelatedType(3);
							updateMaps.add(updatetMessage);
						}
					}else {
						continue;
					}
				}
			}else {
				//如果前端传过来的数据是空，则数据库中的数据都是需要删除的数据
				deleteMaps.addAll(oldMaps);
			}
			//更新的数据与数据库中数据对比找出哪些数据需要删除
			oldMaps.removeAll(updateMaps);
			deleteMaps.addAll(oldMaps);
			
			if (insertMaps.size()>0) {
				scenicCommercialMapper.insertScenicMapMsg(insertMaps);
			}
			if (updateMaps.size()>0) {
				for (MapMessage updMessage : updateMaps) {
					scenicCommercialMapper.updateScenicMapMsg(updMessage);
				}
			}
			if (deleteMaps.size()>0) {
				for (MapMessage mapMessage : deleteMaps) {
					scenicCommercialMapper.deleteScenicMapMsg(mapMessage);
				}
			}
			scenicCommercialMapper.updateCommercialInfo(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	@Override
	public List<Dictionary> initScenicSelectOption(
			Integer id) {
		try {
			return scenicCommercialMapper.initScenicSelectOption(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Integer getIdByScenicType(ScenicCommercial scenicCommercial) {
		try {
			return scenicCommercialMapper.getIdByScenicType(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<ScenicCommercial> initScenicParentOptions(
			ScenicCommercial scenicCommercial) {
		try {
			scenicCommercial.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			return scenicCommercialMapper.initScenicParentOptions(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<ScenicCommercial> initScenicCityOptions(
			ScenicCommercial scenicCommercial) {
		try {
			return scenicCommercialMapper.initScenicCityOptions(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<ScenicCommercial> initScenicCityAreaOptions(
			ScenicCommercial scenicCommercial) {
		try {
			return scenicCommercialMapper.initScenicCityAreaOptions(scenicCommercial);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public ScenicCommercialApprove getCommercialAttestById(
			Integer scenicSellerId) {
		try {
			return scenicCommercialMapper.getCommercialAttestById(scenicSellerId);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void addScenicCommercialAttest(
			ScenicCommercialApprove commercialApprove,AuthUser user) {
		try {
			commercialApprove.setCreateUser(user.getId());
			scenicCommercialMapper.addScenicCommercialAttest(commercialApprove);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateScenicCommercialAttest(
			ScenicCommercialApprove commercialApprove, AuthUser userInfo) {
		try {
			commercialApprove.setUpdateUser(userInfo.getId());
			scenicCommercialMapper.updateScenicCommercialAttest(commercialApprove);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void deleteByPrimaryKey(Integer parseInt) {
		 try {
			scenicCommercialMapper.deleteByPrimaryKey(parseInt);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateForbiddenItemScenic(ScenicCommercial scenicCommercial,
			AuthUser userInfo) {
		try {
			try {
				scenicCommercial.setUpdateUser(userInfo.getId());
				scenicCommercial.setUpdateTime(new Date());
				scenicCommercialMapper.updateValid(scenicCommercial);
				scenicCommercialMapper.updateForbiddenItemScenic(scenicCommercial);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	
	@Override
	public int updatScenicCommercialBasic(AuthUser user,ScenicCommercial scenicCommercial) {
		try {
			Date now = DateUtil.getNow();
			ScenicCommercial scenicCommercialExample = scenicCommercialMapper.getScenicCommercial(scenicCommercial);
			scenicCommercialExample.setId(scenicCommercial.getId());
			
			scenicCommercialExample.setBusinessTime(scenicCommercial.getBusinessTime());
			scenicCommercialExample.setTraffics(scenicCommercial.getTraffics());
			scenicCommercialExample.setTips(scenicCommercial.getTips());
			scenicCommercialExample.setIntroduce(scenicCommercial.getIntroduce());
			scenicCommercialExample.setUpdateTime(now);
			scenicCommercialExample.setUpdateUser(user.getId());
			
			List<Position> positions = scenicCommercial.getPositions();
			List<Position> newPositions = new ArrayList<Position>();
			if(positions!=null && !positions.isEmpty()){
				Iterator<Position> positionsIterator = positions.iterator();
				while(positionsIterator.hasNext()){
					Position position = positionsIterator.next();
					if(position.getType()==null){
						positionsIterator.remove();
					}else{
						position.setOutRelatedId(scenicCommercialExample.getId());
						//position.setOutRelatedType(Integer.valueOf(scenicCommercialExample.getType()));
						position.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
						position.setCreateTime(now);
						position.setCreateUser(user.getId());
						newPositions.add(position);
					}
				}
			}
			
			Position position = new Position();
			position.setOutRelatedId(scenicCommercialExample.getId());
			position.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_SCENIC.getCode()));
			positionMapper.deletePosition(position);
			if(!newPositions.isEmpty()){
				positionMapper.saveBatchPosition(positions);
			}
			return scenicCommercialMapper.updateScenicCommercial(scenicCommercialExample);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}

	@Override
	public int updatScenicCommercial(AuthUser user,ScenicCommercial scenicCommercial, String scenicImageFile,Map<String, List<MultipartFile>> filesMap) {
		try {
			ScenicCommercial scenicCommercialExample = scenicCommercialMapper.getScenicCommercial(scenicCommercial);
			scenicCommercialExample.setId(scenicCommercial.getId());
			scenicCommercialExample.setName(scenicCommercial.getName());
			scenicCommercialExample.setType(scenicCommercial.getType());
			if(scenicCommercial.getType()!=null && scenicCommercial.getType().equals(SysEnum.MAIN_TYPE_SCENIC.getCode())){
				scenicCommercialExample.setStarLevel(scenicCommercial.getStarLevel());
			}else{
				scenicCommercialExample.setStarLevel(null);
			}
			scenicCommercialExample.setTypeCategory(scenicCommercial.getTypeCategory());
			scenicCommercialExample.setParentId(scenicCommercial.getParentId());
			scenicCommercialExample.setCityId(scenicCommercial.getCityId());
			scenicCommercialExample.setCityAreaId(scenicCommercial.getCityAreaId());
			scenicCommercialExample.setAddress(scenicCommercial.getAddress());
			scenicCommercialExample.setTel(scenicCommercial.getTel());
			scenicCommercialExample.setValid(scenicCommercial.getValid());
			scenicCommercialExample.setAddress(scenicCommercial.getAddress());
			scenicCommercialExample.setUpdateTime(new Date());
			scenicCommercialExample.setUpdateUser(user.getId());
			
			if(filesMap!=null && !filesMap.isEmpty()){
				List<MultipartFile> multipartFiles = filesMap.get(scenicImageFile);
				if(multipartFiles!=null && !multipartFiles.isEmpty()){
					if(StringUtils.isNotBlank(scenicCommercialExample.getCoversImageUrl())){
						fastDFSStorageService.deleteResourceByPath(scenicCommercialExample.getCoversImageUrl().replace(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL), ""));
					}
					MultipartFile multipartFile = multipartFiles.get(0);
					String fileType = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(fileType, multipartFile.getBytes(), null);
					scenicCommercialExample.setCoversImageName(multipartFile.getOriginalFilename());
					scenicCommercialExample.setCoversImageUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
				}
			}
			return scenicCommercialMapper.updateScenicCommercial(scenicCommercialExample);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}

	@Override
	public ScenicCommercial getScenicCommercial(ScenicCommercial scenicCommercial) {
		try {
			ScenicCommercial scenicCommercialExample = scenicCommercialMapper.selectByPrimaryKey(scenicCommercial.getId());
			Position positionExample = new Position();
			positionExample.setOutRelatedId(scenicCommercialExample.getId());
			positionExample.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_SCENIC.getCode()));
			List<Position> positions = positionMapper.getPositionList(positionExample);
			scenicCommercialExample.setPositions(positions==null?new ArrayList<Position>():positions);
			return scenicCommercialExample;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Pictures> getScenicCommercialPhotoList(Pictures picture,boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(picture.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<Pictures> pictures = picturesMapper.getPictureList(picture);
			return pictures;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Pictures savePictureLogo(AuthUser user, Pictures picture) {
		try {
			//把以前是logo的设置成否
			picture.setCategoryType(1);
			picturesMapper.updatePictureByFK(picture);
			//保存图片的name和url到对应的景区商户
			Pictures logoPicture = picturesMapper.getPicture(picture);
			logoPicture.setLogo(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
			ScenicCommercial scenicCommercial = scenicCommercialMapper.selectByPrimaryKey(logoPicture.getRelatedId());
			scenicCommercial.setCoversImageName(logoPicture.getName());
			scenicCommercial.setCoversImageUrl(logoPicture.getUrl());
			scenicCommercial.setUpdateTime(new Date());
			scenicCommercial.setUpdateUser(user.getId());
			scenicCommercialMapper.updateScenicCommercial(scenicCommercial);
			picturesMapper.updatePicture(logoPicture);
			return logoPicture;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int deletePicture(Pictures picture) {
		try {
			return picturesMapper.deletePicture(picture);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveScenicCommercialPictures(AuthUser user,ScenicCommercial scenicCommercial,Integer[] materialIds) {
		try {
			Date now = DateUtil.getNow();
			Material materialExample = new Material();
			List<Pictures> pictures = new ArrayList<Pictures>();
			for (Integer id : materialIds) {
				materialExample.setId(id);
				Material material = materialMapper.getMaterial(materialExample);
				
				Pictures picture = new Pictures();
				picture.setUrl(material.getUrl());
				picture.setName(material.getName());
				picture.setLogo(Integer.valueOf(SysEnum.COMMON_BOOL_NO.getCode()));
				picture.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
				picture.setRelatedId(scenicCommercial.getId());
				picture.setCategoryType(material.getType());
				picture.setCreateTime(now);
				picture.setCreateUser(user.getId());
				pictures.add(picture);
			}
			return picturesMapper.saveBatchPictures(pictures);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	

}
