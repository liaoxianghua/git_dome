/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 */
package com.spring.scenic.busi.intreface.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.application.BusiNoticeService;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiNotice;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.system.domain.AuthUser;

/**
 * 此处为类说明：商户中心controller层
 * @author ranmaoping
 * @date 2017年3月22日
 */
@Controller
@RequestMapping("busi/busiNotice")
public class BusiNoticeController {

    @Autowired
    private BusiNoticeService busiNoticeService;
    @Autowired
    private BusiSellerService busiSellerService;

    /**
     * 
     * 此处为类方法说明:进入商户中心公告页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiNoticeList", method = RequestMethod.GET)
    public String busiNoticeList(HttpServletRequest request, HttpServletResponse response) {
        return "busi/busiNotice/busiNoticeList";
    }

    /**
     * 
     * 此处为类方法说明:查询商户信息列表
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "getBusiNoticeList", method = RequestMethod.POST)
    public EntityData getBusiNoticeList(HttpServletRequest request, HttpServletResponse response, BusiNotice busiNotice) {
        busiNotice.initDataTableParam(request);
        List<BusiNotice> list = busiNoticeService.getBusiNoticeList(busiNotice, SysConstant.PAGE_TRUE);
        PageInfo<BusiNotice> page = new PageInfo<BusiNotice>(list);
        EntityData data = new EntityData(busiNotice, page);
        return data;
    }

    /**
     * 
     * 此处为类方法说明:进入商户新增页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiNoticeAdd", method = RequestMethod.GET)
    public String busiNoticeAdd(HttpServletRequest request, HttpServletResponse response, BusiNotice busiNotice) {
        request.setAttribute("operate", "new");
        return "busi/busiNotice/busiNoticeEdit";
    }

    /**
     * 
     * 此处为类方法说明：进入商户编辑页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiNoticeUpdate", method = RequestMethod.GET)
    public String busiNoticeUpdate(HttpServletRequest request, HttpServletResponse response, BusiNotice busiNotice) {
        if (null != busiNotice.getId()) {
            BusiNotice busiNoticeInfo = busiNoticeService.getBusiNoticeById(busiNotice);
            request.setAttribute("busiNoticeInfo", busiNoticeInfo);
            request.setAttribute("operate", "edit");
        }
        return "busi/busiNotice/busiNoticeEdit";
    }

    /**
     * 
     * 此处为类方法说明：更新商户状态
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "updateBusiNoticeStatus", method = RequestMethod.POST)
    public MessageData updateBusiNoticeStatus(HttpServletRequest request, HttpServletResponse response,
        BusiNotice busiNotice) {
        AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if (null != userInfo) {
            this.busiNoticeService.updateBusiNoticeStatus(userInfo, busiNotice);
        }
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false,
                null, "", null);
    }
    
    /**
     * 
     * 此处为类方法说明:置顶公告
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月24日     
     * @memo ：   
     **
     */
    @ResponseBody
    @RequestMapping(value = "updateBusiNoticeToTop", method = RequestMethod.POST)
    public MessageData updateBusiNoticeToTop(HttpServletRequest request, HttpServletResponse response,
        BusiNotice busiNotice) {
        AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if (null != userInfo) {
            this.busiNoticeService.updateBusiNoticeToTop(userInfo, busiNotice);
            return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
        }
        return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
    }

    @ResponseBody
    @RequestMapping(value = "saveNoticeInfo", method = RequestMethod.POST)
    public MessageData saveNoticeInfo(HttpServletRequest request,BusiNotice busiNotice, String key) {
        AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
        MessageData messageData = busiNoticeService.saveBusiNotice(user, filesMap, key,busiNotice);
        return messageData;
     
    }    
    
    @RequestMapping(value = "noticeAttachDownload", method = RequestMethod.GET)
    public void noticeAttachDownload(HttpServletResponse response, BusiNotice busiNotice) {
        busiNoticeService.noticeAttachDownload(response, busiNotice);
    }


}
