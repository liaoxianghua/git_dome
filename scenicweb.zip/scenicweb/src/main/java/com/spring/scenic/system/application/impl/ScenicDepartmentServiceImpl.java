package com.spring.scenic.system.application.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.application.ScenicDepartmentService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.ScenicDepartment;
import com.spring.scenic.system.infrastructure.ScenicDepartmentMapper;

@Service
public class ScenicDepartmentServiceImpl implements ScenicDepartmentService {

	@Resource
	private ScenicDepartmentMapper scenicDepartmentMapper;


	public int updateByPrimaryKey(ScenicDepartment scenicDepartment) {
		try {
			return scenicDepartmentMapper.updateByPrimaryKey(scenicDepartment);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public ScenicDepartment selectByPrimaryKey(Integer id) {
		try {
			return scenicDepartmentMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int updateByPrimaryKey(ScenicDepartment scenicDepartment,
			AuthUser user) {
		try {
			scenicDepartment.setUpdateUser(user.getId());
			return scenicDepartmentMapper.updateByPrimaryKey(scenicDepartment);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateForbiddenOrUseData(ScenicDepartment scenicDepartment,
			AuthUser userInfo) {
		try {
			scenicDepartment.setUpdateUser(userInfo.getId());
			scenicDepartmentMapper.forbiddenOrUseData(scenicDepartment);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	@Override
	public List<ScenicDepartment> queryScenicDepartmentList(
			ScenicDepartment scenicDepartment, boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(scenicDepartment.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<ScenicDepartment> resultList = scenicDepartmentMapper.selectScenicDepartmentForManager(scenicDepartment);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void addScenicDept(ScenicDepartment scenicDepartment, AuthUser userInfo) {
		try {
			scenicDepartment.setCreateUser(userInfo.getId());
			scenicDepartmentMapper.insert(scenicDepartment);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void deleteByPrimaryKey(Integer id) {
		try {
			scenicDepartmentMapper.deleteByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}		
	}


}
