/**
 * 
 */
package com.spring.scenic.member.application;

import java.util.List;

import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.system.domain.AuthUser;

/**	@Description：会员管理常用出行人接口实现类
 *  @author：ranmaoping
 *  @date:下午3:12:58 2017年1月17日
 *  @version:1.0
 *
 */
public interface MemberDetailInfoService {

	/**
	 * 
	 *@Description:查询常用出行人
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	List<MemberDetailInfo> queryCommonTripManList(MemberBasic member);

	/**
	 * 新增常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	void addMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo);

	/**
	 * 修改常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月20日
	 */
	void updateMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo);
	/**
	 * 查询常用出行人信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月22日
	 */
	MemberDetailInfo updateMemberCommonTripMan(MemberDetailInfo memberDetailInfo);
	/**
	 * 删除常用出行人
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月22日
	 */
	void deleteInfo(MemberDetailInfo memberDetailInfo);


}
