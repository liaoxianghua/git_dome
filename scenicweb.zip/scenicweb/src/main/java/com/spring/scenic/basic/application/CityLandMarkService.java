package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.CityLandMark;

public interface CityLandMarkService {

	/**
	 * @param cityLandMark
	 * @return
	 */
	public List<CityLandMark> getCityLandMarkList(CityLandMark cityLandMark);

	/**
	 * @param cityLandMark
	 * @return
	 */
	public CityLandMark getCityLandMarkInfoById(CityLandMark cityLandMark);

	/**
	 * @param cityLandMark
	 * @return 
	 */
	public Integer saveCityLandMark(CityLandMark cityLandMark);

	/**
	 * @param cityLandMark
	 * @return
	 */
	public CityLandMark getPositionList(CityLandMark cityLandMark);

	/**
	 * @param cityLandMark
	 * @return
	 */
	public CityLandMark getPositionInfoById(CityLandMark cityLandMark);

	/**
	 * @param cityLandMark
	 */
	public void saveCityLandMark1(CityLandMark cityLandMark);

	/**
	 * @param clmDto
	 */
	public void updateCityLandMarkStatus(CityLandMark clmDto);

}
