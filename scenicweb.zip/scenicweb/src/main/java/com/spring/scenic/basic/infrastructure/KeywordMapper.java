package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.basic.domain.KeywordRef;

public interface KeywordMapper {
	
	
    int insert(Keyword record);

    int insertSelective(Keyword record);

    Keyword selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Keyword record);

    int updateByPrimaryKey(Keyword record);

	List<Keyword> queryKeywordList(Keyword keyword);

	void updateKeywordById(Keyword keyword);

	List<Keyword> selectKeywordList(Keyword keyword);

	int addTravelNoteKeyword(KeywordRef keywordRef);

	int getTravelKeywordRef(KeywordRef keywordRef);

	List<Keyword> selectByTravelNoteKeywordList(KeywordRef keywordRef);

	void delTravelNoteKeyword(Keyword keyword);

	List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword);

	int getSysConfigKeywordCount(KeywordRef keywordRef);

    List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef);

    void deleteSysConfigKeyword(KeywordRef keywordRef);

    void updateSysConfigKeywordOrder(List<KeywordRef> list);

    int getCurrentKeywordIdCount(KeywordRef keywordRef);

    int getkeywordTypeByid(Keyword keyword);

    int selectKeyNameCountByParam(Keyword keyword);

}