package com.spring.scenic.basic.intreface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.ScenicCommercialService;
import com.spring.scenic.basic.domain.ScenicCommercial;
import com.spring.scenic.basic.domain.ScenicCommercialApprove;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.material.domain.Pictures;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;
/**
 * 基础信息景区商户管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "basic/scenicCommercial")
public class ScenicCommercialController {
	@Autowired
	private ScenicCommercialService scenicCommercialService;
	
	/**
	 * 
	  * @Description: 景区商户管理页面跳转
	  * @param @return
	  * @return String
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:04
	 */
	@RequestMapping(value = "scenicCommercialManage")
	public String scenicCommercialManage() {
		return "/basic/scenicCommercial/scenicCommercialManageMain";
	}
	/**
	 * 编辑
	 * @param request
	 * @param response
	 * @param scenicCommercial
	 * @return
	 */
	@RequestMapping(value = "scenicCommercialManageEdit")
	public String scenicCommercialManageEdit(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) {
		if (scenicCommercial.getId()!= null &&! "".equals(scenicCommercial.getId())) {
			ScenicCommercial scenicVo =  scenicCommercialService.selectByPrimaryKey(scenicCommercial.getId());
			request.setAttribute("scenicVo", scenicVo);
		}
		return "/basic/scenicCommercial/scenicCommercialManageEdit";
	}
	/**
	 * 详情页面编辑
	 * @param request
	 * @param response
	 * @param scenicCommercial
	 * @return
	 */
	@RequestMapping(value = "scenicCommercialDetailEdit")
	public String scenicCommercialDetailEdit(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) {
		if (scenicCommercial.getId()!= null) {
			ScenicCommercial scenicVo =  scenicCommercialService.getScenicCommercial(scenicCommercial);
			scenicVo.setFullAddress((scenicVo.getCityName()==null?"":scenicVo.getCityName()+"  ") + (scenicVo.getCityAreaName()==null?"":scenicVo.getCityAreaName()+"  ") +(scenicVo.getAddress()==null?"":scenicVo.getAddress()));
			scenicVo.setFullTypeName(
					ApplicationContentUtil.getCachedDictionary(SysEnum.MAIN_TYPE.getCode(),scenicVo.getType()).getName()+"/"+
							ApplicationContentUtil.getCachedDictionary((scenicVo.getType().equals("1")?SysEnum.MAIN_TYPE.getCode():SysEnum.MAIN_TYPE.getCode()),scenicVo.getType()).getName()
							);
			request.setAttribute("scenicVo", scenicVo);
		}
		return "/basic/scenicCommercial/scenicCommercialDetailEdit";
	}
		
	
	@RequestMapping(value = "scenicCommercialApprove")
	public String directScenicCommercialApprove() {
		return "/baseinfo/scenicCommercialApprove";
	}
	
	/**
	 * 
	  * @Description: 支持批量删除,以逗号分隔
	  * @param @param id
	  * @param @return
	  * @return RespBody
	  * @author 李cm
	  * @date 2016-12-14 下午2:24:01
	 */
	@RequestMapping(value = "del",method=RequestMethod.POST)
	@ResponseBody
	public MessageData deleteScenicCommercial(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial){
		String[] ids = String.valueOf(scenicCommercial.getId()).split(",");
		for(String str : ids){
			scenicCommercialService.deleteByPrimaryKey(Integer.parseInt(str));
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 
	  * @Description: 景区商户管理信息详情
	  * @param @param 
	  * @param @param dataGrid
	  * @param @return
	  * @return DataGridResponse
	  * @author 李cm
	  * @date 2016-12-16 上午11:53:22
	 */
	@RequestMapping(value = "queryScenicCommercial",method=RequestMethod.POST)
	@ResponseBody
	public EntityData queryScenicCommercial(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) {
		scenicCommercial.initDataTableParam(request);
		List<ScenicCommercial> list = scenicCommercialService.queryScenicCommercial(scenicCommercial, SysConstant.PAGE_FALSE);
		PageInfo<ScenicCommercial> page = new PageInfo<ScenicCommercial>(list);
		EntityData data = new EntityData(scenicCommercial,page);
		return data;
	}
	
	/**
	 * 新增修改数据
	 * @param scenicCommercialDTO
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "operateScenicCommercial",method=RequestMethod.POST)
	public  MessageData operateScenicCommercial(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial,String coversImageFile) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (scenicCommercial.getId() == null) {
			scenicCommercialService.addScenicCommercial(scenicCommercial,userInfo);
		}else {
			Map<String, List<MultipartFile>> filesMap = null;
			if (StringUtil.isNotEmpty(coversImageFile)) {
				MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
				filesMap = multipartRequest.getMultiFileMap();
			}
			scenicCommercialService.updateByPrimaryKey(scenicCommercial, userInfo,filesMap,coversImageFile);
			ScenicCommercial resultsCommercial = scenicCommercialService.selectByPrimaryKey(scenicCommercial.getId());
			request.setAttribute("scenicVo", resultsCommercial);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 禁用或启用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData",method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysConstant.IS_FORBIDDEN_FLAG_NO.equals(scenicCommercial.getFlag())) {//0禁用
			scenicCommercial.setValid(Integer.valueOf(SysConstant.VALITY_NO));
		}else {//1启用
			scenicCommercial.setValid(Integer.valueOf(SysConstant.VALITY_YES));
		}
		if (scenicCommercial.getParentStrId()==null || StringUtil.isEmpty(scenicCommercial.getParentStrId())) {//禁用父部门及其子部门
			scenicCommercialService.updateForbiddenItemScenic(scenicCommercial,userInfo);
		}else {
			scenicCommercialService.updateValid(scenicCommercial,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	@RequestMapping(value = "addCommercialMapInfo")
	@ResponseBody
	public MessageData  addCommercialMapInfo(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 更新商户信息
	 * @param request
	 * @param response
	 * @param scenicCommercial
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "updateCommercialInfo",method=RequestMethod.POST)
	@ResponseBody
	public MessageData  updateCommercialInfo(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		scenicCommercialService.updateCommercialInfo(scenicCommercial,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 认证商户
	 * @param request
	 * @param response
	 * @param scenicCommercial
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "scenicCommercialAttest",method=RequestMethod.POST)
	@ResponseBody
	public MessageData  scenicCommercialAttest(HttpServletRequest request, HttpServletResponse response,ScenicCommercialApprove commercialApprove) throws Exception {
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (commercialApprove.getId() == null || "".equals(commercialApprove.getId())) {//如果为空则新增
			if ("Y".equals(commercialApprove.getIsEnterCommercial())) {
				//如果是入驻商户则生成组织架构
				scenicCommercialService.addScenicCommercialAttest(commercialApprove,userInfo);
			}else {
				scenicCommercialService.addScenicCommercialAttest(commercialApprove,userInfo);
			}
			
		}else {//修改
			if ("Y".equals(commercialApprove.getIsEnterCommercial())) {
				//修改组织架构的入驻商户
				scenicCommercialService.updateScenicCommercialAttest(commercialApprove,userInfo);
			}else {
				scenicCommercialService.updateScenicCommercialAttest(commercialApprove,userInfo);
			}
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 加载景区商户具体类别下拉数据
	 * @param request
	 * @param response
	 * @param commercialApprove
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "initScenicSelectOption",method=RequestMethod.POST)
	public List<Dictionary>  initScenicSelectOption(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		ScenicCommercial scenicVo = new ScenicCommercial();
		ScenicCommercial sellerVo = new ScenicCommercial();
		List<Dictionary> resultList = new ArrayList<Dictionary>();
		scenicVo.setType("SCENIC_TYPE");
		sellerVo.setType("SELLER_TYPE");
		Integer typeId1 = scenicCommercialService.getIdByScenicType(scenicVo);//查询类型为景区的字典id
		Integer typeId2 = scenicCommercialService.getIdByScenicType(sellerVo);//查询类型为商户的字典id
		
		if ("1".equals(scenicCommercial.getType())) {
			List<Dictionary> temlisDictionaries = scenicCommercialService.initScenicSelectOption(typeId1);
			return temlisDictionaries;
		}else if ("2".equals(scenicCommercial.getType())) {
			return scenicCommercialService.initScenicSelectOption(typeId2);
		}else {
			List<Dictionary> scenicList = scenicCommercialService.initScenicSelectOption(typeId1);
			List<Dictionary> sellerList = scenicCommercialService.initScenicSelectOption(typeId2);
			if (scenicList != null) {
				resultList.addAll(scenicList);
			}
			if (sellerList != null) {
				resultList.addAll(sellerList);
			}
			return resultList;
		}
	}
	
	/**
	 * 加载景区上级商户下拉数据
	 * @param request
	 * @param response
	 * @param commercialApprove
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "initScenicParentOptions",method=RequestMethod.POST)
	@ResponseBody
	public List<ScenicCommercial>  initScenicParentOptions(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		List<ScenicCommercial> resultVo = scenicCommercialService.initScenicParentOptions(scenicCommercial);
		return resultVo;
	}
	
	/**
	 * 加载城市下拉数据
	 * @param request
	 * @param response
	 * @param commercialApprove
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "initScenicCityOptions",method=RequestMethod.POST)
	@ResponseBody
	public List<ScenicCommercial>  initScenicCityOptions(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		List<ScenicCommercial> resultVo = scenicCommercialService.initScenicCityOptions(scenicCommercial);
		return resultVo;
	}
	
	/**
	 * 加载城市地区下拉数据
	 * @param request
	 * @param response
	 * @param commercialApprove
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "initScenicCityAreaOptions",method=RequestMethod.POST)
	@ResponseBody
	public List<ScenicCommercial>  initScenicCityAreaOptions(HttpServletRequest request, HttpServletResponse response,ScenicCommercial scenicCommercial) throws Exception {
		List<ScenicCommercial> resultVo = scenicCommercialService.initScenicCityAreaOptions(scenicCommercial);
		return resultVo;
	}

	/**
	 * @Description 景区、商户上部信息修改
	 * @param request
	 * @param scenicCommercial
	 * @param scenicCommercialCoversImage 附件绑定值
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月8日
	 */
	@ResponseBody
	@RequestMapping(value="updatScenicCommercial",method=RequestMethod.POST)
	public MessageData updatScenicCommercial(HttpServletRequest request,ScenicCommercial scenicCommercial,String scenicCommercialCoversImage){
		if(scenicCommercial.getId()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
			Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
			scenicCommercialService.updatScenicCommercial(user,scenicCommercial,scenicCommercialCoversImage,filesMap);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
	}
	
	/**
	 * @Description 保存景区、商户下部-tab页信息
	 * @param request
	 * @param scenicCommercial
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value="updatScenicCommercialBasic",method=RequestMethod.POST)
	public MessageData updatScenicCommercialBasic(HttpServletRequest request,ScenicCommercial scenicCommercial){
		if(scenicCommercial.getId()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			scenicCommercialService.updatScenicCommercialBasic(user,scenicCommercial);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE);
		}
	}
	
	/**
	 * @Description 保存景区、商户下部-tab页图片分页
	 * @param request
	 * @param response
	 * @param picture
	 * @throws Exception
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value = "getScenicCommercialPhotoList",method=RequestMethod.POST)
	public EntityData getScenicCommercialPhotoList(HttpServletRequest request, HttpServletResponse response,Pictures picture) throws Exception {
		picture.initDataTableParam(request);
		List<Pictures> pictures = scenicCommercialService.getScenicCommercialPhotoList(picture,SysConstant.PAGE_TRUE);
		PageInfo<Pictures> page = new PageInfo<Pictures>(pictures);
		EntityData data = new EntityData(picture,page);
		return data;
	}
	
	/**
	 * @Description 设为logo、取消logo
	 * @param request
	 * @param picture
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value="savePictureLogo",method=RequestMethod.POST)
	public MessageData savePictureLogo(HttpServletRequest request,Pictures picture){
		if(picture.getId()!=null && picture.getRelatedId()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			Pictures logoPic = scenicCommercialService.savePictureLogo(user,picture);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, logoPic.getUrl());
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE);
		}
	}
	
	/**
	 * @Description 删除图片
	 * @param request
	 * @param picture
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value="deletePicture",method=RequestMethod.POST)
	public MessageData deletePicture(HttpServletRequest request,Pictures picture){
		if(picture.getId()!=null){
			scenicCommercialService.deletePicture(picture);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE);
		}
	}
	
	/**
	 * @Description 弹出选择图片的窗口
	 * @param request
	 * @param picture
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月10日
	 */
	@RequestMapping(value = "scenicCommercialPictureChose")
	public String scenicCommercialPictureChose(HttpServletRequest request,Pictures picture) {
		return "/basic/scenicCommercial/scenicCommercialPictureChose";
	}
	
	/**
	 * @Description 保存选择图片数据
	 * @param request
	 * @param picture
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月10日
	 */
	@ResponseBody
	@RequestMapping(value="saveScenicCommercialPicture",method=RequestMethod.POST)
	public MessageData saveScenicCommercialPicture(HttpServletRequest request,ScenicCommercial scenicCommercial,@RequestParam("materialIds[]") Integer materialIds[]){
		if(scenicCommercial.getId()!=null&&materialIds.length>0){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			scenicCommercialService.saveScenicCommercialPictures(user,scenicCommercial,materialIds);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE);
		}
	}
	/**
	 * 查询景区商户详情
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月15日
	 */
	@ResponseBody
	@RequestMapping(value="selectScenicDetailsById",method=RequestMethod.POST)
	public ScenicCommercial selectScenicDetailsById(HttpServletRequest request,ScenicCommercial scenicCommercial){
			ScenicCommercial scenicVo =  scenicCommercialService.getScenicCommercial(scenicCommercial);
			scenicVo.setFullAddress((scenicVo.getCityName()==null?"":scenicVo.getCityName()+"  ") + (scenicVo.getCityAreaName()==null?"":scenicVo.getCityAreaName()+"  ") +(scenicVo.getAddress()==null?"":scenicVo.getAddress()));
			scenicVo.setFullTypeName(
					ApplicationContentUtil.getCachedDictionary(SysEnum.MAIN_TYPE.getCode(),scenicVo.getType()).getName()+"/"+
							ApplicationContentUtil.getCachedDictionary((scenicVo.getType().equals("1")?SysEnum.MAIN_TYPE.getCode():SysEnum.MAIN_TYPE.getCode()),scenicVo.getType()).getName()
							);
			return scenicVo;
	}
	
	
	
}
