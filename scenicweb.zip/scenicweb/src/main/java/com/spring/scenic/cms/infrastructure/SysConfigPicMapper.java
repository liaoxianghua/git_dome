package com.spring.scenic.cms.infrastructure;

import java.util.List;

import com.spring.scenic.cms.domain.SysConfigPic;

public interface SysConfigPicMapper {
   
    int deleteByPrimaryKey(Integer id);

    int insert(SysConfigPic record);

    int insertSelective(SysConfigPic record);

    SysConfigPic selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SysConfigPic record);

    int updateByPrimaryKey(SysConfigPic record);

	List<SysConfigPic> getSysConfigPic(SysConfigPic sysConfigPic);

	void addsysConfigPic(SysConfigPic sysConfigPic);

	SysConfigPic getSysConfigPicInfoById(SysConfigPic sysConfigPic);

	void updateSysConfigPic(SysConfigPic sysConfigPicExample);

	void deleteSysConfigPic(SysConfigPic sysConfigPic);
}