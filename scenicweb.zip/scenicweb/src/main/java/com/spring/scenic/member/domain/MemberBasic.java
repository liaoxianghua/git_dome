package com.spring.scenic.member.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class MemberBasic extends Entity<MemberBasic> {
    private Integer id;

    private String memberAccount;

    private String password;

    private String imageUrl;

    private Short careerType;

    private Short educateType;

    private Short activatedFlg;

    private String memberFrom;

    private Short valid;

    private Date loginTime;

    private Short loginFrom;

    private Date lastLoginTime;

    private String loginIp;

    private String guid;

    private String memberLevel;

    private String activityDegree;

    private BigDecimal growthValue;

    private Date growthDate;

    private Integer createUser;

    private Date createTime;

    private Integer updateUser;

    private Date updateTime;
    
    private MemberDetailInfo memberDetail;
    
    private List<MemberSharedAccount> memberSharedAccountList;
    
    private String nameCh;
    
    private String phoneCh;
    
    private Integer type;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount == null ? null : memberAccount.trim();
    }

    public String getPassword() {
        return password;
    }
   
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? null : imageUrl.trim();
    }

    public Short getCareerType() {
        return careerType;
    }

    public void setCareerType(Short careerType) {
        this.careerType = careerType;
    }

    public Short getEducateType() {
        return educateType;
    }

    public void setEducateType(Short educateType) {
        this.educateType = educateType;
    }

    public Short getActivatedFlg() {
        return activatedFlg;
    }

    public void setActivatedFlg(Short activatedFlg) {
        this.activatedFlg = activatedFlg;
    }

    public String getMemberFrom() {
        return memberFrom;
    }

    public void setMemberFrom(String memberFrom) {
        this.memberFrom = memberFrom == null ? null : memberFrom.trim();
    }

    public Short getValid() {
        return valid;
    }

    public void setValid(Short valid) {
        this.valid = valid;
    }

    public Date getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }

    public Short getLoginFrom() {
        return loginFrom;
    }

  
    public void setLoginFrom(Short loginFrom) {
        this.loginFrom = loginFrom;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }
   
    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp == null ? null : loginIp.trim();
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid == null ? null : guid.trim();
    }

    public String getMemberLevel() {
        return memberLevel;
    }

    public void setMemberLevel(String memberLevel) {
        this.memberLevel = memberLevel == null ? null : memberLevel.trim();
    }

    public String getActivityDegree() {
        return activityDegree;
    }

    public void setActivityDegree(String activityDegree) {
        this.activityDegree = activityDegree == null ? null : activityDegree.trim();
    }

    public BigDecimal getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(BigDecimal growthValue) {
        this.growthValue = growthValue;
    }

    public Date getGrowthDate() {
        return growthDate;
    }

    public void setGrowthDate(Date growthDate) {
        this.growthDate = growthDate;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

	public String getNameCh() {
		return nameCh;
	}

	public void setNameCh(String nameCh) {
		this.nameCh = nameCh;
	}

	public String getPhoneCh() {
		return phoneCh;
	}

	public void setPhoneCh(String phoneCh) {
		this.phoneCh = phoneCh;
	}

	public MemberDetailInfo getMemberDetail() {
		return memberDetail;
	}

	public void setMemberDetail(MemberDetailInfo memberDetail) {
		this.memberDetail = memberDetail;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

    public List<MemberSharedAccount> getMemberSharedAccountList() {
        return memberSharedAccountList;
    }

    public void setMemberSharedAccountList(List<MemberSharedAccount> memberSharedAccountList) {
        this.memberSharedAccountList = memberSharedAccountList;
    }
    
}