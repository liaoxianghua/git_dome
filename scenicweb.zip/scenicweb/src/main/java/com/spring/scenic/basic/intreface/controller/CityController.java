package com.spring.scenic.basic.intreface.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.CityService;
import com.spring.scenic.basic.domain.City;
import com.spring.scenic.basic.domain.CityArea;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;

@Controller
@RequestMapping("basic/city")
public class CityController {
	@Autowired
	private CityService cityService;
	
	
	/**
	 * 加载城市管理页面
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="cityPage",method=RequestMethod.GET)
	public String cityManage(HttpServletRequest request,HttpServletResponse response){
		return "basic/city/cityList";
	}
	/**
	 * 加载区域管理页面
	 * @param request
	 * @param response
	 * @param city
	 * @return
	 */
	@RequestMapping(value="cityAreaPage",method=RequestMethod.GET)
	public String cityAreaManage(HttpServletRequest request,HttpServletResponse response,City city){
		City dto = cityService.getCityInfoById(city);
		CityArea cityArea = new CityArea();
		cityArea.setCityId(city.getId());
		//cityArea.setCityName(city.getName());
		cityArea.setCityName(dto.getName());
		request.setAttribute("cityArea", cityArea);
		return "basic/city/cityAreaList";
	}
	/**
	 * @Description: 进入城市信息分页界面
	 * @param request
	 * @param response
	 * @param city
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="cityInfoList",method=RequestMethod.POST)
	public EntityData cityInfoList(HttpServletRequest request,HttpServletResponse response,City city){
		city.initDataTableParam(request);
		List<City> list = cityService.getCityList(city);
		PageInfo<City> page = new PageInfo<City>(list);
		EntityData data = new EntityData(city,page);
		return data;
	}
	/**
	 * @Description: 进入城市区域信息分页界面
	 * @param request
	 * @param response
	 * @param cityArea
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="cityAreaInfoList",method=RequestMethod.POST)
	public EntityData cityAreaInfoList(HttpServletRequest request,HttpServletResponse response,CityArea cityArea){
		cityArea.initDataTableParam(request);
		List<CityArea> list = cityService.getCityAreaList(cityArea,SysConstant.PAGE_FALSE);
		PageInfo<CityArea> page = new PageInfo<CityArea>(list);
		EntityData data = new EntityData(cityArea,page);
		return data;
	}
	
	/**
	 * @Description: 进入城市新增界面
	 * @param request
	 * @param response
	 * @param city
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityAdd",method=RequestMethod.GET)
	public String cityAdd(HttpServletRequest request,HttpServletResponse response,City city){
		request.setAttribute("operate", "new");
		return "basic/city/cityEdit";
	}
	
	/**
	 * @Description: 进入城市区域新增界面
	 * @param request
	 * @param response
	 * @param city
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityAreaAdd",method=RequestMethod.GET)
	public String cityAdd(HttpServletRequest request,HttpServletResponse response,CityArea cityArea){
		request.setAttribute("cityAreaInfo",cityArea);
		request.setAttribute("operate", "new");
		return "basic/city/cityAreaEdit";
	}
	
	/**
	 * @Description: 进入城市名称修改界面、初始化城市名称信息
	 * @param request
	 * @param response
	 * @param city
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityUpdate",method=RequestMethod.GET)
	public String cityUpdate(HttpServletRequest request,HttpServletResponse response,City city){
		if(city.getId()!=null){
			City dto = cityService.getCityInfoById(city);
			request.setAttribute("cityInfo", dto);
			request.setAttribute("operate", "edit");
		}
		return "basic/city/cityEdit";
	}
	
	/**
	 * @Description: 进入城市区域修改界面、初始化区域信息
	 * @param request
	 * @param response
	 * @param city
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityAreaUpdate",method=RequestMethod.GET)
	public String cityAreaUpdate(HttpServletRequest request,HttpServletResponse response,CityArea cityArea){
		if(cityArea.getId()!=null){
			CityArea dto = cityService.getCityAreaInfoById(cityArea);
			request.setAttribute("cityAreaInfo", dto);
			request.setAttribute("operate", "edit");
		}
		return "basic/city/cityAreaEdit";
	}
	/**
	 * @Description: 保存城市基本信息
	 * @param request
	 * @param response
	 * @param city
	 * @return MessageData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="saveCity",method=RequestMethod.POST)
	public MessageData saveCity(HttpServletRequest request,HttpServletResponse response,City city){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		city.setCreateDate(new Date());
		city.setCreateUser(userInfo.getId());
		this.cityService.saveCity(city);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	/**
	 * @Description: 保存城市区域基本信息
	 * @param request
	 * @param response
	 * @param city
	 * @return MessageData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="saveCityArea",method=RequestMethod.POST)
	public MessageData saveCityArea(HttpServletRequest request,HttpServletResponse response,CityArea cityArea){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		cityArea.setCreateTime(new Date());
		cityArea.setCreateUser(userInfo.getId());
		this.cityService.saveCityArea(cityArea);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 更改城市的状态
	 * @param id
	 * @return
	 */
	@RequestMapping(value ="updateCityStatus",method=RequestMethod.POST)
	@ResponseBody
	public MessageData updateCityStatus(HttpServletRequest request,
			@RequestParam(value="id") Integer id,@RequestParam(value="status") Integer status){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		City city = new City();
		city.setId(id);
		city.setStatus(status);
		city.setUpdateDate(new Date());
		city.setUpdateUser(userInfo.getId());
		//cityMapper.deleteByPrimaryKey(id);
		cityService.updateCityStatus(city);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
	/**
	 * 更改城市区域的状态
	 * @param id
	 * @return
	 */
	@RequestMapping(value ="/updateCityAreaStatus",method=RequestMethod.POST)
	@ResponseBody
	public MessageData updateCityAreaStatus(HttpServletRequest request,
			@RequestParam(value="id") Integer id,@RequestParam(value="valid") Integer valid){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		CityArea cityArea = new CityArea();
		cityArea.setId(id);
		cityArea.setValid(valid);
		cityArea.setUpdateTime(new Date());
		cityArea.setUpdateUser(userInfo.getId());
		//cityMapper.deleteByPrimaryKey(id);
		cityService.updateCityAreaStatus(cityArea);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	/**
	 * 获取国家下拉框的值
	 * @return
	 */
	/*@RequestMapping(value= "countryList",method=RequestMethod.POST)
	@ResponseBody
	public List<City> getCountryList() {
		List<City> list  = cityMapper.getCountryList();
		return list;
	}*/
	
	/**
	 * 获取城市下拉框的值
	 * @return
	 */
/*	@RequestMapping(value= "provincelist",method=RequestMethod.POST)
	@ResponseBody
	public List<City> getProvinceList(@RequestParam(value="id") String id) {
		Integer countryId = Integer.parseInt(id);
		List<City> list  = cityMapper.getProvinceList(countryId);
		return list;
	}*/
	
	/**
	 * 获取所属行政区下拉框的值
	 */
	@RequestMapping(value= "cantonList",method=RequestMethod.POST)
	@ResponseBody
	public List<CityArea> getCantonList(CityArea cityArea) {
		List<CityArea> list  = cityService.getCantonList(cityArea);
		return list;
	}
	/**
	 * 获得城市根据国家或者省份（公共方法）
	 * @param city
	 * @return
	 */
	@RequestMapping(value= "getCityByCountryOrProvince",method=RequestMethod.POST)
	@ResponseBody
	public List<City> getCityByCountryOrProvince(City city) {
		List<City> list  = cityService.getCityByCountryOrProvince(city);
		return list;
	}
}
