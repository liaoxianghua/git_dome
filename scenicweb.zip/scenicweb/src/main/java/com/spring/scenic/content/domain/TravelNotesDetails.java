package com.spring.scenic.content.domain;

import java.util.Date;

/**
 * @Description 游记攻略详情
 * @author 006568（shuchang）
 * @date 2016年12月22日
 */
public class TravelNotesDetails {
	
    /**
     * 主键
     */
    private Integer id;

    /**
     * 图片、视频、音频等链接地址
     */
    private String url;
    
    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 1:文字 ;2:(2:图片 3:语音 4:视频 );5:段落标题
     */
    private Integer type;

    /**
     * 段落标题
     */
    private String title;

    /**
     * 游记、攻略外键
     */
    private Integer travelNotesId;

    /**
     */
    private String guid;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private Integer updateUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 文字
     */
    private String words;
    
    /**
     * 文字 图片 语音 视频 段落标题 的排序字段
     */
    private Integer sortIndex;
    
    /**
     * 虚拟字段:附件绑定的key
     */
    private String fileBindKey;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getTravelNotesId() {
		return travelNotesId;
	}

	public void setTravelNotesId(Integer travelNotesId) {
		this.travelNotesId = travelNotesId;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getWords() {
		return words;
	}

	public void setWords(String words) {
		this.words = words;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getSortIndex() {
		return sortIndex;
	}

	public void setSortIndex(Integer sortIndex) {
		this.sortIndex = sortIndex;
	}

	public String getFileBindKey() {
		return fileBindKey;
	}

	public void setFileBindKey(String fileBindKey) {
		this.fileBindKey = fileBindKey;
	}

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
	
}