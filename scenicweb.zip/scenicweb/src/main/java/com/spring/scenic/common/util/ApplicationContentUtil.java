package com.spring.scenic.common.util;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.system.domain.Dictionary;
 
/**
 * @Description 系统上下文工具类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public class ApplicationContentUtil implements ApplicationContextAware {
	public static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)throws BeansException {
		if(ApplicationContentUtil.applicationContext==null){
			ApplicationContentUtil.applicationContext=applicationContext;
		}
	}

	public static ApplicationContext getApplicationContext(){
		return ApplicationContentUtil.applicationContext;
	}
	
	public static Object getBean(String beanName){
		return ApplicationContentUtil.applicationContext.getBean(beanName);
	}

	public static HttpServletRequest getHttpServletRequest (){
		return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	}
	
	public static HttpSession getHttpSession() {
		return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
	}

	/**
	 * 获取应用服务器物理路径
	 * @author shuchang
	 * @date 2016年8月22日
	 */
	public static String getServletContextRealPath (){
		return getHttpServletRequest().getServletContext().getRealPath("");
	}
	
	/**
	 * @Description 获得系统缓存的字典
	 * @param code
	 * @param value
	 * @return Dictionary
	 * @author 006568（shuchang）
	 * @date 2017年1月11日
	 */
	public static Dictionary getCachedDictionary(String code,String value){
		if(StringUtils.isBlank(code)||StringUtils.isBlank(value)){
			return null;
		}
		HttpServletRequest httpServletRequest = getHttpServletRequest();
		@SuppressWarnings("unchecked")
		Map<String, List<Dictionary>>  cachedDicListMap = (Map<String, List<Dictionary>> ) httpServletRequest.getServletContext().getAttribute(SysConstant.SYS_DIC);
		if(cachedDicListMap.containsKey(code)){
			List<Dictionary> dics = cachedDicListMap.get(code);
			for (Dictionary dictionary : dics) {
				if(dictionary.getValue().equals(value)){
					return dictionary;
				}
			}
		}
		return null;
	}
	
}
