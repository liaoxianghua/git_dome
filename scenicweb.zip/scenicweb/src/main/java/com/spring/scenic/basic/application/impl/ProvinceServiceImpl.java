package com.spring.scenic.basic.application.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.application.ProvinceService;
import com.spring.scenic.basic.domain.Province;
import com.spring.scenic.basic.infrastructure.ProvinceMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

@Service("provinceService")
public class ProvinceServiceImpl implements ProvinceService {
	
	@Autowired
	private ProvinceMapper provinceMapper;
	/**查询省份信息
	 * @param province
	 * @return
	 */
	@Override
	public List<Province> getProvinceList(Province province,boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(province.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<Province> provinceList = provinceMapper.getProvinceInfoList(province);
			return provinceList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	/**
	 * @param province
	 * @return
	 */
	@Override
	public Province getProvinceInfoById(Province province) {
		try {
			Province dto = (Province) provinceMapper.getProvinceInfoById(province);
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	/**新增保存省份
	 * @param province
	 */
	@Override
	public void saveProvince(Province province) {
		validate(province);
		try {
			Integer valid =  Integer.valueOf(province.getValid());
			province.setStatus(valid);
			//校验省份名是否重复
			if(null==(province.getId())||"".equals(province.getId())){
				
				this.provinceMapper.addProvinceInfo(province); // 新增
			} else {
				this.provinceMapper.updateProvinceInfo(province); // 修改
			}
		} catch (Exception e) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}

	/**校验省份名是否重复
	 * @param province
	 */
	private void validate(Province province) {
		if(null!=province.getId()&&null==province.getCountryId()) {
			throw new BussinessException(new BussinessExceptionBean("exception.countryIsInvalid"));
		}
		int count = provinceMapper.getProvinceCount(province);
		if(count>0) {
			throw new BussinessException(new BussinessExceptionBean("exception.provinceNameIsExisted"));
		}
	}
	/**
	 * 启动或者禁用省份
	 */
	public void updateProvinceStatus(Province province) {
		try {
			provinceMapper.updateProvinceStatus(province);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);

		}
	}
	/**
	 * 查询国家信息，用于装填下拉框
	 */
	public List<Province> getCountryList() {
		try {
			List<Province> list = provinceMapper.getCountryList();
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**查询省份信息，用于装填下拉框
	 * @param countryId
	 * @return
	 */
	public List<Province> getProvinceList(Integer countryId) {
		try {
			Province dto = new Province();
			dto.setCountryId(countryId);
			List<Province> list = provinceMapper.getProvinceList(dto);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	public List<Province> getAllProvinceList() {
		try {
			List<Province> list = provinceMapper.getAllProvinceList();
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**查询城市信息，用于装填下拉框
	 * @return
	 */
	public List<Province> getCityList() {
		try {
			List<Province> list = provinceMapper.getCityList();
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	public List<Province> getCityListByIdParam(Province province) {
		try {
			List<Province> list = provinceMapper.getCityListByIdParam(province);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
}
