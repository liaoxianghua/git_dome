/**
 * 
 */
package com.spring.scenic.resource.intreface.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.resource.application.SuppliersService;
import com.spring.scenic.resource.domain.Suppliers;
import com.spring.scenic.resource.domain.SuppliersContract;
import com.spring.scenic.resource.domain.SuppliersLicense;
import com.spring.scenic.resource.domain.SuppliersProductType;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @description:供应商管理
 * @author：ranmaoping
 * @date:上午10:58:39 2016年11月2日
 * @version:1.0
 * 
 */
@Controller
@RequestMapping("resource/suppliers")
public class SuppliersController extends BaseController{

	@Autowired
	SuppliersService suppliersService;

	/**
	 * 加载供应商管理页面
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "suppliersPage", method = RequestMethod.GET)
	public String suppliersManage(HttpServletRequest request,
			HttpServletResponse response) {
		return "resource/suppliers/suppliersList";
	}

	/**
	 * @Description: 进入供应商信息分页界面
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月22日
	 */
	@ResponseBody
	@RequestMapping(value = "suppliersInfoList", method = RequestMethod.POST)
	public EntityData suppliersInfoList(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		suppliers.initDataTableParam(request);
		List<Suppliers> list = suppliersService.getSuppliersList(suppliers,
				SysConstant.PAGE_TRUE);
		PageInfo<Suppliers> page = new PageInfo<Suppliers>(list);
		EntityData data = new EntityData(suppliers, page);
		return data;
	}

	/**
	 * @Description: 进入供应商新增界面
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月22日
	 */
	@RequestMapping(value = "suppliersAdd", method = RequestMethod.GET)
	public String suppliersAdd(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		request.setAttribute("operate", "new");
		return "resource/suppliers/suppliersEdit";
	}

	/**
	 * @Description: 进入供应商名称修改界面、初始化供应商名称信息
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月22日
	 */
	@RequestMapping(value = "suppliersUpdate", method = RequestMethod.GET)
	public String suppliersUpdate(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		if (suppliers.getId() != null) {
			Suppliers dto = suppliersService.getSuppliersInfoById(suppliers);
			request.setAttribute("suppliersInfo", dto);
			request.setAttribute("operate", "edit");
		}
		return "resource/suppliers/suppliersEdit";
	}

	/**
	 * 保存供应商信息
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "saveSuppliers", method = RequestMethod.POST)
	public MessageData saveSuppliers(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(
				SysConstant.SESSION_USER);
		if (userInfo == null) {
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		this.suppliersService.saveSuppliers(userInfo, suppliers);
		return new MessageData(SysConstant.OPERATE_SUCCESS,
				SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,
				"", null);

	}

	/**
	 * 保存供应商信息
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "updateSuppliersStatus", method = RequestMethod.POST)
	public MessageData updateSuppliersStatus(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(
				SysConstant.SESSION_USER);
		if (userInfo == null) {
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		this.suppliersService.updateSuppliersStatus(userInfo, suppliers);
		return new MessageData(SysConstant.OPERATE_SUCCESS,
				SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,
				"", null);
	}

	/**
	 * 跳转到供应商产品信息页面
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@RequestMapping(value = "suppliersProductPage", method = RequestMethod.GET)
	public String suppliersProductPage(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		List<SuppliersProductType> productTypeList = suppliersService
				.getProductTypeList(suppliers);
		if(null==productTypeList||productTypeList.size()==0) {
			request.setAttribute("isNull","isNull");
		}
		request.setAttribute("productTypeList", productTypeList);
		return "resource/suppliers/suppliersProductEdit";
	}

	/**
	 * 保存供应商产品信息
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "saveSuppliersProduct", method = RequestMethod.POST)
	public MessageData saveSuppliersProduct(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (userInfo == null) {
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		this.suppliersService.saveSuppliersProduct(userInfo, suppliers);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
	}

	/**
	 * 跳转到供应商合同信息页面
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@RequestMapping(value = "suppliersContractPage", method = RequestMethod.GET)
	public String suppliersContractPage(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		Suppliers dto = suppliersService.getSuppliersInfoById(suppliers);
		request.setAttribute("suppliersInfo", dto);
		return "resource/suppliers/suppliersContractList";
	}

	/**
	 * @Description: 进入供应商合同界面
	 * @param request
	 * @param response
	 * @param suppliersContract
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月22日
	 */
	@ResponseBody
	@RequestMapping(value = "suppliersContractList", method = RequestMethod.POST)
	public EntityData suppliersContractList(HttpServletRequest request,
			HttpServletResponse response, SuppliersContract suppliersContract) {
		suppliersContract.initDataTableParam(request);
		List<SuppliersContract> list = suppliersService.getSuppliersContrctList(suppliersContract,SysConstant.PAGE_TRUE);
		PageInfo<SuppliersContract> page = new PageInfo<SuppliersContract>(list);
		EntityData data = new EntityData(suppliersContract, page);
		return data;
	}

	/**
	 * @Description: 进入供应商合同新增界面
	 * @param request
	 * @param response
	 * @param suppliersContract
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月24日
	 */
	@RequestMapping(value = "suppliersContractAdd", method = RequestMethod.GET)
	public String suppliersContractAdd(HttpServletRequest request,
			HttpServletResponse response, SuppliersContract suppliersContract) {
		request.setAttribute("suppliersContractInfo", suppliersContract);
		request.setAttribute("operate", "new");
		return "resource/suppliers/suppliersContractAdd";
	}

	/**
	 * @Description: 进入供应商合同修改界面
	 * @param request
	 * @param response
	 * @param suppliersContract
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月24日
	 */
	@RequestMapping(value = "suppliersContractUpdate", method = RequestMethod.GET)
	public String suppliersContractUpdate(HttpServletRequest request,
			HttpServletResponse response, SuppliersContract suppliersContract) {
		if (suppliersContract.getId() != null) {
			SuppliersContract dto = suppliersService
					.getSuppliersContractInfoById(suppliersContract);
			request.setAttribute("suppliersContractInfo", dto);
			request.setAttribute("operate", "edit");
		}

		return "resource/suppliers/suppliersContractEdit";
	}

	/**
	 * 保存供应商合同信息（合同附件上传）
	 * 
	 * @param request
	 * @param suppliersContract
	 * @param key
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "saveSuppliersContract", method = RequestMethod.POST)
	public MessageData saveSuppliersContract(HttpServletRequest request,
			SuppliersContract suppliersContract, String key) {
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession()
					.getAttribute(SysConstant.SESSION_USER);
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
			suppliersService.saveSuppliersContract(user, filesMap, key,suppliersContract);
			return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false,null, null, null);
		 
	}

	/**
	 * @Description 下载供应商合同
	 * @param response
	 * @return void
	 * @author ranmaoping
	 * @date 2017年1月26日
	 */
	@RequestMapping(value = "contractAttachDownload", method = RequestMethod.GET)
	public void contractAttachDownload(HttpServletResponse response,
			SuppliersContract suppliersContract) {
		suppliersService.contractAttachDownload(response, suppliersContract);
	}

	/**
	 * 跳转到供应商证照管理页面
	 * 
	 * @param request
	 * @param response
	 * @param suppliers
	 * @return
	 */
	@RequestMapping(value = "suppliersLicensePage", method = RequestMethod.GET)
	public String suppliersLicensePage(HttpServletRequest request,
			HttpServletResponse response, Suppliers suppliers) {
		Suppliers dto = suppliersService.getSuppliersInfoById(suppliers);
		request.setAttribute("suppliersInfo", dto);
		return "resource/suppliers/suppliersLicenseList";
	}

	/**
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return EntityData
	 * @Description: 进入证照管理界面
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月22日
	 */
	@ResponseBody
	@RequestMapping(value = "suppliersLicenseList", method = RequestMethod.POST)
	public EntityData suppliersLicenseList(HttpServletRequest request,
			HttpServletResponse response, SuppliersLicense suppliersLicense) {
		suppliersLicense.initDataTableParam(request);
		List<SuppliersLicense> list = suppliersService.getSuppliersLicenseList(
				suppliersLicense, SysConstant.PAGE_TRUE);
		PageInfo<SuppliersLicense> page = new PageInfo<SuppliersLicense>(list);
		EntityData data = new EntityData(suppliersLicense, page);
		return data;
	}

	/**
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return String
	 * @Description: 进入证照管理新增界面
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年01月24日
	 */
	@RequestMapping(value = "suppliersLicenseAdd", method = RequestMethod.GET)
	public String suppliersLicenseAdd(HttpServletRequest request,
			HttpServletResponse response, SuppliersLicense suppliersLicense) {
		request.setAttribute("suppliersLicense", suppliersLicense);
		// request.setAttribute("operate", "new");
		return "resource/suppliers/suppliersLicenseEdit";
	}

	/**
	 * 保存供应商证件信息
	 * 
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "saveSuppliersLicense", method = RequestMethod.POST)
	public MessageData saveSuppliersLicense(HttpServletRequest request,
			HttpServletResponse response, SuppliersLicense suppliersLicense,
			String coversImageFile) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(
				SysConstant.SESSION_USER);
		if (userInfo == null) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.empty.userInfo"));
		}
		Map<String, List<MultipartFile>> filesMap = null;
		if (StringUtil.isNotEmpty(coversImageFile)) {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			filesMap = multipartRequest.getMultiFileMap();
		}
		suppliersService.saveSuppliersLicense(userInfo, suppliersLicense,
				filesMap, coversImageFile);
		return new MessageData(SysConstant.OPERATE_SUCCESS,
				SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,
				"", null);
	}

	/**
	 * 供应商证件管理附件查看
	 * 
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return
	 */
	@RequestMapping(value = "suppliersLicenseAttached", method = RequestMethod.GET)
	public String suppliersLicenseAttached(HttpServletRequest request,
			HttpServletResponse response, SuppliersLicense suppliersLicense) {
		List<SuppliersLicense> suppliersLicenseList = null;
		if (suppliersLicense.getId() != null) {
			// 根据ID查询信息
			suppliersLicenseList = suppliersService.getSuppliersLicenseList(
					suppliersLicense, false);
		}
		if (suppliersLicenseList != null && suppliersLicenseList.size() > 0) {
			suppliersLicense = suppliersLicenseList.get(0);
		}
		request.setAttribute("suppliersLicenseAttached", suppliersLicense);
		return "resource/suppliers/suppliersLicenseAttachedShow";
	}

	/**
	 * 删除供应商证件信息
	 * 
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "suppliersLicenseDelete", method = RequestMethod.POST)
	public MessageData suppliersLicenseDelete(HttpServletRequest request,
			HttpServletResponse response, SuppliersLicense suppliersLicense) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(
				SysConstant.SESSION_USER);
		if (userInfo == null) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.empty.userInfo"));
		}
		this.suppliersService
				.deleteSuppliersLicense(userInfo, suppliersLicense);
		return new MessageData(SysConstant.OPERATE_SUCCESS,
				SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,
				"", null);
	}

	/**
	 * 删除供应商证件的附件图片
	 * 
	 * @param request
	 * @param response
	 * @param suppliersLicense
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "deleteSuppliersLicenseAttached", method = RequestMethod.POST)
	public MessageData deleteSuppliersLicenseAttached(
			HttpServletRequest request, HttpServletResponse response,
			SuppliersLicense suppliersLicense) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(
				SysConstant.SESSION_USER);
		if (userInfo == null) {
			throw new BussinessException(new BussinessExceptionBean(
					"exception.empty.userInfo"));
		}
		suppliersService.deleteSuppliersLicenseAttached(userInfo,
				suppliersLicense);
		return new MessageData(SysConstant.OPERATE_SUCCESS,
				SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,
				"", null);
	}
}
