package com.spring.scenic.material.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.material.domain.Material;
import com.spring.scenic.system.domain.AuthUser;

public interface MaterialService {

	int saveMaterialUpload(AuthUser user,Map<String, List<MultipartFile>> filesMap, String[] descriptions,
			Integer[] types, Integer[] usertypes, Integer[] authorizedIds,
			String[] keys, String[] names);

	List<Material> getMaterialList(Material material, boolean pageAble);

	Material getMaterial(Material material);

	int deleteMaterial(Material material);

	int auditMaterial(AuthUser user, Material material);

}
