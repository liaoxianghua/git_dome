package com.spring.scenic.member.infrastructure;

import com.spring.scenic.member.domain.OrderInvoice;

public interface OrderInvoiceMapper {

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    OrderInvoice getOrderInvoiceInfo(String orderNo);
    
}