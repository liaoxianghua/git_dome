/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 */
package com.spring.scenic.busi.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;

/**
 * 此处为类说明：商户管理controller层
 * @author ranmaoping
 * @date 2017年3月20日
 */
@Controller
@RequestMapping("busi/busiSeller")
public class BusiSellerController {

    @Autowired
    private BusiSellerService busiSellerService;

    /**
     * 
     * 此处为类方法说明:进入商户管理页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiSellerList", method = RequestMethod.GET)
    public String busiSellerList(HttpServletRequest request, HttpServletResponse response) {
        return "busi/busiSeller/busiSellerList";
    }

    /**
     * 
     * 此处为类方法说明:查询商户信息列表
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "getBusiSellerList", method = RequestMethod.POST)
    public EntityData getBusiSellerList(HttpServletRequest request, HttpServletResponse response, BusiSeller busiSeller) {
        busiSeller.initDataTableParam(request);
        List<BusiSeller> list = busiSellerService.getBusiSellerList(busiSeller, SysConstant.PAGE_TRUE);
        PageInfo<BusiSeller> page = new PageInfo<BusiSeller>(list);
        EntityData data = new EntityData(busiSeller, page);
        return data;
    }

    /**
     * 
     * 此处为类方法说明:进入商户新增页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiSellerAdd", method = RequestMethod.GET)
    public String busiSellerAdd(HttpServletRequest request, HttpServletResponse response, BusiSeller busiSeller) {
        request.setAttribute("operate", "new");
        return "busi/busiSeller/busiSellerEdit";
    }

    /**
     * 
     * 此处为类方法说明：进入商户编辑页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiSellerUpdate", method = RequestMethod.GET)
    public String busiSellerUpdate(HttpServletRequest request, HttpServletResponse response, BusiSeller busiSeller) {
        if (null != busiSeller.getId()) {
            BusiSeller busiSellerInfo = busiSellerService.getBusiSellerById(busiSeller);
            request.setAttribute("busiSellerInfo", busiSellerInfo);
            request.setAttribute("operate", "edit");
        }
        return "busi/busiSeller/busiSellerEdit";
    }

    /**
     * 
     * 此处为类方法说明：更新商户状态
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月20日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "updateBusiSellerStatus", method = RequestMethod.POST)
    public MessageData updateBusiSellerStatus(HttpServletRequest request, HttpServletResponse response,
        BusiSeller busiSeller) {
        AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if (null != userInfo) {
            this.busiSellerService.updateBusiSellerStatus(userInfo, busiSeller);
        }
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false,
                null, "", null);
    }

    /**
     * 
     * 此处为类方法说明:商户编辑页面初始化所属景区树形结构
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月21日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "initParentScenic", method = RequestMethod.POST)
    public List<ZtreeDept> initParentScenic(HttpServletRequest request, HttpServletResponse response,
        Department department) throws Exception {
        List<ZtreeDept> resultList = busiSellerService.initParentScenic(department);
        return resultList;
    }

    /**
     * 
     * 此处为类方法说明：保存商户信息
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月21日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "saveBusiSeller", method = RequestMethod.POST)
    public MessageData saveBusiSeller(HttpServletRequest request, HttpServletResponse response, BusiSeller busiSeller) {
        AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if (null != userInfo) {
            this.busiSellerService.saveBusiSeller(userInfo, busiSeller);
        }
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
    }

    /**
     * 
     * 此处为类方法说明:进入商户账号编辑页面
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月21日
     * @memo ：
     ** 
     */
    @RequestMapping(value = "busiSellerAccountEdit", method = RequestMethod.GET)
    public String busiSellerAccountEdit(HttpServletRequest request, HttpServletResponse response, BusiSeller busiSeller) {
        Integer sellerId = busiSeller.getId();
        if (null != sellerId) {
            BusiSeller busiSellerInfo = busiSellerService.getBusiSellerById(busiSeller);
            BusiSellerUser busiSellerUserInfo = busiSellerService.getSellerAccountById(sellerId);
            if(null!=busiSellerUserInfo) {
                request.setAttribute("busiSellerUserInfo", busiSellerUserInfo);
            }
            request.setAttribute("busiSellerInfo", busiSellerInfo);
        }
        return "busi/busiSeller/busiSellerAccountEdit";
    }

    /**
     * 
     * 此处为类方法说明:保存商户账号信息
     * @param
     * @return
     ******************************************************************************* 
     * @creator ：rmp
     * @date ：2017年3月22日
     * @memo ：
     ** 
     */
    @ResponseBody
    @RequestMapping(value = "saveBusiSellerUser", method = RequestMethod.POST)
    public MessageData saveBusiSellerUser(HttpServletRequest request, HttpServletResponse response,
        BusiSellerUser busiSellerUser) {
        AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if (null != userInfo) {
            MessageData messageData = busiSellerService.saveBusiSellerUser(userInfo, busiSellerUser);
            return messageData;
        }else {
            return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE);
        }
    }
}
