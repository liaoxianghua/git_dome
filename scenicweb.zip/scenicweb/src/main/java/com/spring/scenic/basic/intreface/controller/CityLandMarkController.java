/**
 * 
 */
package com.spring.scenic.basic.intreface.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.CityLandMarkService;
import com.spring.scenic.basic.domain.CityLandMark;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;

/**
 *  @Description:地标信息查询
 *  @author：ranmaoping
 *  @date:上午11:18:49 2016年12月22日
 *  @version:1.0
 *
 */
@Controller
@RequestMapping("basic/cityLandMark")
public class CityLandMarkController {
	
	
	@Autowired
	private CityLandMarkService cityLandMarkService;
	
	
	/**
	 * 加载地标管理页面
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="cityLandMarkPage",method=RequestMethod.GET)
	public String cityLandMarkManage(HttpServletRequest request,HttpServletResponse response){
		return "basic/cityLandMark/cityLandMarkList";
	}
	
	/**
	 * @Description: 进入地标信息分页界面
	 * @param request
	 * @param response
	 * @param cityLandMark
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	//@SecurityValid(resourceCode="R0070")
	@ResponseBody
	@RequestMapping(value="cityLandMarkInfoList",method=RequestMethod.POST)
	public EntityData cityLandMarkInfoList(HttpServletRequest request,HttpServletResponse response,CityLandMark cityLandMark){
		cityLandMark.initDataTableParam(request);
		List<CityLandMark> list = cityLandMarkService.getCityLandMarkList(cityLandMark);
		PageInfo<CityLandMark> page = new PageInfo<CityLandMark>(list);
		EntityData data = new EntityData(cityLandMark,page);
		return data;
	}
	
	/**
	 * @Description: 进入地标新增界面
	 * @param request
	 * @param response
	 * @param cityLandMark
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityLandMarkAdd",method=RequestMethod.GET)
	public String cityLandMarkAdd(HttpServletRequest request,HttpServletResponse response,CityLandMark cityLandMark){
		request.setAttribute("operate", "new");
		return "basic/cityLandMark/cityLandMarkEdit";
	}
	
	/**
	 * @Description: 进入地标信息修改界面、初始化地标信息
	 * @param request
	 * @param response
	 * @param cityLandMark
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="cityLandMarkUpdate",method=RequestMethod.GET)
	public String cityLandMarkUpdate(HttpServletRequest request,HttpServletResponse response,CityLandMark cityLandMark){
		if(cityLandMark.getId()!=null){
			CityLandMark dto = cityLandMarkService.getCityLandMarkInfoById(cityLandMark);
			request.setAttribute("cityLandMarkInfo", dto);
			request.setAttribute("operate", "edit");
		}
		return "basic/cityLandMark/cityLandMarkEdit";
	}
	
	/**
	 * @Description: 保存地标基本信息
	 * @param request
	 * @param response
	 * @param cityLandMark
	 * @return MessageBean
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="saveCityLandMark",method=RequestMethod.POST)
	public MessageData saveCityLandMark(HttpServletRequest request,HttpServletResponse response,CityLandMark cityLandMark){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		cityLandMark.setCreateUser(userInfo.getId());
		//this.cityLandMarkService.saveCityLandMark1(cityLandMark);
		this.cityLandMarkService.saveCityLandMark(cityLandMark);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	/**
	 * 删除地标
	 * @param id
	 * @return
	 */
	@RequestMapping(value ="updateCityLandMarkStatus",method=RequestMethod.POST)
	@ResponseBody
	public MessageData updateCityLandMarkStatus(HttpServletRequest request,@RequestParam(value="id") Integer id,@RequestParam(value="status") Integer status){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		CityLandMark clmDto = new CityLandMark();
		clmDto.setUpdateUser(userInfo.getId());
		clmDto.setUpdateTime(new Date());
		clmDto.setId(id);
		clmDto.setStatus(status);
		cityLandMarkService.updateCityLandMarkStatus(clmDto);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	
	@RequestMapping(value= "countryList",method=RequestMethod.POST)
	@ResponseBody
	public List<CityLandMark> getCountryList() {
		return null;
	}
	
	@RequestMapping(value= "lgnLatList",method=RequestMethod.POST)
	@ResponseBody
	public CityLandMark getLgnLatList(@RequestParam(value="id") String id) {
		Integer id1 = Integer.parseInt(id);
		//List<CityLandMark> list =  new ArrayList<CityLandMark>();
		CityLandMark clm = new CityLandMark();
		clm.setId(id1);
		CityLandMark dto = cityLandMarkService.getPositionInfoById(clm);
		//list.add(dto);
		//return list;
		return dto;
	}
	
}
