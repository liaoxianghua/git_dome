package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.AuthUserRole;

public interface AuthUserRoleMapper {
  
    int deleteByPrimaryKey(Integer id);
    int insert(AuthUserRole record);
    int insertSelective(AuthUserRole record);
    AuthUserRole selectByPrimaryKey(Integer id);
    int updateByPrimaryKeySelective(AuthUserRole record);
    int updateByPrimaryKey(AuthUserRole record);
	List<AuthUserRole> getRoleUserList(AuthUserRole authUserRole);
	void deleteRoleUser(AuthUserRole authUserRole);
	void insertUserRoleByBatch(List<AuthUserRole> authUserRoles);
	void deleteUserRoleByUserId(AuthUserRole authUserRole);
}