package com.spring.scenic.common.extend;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;

public class ScenicContextLoaderListener implements ServletContextListener {
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		DictionaryService dictionaryService = WebApplicationContextUtils.getWebApplicationContext(sce.getServletContext()).getBean(DictionaryService.class);
		sce.getServletContext().setAttribute(SysConstant.SYS_DIC,dictionaryService.initDictionary(new Dictionary()));
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		sce.getServletContext().removeAttribute(SysConstant.SYS_DIC);
	}

}
