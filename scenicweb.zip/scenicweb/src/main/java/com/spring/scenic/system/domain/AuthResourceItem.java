package com.spring.scenic.system.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class AuthResourceItem extends Entity<AuthResourceItem> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 855576223195228962L;
	
	private Integer id;
	private String name;//资源名称
	private String url;//资源地址
	private Integer parentId;//父级菜单 默认从0开始
	private String parentName;//父菜单名称
	private Integer sort;//排序
	private Integer valid;//0 无效 1 有效
	private Integer type;//1： 菜单 2 ：按钮  
	private Integer systemId;//所属系统
	private String remarks;//备注
	private Date createTime;//创建时间
	private Integer createUser;//创建人信息
	private String createUserName;//创建人名称
	private Date updateTime;//修改时间
	private Integer updateUser;//修改人信息
	private String updateUserName;//修改人名称
	
	
	
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getValid() {
		return valid;
	}
	public void setValid(Integer valid) {
		this.valid = valid;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public String getCreateUserName() {
		return createUserName;
	}
	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateUserName() {
		return updateUserName;
	}
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}
	
	
	
}
