package com.spring.scenic.system.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.application.ScenicDepartmentService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.ScenicDepartment;
/**
 * 系统管理景区商户管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "system/scenicDepartment")
public class ScenicDepartmentController {
	@Autowired
	private ScenicDepartmentService scenicDepartmentService;
	
	/**
	 * 
	  * @Description: 景区商户管理页面跳转
	  * @param @return
	  * @return String
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:04
	 */
	@RequestMapping(value = "scenicDepartmentList")
	public String scenicDepartmentList() {
		return "system/scenicDepartment/scenicDepartmentList";
	}
	/**
	 * 编辑景区商户管理
	 * @param request
	 * @param response
	 * @param scenicDepartment
	 * @return
	 */
	@RequestMapping(value = "scenicDepartmentEdit")
	public String scenicDepartmentEdit(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment ) {
		if (scenicDepartment.getId()!= null && !"".equals(scenicDepartment.getId())) {
			ScenicDepartment vo = scenicDepartmentService.selectByPrimaryKey(scenicDepartment.getId());
			request.setAttribute("scenicDepartmentVo", vo);
		}
		return "/system/scenicDepartment/scenicDepartmentEnterEdit";
	}
	
	/**
	 * 
	  * @Description: 支持批量删除,以逗号分隔
	  * @param @param id
	  * @param @return
	  * @return RespBody
	  * @author 李cm
	  * @date 2016-12-14 下午2:24:01
	 */
	@RequestMapping(value = "deleteCountryById" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData deleteCountry(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment){
		
		scenicDepartmentService.deleteByPrimaryKey(scenicDepartment.getId());
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysEnum.COMMON_USEABLE_YES.getCode().equals(scenicDepartment.getFlag())) {
			scenicDepartment.setValid(String.valueOf(SysConstant.VALITY_NO));
		}else {
			scenicDepartment.setValid(String.valueOf(SysConstant.VALITY_YES));
		}
		scenicDepartmentService.updateForbiddenOrUseData(scenicDepartment,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 
	  * @Description: 景区商户管理信息详情
	  * @param @param userDTO
	  * @param @param dataGrid
	  * @param @return
	  * @return DataGridResponse
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:22
	 */
	@RequestMapping(value = "queryScenicDepartmentList",method=RequestMethod.POST)
	@ResponseBody
	public EntityData queryScenicDepartmentList(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment) {
		scenicDepartment.initDataTableParam(request);
		List<ScenicDepartment> list = scenicDepartmentService.queryScenicDepartmentList(scenicDepartment, SysConstant.PAGE_TRUE);
		PageInfo<ScenicDepartment> page = new PageInfo<ScenicDepartment>(list);
		EntityData data = new EntityData(scenicDepartment,page);
		return data;
	}
	@ResponseBody
	@RequestMapping(value = "insertScenicDepartment",method=RequestMethod.POST)
	public  MessageData insertScenicDepartment(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (scenicDepartment.getId()==null || "".equals(scenicDepartment.getId())) {
			scenicDepartmentService.addScenicDept(scenicDepartment,userInfo);
		}else {
			scenicDepartmentService.updateByPrimaryKey(scenicDepartment, userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	@ResponseBody
	@RequestMapping(value = "updateScenicDepartment",method=RequestMethod.POST)
	public MessageData updateScenicDepartment(HttpServletRequest request, HttpServletResponse response,ScenicDepartment scenicDepartment) throws Exception {
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		scenicDepartmentService.updateByPrimaryKey(scenicDepartment, userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
}
