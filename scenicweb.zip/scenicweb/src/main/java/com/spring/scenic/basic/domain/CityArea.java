package com.spring.scenic.basic.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class CityArea extends Entity<City> implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 主键id
     */
    private Integer id;
    /**
     * 城市id
     */
    private Integer cityId;
    /**
     * 区域名称
     */
    private String name;
    /**
     * 城市名称
     */
    private String cityName;
    /**
     * 操作人id
     */
    private String userId;
    /**
     * 类别
     */
    private Short type;
    /**
     * 类别  1:行政区 2：商业区
     */
    private Integer typeId;
    /**
     * 区域自身关联id
     */
    private Integer innerReleatedId;
    /**
     * 状态 1：有效 0：无效
     */
    private Integer valid;
    /**
     * 行政区状态 1：有效 0：无效
     */
    private Integer cantonValid;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Integer createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人id
     */
    private Integer updateUser;
    /**
     * 创建人姓名
     */
    private String createName;
    /**
     * 更新人姓名
     */
    private String updateName;
    /**
     *行政区下属商业区集合 
     */
    private List<CityBusinessArea> children;
    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
   
    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Short getType() {
        return type;
    }

    public void setType(Short type) {
        this.type = type;
    }

    public Integer getInnerReleatedId() {
        return innerReleatedId;
    }

    public void setInnerReleatedId(Integer innerReleatedId) {
        this.innerReleatedId = innerReleatedId;
    }

    public Integer getValid() {
        return valid;
    }

    public void setValid(Integer valid) {
        this.valid = valid;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }
  
    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }
  
    public Date getUpdateTime() {
        return updateTime;
    }
    
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }
  
    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public List<CityBusinessArea> getChildren() {
		return children;
	}

	public void setChildren(List<CityBusinessArea> children) {
		this.children = children;
	}

	public Integer getCantonValid() {
		return cantonValid;
	}

	public void setCantonValid(Integer cantonValid) {
		this.cantonValid = cantonValid;
	}
	
	@Override
	public int hashCode() {
		String in = String.valueOf(id);
		return in.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		CityArea temp=(CityArea)obj;
		return id.equals(temp.id);
	}
}
