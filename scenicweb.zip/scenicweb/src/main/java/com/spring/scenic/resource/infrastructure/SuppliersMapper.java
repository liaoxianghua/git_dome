package com.spring.scenic.resource.infrastructure;

import java.util.List;

import com.spring.scenic.resource.domain.Suppliers;
import com.spring.scenic.system.domain.Dictionary;

public interface SuppliersMapper {
   
    int deleteByPrimaryKey(Integer id);

    int insert(Suppliers record);

    int insertSelective(Suppliers record);

    Suppliers selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Suppliers record);

    int updateByPrimaryKey(Suppliers record);

	List<Suppliers> getSuppliersList(Suppliers suppliers);
   
	Suppliers getSuppliersInfoById(Suppliers suppliers);

	void addSuppliers(Suppliers suppliers);

	void updateSuppliersStatus(Suppliers suppliers);

	List<Dictionary> getProductTypeList();

	int getSuppliersCodeCount(Suppliers suppliers);
}