package com.spring.scenic.system.application;

import java.util.List;

import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.ScenicDepartment;

public interface ScenicDepartmentService {

	/**修改类型
	 * @param user
	 * @return
	 */
	public int updateByPrimaryKey(ScenicDepartment scenicDepartment,AuthUser user);
	
	/**根据主键查询
	 * @param id
	 * @return
	 */
	public ScenicDepartment selectByPrimaryKey(Integer id);

	/**
	 * 禁用启用数据
	 * @param scenicDepartment
	 * @param userInfo
	 */
	public void updateForbiddenOrUseData(ScenicDepartment scenicDepartment,
			AuthUser userInfo);

	/**
	 * 查询分页数据
	 * @param scenicDepartment
	 * @param pageTrue
	 * @return
	 */
	public List<ScenicDepartment> queryScenicDepartmentList(
			ScenicDepartment scenicDepartment, boolean pageTrue);
	/**
	 * 新增数据
	 * @param scenicDepartment
	 * @param userInfo
	 */
	public void addScenicDept(ScenicDepartment scenicDepartment, AuthUser userInfo);
	/**
	 * 删除数据
	 * @param id
	 */
	public void deleteByPrimaryKey(Integer id);
	
	
}
