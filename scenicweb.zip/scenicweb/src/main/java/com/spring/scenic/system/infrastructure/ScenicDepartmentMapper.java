package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.ScenicDepartment;

public interface ScenicDepartmentMapper {
	
    int deleteByPrimaryKey(Integer id);

    int insert(ScenicDepartment scenicDepartment);
    
    ScenicDepartment selectByPrimaryKey(Integer id);
    
    int updateByPrimaryKey(ScenicDepartment record);
    
    List<ScenicDepartment> selectScenicDepartmentForManager(ScenicDepartment criteria);
    
    List<ScenicDepartment> selectScenicDepartmentByCriteria(ScenicDepartment criteria);

	void forbiddenOrUseData(ScenicDepartment scenicDepartment);
}