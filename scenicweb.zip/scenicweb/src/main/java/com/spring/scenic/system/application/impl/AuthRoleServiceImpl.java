package com.spring.scenic.system.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.system.application.AuthResourceService;
import com.spring.scenic.system.application.AuthRoleService;
import com.spring.scenic.system.domain.AuthPermission;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;
import com.spring.scenic.system.infrastructure.AuthPermissionMapper;
import com.spring.scenic.system.infrastructure.AuthResourceMapper;
import com.spring.scenic.system.infrastructure.AuthRoleMapper;
import com.spring.scenic.system.infrastructure.AuthUserRoleMapper;


@Service
public class AuthRoleServiceImpl implements AuthRoleService {

	@Resource
	private AuthResourceService authResourceService;
	
	@Resource
	private AuthRoleMapper authRoleMapper;
	
	@Resource 
	private AuthResourceMapper authResourceMapper;
	
	@Resource
	private AuthPermissionMapper authPermissionMapper;
	
	@Resource
	private AuthUserRoleMapper authUserRoleMapper;

	@Override
	public List<AuthRole> queryRoleList(AuthRole authRole, boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(authRole.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<AuthRole> resultList = authRoleMapper.queryRoleList(authRole);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public void addRole(AuthRole authRole, AuthUser userInfo) {
		try {
			authRole.setCreateUser(userInfo.getId());
			authRole.setCreateTime(new Date());
			if (StringUtil.isNotEmpty(authRole.getRoleName())) {
				authRole.setRoleName(authRole.getRoleName().trim());
			}
			if (StringUtil.isNotEmpty(authRole.getRoleCode())) {
				authRole.setRoleCode(authRole.getRoleCode().trim());
			}
			if (StringUtil.isNotEmpty(authRole.getRemarks())) {
				authRole.setRemarks(authRole.getRemarks().trim());
			}
			authRoleMapper.insertRole(authRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public void updateRole(AuthRole authRole, AuthUser userInfo) {
		try {
			AuthRole aRole = new AuthRole();
			aRole =	authRoleMapper.selectByPrimaryKey(authRole.getId());
			aRole.setRoleName(authRole.getRoleName());
			aRole.setRoleCode(authRole.getRoleCode());
			aRole.setValid(authRole.getValid());
			aRole.setRemarks(authRole.getRemarks());
			aRole.setUpdateUser(userInfo.getId());
			aRole.setUpdateTime(new Date());
			authRoleMapper.updateByPrimaryKey(aRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public AuthRole selectByPrimaryKey(Integer id) {
		try {
			return authRoleMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public void updateForbiddenOrUseData(AuthRole authRole, AuthUser userInfo) {
		try {
			authRole.setUpdateUser(userInfo.getId());
			authRole.setUpdateTime(new Date());
			authRoleMapper.updateForbiddenOrUseData(authRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}		
	}


	@Override
	public int updatePermission(Integer resourceId, Integer roleId,Integer status,AuthUser user) {
		try {
			Date now = DateUtil.getNow();
			AuthResource currentResource = null;
			AuthResource resourceExample = new AuthResource();
			resourceExample.setValid(Integer.parseInt(SysEnum.COMMON_VALID_YES.getCode()));
			List<AuthResource> assignedResources = null;
			Map<String,Object> selectMap = new HashMap<String,Object>();
			selectMap.put("userId", user.getId());
			List<AuthResource> resources = authResourceMapper.getValidResourceList(selectMap);
			if(resources!=null && !resources.isEmpty()){
				for (AuthResource resource : resources) {
					recursionResource(resource,resources);
					if(resourceId!=null && resourceId.equals(resource.getId())){
						currentResource = resource;
					}
				}
			}
			
			if(roleId!=null){
				AuthRole authRole = new AuthRole();
				authRole.setId(roleId);
				assignedResources = authResourceService.getResourceListByRole(authRole);
				if(assignedResources!=null && !assignedResources.isEmpty()){
					for (AuthResource assignedResource : assignedResources) {
						recursionResource(assignedResource,resources);
					}
				}
				authPermissionMapper.deletePermissionByRole(authRole);
			}
			
			Set<Integer> newAssignedResourceIds = new HashSet<Integer>();
			if(status==0){//移出
				//剔除向上向下关联的节点
				if(assignedResources!=null){
					Iterator<AuthResource> assiginedIterator = assignedResources.iterator();
					while(assiginedIterator.hasNext()){
						AuthResource associationResource = assiginedIterator.next();
						if(associationResource.getId().equals(currentResource.getId())){
							assiginedIterator.remove();
							assignedResources = recursionRemoveParent(associationResource,assignedResources);
							assignedResources = recursionRemoveChild(associationResource,assignedResources);
							break;
						}
					}
				}
				//将无关的节点由下向上推
				newAssignedResourceIds = resetAssignedResourceIds(assignedResources);
//				for (Integer id : newAssignedResourceIds) {
//					System.out.println("R-ID："+id);
//				}
			}else if(status==1){//移入
				if(assignedResources!=null){
					for (AuthResource assignedResource : assignedResources) {
						newAssignedResourceIds.add(assignedResource.getId());
					}
				}
				if(currentResource!=null){
					newAssignedResourceIds.add(currentResource.getId());
					newAssignedResourceIds = recursionAddParent(currentResource,newAssignedResourceIds);
					newAssignedResourceIds = recursionAddChild(currentResource,newAssignedResourceIds);
				}
//				for (Integer id : newAssignedResourceIds) {
//					System.out.println("A-ID："+id);
//				}
			}
			if(newAssignedResourceIds!=null && !newAssignedResourceIds.isEmpty()){
				AuthPermission permission = null;
				List<AuthPermission> permissions = new ArrayList<AuthPermission>();
				for (Integer rId : newAssignedResourceIds) {
					permission = new AuthPermission();
					permission.setResourceId(rId);
					permission.setRoleId(roleId);
					permission.setValid(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
					permission.setCreateTime(now);
					permission.setCreateUser(user.getId());
					permissions.add(permission);
				}
				return authPermissionMapper.saveBatchPermissions(permissions);
			}
			return 0;//无权限
		}  catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	private Set<Integer> recursionAddChild(AuthResource currentResource,Set<Integer> newAssignedResourceIds) {
		try {
			if(currentResource.getChildren()!=null){
				for (AuthResource authResource : currentResource.getChildren()) {
					newAssignedResourceIds.add(authResource.getId());
					recursionAddChild(authResource,newAssignedResourceIds);
				}
				
			}
			return  newAssignedResourceIds;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	private Set<Integer> recursionAddParent(AuthResource currentResource,Set<Integer> newAssignedResourceIds) {
		try {
			if(currentResource.getParent()!=null){
				newAssignedResourceIds.add(currentResource.getParent().getId());
				recursionAddParent(currentResource.getParent(),newAssignedResourceIds);
			}
			return newAssignedResourceIds;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	/**
	 * @Description 将最小叶子节点向上加
	 * @param assignedResources
	 * @return Set<Integer>
	 * @author 006568（shuchang）
	 * @date 2017年2月8日
	 */
	private Set<Integer> resetAssignedResourceIds(List<AuthResource> assignedResources) {
		try {
			Set<Integer> assignedResourceIds = new HashSet<Integer>();
			for (AuthResource authResource : assignedResources) {
				if(authResource.getChildren()==null){
					assignedResourceIds.add(authResource.getId());
					assignedResourceIds = resetRecursionResourceParentIds(authResource,assignedResourceIds);
				}
			}
			return assignedResourceIds;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	
	/**
	 * @Description 递归添加节点的父节点
	 * @param authResource
	 * @param assignedResourceIds
	 * @return Set<Integer>
	 * @author 006568（shuchang）
	 * @date 2017年2月8日
	 */
	private Set<Integer> resetRecursionResourceParentIds(AuthResource authResource ,Set<Integer> assignedResourceIds) {
		try {
			if(authResource.getParent()!=null){
				assignedResourceIds.add(authResource.getParent().getId());
				resetRecursionResourceParentIds(authResource.getParent(),assignedResourceIds);
			}
			return assignedResourceIds;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * @Description 在被授权的资源里将关联资源递归剔除
	 * @param associationResource 关联的资源
	 * @param assignedResources	授权的资源
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月8日
	 */
	public List<AuthResource> recursionRemoveParent(AuthResource associationResource,List<AuthResource> assignedResources){
		try {
			if(associationResource.getParent()!=null){
				Iterator<AuthResource> assiginedIterator = assignedResources.iterator();
				while(assiginedIterator.hasNext()){
					AuthResource resource = assiginedIterator.next();
					if(resource.getId().equals(associationResource.getParent().getId())){
						assiginedIterator.remove();
						assignedResources = recursionRemoveParent(resource,assignedResources);
						break;
					}
				}
			}
			return  assignedResources;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	public List<AuthResource> recursionRemoveChild(AuthResource associationResource,List<AuthResource> assignedResources){
		try {
			if(associationResource.getChildren()!=null){
				for (AuthResource authResource : associationResource.getChildren()) {
					Iterator<AuthResource> assiginedIterator = assignedResources.iterator();
					while(assiginedIterator.hasNext()){
						AuthResource resource = assiginedIterator.next();
						if(resource.getId().equals(authResource.getId())){
							assiginedIterator.remove();
							assignedResources = recursionRemoveChild(authResource,assignedResources);
							break;
						}
					}
				}
				
			}
			return  assignedResources;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**
	 * @Description 递归获得当前节点的父级
	 * @param resource
	 * @param parents
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月7日
	 */
	public List<AuthResource> recursionResourceParent(AuthResource resource,List<AuthResource> parents){
		try {
			if(resource.getParent()!=null){
				parents.add(resource.getParent());
				recursionResourceParent(resource.getParent(),parents);
			}
			return  parents;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**
	 * @Description 递归获得当前节点的子级
	 * @param resource
	 * @param parents
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月7日
	 */
	public List<AuthResource> recursionResourceChildren(AuthResource resource,List<AuthResource> childrens){
		try {
			if(resource.getChildren()!=null){
				for (AuthResource authResource : resource.getChildren()) {
					childrens.add(authResource);
					recursionResourceChildren(authResource,childrens);
				}
			}
			return  childrens;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	
	/**
	 * @Description 给每个AuthResource设置父级和子级
	 * @param compareResource
	 * @param resources
	 * @return void
	 * @author 006568（shuchang）
	 * @date 2017年2月7日
	 */
	public void recursionResource(AuthResource compareResource,List<AuthResource> resources){
		try {
			AuthResource parentAuthResource = null;
			List<AuthResource> authResources = new ArrayList<AuthResource>();
			for (AuthResource currentResource : resources) {
				if(currentResource.getParentId()!=null && currentResource.getParentId().equals(compareResource.getId())){
					authResources.add(currentResource);
				}
				if(compareResource.getParentId()!=null && compareResource.getParentId().equals(currentResource.getId())){
					parentAuthResource = currentResource;
				}
			}
			compareResource.setChildren(authResources.isEmpty()?null:authResources);
			compareResource.setParent(parentAuthResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	/**
	 * @Description 查询角色中的用户信息
	 * @param authUserRole
	 * @param pageTrue
	 * @return List
	 * @author 004225（ranmaoping）
	 * @date 2017年2月7日
	 */
	public List<AuthUserRole> getRoleUserList(AuthUserRole authUserRole,
			boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(authUserRole.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<AuthUserRole> resultList = authUserRoleMapper.getRoleUserList(authUserRole);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * @Description 查询角色中的用户信息
	 * @param authUserRole
	 * @param pageTrue
	 * @return List
	 * @author 004225（ranmaoping）
	 * @date 2017年2月7日
	 */
	public void deleteRoleUser(AuthUserRole authUserRole) {
		try {
			authUserRoleMapper.deleteRoleUser(authUserRole);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	

	@Override
	public AuthRole getRole(AuthRole authRole) {
		try {
			return authRoleMapper.getRole(authRole);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public List<AuthRole> getRoleList(AuthRole authRole) {
		try {
			return authRoleMapper.getRoleList(authRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public List<AuthRole> getRoleListByResource(AuthResource resource) {
		try {
			return authRoleMapper.getRoleListByResource(resource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
