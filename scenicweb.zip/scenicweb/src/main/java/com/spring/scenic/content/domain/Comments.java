package com.spring.scenic.content.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.spring.scenic.basic.domain.ScenicSeller;
import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 内容管理-点评表
 * @author 006568（shuchang）
 * @date 2016年12月30日
 */
public class Comments extends Entity<Comments>{
	
    /**
     * 主键
     */
    private Integer id;

    /**
     * 会员id
     */
    private Integer memberid;

    /**
     * 发表时间
     */
    private Date publishTime;

    /**
     * 点评的主体资源id
     */
    private Integer cmmtMainId;

    /**
     * 人均费用
     */
    private String perCapitaFees;

    /**
     * 分类（字典数据）：景区、商户
     */
    private Short outType;

    /**
     * 分类子类（字典数据）：如古镇、自然山水
     */
    private Short outSubType;

    /**
     * 总评分(平均分)
     */
    private BigDecimal totalScore;

    /**
     * 1 未审核 2 已通过 3 审核不通过
     */
    private Short status;

    /**
     * 点评来源： 1微信 2 M网 3 安卓 4 ios 5 pc 6 系统导入
     */
    private Short cmmtFrom;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private Integer updateUser;

    /**
     * 点评内容
     */
    private String cmmtContent;
    
    /**
     * 业务字段-查询条件-点评人
     */
    private String evaluaterName;
    
    /**
     * 业务字段-查询条件-主体名称（景区商户）
     */
    private String sellerName;
    
    /**
     * 业务字段-查询条件-包含图片
     */
    private Integer includeImage;
    
    
    /**
     * 业务字段-点评者
     */
    private AuthUser evaluater;
    
    /**
     * 业务字段-点评主体
     */
    private ScenicSeller seller;
    
    /**
     * 业务字段-点评图片
     */
    private List<CommentsImage> commentsImages;
    
    /**
     * 业务字段-点评评分
     */
    private List<CommentsOption> commentsOptions;
    

	public AuthUser getEvaluater() {
		return evaluater;
	}

	public void setEvaluater(AuthUser evaluater) {
		this.evaluater = evaluater;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMemberid() {
		return memberid;
	}

	public void setMemberid(Integer memberid) {
		this.memberid = memberid;
	}

	public Date getPublishTime() {
		return publishTime;
	}

	public void setPublishTime(Date publishTime) {
		this.publishTime = publishTime;
	}

	public Integer getCmmtMainId() {
		return cmmtMainId;
	}

	public void setCmmtMainId(Integer cmmtMainId) {
		this.cmmtMainId = cmmtMainId;
	}

	public String getPerCapitaFees() {
		return perCapitaFees;
	}

	public void setPerCapitaFees(String perCapitaFees) {
		this.perCapitaFees = perCapitaFees;
	}

	public Short getOutType() {
		return outType;
	}

	public void setOutType(Short outType) {
		this.outType = outType;
	}

	public Short getOutSubType() {
		return outSubType;
	}

	public void setOutSubType(Short outSubType) {
		this.outSubType = outSubType;
	}

	public BigDecimal getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getCmmtFrom() {
		return cmmtFrom;
	}

	public void setCmmtFrom(Short cmmtFrom) {
		this.cmmtFrom = cmmtFrom;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getCmmtContent() {
		return cmmtContent;
	}

	public void setCmmtContent(String cmmtContent) {
		this.cmmtContent = cmmtContent;
	}

	public List<CommentsImage> getCommentsImages() {
		return commentsImages;
	}

	public void setCommentsImages(List<CommentsImage> commentsImages) {
		this.commentsImages = commentsImages;
	}

	public List<CommentsOption> getCommentsOptions() {
		return commentsOptions;
	}

	public void setCommentsOptions(List<CommentsOption> commentsOptions) {
		this.commentsOptions = commentsOptions;
	}

	public ScenicSeller getSeller() {
		return seller;
	}

	public void setSeller(ScenicSeller seller) {
		this.seller = seller;
	}

	public String getEvaluaterName() {
		return evaluaterName;
	}

	public void setEvaluaterName(String evaluaterName) {
		this.evaluaterName = evaluaterName;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public Integer getIncludeImage() {
		return includeImage;
	}

	public void setIncludeImage(Integer includeImage) {
		this.includeImage = includeImage;
	}
    
}