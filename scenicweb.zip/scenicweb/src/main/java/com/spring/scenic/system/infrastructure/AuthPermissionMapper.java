package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.AuthPermission;
import com.spring.scenic.system.domain.AuthRole;

public interface AuthPermissionMapper {
    
	List<AuthPermission> getPermissionList(AuthPermission permissionExpample);

	int deletePermissionByRole(AuthRole authRole);

	int saveBatchPermissions(List<AuthPermission> permissions);
	
}