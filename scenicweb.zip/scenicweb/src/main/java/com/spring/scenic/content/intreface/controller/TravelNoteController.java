package com.spring.scenic.content.intreface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.content.application.TravelNoteService;
import com.spring.scenic.content.domain.TravelNotes;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 内容管理-游记管理接口
 * @author 006568（shuchang）
 * @date 2016年12月22日
 */
@Controller
@RequestMapping("content/travelNote")
public class TravelNoteController extends BaseController{

	@Autowired 
	TravelNoteService travelNoteService;
	@Autowired
	KeywordService keywordService;
	
	@RequestMapping(value="travelNoteList",method=RequestMethod.GET)
	public String travelNoteList(){
		
		return "content/travelNote/travelNoteList";
	}
	
	@RequestMapping(value="travelNoteAdd",method=RequestMethod.GET)
	public String travelNoteAdd(HttpServletRequest request){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		request.setAttribute("userInfo", user);
		return "content/travelNote/travelNoteAdd";
	}
	/**
	 * 
	 *@Description:关键字
	 *@Auth: lichangmao
	 *@2017年1月18日
	 */
	@RequestMapping(value="travelNoteKeyword",method=RequestMethod.GET)
	public String travelNoteKeyword(HttpServletRequest request,Keyword keyword){
		List<Keyword> keywordList = keywordService.selectByTravelNoteKeywordList(keyword);
		if (keywordList!=null && keywordList.size()>0) {
			request.setAttribute("keywordList", keywordList);
		}else {
			request.setAttribute("keywordList", new ArrayList<Keyword>());
		}
		request.setAttribute("travelNoteId",keyword.getId());
		return "content/travelNote/travelNoteKeyword";
	}
	
	/**
	 * @Description 游记攻略管理分页数据接口
	 * @param request
	 * @param travelNote
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="getTravelNoteListData",method=RequestMethod.POST)
	public EntityData getTravelNoteListData(HttpServletRequest request,TravelNotes travelNote){
		travelNote.initDataTableParam(request);
		List<TravelNotes> travelNotes = travelNoteService.getTravelNoteList(travelNote,SysConstant.PAGE_TRUE);
		PageInfo<TravelNotes> page = new PageInfo<TravelNotes>(travelNotes);
		EntityData data = new EntityData(travelNote,page);
		return data;
	}
	

	/**
	 * @Description 保存游记、攻略和其文字、图片等附件
	 * @param travelNote 保存游记、攻略 基础信息
	 * @param coversImageFile 负面图片
	 * @param travelNotesDetailsFileNames 业务数据和附件的绑定标记
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2016年12月28日
	 */
	@ResponseBody
	@RequestMapping(value="saveTravelNote",method=RequestMethod.POST)
	public MessageData saveTravelNote(HttpServletRequest request,TravelNotes travelNote,String coversImageFile){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
		Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
		travelNoteService.saveTravelNote(user,travelNote,filesMap,coversImageFile);
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
	}
	
	/**
	 * @Description 修改游记、攻略和其文字、图片等附件
	 * @param travelNote 保存游记、攻略 基础信息
	 * @param coversImageFile 负面图片
	 * @param travelNotesDetailsFileNames 业务数据和附件的绑定标记
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年2月14日
	 */
	@ResponseBody
	@RequestMapping(value="updateTravelNote",method=RequestMethod.POST)
	public MessageData updateTravelNote(HttpServletRequest request,TravelNotes travelNote,String coversImageFile){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
		Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
		travelNoteService.updateTravelNote(user,travelNote,filesMap,coversImageFile);
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
	}
	
	/**
	 * @Description 查看游记攻略
	 * @param request
	 * @param travelNote
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月26日
	 */
	@RequestMapping(value="viewTravelNote",method=RequestMethod.GET)
	public String viewTravelNote(HttpServletRequest request,TravelNotes travelNote){
		TravelNotes viewTravelNote = travelNoteService.getTravelNoteWithDetail(travelNote);
		request.setAttribute("travelNote", viewTravelNote);
		return "content/travelNote/travelNoteView";
	}
	
	
	/**
	 * @Description 进入游记编辑页面
	 * @param request
	 * @param travelNote
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年2月13日
	 */
	@RequestMapping(value="editTravelNote",method=RequestMethod.GET)
	public String editTravelNote(HttpServletRequest request,TravelNotes travel){
		TravelNotes viewTravelNote = travelNoteService.getTravelNoteWithDetail(travel);
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		request.setAttribute("userInfo", user);
		request.setAttribute("travelNote", viewTravelNote);
		return "content/travelNote/travelNoteEdit";
	}
	
	
	/**
	 * @Description 审核游记攻略
	 * @param request
	 * @param travelNote
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2016年12月26日
	 */
	@ResponseBody
	@RequestMapping(value="saveAuditTravelNote",method=RequestMethod.POST)
	public MessageData saveAuditTravelNote(HttpServletRequest request,TravelNotes travelNote){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		if(travelNote.getId()==null||travelNote.getStatus()==null){
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		travelNoteService.saveAuditTravelNote(user,travelNote);
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
	}
	
	/**
	 * 删除关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月16日
	 */
	@ResponseBody
	@RequestMapping(value = "delTravelNoteKeyword" ,method=RequestMethod.POST)
	public String delTravelNoteKeyword(HttpServletRequest request, HttpServletResponse response,Keyword keyword){
		keywordService.delTravelNoteKeyword(keyword);
		return SysConstant.OPT_SUCCESS;
	}
	
}
