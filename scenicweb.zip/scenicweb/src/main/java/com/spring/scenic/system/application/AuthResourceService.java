package com.spring.scenic.system.application;

import java.util.List;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;


public interface AuthResourceService {

	/**
	 * 通过id查询菜单信息
	 * @param id
	 * @return
	 */
	AuthResource selectByPrimaryKey(Integer id);

	/**
	 * 启用禁用数据
	 * @param menu
	 * @param userInfo
	 */
	void updateForbiddenOrUseData(AuthResource menu, AuthUser userInfo);

	/**
	 * 查询菜单列表
	 * @param menu
	 * @param pageTrue
	 * @return
	 */
	List<AuthResource> queryMenuList(AuthResource menu, boolean pageTrue);
	/**
	 * 新增菜单模块
	 * @param menu
	 * @param userInfo
	 */
	void addMenu(AuthResource menu, AuthUser userInfo);
	/**
	 * 修改菜单模块
	 * @param menu
	 * @param userInfo
	 */
	void updateMenu(AuthResource menu, AuthUser userInfo);
	/**
	 * 新增子菜单
	 * @param menu
	 * @param userInfo
	 */
	void addMenuItem(AuthResource menu, AuthUser userInfo);
	/**
	 * 修改子菜单
	 * @param menu
	 * @param userInfo
	 */
	void updateMenuItem(AuthResource menu, AuthUser userInfo);


	List<AuthResource> getAuthResourceList(AuthResource authResource);
	/**
	 * 禁用菜单及其子菜单
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月11日
	 */
	void updateForbiddenItemMenu(AuthResource menu, AuthUser userInfo);

	/**
	 * 新增菜单功能
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月6日
	 */
	void addMenuFunction(AuthResource menu, AuthUser userInfo);

	/**
	 * 查询菜单功能列表
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月6日
	 */
	List<AuthResource> queryMenuFunctionList(AuthResource menu, boolean pageTrue);
	
	/**
	 * @Description 查看资源列表（被角色包含的会被标记）
	 * @param request
	 * @param role 角色信息
	 * @param resource 资源信息
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @param user 
	 * @date 2017年2月6日
	 */
	List<AuthResource> getResourceList(AuthResource resource, AuthRole role, AuthUser user, boolean pageAble);

	/**
	 * @Description 获取角色获取权限
	 * @param authRole
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月7日
	 */
	List<AuthResource> getResourceListByRole(AuthRole authRole);

	/**
	 * 校验菜单功能代码是否重复
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月8日
	 */
	int checkMenuCodeByParam(AuthResource menu);
	
	/**
	 * @Description 根据用户角色和
	 * @param userId 用户ID （可选）
	 * @param roleId 角色ID （必选）
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2016年12月2日
	 */
	List<AuthResource> getUserPermissionByRole(Integer userId, Integer roleId);
	/**
	 * 修改功能
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月13日
	 */
	void updateMenuFunction(AuthResource menu, AuthUser userInfo);
	
	
	
	
}
