package com.spring.scenic.member.application.impl;

import org.springframework.stereotype.Service;

import com.spring.scenic.member.application.MemberDocumentService;

/**
 * @Description:会员证件
 *@Auth: lichangmao
 *@2017年1月24日
 */
@Service
public class MemberDocumentServiceImpl implements MemberDocumentService{
	
	
}
