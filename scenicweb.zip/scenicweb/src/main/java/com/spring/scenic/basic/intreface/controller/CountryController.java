package com.spring.scenic.basic.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.CountryService;
import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;
/**
 * 国家管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "basic/country")
public class CountryController {
	@Autowired
	private CountryService countryService;
	/**
	 * 
	  * @Description: 国家管理页面跳转
	  * @param @return
	  * @return String
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:04
	 */
	@RequestMapping(value = "countryManagement")
	public String countryManagementMain() {
		return "/basic/country/countryManagementMain";
	}
	
	@RequestMapping(value = "countryManagementEdit")
	public String countryManagementEdit(HttpServletRequest request, HttpServletResponse response,Country country) {
		if (country.getId()!= null && !"".equals(country.getId())) {
			Country editVo = countryService.selectByPrimaryKey(country.getId());
			request.setAttribute("countryVo", editVo);
		}
		return "/basic/country/countryManagementEdit";
	}
	
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData resetCountryById(HttpServletRequest request, HttpServletResponse response,Country country){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysConstant.IS_FORBIDDEN_FLAG_NO.equals(country.getFlag())) {
			country.setValid(Short.valueOf(SysConstant.VALITY_NO));
		}else {
			country.setValid(Short.valueOf(SysConstant.VALITY_YES));
		}
		countryService.updateCountryById(country,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 
	  * @Description: 国家管理信息详情
	  * @param @param userDTO
	  * @param @param dataGrid
	  * @param @return
	  * @return DataGridResponse
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:22
	 */
	@RequestMapping(value = "queryCountryList" ,method=RequestMethod.POST)
	@ResponseBody
	public EntityData queryCountryList(HttpServletRequest request, HttpServletResponse response,Country country) {
		country.initDataTableParam(request);
		List<Country> list = countryService.queryCountry(country, SysConstant.PAGE_TRUE);
		PageInfo<Country> page = new PageInfo<Country>(list);
		EntityData data = new EntityData(country,page);
		return data;
	}
	@ResponseBody
	@RequestMapping(value = "insertCountry" ,method=RequestMethod.POST)
	public  MessageData addCountry(HttpServletRequest request, HttpServletResponse response,Country country){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (country.getId() == null) {
			countryService.addCountry(country,userInfo);
		}else {
			countryService.updateByPrimaryKey(country, userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	@ResponseBody
	@RequestMapping(value = "updateCountry" ,method=RequestMethod.POST)
	public MessageData updateCountry(HttpServletRequest request, HttpServletResponse response,Country country) throws Exception {
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		countryService.updateByPrimaryKey(country, userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
}
