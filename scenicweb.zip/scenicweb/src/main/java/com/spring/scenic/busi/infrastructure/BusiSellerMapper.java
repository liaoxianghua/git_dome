package com.spring.scenic.busi.infrastructure;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSeller;

public interface BusiSellerMapper {
   
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    List<BusiSeller> getBusiSellerList(BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    int updateBusiSellerStatus(BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    BusiSeller getBusiSellerById(BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    int addBusiSeller(BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    int updateBusiSeller(BusiSeller busiSeller);
}