/**
 * 
 */
package com.spring.scenic.cms.intreface.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.basic.domain.KeywordRef;
import com.spring.scenic.cms.application.SysConfigService;
import com.spring.scenic.cms.domain.SysConfig;
import com.spring.scenic.cms.domain.SysConfigPic;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.system.domain.AuthUser;

/** @Description:系统配置Controller层
 *  @author：ranmaoping
 *  @date:下午2:44:10 2017年3月6日
 *  @version:1.0
 */
@Controller
@RequestMapping("cms/sysConfig")
public class SysConfigController extends BaseController {
	
	@Autowired
	private SysConfigService sysConfigService;
	
	/**
	 * 进入系统配置页面
	 * @return
	 */
	@RequestMapping(value = "sysConfigPage",method = RequestMethod.GET)
	public String systemConfigList(HttpServletRequest request,
			HttpServletResponse response) {
		return "cms/sysConfig/sysConfigList";
	} 
	
	/**
	 * 进入内容配置页面
	 * @return
	 */
	@RequestMapping(value = "contentConfigPage",method = RequestMethod.GET)
	public String contentConfigList(HttpServletRequest request,
			HttpServletResponse response) {
		return "cms/contentConfig/contentConfigList";
	} 
	
	/**
	 * @Description: 进入系统配置分页界面
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return EntityData
	 * @author ranmaoping(004225)
	 * @date 上午11:18:49 2017年03月06日
	 */
	@ResponseBody
	@RequestMapping(value = "getsysConfigList", method = RequestMethod.POST)
	public EntityData sysConfigInfoList(HttpServletRequest request,HttpServletResponse response,SysConfig sysConfig) {
		sysConfig.initDataTableParam(request);
		List<SysConfig> list = sysConfigService.getsysConfigList(sysConfig,SysConstant.PAGE_TRUE);
		PageInfo<SysConfig> page = new PageInfo<SysConfig>(list);
		EntityData data = new EntityData(sysConfig, page);
		return data;
	}
	/**
	 * @Description: 进入系统配置新增界面
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年03月07日
	 */
	@RequestMapping(value = "sysConfigAdd", method = RequestMethod.GET)
	public String sysConfigAdd(HttpServletRequest request,HttpServletResponse response, SysConfig sysConfig) {
		request.setAttribute("operate", "new");
		return "cms/sysConfig/sysConfigEdit";
	}
	/**
	 * @Description: 进入系统配置编辑界面
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年03月07日
	 */
	@RequestMapping(value = "sysConfigUpdate", method = RequestMethod.GET)
	public String sysConfigUpdate(HttpServletRequest request,HttpServletResponse response, SysConfig sysConfig) {
		SysConfig sysConfigInfo = sysConfigService.getSysConfigInfoById(sysConfig);
		request.setAttribute("sysConfigInfo", sysConfigInfo);
		request.setAttribute("operate", "edit");
		return "cms/sysConfig/sysConfigEdit";
	}
	/**
	 * 更新系统配置状态
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "updateSysConfigStatus", method = RequestMethod.POST)
	public MessageData updateSysConfigStatus(HttpServletRequest request,HttpServletResponse response,SysConfig sysConfig) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(null!=userInfo) {
			this.sysConfigService.updateSysConfigStatus(userInfo, sysConfig);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
	}
	/**
	 * @Description 保存新增、编辑的系统配置信息
	 * @param user
	 * @param sysConfig
	 * @return 
	 * @author 冉茂平
	 * @date 2017年3月7日
	 */
	@ResponseBody
	@RequestMapping(value="saveSysConfig",method=RequestMethod.POST)
	public MessageData saveMaterialAuthorized(HttpServletRequest request,SysConfig sysConfig){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		sysConfigService.saveSysConfig(user,sysConfig);
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	/**
	 * 进入图文链接管理页面
	 * @return
	 */
	@RequestMapping(value = "sysConfigPicManage",method = RequestMethod.GET)
	public String sysConfigPicList(HttpServletRequest request,HttpServletResponse response,SysConfig sysConfig) {
		if(null!=sysConfig.getId()) {
			SysConfig sysConfigInfo =sysConfigService.getSysConfigInfoById(sysConfig);
			request.setAttribute("sysConfigInfo", sysConfigInfo);
		}
		return "cms/contentConfig/sysConfigPicList";
	}
	/**
	 * @Description: 查询图文链接类型的信息
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return EntityData
	 * @author ranmaoping(004225)
	 * @date 上午11:18:49 2017年03月06日
	 */
	@ResponseBody
	@RequestMapping(value = "getSysConfigPic", method = RequestMethod.POST)
	public EntityData getSysConfigPic(HttpServletRequest request,HttpServletResponse response,SysConfigPic sysConfigPic) {
		sysConfigPic.initDataTableParam(request);
		List<SysConfigPic> list = sysConfigService.getSysConfigPic(sysConfigPic,SysConstant.PAGE_TRUE);
		PageInfo<SysConfigPic> page = new PageInfo<SysConfigPic>(list);
		EntityData data = new EntityData(sysConfigPic, page);
		return data;
	}
	/**
	 * @Description: 进入图文链接新增界面
	 * @param request
	 * @param response
	 * @param sysConfigPicInfo
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年03月07日
	 */
	@RequestMapping(value = "sysConfigPicAdd", method = RequestMethod.GET)
	public String sysConfigPicAdd(HttpServletRequest request,HttpServletResponse response, SysConfigPic sysConfigPicInfo) {
	    SysConfig sysConfig = new SysConfig();
	    sysConfig.setId(sysConfigPicInfo.getSysConfigId());
	    SysConfig sysConfigInfo =sysConfigService.getSysConfigInfoById(sysConfig);
	    request.setAttribute("sysConfigInfo", sysConfigInfo);
		request.setAttribute("sysConfigPicInfo", sysConfigPicInfo);
		request.setAttribute("operate", "new");
		return "cms/contentConfig/sysConfigPicEdit";
	}
	/**
	 * @Description: 进入图文链接编辑界面
	 * @param request
	 * @param response
	 * @param sysConfig
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年03月07日
	 */
	@RequestMapping(value = "sysConfigPicUpdate", method = RequestMethod.GET)
	public String sysConfigPicUpdate(HttpServletRequest request,HttpServletResponse response, SysConfigPic sysConfigPic) {
	    SysConfig sysConfigInfo =sysConfigService.getSysConfigInfoByPicId(sysConfigPic.getId());
	    SysConfigPic sysConfigPicInfo = sysConfigService.getSysConfigPicInfoById(sysConfigPic);
        request.setAttribute("sysConfigInfo", sysConfigInfo);
		request.setAttribute("sysConfigPicInfo", sysConfigPicInfo);
		request.setAttribute("operate", "new");
		return "cms/contentConfig/sysConfigPicEdit";
	}
	
	/**
	 * @Description 弹出选择图片的窗口
	 * @param request
	 * @param sysConfigPic
	 * @return String
	 * @author ranmaoping
	 * @date 2017年3月08日
	 */
	@RequestMapping(value = "sysConfigPicChoose")
	public String sysConfigPicChoose(HttpServletRequest request,SysConfigPic sysConfigPic) {
		return "cms/contentConfig/sysConfigPicChoose";
	}
	
	/**
	 * @Description 保存新增、编辑的图文链接信息
	 * @param sysConfigPic
	 * @param sysConfig
	 * @return 
	 * @author 冉茂平
	 * @date 2017年3月7日
	 */
	@ResponseBody
	@RequestMapping(value="saveSysConfigPic",method=RequestMethod.POST)
	public MessageData saveSysConfigPic(HttpServletRequest request,SysConfigPic sysConfigPic){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		sysConfigService.saveSysConfigPic(user,sysConfigPic);
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	/**
     * 删除图文链接信息
     * @param request
     * @param response
     * @param sysConfig
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "deleteSysConfigPic", method = RequestMethod.POST)
    public MessageData deleteSysConfigPic(HttpServletRequest request,HttpServletResponse response,SysConfigPic sysConfigPic) {
        this.sysConfigService.deleteSysConfigPic(sysConfigPic);
        return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
    }
	/**
	 * @Description 进入系统配置推荐关键字添加页面
	 * @param request
	 * @param sysConfigPic
	 * @return
	 * @author 冉茂平
	 * @date 2017年3月8日
	 */
	@RequestMapping(value="sysConfigKeyWords",method=RequestMethod.GET)
	public String sysConfigKeyWords(HttpServletRequest request,HttpServletResponse response,SysConfig sysConfig){
		if(null!=sysConfig.getId()) {
			KeywordRef keywordRef = new KeywordRef();
			keywordRef.setOutRelatedId(sysConfig.getId());
			List<KeywordRef> keywordRefList = sysConfigService.getRealtiveKeywordList(keywordRef);
			SysConfig sysConfigInfo =sysConfigService.getSysConfigInfoById(sysConfig);
			request.setAttribute("sysConfigInfo", sysConfigInfo);
			request.setAttribute("keywordRefInfo", keywordRef);
			request.setAttribute("keywordRefList", keywordRefList);
		}
		return "cms/contentConfig/sysConfigKeyWords";
	}
	/**
	 * @Description 联想查询内容配置关键字
	 * @param keyword
	 * @return
	 * @author 冉茂平
	 * @date 2017年3月15日
	 */
	@ResponseBody
	@RequestMapping(value="getSysConfigKeywordsByImagine",method=RequestMethod.POST)
	public Map<String, Object> getSysConfigKeywordsByImagine(Keyword keyword) {
		List<Keyword> list  = sysConfigService.getSysConfigKeywordsByImagine(keyword);
		Map<String, Object> map = new HashMap<String, Object>();
        map.put("flag","success");
        map.put("data",list);
        return map;
	}
	/**
	 * @Description 保存内容配置关键字
	 * @param sysConfigKeyword
	 * @return 
	 * @author 冉茂平
	 * @date 2017年3月15日
	 */
	@ResponseBody
	@RequestMapping(value="saveSysConfigKeyword",method=RequestMethod.POST)
	public KeywordRef saveSysConfigKeyword(HttpServletRequest request,KeywordRef keywordRef,Keyword keyword){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		KeywordRef keywordRefDto = sysConfigService.saveSysConfigKeyword(user,keywordRef,keyword);
		return keywordRefDto;
	}
	/**
     * 删除系统配置关键字
     * @param request
     * @param response
     * @param sysConfig
     * @return
     * @author 冉茂平
     * @date 2017年3月15日
     */
    @ResponseBody
    @RequestMapping(value = "deleteSysConfigKeyword", method = RequestMethod.POST)
    public MessageData deleteSysConfigKeyword(HttpServletRequest request,HttpServletResponse response,KeywordRef keywordRef) {
        this.sysConfigService.deleteSysConfigKeyword(keywordRef);
        return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
    }
    /**
     * 系统配置关键字拖拽排序
     * @param request
     * @param response
     * @param sysConfig
     * @return
     * @author 冉茂平
     * @date 2017年3月15日
     */
    @ResponseBody
    @RequestMapping(value = "updateSysConfigKeywordOrder", method = RequestMethod.POST)
    public MessageData updateSysConfigKeywordOrder(HttpServletRequest request,HttpServletResponse response,KeywordRef keywordRef) {
        this.sysConfigService.updateSysConfigKeywordOrder(keywordRef);
        return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
    }
}
