/**
 * 
 */
package com.spring.scenic.member.application;

import java.util.List;

import com.spring.scenic.member.domain.Collection;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.Order;
import com.spring.scenic.member.domain.OrderInvoice;
import com.spring.scenic.member.domain.OrderMoneyChangeRec;
import com.spring.scenic.member.domain.OrderPayRecord;

/**	@Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:12:58 2017年1月17日
 *  @version:1.0
 *
 */
public interface MemberBasicService {

	/**
	 * @param member
	 * @param pageTrue
	 * @return
	 */
	List<MemberBasic> getMemberList(MemberBasic member, boolean pageAble);

	/**
	 * @param member
	 * @return
	 */
	MemberBasic getMemberDetailInfo(MemberBasic member);

	/**
	 * @param member
	 */
	void saveMemberBasicInfo(MemberBasic member);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月29日     
     * @memo ：   
     **
     */
    List<Order> getMemberOrders(Order order, boolean pageAble);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月29日     
     * @memo ：   
     **
     */
    List<Collection> getMemberCollections(Collection collection, boolean pageAble);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    Order getMemberOrderDetail(Order order);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    OrderInvoice getOrderInvoiceInfo(String orderNo);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    List<OrderMoneyChangeRec> getChangeRecList(String orderNo);
    
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    List<OrderPayRecord> getPayRecListList(String orderNo);

}
