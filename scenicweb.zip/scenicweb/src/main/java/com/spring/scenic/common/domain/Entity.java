package com.spring.scenic.common.domain;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.spring.scenic.common.config.SysConstant;

/**
 * @Description 系统实体对象基类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public class Entity<T>{
	
	/**
	 * 数据库主键对应的序列，保存时将该序列（即主键）返回
	 */
	private Integer sequence;
	
	/**
	 * Datatable插件参数（固定），前后台交互次数
	 */
	protected long draw;
	
	/**
	 * 开始页码
	 */
	protected int pageNum; 
	
	/**
	 * 分页大小
	 */
	protected Integer pageSize; 
	
	/**
	 * 排序字段
	 */
	protected String orderField;
	
	/**
	 * 排序方式
	 */
	protected String orderDirection; 
	
	/**
	 * 数据行号
	 */
	protected Long row_id;
	
	/**
	 * 开始日期
	 */
	protected Date startDate; 
	
	/**
	 * 结束日期
	 */
	protected Date endDate; 
	
	/**
	 * 数据库中排序条件（数据库字段对应的实体属性需驼峰标示）
	 */
	protected String orderByClause;
	

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getRow_id() {
		return row_id;
	}

	public void setRow_id(Long row_id) {
		this.row_id = row_id;
	}

	public long getDraw() {
		return draw;
	}

	public void setDraw(long draw) {
		this.draw = draw;
	}

	public String getOrderField() {
		return orderField;
	}

	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}

	public String getOrderDirection() {
		return orderDirection;
	}

	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	
	public String getOrderByClause() {
		return orderByClause;
	}

	public void setOrderByClause(String orderByClause) {
		this.orderByClause = orderByClause;
	}
	

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * @Description: 前端datagrid分页情况下初始化分页必要参数
	 * @param request 
	 * @return void
	 * @author shuchang
	 * @date 2016年8月9日
	 */
	public void initDataTableParam(HttpServletRequest request) {
		//开始数据索引
		String start = request.getParameter("start")==null?null:request.getParameter("start").toString(); 
		//排序方式 ASC/desc
		String dir = request.getParameter("order[0][dir]")==null?null:request.getParameter("order[0][dir]").toString();
		//按照第几个字段排序
		String orderNum = request.getParameter("order[0][column]")==null?null:request.getParameter("order[0][column]").toString();
		//排序字段
		String order = request.getParameter("columns["+orderNum+"][data]"); 
		//Datatable与后台交互次数
		draw = Long.parseLong(request.getParameter("draw")==null?"0":request.getParameter("draw").toString()); 
		
		if(!StringUtils.isEmpty(start)){
			pageNum =  Integer.parseInt(start)/SysConstant.PAGE_PAGESIZE + 1;
		}
		if(StringUtils.isNotEmpty(order)){
			orderField = order.replaceAll("[ ][;]*","");
		}
		if(!StringUtils.equalsIgnoreCase(dir, "asc") && !StringUtils.equalsIgnoreCase(dir, "desc")){
			orderDirection = "asc";
		}else{
			orderDirection = dir;
		}
		if(StringUtils.isNotBlank(orderField)){
			this.orderByClause = setOrderByClause(orderField,orderDirection);
		}
	}

	/**
	 * 
	 * @Description: 将对象排序字段、排序方式封装成数据库字段排序样式
	 * @param orderField	排序字段
	 * @param orderDirection	排序方式
	 * @return String	封装后的数据库字段排序样式
	 * @author shuchang
	 * @date 2016年8月9日
	 */
	private String setOrderByClause(String orderField, String orderDirection) {
		String orderByClause = "";
		for (int i = 0; i < orderField.length(); i++) {
			char c = orderField.charAt(i);
			if(Character.isUpperCase(c)){
				orderByClause+="_";
			}
			orderByClause+=String.valueOf(c);
		}
		return (orderByClause+" "+orderDirection).toUpperCase();
	}

}
