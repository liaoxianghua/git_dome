package com.spring.scenic.basic.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

	public class MapMessage extends Entity<MapMessage> implements Serializable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1387299469145065287L;
		private Integer id;
		private Integer scenicId;//景区id
		private Integer scenicParentId;//上级景区id
		private Integer mapType;//地图类型1 百度 2 谷歌 3 高德 4 腾讯
		private String mapLgn;//经度
		private String mapLat;//纬度
		private Integer outRelatedType;//1:地标 2:城市 3：景区 商户
		private Integer outRelatedId;//外部关联id;
		private Integer valid;//1 有效 0 无效
	    private Integer createUser;
	    private String createuserName;
	    private Date createTime;
	    private Integer updateUser;
	    private Date updateTime;
	    
	    
	    
		public Integer getOutRelatedType() {
			return outRelatedType;
		}
		public void setOutRelatedType(Integer outRelatedType) {
			this.outRelatedType = outRelatedType;
		}
		public Integer getValid() {
			return valid;
		}
		public void setValid(Integer valid) {
			this.valid = valid;
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public Integer getMapType() {
			return mapType;
		}
		public void setMapType(Integer mapType) {
			this.mapType = mapType;
		}
		public Integer getScenicId() {
			return scenicId;
		}
		public void setScenicId(Integer scenicId) {
			this.scenicId = scenicId;
		}
		public Integer getScenicParentId() {
			return scenicParentId;
		}
		public void setScenicParentId(Integer scenicParentId) {
			this.scenicParentId = scenicParentId;
		}
		public String getMapLgn() {
			return mapLgn;
		}
		public void setMapLgn(String mapLgn) {
			this.mapLgn = mapLgn;
		}
		public String getMapLat() {
			return mapLat;
		}
		public void setMapLat(String mapLat) {
			this.mapLat = mapLat;
		}
		public Integer getCreateUser() {
			return createUser;
		}
		public void setCreateUser(Integer createUser) {
			this.createUser = createUser;
		}
		public String getCreateuserName() {
			return createuserName;
		}
		public void setCreateuserName(String createuserName) {
			this.createuserName = createuserName;
		}
		public Date getCreateTime() {
			return createTime;
		}
		public void setCreateTime(Date createTime) {
			this.createTime = createTime;
		}
		public Integer getUpdateUser() {
			return updateUser;
		}
		public void setUpdateUser(Integer updateUser) {
			this.updateUser = updateUser;
		}
		public Date getUpdateTime() {
			return updateTime;
		}
		public void setUpdateTime(Date updateTime) {
			this.updateTime = updateTime;
		}
		
		public boolean equals(Object obj) {
	        if (obj instanceof MapMessage) {
	        	MapMessage message = (MapMessage) obj;
	            return (id.equals(message.id));
	        }
	        return super.equals(obj);
	    }
		public Integer getOutRelatedId() {
			return outRelatedId;
		}
		public void setOutRelatedId(Integer outRelatedId) {
			this.outRelatedId = outRelatedId;
		}
		
}
