package com.spring.scenic.material.domain;

import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 素材库实体
 * @author 006568（shuchang）
 * @date 2017年1月4日
 */
public class Material extends Entity<Material>{
    /**
     * 主键
     */
    private Integer id;

    /**
     * 素材名称
     */
    private String name;

    /**
     * 素材地址
     */
    private String url;

    /**
     * 1 图片 2 音频 3 视频
     */
    private Integer type;

    /**
     * 素材描述
     */
    private String descriptions;

    /**
     * 素材用途类型 数据字典 material_usertype
     */
    private Integer usertype;

    /**
     * 授权id
     */
    private Integer authorizedId;

    /**
     * 1 未审核 2 已通过 3 未通过
     */
    private Integer examineStatus;
    
    /**
     * 审核人
     */
    private Integer examineUser;

    /**
     * 审核时间
     */
    private Date examineTime;

    /**
     * 审核备注
     */
    private String examineRemarks;

    /**
     * 1 有效 0 无效
     */
    private Integer valid;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private Integer updateUser;
    
    /**
     * 业务字段：素材集合
     */
    private List<Material> materials;
    
    /**
     * 业务字段：审核人名
     */
    private String examineUserName;
    
    /**
     * 业务字段：创建人名
     */
    private String createUserName;
    
    /**
     * 业务字段：审核机构
     */
    private MaterialAuthorized authorized;
    
    /**
     * 业务字段：创建人
     */
    private AuthUser creater;

	public AuthUser getCreater() {
		return creater;
	}

	public void setCreater(AuthUser creater) {
		this.creater = creater;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}

	public Integer getUsertype() {
		return usertype;
	}

	public void setUsertype(Integer usertype) {
		this.usertype = usertype;
	}

	public Integer getAuthorizedId() {
		return authorizedId;
	}

	public void setAuthorizedId(Integer authorizedId) {
		this.authorizedId = authorizedId;
	}

	public Integer getExamineStatus() {
		return examineStatus;
	}

	public void setExamineStatus(Integer examineStatus) {
		this.examineStatus = examineStatus;
	}

	public Date getExamineTime() {
		return examineTime;
	}

	public void setExamineTime(Date examineTime) {
		this.examineTime = examineTime;
	}

	public String getExamineRemarks() {
		return examineRemarks;
	}

	public void setExamineRemarks(String examineRemarks) {
		this.examineRemarks = examineRemarks;
	}

	public Integer getValid() {
		return valid;
	}

	public void setValid(Integer valid) {
		this.valid = valid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public List<Material> getMaterials() {
		return materials;
	}

	public void setMaterials(List<Material> materials) {
		this.materials = materials;
	}

	public Integer getExamineUser() {
		return examineUser;
	}

	public void setExamineUser(Integer examineUser) {
		this.examineUser = examineUser;
	}

	public String getExamineUserName() {
		return examineUserName;
	}

	public void setExamineUserName(String examineUserName) {
		this.examineUserName = examineUserName;
	}

	public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public MaterialAuthorized getAuthorized() {
		return authorized;
	}

	public void setAuthorized(MaterialAuthorized authorized) {
		this.authorized = authorized;
	}

}