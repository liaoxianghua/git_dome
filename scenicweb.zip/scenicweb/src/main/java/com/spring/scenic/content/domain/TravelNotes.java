package com.spring.scenic.content.domain;

import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description 游记攻略信息表
 * @author 006568（shuchang）
 * @date 2016年12月22日
 */
public class TravelNotes extends Entity<TravelNotes> {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 作者
     */
    private String authorName;

    /**
     * 类别：1 游记 2 攻略
     */
    private Integer type;

    /**
     * 封面图片地址
     */
    private String coversImageUrl;
    
    /**
     * 封面图片名称
     */
    private String coversImageName;

    /**
     * 出发时间
     */
    private Date departureDate;

    /**
     * 人均费用
     */
    private String fee;

    /**
     * 人物
     */
    private String persons;

    /**
     * 出行天数
     */
    private String days;

    /**
     * 有效性：1 有效 0 无效
     */
    private Short valid;

    /**
     * 审核状态：1 未审核 2 已审核 3 未通过
     */
    private Short status;

    /**
     * 发表时间
     */
    private Date publishDate;

    /**
     * 审核人
     */
    private Integer reviewedUser;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer createUser;
    
    /**
     * 创建人类别
     */
    private Integer createUserType;
    
    private String createUserName;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private Integer updateUser;
    
    
    /**
     * 业务字段：攻略游记内容
     */
    private List<TravelNotesDetails> travelNotesDetails;
    
    /**
     * 业务字段：审核人名
     */
    private String reviewedUserName;
    
    
	public String getReviewedUserName() {
		return reviewedUserName;
	}

	public void setReviewedUserName(String reviewedUserName) {
		this.reviewedUserName = reviewedUserName;
	}

	public List<TravelNotesDetails> getTravelNotesDetails() {
		return travelNotesDetails;
	}

	public void setTravelNotesDetails(List<TravelNotesDetails> travelNotesDetails) {
		this.travelNotesDetails = travelNotesDetails;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCoversImageUrl() {
		return coversImageUrl;
	}

	public void setCoversImageUrl(String coversImageUrl) {
		this.coversImageUrl = coversImageUrl;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getPersons() {
		return persons;
	}

	public void setPersons(String persons) {
		this.persons = persons;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public Short getValid() {
		return valid;
	}

	public void setValid(Short valid) {
		this.valid = valid;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public Integer getReviewedUser() {
		return reviewedUser;
	}

	public void setReviewedUser(Integer reviewedUser) {
		this.reviewedUser = reviewedUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getCoversImageName() {
		return coversImageName;
	}

	public void setCoversImageName(String coversImageName) {
		this.coversImageName = coversImageName;
	}

    public Integer getCreateUserType() {
        return createUserType;
    }

    public void setCreateUserType(Integer createUserType) {
        this.createUserType = createUserType;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

}