package com.spring.scenic.system.intreface.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;


/**
 * @Description 系统字典
 * @author 006568（shuchang）
 * @date 2016年12月29日
 */
@Controller
@RequestMapping(value="system/dictionary")
public class DictionaryController {

	@Autowired
	private DictionaryService dictionaryService;
	
	@Autowired
	private AuthUserService authUserService;
	
	/**
	 * @Description 字典列表页面
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@RequestMapping(value="dictionaryList",method=RequestMethod.GET)
	public String dictionaryList() {
		return "/system/dictionary/dictionaryList";
	}
	
	/**
	 * @Description 字典添加页面
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@RequestMapping(value="dictionaryAdd",method=RequestMethod.GET)
	public String dictionaryAdd() {
		return "/system/dictionary/dictionaryEdit";
	}
	
	/**
	 * @Description 字典修改页面
	 * @param request
	 * @param dictionary
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@RequestMapping(value="dictionaryEdit",method=RequestMethod.GET)
	public String dictionaryEdit(HttpServletRequest request,Dictionary dictionary) {
		Dictionary exsitDictionary = dictionaryService.getDictionary(dictionary);
		request.setAttribute("dic", exsitDictionary);
		return "/system/dictionary/dictionaryEdit";
	}
	
	/**
	 * @Description 字典项添加参数界面
	 * @param request
	 * @param dictionary 父级字典
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@RequestMapping(value="dictionaryItemAdd",method=RequestMethod.GET)
	public String dictionaryItemAdd(HttpServletRequest request,Dictionary dictionary) {
		Dictionary parentDictionary = new Dictionary();
		parentDictionary.setId(dictionary.getParentId());
		Dictionary dicType = dictionaryService.getDictionary(parentDictionary);
		request.setAttribute("dictionaryItem", dictionary);
		request.setAttribute("dicType", dicType);
		return "/system/dictionary/dictionaryItemEdit";
	}
	
	/**
	 * @Description 字典项修改界面
	 * @param reques
	 * @param dictionary
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@RequestMapping(value="dictionaryItemEdit",method=RequestMethod.GET)
	public String dictionaryItemEdit(HttpServletRequest request,Dictionary dictionaryItem) {
		Dictionary exsitDictionaryItem = dictionaryService.getDictionary(dictionaryItem);
		request.setAttribute("dictionaryItem", exsitDictionaryItem);
		request.setAttribute("dicType", exsitDictionaryItem);
		return "/system/dictionary/dictionaryItemEdit";
	}
	
	/**
	 * @Description 无分页的字典列表树
	 * @param request
	 * @param dictionary
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@ResponseBody
	@RequestMapping(value="getDictionaryListData",method=RequestMethod.POST)
	public EntityData getDictionaryListData(HttpServletRequest request,Dictionary dictionary){
		dictionary.initDataTableParam(request);
		List<Dictionary> list = dictionaryService.getDictionaryList(dictionary,SysConstant.PAGE_FALSE); 
		PageInfo<Dictionary> page = new PageInfo<Dictionary>(list);
		EntityData data = new EntityData(dictionary,page);
		return data;
	}
	
	/**
	 * @Description 素材查询获取审核状态：无审核权限的仅显示已审核
	 * @param dictionary
	 * @return List<Dictionary>
	 * @author 006568（shuchang）
	 * @date 2017年3月1日
	 */
	@ResponseBody
	@RequestMapping(value="getDictionaryListByCode",method=RequestMethod.POST)
	public List<Dictionary> getDictionaryListByCode(Dictionary dictionary){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		List<Dictionary> list = dictionaryService.getDictionaryListByCode(dictionary); 
		if(!authUserService.authorityUser("R050203", user) && list!=null){
			Iterator<Dictionary> dIterator = list.iterator();
			while(dIterator.hasNext()){
				Dictionary cDictionary = dIterator.next();
				if(!cDictionary.getName().equals(SysEnum.MATERIAL_STATUS_PASS.getDescription())){
					dIterator.remove();
				}
			}
		}
		return list;
	}
	
	/**
	 * @Description 修改、保存字典或元素
	 * @param request
	 * @param dictionary
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@ResponseBody
	@RequestMapping(value="saveDictionary",method=RequestMethod.POST)
	public MessageData saveDictionary(HttpServletRequest request,Dictionary dictionary){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		dictionaryService.saveDictionary(user,dictionary); 
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	
	/**
	 * @Description 删除字典及其子元素数据
	 * @param request
	 * @param dictionary
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@ResponseBody
	@RequestMapping(value="deleteDictionary",method=RequestMethod.POST)
	public MessageData deleteDictionary(HttpServletRequest request,Dictionary dictionary){
		dictionaryService.deleteDictionary(dictionary); 
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	
	/**
	 * @Description 字典初始化
	 * @param request
	 * @param dictionary
	 * @return Map<String,List<Dictionary>>
	 * @author 006568（shuchang）
	 * @date 2016年12月29日
	 */
	@ResponseBody
	@RequestMapping(value="initDictionary",method=RequestMethod.POST)
	public Map<String, List<Dictionary>> initDictionary(HttpServletRequest request,Dictionary dictionary){
		Map<String, List<Dictionary>> dicMap = dictionaryService.initDictionary(dictionary); 
		return dicMap;
	}
	
}
