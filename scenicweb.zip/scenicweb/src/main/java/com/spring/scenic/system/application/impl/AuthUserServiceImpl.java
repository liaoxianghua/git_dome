package com.spring.scenic.system.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.common.util.RSAUtils;
import com.spring.scenic.common.util.ScenicSecurityTool;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.dto.PasswordVo;
import com.spring.scenic.system.domain.dto.UserLogVo;
import com.spring.scenic.system.infrastructure.AuthResourceMapper;
import com.spring.scenic.system.infrastructure.AuthRoleMapper;
import com.spring.scenic.system.infrastructure.AuthUserLogMapper;
import com.spring.scenic.system.infrastructure.AuthUserMapper;
import com.spring.scenic.system.infrastructure.AuthUserRoleMapper;

@Service
public class AuthUserServiceImpl implements AuthUserService {
	
	@Resource
	private AuthUserMapper authUserMapper;
	@Resource
	private AuthUserLogMapper authUserLogMapper;
	@Resource
	private AuthUserRoleMapper authUserRoleMapper;
	@Resource
	private AuthRoleMapper roleMapper;
	
	@Resource
	private AuthResourceMapper authResourceMapper;
	
	@Override
	public AuthUser getUserByAccount(String username) {
		return authUserMapper.getUserByAccount(username);
	}

	@Override
	public List<AuthRole> getUserAuthRoleList(AuthUser authUser) {
		return authUserMapper.getUserAuthRoleList(authUser);
	}

	@Override
	public List<AuthResource> getUserAuthResourceList(AuthUser authUser) {
		return authUserMapper.getUserAuthResourceList(authUser);
	}

	@Override
	public List<AuthUser> queryUserList(AuthUser authUser, boolean pageTrue) {
		if(pageTrue){
			PageHelper.startPage(authUser.getPageNum(), SysConstant.PAGE_PAGESIZE);
		}
		return authUserMapper.queryUserList(authUser);
	}

	@Override
	public MessageData addUser(AuthUser authUser, AuthUser userInfo) {
		try {
		    MessageData messageData = new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
		    //校验username 是否重复 ，如果重复，提示
		    int count = authUserMapper.selectCountByParam(authUser);
		    if(count>0) {
		        messageData.setStatusCode(201);
		        messageData.setMessage("该用户名已被使用,请重先输入！");
		        return messageData;
		    }
			Date date = DateUtil.getNow();
			authUser.setCreateUser(userInfo.getId());
			authUser.setCreateTime(date);
			authUser.setPassword(MD5.getMD5Encode(SysConstant.INITIAL_PASSWORD));
			//新增前加入日志表
			UserLogVo userLogVo = new UserLogVo();
			userLogVo.setOptBy(userInfo.getId());
			userLogVo.setOptTime(date);
			userLogVo.setOptType(Integer.valueOf(SysEnum.USER_LOG_TYPE_ADD.getCode()));
			authUserLogMapper.addUserLog(userLogVo);
			authUserMapper.addUser(authUser);
			return messageData;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateByPrimaryKey(AuthUser authUser, AuthUser userInfo) {
		try {
			Date date = DateUtil.getNow();
			AuthUser userVo  = new AuthUser();
			userVo = authUserMapper.selectUserByPrimaryKey(authUser.getId());
			userVo.setUsername(authUser.getUsername());
			userVo.setTruename(authUser.getTruename());
			userVo.setType(authUser.getType());
			userVo.setDepartmentId(authUser.getDepartmentId());
			userVo.setValid(authUser.getValid());
			userVo.setTel(authUser.getTel());
			userVo.setPhone(authUser.getPhone());
			userVo.setQq(authUser.getQq());
			userVo.setWeixin(authUser.getWeixin());
			userVo.setEmail(authUser.getEmail());
			userVo.setModifyUser(userInfo.getId());
			userVo.setModifyTime(date);
			//记录日志
			UserLogVo userLogVo = new UserLogVo();
			userLogVo.setOptBy(userInfo.getId());
			userLogVo.setOptTime(date);
			userLogVo.setOptType(Integer.valueOf(SysEnum.USER_LOG_TYPE_UPDATE.getCode()));
			authUserLogMapper.addUserLog(userLogVo);
			authUserMapper.updateByPrimaryKey(userVo);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	@Override
	public void updateForbiddenOrUseData(AuthUser authUser, AuthUser userInfo) {
		try {
			authUser.setModifyTime(new Date());
			authUser.setModifyUser(userInfo.getId());
			authUser.setPassword(MD5.getMD5Encode(SysConstant.INITIAL_PASSWORD));
			authUserMapper.updateForbiddenOrUseData(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Department> initDeptOptions(AuthUser authUser) {
		try {
			return authUserMapper.initDeptOptions(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Map<Object, Object> checkUserAccountIsExist(AuthUser authUser) {
		try {
			Map<Object, Object> map = new HashMap<Object, Object>();;
			try {
				int count = authUserMapper.queryUserByUserName(authUser);
				if (count>0) {
					map.put("error", "该账号名已经存在！");
				}else {
					map.put("ok", "");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return map;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public AuthUser selectUserByPrimaryKey(Integer id) {
		try {
			return authUserMapper.selectUserByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public MessageData updateUserById(AuthUser authUser, AuthUser userInfo) {
		try {
		    MessageData messageData = new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
            //校验username 是否重复 ，如果重复，提示
            int count = authUserMapper.selectCountByParam(authUser);
            if(count>0) {
                messageData.setStatusCode(201);
                messageData.setMessage("该用户名已被使用,请重先输入！");
                return messageData;
            }
			Date date = DateUtil.getNow();
			AuthUser userVo  = new AuthUser();
			userVo = authUserMapper.selectUserByPrimaryKey(authUser.getId());
			userVo.setUsername(authUser.getUsername());
			userVo.setTruename(authUser.getTruename());
			userVo.setType(authUser.getType());
			userVo.setDepartmentId(authUser.getDepartmentId());
			userVo.setValid(authUser.getValid());
			userVo.setTel(authUser.getTel());
			userVo.setPhone(authUser.getPhone());
			userVo.setQq(authUser.getQq());
			userVo.setWeixin(authUser.getWeixin());
			userVo.setEmail(authUser.getEmail());
			userVo.setModifyUser(userInfo.getId());
			userVo.setModifyTime(date);
			//记录日志
			UserLogVo userLogVo = new UserLogVo();
			userLogVo.setOptBy(userInfo.getId());
			userLogVo.setOptTime(date);
			userLogVo.setOptType(Integer.valueOf(SysEnum.USER_LOG_TYPE_UPDATE.getCode()));
			authUserLogMapper.addUserLog(userLogVo);
			authUserMapper.updateUserById(userVo);
			return messageData;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}		
	}

	@Override
	public void updateUserPassword(AuthUser authUser,AuthUser userInfo) {
		try {
			Date date = DateUtil.getNow();
			authUser.setPassword(MD5.getMD5Encode(SysConstant.INITIAL_PASSWORD));
			authUser.setModifyUser(userInfo.getId());
			authUser.setModifyTime(date);
			//记录日志
			UserLogVo userLogVo = new UserLogVo();
			userLogVo.setOptBy(userInfo.getId());
			userLogVo.setOptTime(date);
			userLogVo.setOptType(Integer.valueOf(SysEnum.USER_LOG_TYPE_RESET.getCode()));
			authUserLogMapper.addUserLog(userLogVo);
			authUserMapper.updateUserPassword(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * 我的信息页面-修改密码
	 */
	@Override
	public AuthUser updatePassword(PasswordVo vo,AuthUser loginUser) {
		try {
			AuthUser userInfo=null;
			if(loginUser !=null){
				userInfo= authUserMapper.queryUserInfoById(loginUser.getId());
			}
			String flag = "";
			vo.setOldPassword(RSAUtils.decryptStringByJs(vo.getOldPassword()));//对原密码进行解密
			String md5Password = MD5.getMD5Encode(vo.getOldPassword());//对原密码进行MD5加密
			if (userInfo !=null && userInfo.getPassword().equals(md5Password)) {//判断加密的密码是否一致
				vo.setConfirmPass(RSAUtils.decryptStringByJs(vo.getConfirmPass()));
				vo.setNewPassword(RSAUtils.decryptStringByJs(vo.getNewPassword()));
				if(!vo.getOldPassword().equals(vo.getNewPassword())){
					if ((vo.getConfirmPass().equals(vo.getNewPassword()))) {//判断确认密码和新密码是否相同
						String regex="^(?![0-9]+$)(?![A-Za-z]+$)(?![^A-Za-z0-9]+$)([^\\f\\n\\r\\t\\v\\s]){6,20}$";
						Pattern pattern=Pattern.compile(regex);
						Matcher matcher=pattern.matcher(vo.getNewPassword());
						if(matcher.matches()){//验证通过
						   String Password = ScenicSecurityTool.MD5(vo.getNewPassword());//将新密码加密
							vo.setNewPassword(Password);//重新设置密码
							vo.setUserId(loginUser.getId());
							this.authUserMapper.updatePassword(vo);	//更新密码		
							flag = SysConstant.MESSAGE_TYPE_SUCCESS;	//返回成功	 
					   }else{
						   flag= SysConstant.MESSAGE_TYPE_NOTMATCH;
					   }
					}else{
						flag= SysConstant.MESSAGE_TYPE_ERROR;//当密码不一致返回error
					}
				}else{
					flag= SysConstant.MESSAGE_TYPE_SAME;//当新密码与原密码相同返回same
				}
			} else {
				flag= SysConstant.MESSAGE_TYPE_FAIL;//当原密码不一致返回fail
			}
			loginUser.setFlag(flag);
			return loginUser;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.error.systemupdatepassword"), e);
		}
	}
	/**
	 * 我的信息页面-更新联系方式
	 */
	public AuthUser updateContactInfo(AuthUser authUser) {
		try {
			authUser.setModifyUser(authUser.getId());
			authUser.setModifyTime(new Date());
			this.authUserMapper.updateContactInfo(authUser);
			return authUser;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	@Override
	public List<UserLogVo> queryUserLogList(UserLogVo logVo, boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(logVo.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<UserLogVo> resultList = authUserLogMapper.queryUserLogList(logVo);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * @Description 查询用户的角色信息
	 * @param authUserRole
	 * @param pageTrue
	 * @return List
	 * @author 004225（ranmaoping）
	 * @date 2017年2月7日
	 */
	public List<AuthUserRole> getUserRoleList(AuthUserRole authUserRole,
			boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(authUserRole.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<AuthUserRole> resultList = authUserRoleMapper.getRoleUserList(authUserRole);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * @Description 查询用户的角色信息
	 * @param authUser
	 * @param pageTrue
	 * @return List
	 * @author 004225（ranmaoping）
	 * @date 2017年2月7日
	 */
	@Override
	public List<AuthRole> getRoleListByUser(AuthUser authUser) {
		try {
			List<AuthRole> roles = roleMapper.queryRoleList(new AuthRole());
			List<AuthRole> assignedList = roleMapper.getRoleListByUser(authUser);
			for (AuthRole assignedRole : assignedList) {
				for (AuthRole allRole : roles) {
					if(allRole.getId().equals(assignedRole.getId())){
						allRole.setAssigned(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
						break;
					}
				}
			}
			return roles;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * @Description 保存用户的角色信息
	 * @param authUserRole
	 * @param pageTrue
	 * @return List
	 * @author 004225（ranmaoping）
	 * @date 2017年2月7日
	 */	
	@Override
	public void saveUserRole(AuthUser userInfo, AuthUserRole authUserRole,String roleIds) {
		try {
			if(null!=authUserRole.getUserId()) {
				//保存用户角色前，删除该用户原有的角色
				authUserRoleMapper.deleteUserRoleByUserId(authUserRole);
				String[] roleIdArray;
				if(StringUtil.isNotEmpty(roleIds)) {
					List<AuthUserRole> authUserRoles = new ArrayList<AuthUserRole>();
					roleIdArray = roleIds.split(",");
					for(int i=0;i<roleIdArray.length;i++) {
						AuthUserRole authUserRoleDto = new AuthUserRole();
						String roleId = roleIdArray[i];
						authUserRoleDto.setUserId(authUserRole.getUserId());
						authUserRoleDto.setRoleId(Integer.valueOf(roleId));
						authUserRoleDto.setCreateTime(new Date());
						authUserRoleDto.setCreateUser(userInfo.getId());
						authUserRoleDto.setUpdateTime(new Date());
						authUserRoleDto.setUpdateUser(userInfo.getId());
						//记录日志
						UserLogVo userLogVo = new UserLogVo();
						userLogVo.setOptBy(userInfo.getId());
						userLogVo.setOptTime(new Date());
						userLogVo.setOptType(Integer.valueOf(SysEnum.USER_LOG_TYPE_UPDATE_PERMISSIONS.getCode()));
						authUserLogMapper.addUserLog(userLogVo);
						authUserRoles.add(authUserRoleDto);
					}
					//批量保存用户角色
					if(null!=authUserRoles&&authUserRoles.size()>0) {
						authUserRoleMapper.insertUserRoleByBatch(authUserRoles);
					}
					
				}
			}
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	@Override
	public List<AuthRole> setlectRoleByUserId(AuthUser authUser) {
		try {
			return roleMapper.setlectRoleByUserId(authUser);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public boolean authorityUser(String code, AuthUser user) {
		try {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("code", code);
			map.put("userId", user.getId());
			List<AuthResource> userResouces = authResourceMapper.authorityUser(map);
			return userResouces!=null&&!userResouces.isEmpty() ;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public String getResourcesByUser(AuthUser user) {
		try {
			List<AuthResource> userResouces = authResourceMapper.getResourcesByUser(user);
			StringBuffer menu =new StringBuffer();
			if(userResouces!=null && !userResouces.isEmpty()){
				for (AuthResource resource : userResouces) {
					if(Integer.valueOf(SysEnum.RESOURCE_TYPE_MODULE.getCode()).equals(resource.getType())){
						menu.append("<li><a style='cursor:pointer;'><i class=\"\"></i><span class=\"title\">");
						menu.append(resource.getName()); 
						menu.append("</span><span class=\"arrow\"></span></a>");
						menu.append(getSubNote(resource,userResouces));				 
						menu.append("</li>");
					}
				}
			}
			return menu.toString();
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	public String getSubNote(AuthResource moduleResource,List<AuthResource> resources){
		try {
			StringBuffer menuSub =new StringBuffer();
			menuSub.append("<ul class=\"sub-menu\">");
			for (AuthResource resource : resources) {
				if(Integer.valueOf(SysEnum.RESOURCE_TYPE_MENU.getCode()).equals(resource.getType()) && moduleResource.getId().equals(resource.getParentId())){
					menuSub.append("<li><a addtabs='"+resource.getCode()+ "' style='cursor:pointer;' url='"+resource.getUrl()+ "'><i class=\"fa fa-file-o\"></i>");
					menuSub.append(resource.getName()); 
					menuSub.append("</a></li>");
				}
				continue;
			}
			menuSub.append("</ul>");
			return menuSub.toString();
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
