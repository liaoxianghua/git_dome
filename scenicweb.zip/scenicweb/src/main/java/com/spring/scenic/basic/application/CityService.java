package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.City;
import com.spring.scenic.basic.domain.CityArea;

public interface CityService {

	/**
	 * @param city
	 * @return
	 */
	List<City> getCityList(City city);

	/**
	 * @param city
	 * @return
	 */
	City getCityInfoById(City city);

	/**
	 * @param city
	 */
	void saveCity(City city);

	/**
	 * @param cityArea
	 * @param pageFalse 
	 * @return
	 */
	List<CityArea> getCityAreaList(CityArea cityArea, boolean pageFalse);

	/**
	 * @param cityArea
	 */
	void saveCityArea(CityArea cityArea);

	/**
	 * @param cityArea
	 * @return
	 */
	CityArea getCityAreaInfoById(CityArea cityArea);

	/**
	 * @param cityArea
	 * @return
	 */
	List<CityArea> getCantonList(CityArea cityArea);

	/**
	 * @param city
	 */
	void updateCityStatus(City city);

	/**
	 * @param cityArea
	 */
	void updateCityAreaStatus(CityArea cityArea);

	/**
	 * @param city
	 * @return
	 */
	List<City> getCityByCountryOrProvince(City city);

}
