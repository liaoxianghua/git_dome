package com.spring.scenic.content.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.content.domain.TravelNotes;
import com.spring.scenic.system.domain.AuthUser;

public interface TravelNoteService {

	List<TravelNotes> getTravelNoteList(TravelNotes travelNote, Boolean pageAble);

	int saveTravelNote(AuthUser user, TravelNotes travelNote, Map<String, List<MultipartFile>> filesMap,String coversImageFile);

	TravelNotes getTravelNoteWithDetail(TravelNotes travelNote);

	int saveAuditTravelNote(AuthUser user, TravelNotes travelNote);

	List<Keyword> getKeywordListById(Integer id);

	int updateTravelNote(AuthUser user, TravelNotes travelNote,Map<String, List<MultipartFile>> filesMap, String coversImageFile);

}
