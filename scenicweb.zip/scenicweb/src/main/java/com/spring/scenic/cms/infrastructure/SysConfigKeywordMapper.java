package com.spring.scenic.cms.infrastructure;

import com.spring.scenic.cms.domain.SysConfigKeyword;

public interface SysConfigKeywordMapper {

	int saveSysConfigKeyword(SysConfigKeyword sysConfigKeyword);

	int getSysConfigKeywordCount();
}