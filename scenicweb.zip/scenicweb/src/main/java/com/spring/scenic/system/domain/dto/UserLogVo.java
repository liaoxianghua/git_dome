package com.spring.scenic.system.domain.dto;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description:用户日志
 *@Auth: lichangmao
 *@2017年1月18日
 */
public class UserLogVo extends Entity<UserLogVo> implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6898637039376857726L;

	private Integer id;
	
	private Integer optType;
	
	private Date optTime;
	
	private Integer optBy;
	
	private String optByName;

	
	
	public String getOptByName() {
		return optByName;
	}

	public void setOptByName(String optByName) {
		this.optByName = optByName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOptType() {
		return optType;
	}

	public void setOptType(Integer optType) {
		this.optType = optType;
	}

	public Date getOptTime() {
		return optTime;
	}

	public void setOptTime(Date optTime) {
		this.optTime = optTime;
	}

	public Integer getOptBy() {
		return optBy;
	}

	public void setOptBy(Integer optBy) {
		this.optBy = optBy;
	}
	
	
	
}	
