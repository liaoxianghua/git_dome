package com.spring.scenic.basic.domain;

import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class CityLandMark extends Entity<CityLandMark> {
	/**
	 * 主键
	 */
    private Integer id;
    /**
	 * 操作人id
	 */
	private Integer userId;
	/**
	 * 地标名称
	 */
    private String name;
    /**
     * 国家名称
     */
    private String countryName;
    /**
     * 外关联id
     */
    private Integer outRelatedId;
    /**
     * 外关联类型
     */
    private Integer outRelatedType;
    /**
     * 类型
     */
    private String type;
    /**
     * 城市id
     */
    private Integer cityId;
    /**
     * 类型id
     */
    private Integer typeId;

    /**
	 * 状态 1：有效 ,0：无效
	 */
    private String valid;
    /**
	 * 状态 1：有效 ,0：无效
	 */
    private Integer status;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 位置信息
     */
    private String positionInfo;
    /**
     * 创建人姓名
     */
    private String createName;
    /**
     * 城市名
     */
    private String cityName;
    /**
     * 地图经纬度信息集合
     */
    private List<MapMessage> liMapMessages;
    /**
     * 创建人
     */
	private Integer createUser;
	/**
	 * 更新时间
	 */
    private Date updateTime;
    /**
	 * 国家状态 1:有效 0：无效
	 */
	private Integer countryValid;
	/**
	 * 城市状态状态 1:有效 0：无效
	 */
	private Integer cityValid;
    /**
    * 更新人
    */
    private Integer updateUser;
    /**
	 * 操作人
	 */
    /**
     * 交通站类型名称
     */
    private String typeName;
    
	private String updateName;
	
    private String baiduLgn;//经度
	
	private String baiduLat;//纬度
	//高德经纬度
	
	private String gaodeLgn;//经度
	
	private String gaodeLat;//纬度
	//谷歌经纬度
	
	private String googleLgn;//经度
	
	private String googleLat;//纬度
	//腾讯经纬度
	
	private String txLgn;//经度
	
	private String txLat;//纬度
  
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   
    public String getName() {
        return name;
    }

  
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

  
    public String getType() {
        return type;
    }

   
    public void setType(String type) {
        this.type = type;
    }

   
    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

 
    public String getValid() {
        return valid;
    }

    public void setValid(String valid) {
        this.valid = valid;
    }

   
    public Date getCreateTime() {
        return createTime;
    }

  
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    
    public Integer getCreateUser() {
        return createUser;
    }

   
    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

   
    public Date getUpdateTime() {
        return updateTime;
    }

   
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

   
    public Integer getUpdateUser() {
        return updateUser;
    }

   
    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

/*	public String getCityid() {
		return cityid;
	}

	public void setCityid(String cityid) {
		this.cityid = cityid;
	}*/

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	private String lgn;
	
	private String lat;
	
	public String getBaiduLgn() {
		return baiduLgn;
	}

	public void setBaiduLgn(String baiduLgn) {
		this.baiduLgn = baiduLgn;
	}

	public String getBaiduLat() {
		return baiduLat;
	}

	public void setBaiduLat(String baiduLat) {
		this.baiduLat = baiduLat;
	}

	public String getGaodeLgn() {
		return gaodeLgn;
	}

	public void setGaodeLgn(String gaodeLgn) {
		this.gaodeLgn = gaodeLgn;
	}

	public String getGaodeLat() {
		return gaodeLat;
	}

	public void setGaodeLat(String gaodeLat) {
		this.gaodeLat = gaodeLat;
	}

	public String getGoogleLgn() {
		return googleLgn;
	}

	public void setGoogleLgn(String googleLgn) {
		this.googleLgn = googleLgn;
	}

	public String getGoogleLat() {
		return googleLat;
	}

	public void setGoogleLat(String googleLat) {
		this.googleLat = googleLat;
	}

	public String getTxLgn() {
		return txLgn;
	}

	public void setTxLgn(String txLgn) {
		this.txLgn = txLgn;
	}

	public String getTxLat() {
		return txLat;
	}

	public void setTxLat(String txLat) {
		this.txLat = txLat;
	}

	public String getLgn() {
		return lgn;
	}

	public void setLgn(String lgn) {
		this.lgn = lgn;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public Integer getOutRelatedId() {
		return outRelatedId;
	}

	public void setOutRelatedId(Integer outRelatedId) {
		this.outRelatedId = outRelatedId;
	}

	public Integer getOutRelatedType() {
		return outRelatedType;
	}

	public void setOutRelatedType(Integer outRelatedType) {
		this.outRelatedType = outRelatedType;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<MapMessage> getLiMapMessages() {
		return liMapMessages;
	}

	public void setLiMapMessages(List<MapMessage> liMapMessages) {
		this.liMapMessages = liMapMessages;
	}
    
	public String getPositionInfo() {
		return positionInfo;
	}

	public void setPositionInfo(String positionInfo) {
		this.positionInfo = positionInfo;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getCountryValid() {
		return countryValid;
	}

	public void setCountryValid(Integer countryValid) {
		this.countryValid = countryValid;
	}

	public Integer getCityValid() {
		return cityValid;
	}

	public void setCityValid(Integer cityValid) {
		this.cityValid = cityValid;
	}
	
	
}