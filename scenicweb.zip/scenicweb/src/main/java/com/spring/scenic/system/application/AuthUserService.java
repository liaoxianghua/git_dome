package com.spring.scenic.system.application;

import java.util.List;
import java.util.Map;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.dto.PasswordVo;
import com.spring.scenic.system.domain.dto.UserLogVo;

public interface AuthUserService {
	
	AuthUser getUserByAccount(String username);

	List<AuthRole> getUserAuthRoleList(AuthUser authUser);

	List<AuthResource> getUserAuthResourceList(AuthUser authUser);
	/**
	 * 查询用户信息分页列表
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	List<AuthUser> queryUserList(AuthUser authUser, boolean pageTrue);

	/**
	 * 新增用户信息
	 * @return 
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	MessageData addUser(AuthUser authUser, AuthUser userInfo);

	/**
	 * 修改用户信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	void updateByPrimaryKey(AuthUser authUser, AuthUser userInfo);

	/**
	 * 启用禁用数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	void updateForbiddenOrUseData(AuthUser authUser, AuthUser userInfo);

	/**
	 * 加载部门下拉框数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	List<Department> initDeptOptions(AuthUser authUser);

	/**
	 * 校验用户名是否存在
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	Map<Object, Object> checkUserAccountIsExist(AuthUser authUser);

	/**
	 * 通过id查询用户
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	AuthUser selectUserByPrimaryKey(Integer id);

	/**
	 * 更新用户信息
	 * @return 
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	MessageData updateUserById(AuthUser authUser, AuthUser userInfo);

	/**
	 * 重置密码
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月10日
	 */
	void updateUserPassword(AuthUser authUser,AuthUser userInfo);

	/**我的信息页面 修改密码
	 * @param vo
	 * @param userInfo
	 * @Auth: ranmaoping
	 * @2017年1月14日
	 * @return
	 */
	AuthUser updatePassword(PasswordVo vo, AuthUser userInfo);
	/**
	 * @param authUser
	 * @return
	 */
	AuthUser updateContactInfo(AuthUser authUser);

	/**
	 * 
	 *@Description:查询用户操作日志
	 *@Auth: lichangmao
	 *@2017年1月18日
	 */
	List<UserLogVo> queryUserLogList(UserLogVo logVo, boolean pageTrue);

	/**
	 * @param authUserRole
	 * @param pageFalse
	 * @return
	 */
	List<AuthUserRole> getUserRoleList(AuthUserRole authUserRole,
			boolean pageFalse);

	List<AuthRole> getRoleListByUser(AuthUser authUser);

	/**保存用户角色信息
	 * @param userInfo
	 * @param authUserRole
	 * @param roleIds 
	 */
	void saveUserRole(AuthUser userInfo, AuthUserRole authUserRole, String roleIds);


	/**
	 * 通过userId查询对应的角色信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月10日
	 */
	List<AuthRole> setlectRoleByUserId(AuthUser authUser);

	/**
	 * @Description 生成用户菜单
	 * @param user
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年2月13日
	 */
	String getResourcesByUser(AuthUser user);

	/**
	 * @Description 验证用户是否有权限（true：有；false：无）
	 * @param code
	 * @param user
	 * @return boolean
	 * @author 006568（shuchang）
	 * @date 2017年3月1日
	 */
	boolean authorityUser(String code, AuthUser user);

}
