package com.spring.scenic.system.intreface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.system.application.AuthResourceService;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.dto.PasswordVo;
import com.spring.scenic.system.domain.dto.UserLogVo;

/**
 * @Description 系统管理-用户管理
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
@Controller
@RequestMapping("system/user")
public class AuthUserController extends BaseController{
	
	@Autowired
	private AuthUserService authUserService;
	
	@Autowired
	private AuthResourceService resourceService;
	
	
	@RequestMapping(value="userManagement",method=RequestMethod.GET)
	public String userManagement(){
		return "/system/user/userManagementMain";
	}
	/**
	 *@Description:新增编辑页面弹出框
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	@RequestMapping(value="userManagementEdit",method=RequestMethod.GET)
	public String userManagementEdit(HttpServletRequest request, HttpServletResponse response, AuthUser authUser){
		if (authUser.getId()!=null) {
			AuthUser authUserVo = authUserService.selectUserByPrimaryKey(authUser.getId());
			request.setAttribute("authUserVo", authUserVo);
		}
		return "/system/user/userManagementEdit";
	}
	/**
	 * 
	 *@Description:用户日志页面
	 *@Auth: lichangmao
	 *@2017年1月18日
	 */
	@RequestMapping(value="userLogView",method=RequestMethod.GET)
	public String userLogView(HttpServletRequest request, HttpServletResponse response, AuthUser authUser){
		if (authUser.getId()!=null) {
			AuthUser authUserVo = authUserService.selectUserByPrimaryKey(authUser.getId());
			request.setAttribute("authUserVo", authUserVo);
		}
		return "/system/user/userLogView";
	}
	
	/**
	 * @Description 用户角色查看列表
	 * @param request
	 * @param authUser
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月2日
	 */
	@RequestMapping(value="userRole",method=RequestMethod.GET)
	public String userRole(HttpServletRequest request, AuthUser authUser){
		if (authUser.getId()!=null) {
			request.setAttribute("authUserVo", authUser);
		}
		return "/system/user/userRole";
	}
	/**
	 * @Description 查看用户角色信息列表
	 * @param request
	 * @param authUserRole
	 * @return EntityData
	 * @author 004225（ranmaoping）
	 * @date 2017年2月9日
	 */
	@ResponseBody
	@RequestMapping(value = "getUserRoleList" ,method=RequestMethod.POST)
	public EntityData getRoleUserList(HttpServletRequest request, AuthRole role,AuthUser authUser) {
		if(authUser.getId()!=null){
			role.initDataTableParam(request);
			List<AuthRole> roleList = authUserService.getRoleListByUser(authUser);
			PageInfo<AuthRole> page = new PageInfo<AuthRole>(roleList);
			EntityData data = new EntityData(role,page);
			return data;
		}
		return new EntityData(new ArrayList<AuthRole>());
	}
	/**
	 * @Description 查看用户角色信息列表
	 * @param request
	 * @param authUserRole
	 * @return EntityData
	 * @author 004225（ranmaoping）
	 * @date 2017年2月9日
	 */
	@ResponseBody
	@RequestMapping(value = "saveUserRole" ,method=RequestMethod.POST)
	public MessageData saveUserRole(HttpServletRequest request, AuthUserRole authUserRole,String roleIds) {
		AuthUser userInfo = (AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (userInfo == null) {
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		this.authUserService.saveUserRole(userInfo, authUserRole,roleIds);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null,"", null);
	}
	
	/**
	 * @Description 用户权限查看列表
	 * @param request
	 * @param authUser
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2016年12月2日
	 */
	@RequestMapping(value="userPermission",method=RequestMethod.GET)
	public String userPermission(HttpServletRequest request, AuthUser authUser){
		AuthUser authUserVo = new AuthUser();
		List<AuthRole> authRoleList = new ArrayList<AuthRole>();
		if (authUser.getId()!=null) {
			authUserVo = authUserService.selectUserByPrimaryKey(authUser.getId());
			authRoleList = authUserService.setlectRoleByUserId(authUser);
		}
		request.setAttribute("authUserVo", authUserVo);
		request.setAttribute("authRoleList", authRoleList);
		return "/system/user/userPermission";
	}
	
	@RequestMapping(value="addUserRole",method=RequestMethod.GET)
	public String addUserRole(HttpServletRequest request, AuthUser authUser){
		return "/system/user/userRoleAdd";
	}
	
	/**
	 * @Description 根据用户角色和
	 * @param userId 用户ID （可选）
	 * @param roleId 角色ID （必选）
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2016年12月2日
	 */
	@ResponseBody
	@RequestMapping(value="getUserPermissionByRole",method=RequestMethod.POST)
	public List<AuthResource> getUserPermissionByRole(HttpServletRequest request,AuthResource resource,Integer userId, Integer roleId){
		//resource.initDataTableParam(request);
		List<AuthResource> list = resourceService.getUserPermissionByRole(userId, roleId);
		//PageInfo<AuthResource> page = new PageInfo<AuthResource>(list);
		//EntityData data = new EntityData(resource,page);
		return list==null?new ArrayList<AuthResource>():list;
	}
	
	/**
	 * 查询用户列表信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value="queryUserList",method=RequestMethod.POST)
	public EntityData queryUserList(HttpServletRequest request,AuthUser authUser) throws Exception{
		authUser.initDataTableParam(request);
		List<AuthUser> list = authUserService.queryUserList(authUser, SysConstant.PAGE_TRUE);
		PageInfo<AuthUser> page = new PageInfo<AuthUser>(list);
		EntityData data = new EntityData(authUser,page);
		return data;
	}
	/**
	 * 新增修改用户
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value = "opterateUser" ,method=RequestMethod.POST)
	public  MessageData opterateUser(HttpServletRequest request, HttpServletResponse response,AuthUser authUser) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		MessageData messageData = new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
		if (authUser.getId()==null || "".equals(authUser.getId())) {
		    messageData = authUserService.addUser(authUser,userInfo);
		}else {
		    messageData = authUserService.updateUserById(authUser,userInfo);
		}
		return messageData;
	}
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,AuthUser authUser) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysEnum.COMMON_USEABLE_NO.getCode().equals(authUser.getFlag())) {
			authUser.setValid(Short.valueOf(SysEnum.COMMON_USEABLE_NO.getCode()));
		}else {
			authUser.setValid(Short.valueOf(SysEnum.COMMON_USEABLE_YES.getCode()));
		}
		authUserService.updateForbiddenOrUseData(authUser,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 加载数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value = "initDeptOptions",method=RequestMethod.POST)
	public List<Department> initDeptOptions(HttpServletRequest request, HttpServletResponse response,AuthUser authUser) throws Exception {
		List<Department> resultList = authUserService.initDeptOptions(authUser);
		return resultList;
	}
	/**
	 * 加载数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	@ResponseBody
	@RequestMapping(value = "checkUserAccountIsExist",method=RequestMethod.POST)
	public Map<Object, Object> checkUserAccountIsExist(HttpServletRequest request, HttpServletResponse response,AuthUser authUser) throws Exception {
		Map<Object,Object> resultMap = authUserService.checkUserAccountIsExist(authUser);
		return resultMap;
	}
	@ResponseBody
	@RequestMapping(value="updateUserPassword",method=RequestMethod.POST)
	public MessageData updateUserPassword(HttpServletRequest request, HttpServletResponse response,AuthUser authUser) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		authUserService.updateUserPassword(authUser,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
	/**
	 * 跳转到我的信息页面
	 * @param request
	 * @param response
	 * @param authUser
	 * @Auth: ranmaoping
	 * @2017年1月14日
	 * @return
	 */
	@RequestMapping(value="myInformation",method=RequestMethod.GET)
	public String userInfo(HttpServletRequest request, HttpServletResponse response, AuthUser authUser){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (userInfo.getId()!=null) {
			request.setAttribute("myInformation", userInfo);
		}
		return "/system/user/myInformation";
	}
	
	/**
	 * 我的信息页面—密码修改
	 * @param request
	 * @param response
	 * @param vo
	 * @Auth: ranmaoping
	 * @2017年1月14日
	 * @return
	 */
	@RequestMapping(value="updatePassword",method=RequestMethod.POST)
	@ResponseBody
	public String newPasswordPage(HttpServletRequest request,HttpServletResponse response,PasswordVo vo){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		AuthUser uvo=this.authUserService.updatePassword(vo,userInfo);
 		if(SysConstant.MESSAGE_TYPE_SUCCESS.equals(uvo.getFlag())){
			reloadLoginUser(request, uvo);
			return "ok";
		}else{
			return uvo.getFlag();
		}
	}
	
	@ResponseBody
	@RequestMapping(value="updateContactInfo",method=RequestMethod.POST)
	public MessageData updateContactInfo(HttpServletRequest request,HttpServletResponse response,AuthUser authUser){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		authUser.setId(userInfo.getId());
		AuthUser vo = this.authUserService.updateContactInfo(authUser);
		reloadLoginUser(request, vo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
	/**
	 * 
	 *@Description:查询用户操作日志
	 *@Auth: lichangmao
	 *@2017年1月18日
	 */
	@ResponseBody
	@RequestMapping(value="queryUserLogList",method=RequestMethod.POST)
	public EntityData queryUserLogList(HttpServletRequest request,UserLogVo logVo) throws Exception{
		logVo.initDataTableParam(request);
		List<UserLogVo> list = authUserService.queryUserLogList(logVo, SysConstant.PAGE_TRUE);
		PageInfo<UserLogVo> page = new PageInfo<UserLogVo>(list);
		EntityData data = new EntityData(logVo,page);
		return data;
	}
	
	
	/**
	 * @Description 用户标签权限查询
	 * @param request
	 * @param code 权限编码
	 * @return boolean 是否 通过
	 * @author 006568（shuchang）
	 * @date 2017年2月13日
	 */
	@ResponseBody
	@RequestMapping(value="authUser",method=RequestMethod.POST)
	public boolean authUser(HttpServletRequest request,String code) {
		AuthUser user =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		return authUserService.authorityUser(code, user);
	}
	
	/**
	 * @Description 初始化界面
	 * @param request
	 * @param userInfo 用户
	 * @throws Exception
	 * @author 006568（shuchang）
	 * @date 2017年2月13日
	 */
	@ResponseBody
	@RequestMapping(value="initResource",method=RequestMethod.POST)
	public String initResource(HttpServletRequest request,AuthUser userInfo) throws Exception{
		AuthUser user =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		return authUserService.getResourcesByUser(user);
	}
	
}
