/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 * 
 */
package com.spring.scenic.busi.application.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.infrastructure.ScenicCommercialMapper;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.infrastructure.BusiSellerMapper;
import com.spring.scenic.busi.infrastructure.BusiSellerUserMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;

/**
 * 此处为类说明:商户管理实现类
 * @author rmp
 * @date 2017年3月20日
 */
@Service
public class BusiSellerServiceImpl implements BusiSellerService {
    
    @Autowired
    private BusiSellerMapper busiSellerMapper;
    @Autowired
    private BusiSellerUserMapper busiSellerUserMapper;
    @Autowired
    private ScenicCommercialMapper scenicCommercialMapper;
    
    /**
     * 查询商户信息
     */
    @Override
    public List<BusiSeller> getBusiSellerList(BusiSeller busiSeller, boolean pageAble) {
        try {
            if (pageAble) {
                PageHelper.startPage(busiSeller.getPageNum(),SysConstant.PAGE_PAGESIZE);
            }
            List<BusiSeller> list = busiSellerMapper.getBusiSellerList(busiSeller);
            return list;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
    }
    
    /**
     * 启用禁用商户
     */
    @Override
    public int updateBusiSellerStatus(AuthUser userInfo, BusiSeller busiSeller) {
        try {
            busiSeller.setUpdateTime(new Date());
            busiSeller.setUpdateUser(userInfo.getId());
            return busiSellerMapper.updateBusiSellerStatus(busiSeller);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
        
    }
    
    /**
     * 根据id查询商户信息
     */
    @Override
    public BusiSeller getBusiSellerById(BusiSeller busiSeller) {
        try {
            BusiSeller busiSellerInfo = busiSellerMapper.getBusiSellerById(busiSeller);
            return busiSellerInfo;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 初始化所属景区属性结构
     */
    @Override
    public List<ZtreeDept> initParentScenic(Department department) {
        try {
            List<ZtreeDept> resultList = scenicCommercialMapper.initParentScenic(department);
            return resultList;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 保存商户信息
     */
    @Override
    public int saveBusiSeller(AuthUser userInfo, BusiSeller busiSeller) {
        try {
            int count = 0;
            if(null==busiSeller.getId()) {
                busiSeller.setCreateTime(new Date());
                busiSeller.setCreateUser(userInfo.getId());
                busiSeller.setUpdateTime(new Date());
                busiSeller.setUpdateUser(userInfo.getId());
                count = busiSellerMapper.addBusiSeller(busiSeller);
            }else{
                BusiSeller busiSellerExample = busiSellerMapper.getBusiSellerById(busiSeller);
                busiSellerExample.setSellerName(busiSeller.getSellerName());
                busiSellerExample.setScenicSellerId(busiSeller.getScenicSellerId());
                busiSellerExample.setRemark(busiSeller.getRemark());
                busiSellerExample.setValid(busiSeller.getValid());
                busiSellerExample.setUpdateTime(new Date());
                busiSellerExample.setUpdateUser(userInfo.getId());
                count = busiSellerMapper.updateBusiSeller(busiSellerExample);
            }
            return count;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);  
        }
    }
    
    /**
     * 根据商户id查询商户账号信息
     */
    @Override
    public BusiSellerUser getSellerAccountById(Integer id) {
        try {
            BusiSellerUser busiSellerUser = busiSellerUserMapper.getSellerAccountById(id);
            return busiSellerUser;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 保存商户账号信息
     */
    @Override
    public MessageData saveBusiSellerUser(AuthUser userInfo, BusiSellerUser busiSellerUser) {
        try {
            MessageData messageData = new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
            //商户账号不能重复，新增编辑时，做重复校验
            int count = busiSellerUserMapper.selectAccountCountByParam(busiSellerUser);
            if(count>0) {
                messageData.setStatusCode(201);
                messageData.setMessage("该用户名已被使用,请重先输入！");
                return messageData;
            }else {
                if(null==busiSellerUser.getId()) {
                    busiSellerUser.setCreateTime(new Date());
                    busiSellerUser.setCreateUser(userInfo.getId());
                    busiSellerUser.setUpdateTime(new Date());
                    busiSellerUser.setUpdateUser(userInfo.getId());
                    busiSellerUser.setPwd(MD5.getMD5Encode(SysConstant.INITIAL_PASSWORD));
                    busiSellerUserMapper.addBusiSellerUser(busiSellerUser);
                }else{
                    BusiSellerUser busiSellerUserExample = busiSellerUserMapper.getSellerAccount(busiSellerUser);
                    busiSellerUserExample.setUsername(busiSellerUser.getUsername());
                    busiSellerUserExample.setTruename(busiSellerUser.getTruename());
                    busiSellerUserExample.setValid(busiSellerUser.getValid());
                    busiSellerUserExample.setTel(busiSellerUser.getTel());
                    busiSellerUserExample.setPhone(busiSellerUser.getPhone());
                    busiSellerUserExample.setQq(busiSellerUser.getQq());
                    busiSellerUserExample.setWeixin(busiSellerUser.getWeixin());
                    busiSellerUserExample.setEmail(busiSellerUser.getEmail());
                    busiSellerUserExample.setUpdateTime(new Date());
                    busiSellerUserExample.setUpdateUser(userInfo.getId());
                    busiSellerUserMapper.updateBusiSellerUser(busiSellerUserExample);
                }
            }
            return messageData;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    

}
