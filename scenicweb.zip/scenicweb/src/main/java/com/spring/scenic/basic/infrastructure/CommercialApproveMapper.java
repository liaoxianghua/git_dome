package com.spring.scenic.basic.infrastructure;

import com.spring.scenic.basic.domain.CommercialApprove;


public interface CommercialApproveMapper {
  
    int deleteByPrimaryKey(Integer id);

    int insert(CommercialApprove record);

    int insertSelective(CommercialApprove record);

    CommercialApprove selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(CommercialApprove record);

    int updateByPrimaryKey(CommercialApprove record);

	int addCommercialApprove(CommercialApprove commercialApprove);



}