package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.OrderMoneyChangeRec;

public interface OrderMoneyChangeRecMapper {

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    List<OrderMoneyChangeRec> getChangeRecList(String orderNo);
    
}