package com.spring.scenic.material.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description 景区商户图片
 * @author 006568（shuchang）
 * @date 2017年1月9日
 */
public class Pictures extends Entity<Pictures>{
    /**
     */
    private Integer id;

    /**
     */
    private String url;

    /**
     */
    private String name;

    /**
     */
    private String remarks;

    /**
     */
    private Integer logo;

    /**
     */
    private Integer valid;

    /**
     */
    private Integer relatedId;

    /**
     */
    private Date createTime;

    /**
     */
    private Integer createUser;

    /**
     */
    private Date updateTime;

    /**
     */
    private Integer updateUser;

    /**
     */
    private Integer categoryType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getLogo() {
		return logo;
	}

	public void setLogo(Integer logo) {
		this.logo = logo;
	}

	public Integer getValid() {
		return valid;
	}

	public void setValid(Integer valid) {
		this.valid = valid;
	}

	public Integer getRelatedId() {
		return relatedId;
	}

	public void setRelatedId(Integer relatedId) {
		this.relatedId = relatedId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Integer getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(Integer categoryType) {
		this.categoryType = categoryType;
	}

}