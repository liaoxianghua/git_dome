package com.spring.scenic.system.infrastructure;

import java.util.List;
import java.util.Map;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthResourceItem;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;


public interface AuthResourceMapper {
	
	/**
	 * @Description 获取所有有效资源及被分配的无效资源
	 * @param map
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月20日
	 */
	List<AuthResource> getDefaultOrAssignedResourceList(Map<String,Object> map);

	List<AuthResource> getValidOrAssignedResourceList(Map<String, Object> selectMap);
	
	List<AuthResourceItem> selectMenuItemList(AuthResource menu);

	AuthResource selectByPrimaryKey(Integer id);

	void insertMenu(AuthResource menu);

	void updateMenu(AuthResource menu);

	void forbiddenOrUseData(AuthResource menu);

	List<AuthResource> getAuthResourceList(AuthResource authResource);

	List<AuthResource> selectByPrimaryIdList(
			List<String> parentIdList);

	void updateForbiddenItemMenu(AuthResource menu);

	void updateByPrimaryKey(AuthResource authResource);

	List<AuthResource> queryMenuFunctionList(AuthResource menu);

	List<AuthResource> selectMenuListNew(AuthResource resource);

	/**
	 * @Description 根据角色获取权限
	 * @param authRole
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月7日
	 */
	List<AuthResource> getResourceListByRole(AuthRole authRole);
	/**
	 * 校验菜单功能是否重复
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月8日
	 */
	int checkMenuCodeByParam(AuthResource menu);

	List<AuthResource> getResourcesByUser(AuthUser user);

	int getFunctionCountByParentId(AuthResource menu);

	int getModuleCount(AuthResource menu);

	/**
	 * @Description 验证用户
	 * @param map
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年2月13日
	 */
	List<AuthResource> authorityUser(Map<String, Object> map);

	List<AuthResource> getValidResourceList(Map<String, Object> selectMap);

	
	
}