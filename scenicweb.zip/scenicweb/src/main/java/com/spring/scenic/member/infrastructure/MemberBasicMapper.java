package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;

public interface MemberBasicMapper {
    int deleteByPrimaryKey(Integer id);
    
    int insert(MemberBasic record);
    
    int insertSelective(MemberBasic record);
    
    MemberBasic selectByPrimaryKey(Integer id);
    
    int updateByPrimaryKeySelective(MemberBasic record);
    
    int updateByPrimaryKey(MemberBasic record);
    
	List<MemberBasic> getMemberList(MemberBasic member);

	MemberBasic getMemberDetailInfo(MemberBasic member);

	void updateMemberBasicInfo(MemberBasic member);

	void updateMemberDetailInfo(MemberDetailInfo memberDetailInfo);
}