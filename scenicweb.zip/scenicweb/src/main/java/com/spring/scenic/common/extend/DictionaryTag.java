package com.spring.scenic.common.extend;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.material.domain.MaterialAuthorized;
import com.spring.scenic.material.infrastructure.MaterialAuthorizedMapper;
import com.spring.scenic.system.domain.Dictionary;

/**
 * @Description 字典标签
 * @author 006568（shuchang）
 * @date 2017年2月10日
 */
public class DictionaryTag extends SimpleTagSupport {

	private String dicCode;
	
	private String dicValue;
	
	private ServletContext servletContext;
	
	private static final Logger logger = Logger.getLogger(DictionaryTag.class);
	
	@Override
	public void doTag() throws JspException, IOException {
		try {
			JspWriter out = getJspContext().getOut();
			if(StringUtils.isBlank(dicCode) || StringUtils.isBlank(dicValue)){
				out.write("");
				logger.info("DictionaryTag hander for dicCode: "+dicCode+" dicValue: "+dicValue+" some is blank so write ''...");
			}else{
				if("MATERIAL_AUTHORIZEDID".equals(dicCode)){
					MaterialAuthorizedMapper materialAuthorizedMapper = WebApplicationContextUtils.getWebApplicationContext(servletContext).getBean(MaterialAuthorizedMapper.class);
					MaterialAuthorized authorized = new MaterialAuthorized();
					authorized.setId(Integer.parseInt(dicValue));
					authorized = materialAuthorizedMapper.getMaterialAuthorized(authorized);
					out.write(authorized==null?null:authorized.getAuthOrg());
				}else{
					Dictionary dic = ApplicationContentUtil.getCachedDictionary(dicCode, dicValue);
					out.write(dic==null?"":dic.getName());
				}
			}
		} catch (Exception e) {
			logger.info("DictionaryTag hander for dicCode: "+dicCode+" dicValue: "+dicValue+" raise an exception...");
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	protected JspFragment getJspBody() {
		return super.getJspBody();
	}

	@Override
	protected JspContext getJspContext() {
		return super.getJspContext();
	}

	@Override
	public JspTag getParent() {
		return super.getParent();
	}

	@Override
	public void setJspBody(JspFragment jspBody) {
		super.setJspBody(jspBody);
	}

	@Override
	public void setJspContext(JspContext pc) {
		PageContext pageContext = (PageContext)pc;
		servletContext = pageContext.getServletContext();
		super.setJspContext(pc);
	}

	@Override
	public void setParent(JspTag parent) {
		super.setParent(parent);
	}

	public String getDicCode() {
		return dicCode;
	}

	public void setDicCode(String dicCode) {
		this.dicCode = dicCode;
	}

	public String getDicValue() {
		return dicValue;
	}

	public void setDicValue(String dicValue) {
		this.dicValue = dicValue;
	}

}
