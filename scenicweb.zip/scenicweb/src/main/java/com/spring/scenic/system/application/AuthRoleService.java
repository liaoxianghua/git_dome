package com.spring.scenic.system.application;

import java.util.List;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;


public interface AuthRoleService {

	/**
	 * 查询角色列表
	 * @param authRole
	 * @param pageTrue
	 * @return
	 */
	List<AuthRole> queryRoleList(AuthRole authRole, boolean pageTrue);

	/**
	 * 新增角色
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月7日
	 */
	void addRole(AuthRole authRole, AuthUser userInfo);

	/**
	 * 更新角色
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月7日
	 */
	void updateRole(AuthRole authRole, AuthUser userInfo);

	/**
	 * 通过id查询角色信息
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月7日
	 */
	AuthRole selectByPrimaryKey(Integer id);

	/**
	 * 启用禁用数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月9日
	 */
	void updateForbiddenOrUseData(AuthRole authRole, AuthUser userInfo);

	int updatePermission(Integer resourceId, Integer roleId, Integer status, AuthUser user);

	/**查询角色中的用户
	 * @param authUserRole
	 * @param pageTrue
	 * @Auth: lichangmao
	 * @return
	 */
	List<AuthUserRole> getRoleUserList(AuthUserRole authUserRole, boolean pageTrue);

	/**移除角色中的用户
	 * @param authUserRole
	 */
	void deleteRoleUser(AuthUserRole authUserRole);

	/**
	 * @Description 获取系统角色
	 * @param authRole
	 * @return List<AuthRole>
	 * @author 006568（shuchang）
	 * @date 2017年2月10日
	 */
	List<AuthRole> getRoleList(AuthRole authRole);
	
	/**
	 * @Description 根据资源获取访问需要的角色
	 * @param resource
	 * @return List<AuthRole>
	 * @author 006568（shuchang）
	 * @date 2017年2月10日
	 */
	List<AuthRole> getRoleListByResource(AuthResource resource);

	
	/**
	 * @Description 查询单个role
	 * @param authRole
	 * @return AuthRole
	 * @author 006568（shuchang）
	 * @date 2017年2月22日
	 */
	AuthRole getRole(AuthRole authRole);
	
	
	
	
}
