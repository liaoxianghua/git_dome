/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 * 
 */
package com.spring.scenic.busi.application;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.busi.domain.BusiNotice;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;

/**
 * 此处为类说明:商户中心公告接口类
 * @author rmp
 * @date 2017年3月22日
 */
public interface BusiNoticeService {

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月22日     
     * @memo ：   
     **
     */
    List<BusiNotice> getBusiNoticeList(BusiNotice busiNotice, boolean pageAble);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月22日     
     * @memo ：   
     **
     */
    int updateBusiNoticeStatus(AuthUser userInfo, BusiNotice busiNotice);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月23日     
     * @memo ：   
     **
     */
    int updateBusiNoticeToTop(AuthUser userInfo, BusiNotice busiNotice);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月24日     
     * @memo ：   
     **
     */
    MessageData saveBusiNotice(AuthUser user, Map<String, List<MultipartFile>> filesMap, String key,
        BusiNotice busiNotice);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月24日     
     * @memo ：   
     **
     */
    BusiNotice getBusiNoticeById(BusiNotice busiNotice);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月24日     
     * @memo ：   
     **
     */
    void noticeAttachDownload(HttpServletResponse response, BusiNotice busiNotice);

}
