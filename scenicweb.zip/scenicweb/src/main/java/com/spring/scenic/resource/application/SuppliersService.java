/**
 * 
 */
package com.spring.scenic.resource.application;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.resource.domain.Suppliers;
import com.spring.scenic.resource.domain.SuppliersContract;
import com.spring.scenic.resource.domain.SuppliersLicense;
import com.spring.scenic.resource.domain.SuppliersProductType;
import com.spring.scenic.system.domain.AuthUser;

/** @descriptipn:供应商管理接口
 *  @author：ranmaoping
 *  @date:上午11:04:42 2016年11月2日
 *  @version:1.0
 *
 */
public interface SuppliersService {

	/**
	 * @param suppliers
	 * @param pageAble
	 * @return
	 */
	List<Suppliers> getSuppliersList(Suppliers suppliers, boolean pageAble);
	/**
	 * @param suppliers
	 * @return
	 */
	Suppliers getSuppliersInfoById(Suppliers suppliers);
	/**
	 * @param userInfo 
	 * @param suppliers
	 */
	void saveSuppliers(AuthUser userInfo, Suppliers suppliers);
	/**
	 * @param userInfo
	 * @param suppliers
	 */
	void updateSuppliersStatus(AuthUser userInfo, Suppliers suppliers);
	/**
	 * @param suppliers 
	 * @return
	 */
	List<SuppliersProductType> getProductTypeList(Suppliers suppliers);
	/**
	 * @param userInfo
	 * @param suppliers
	 */
	void saveSuppliersProduct(AuthUser userInfo, Suppliers suppliers);
	/**
	 * @param suppliersContract
	 * @param pageAble
	 * @return
	 */
	List<SuppliersContract> getSuppliersContrctList(
			SuppliersContract suppliersContract, boolean pageAble);
	/**
	 * @param user
	 * @param filesMap
	 * @param key
	 * @param suppliersContract 
	 * @return
	 */
	void saveSuppliersContract(AuthUser user,
			Map<String, List<MultipartFile>> filesMap, String key, SuppliersContract suppliersContract);
	/**
	 * @param suppliersContract
	 * @return
	 */
	SuppliersContract getSuppliersContractInfoById(SuppliersContract suppliersContract);
	/**
	 * @param response
	 * @param suppliersContract
	 */
	void contractAttachDownload(HttpServletResponse response,
			SuppliersContract suppliersContract);


    /**
     * 查询供应商证照管理列表信息
     * @param suppliersLicense
     * @param pageAble
     * @return
     */
    List<SuppliersLicense> getSuppliersLicenseList(SuppliersLicense suppliersLicense, boolean pageAble);


    /**
     * 保存供应商证件信息
     * @param userInfo
     * @param suppliersLicense
     * @param filesMap
     * @param coversImageFile
     */
    void saveSuppliersLicense(AuthUser userInfo, SuppliersLicense suppliersLicense, Map<String, List<MultipartFile>> filesMap, String coversImageFile);

    /**
     * 删除供应商证件信息
     * @param userInfo
     * @param suppliersLicense
     */
    void deleteSuppliersLicense(AuthUser userInfo, SuppliersLicense suppliersLicense);

	/**
	 * 删除供应商证件附件图片
	 * @param userInfo
	 * @param suppliersLicense
	 */
	void deleteSuppliersLicenseAttached (AuthUser userInfo, SuppliersLicense suppliersLicense);
}
