package com.spring.scenic.content.application.impl;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.domain.ScenicSeller;
import com.spring.scenic.basic.infrastructure.ScenicSellerMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.CalculateUtil;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.MultiPartUtil;
import com.spring.scenic.content.application.CommentsService;
import com.spring.scenic.content.domain.Comments;
import com.spring.scenic.content.domain.CommentsImage;
import com.spring.scenic.content.domain.CommentsOption;
import com.spring.scenic.content.domain.CommentsScoreItems;
import com.spring.scenic.content.infrastructure.CommentsMapper;
import com.spring.scenic.content.infrastructure.CommentsScoreItemsMapper;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;

/**
 * @Description 点评管理服务类
 * @author 006568（shuchang）
 * @date 2016年12月30日
 */
@SuppressWarnings("deprecation")
@Service
public class CommentsServiceImpl implements CommentsService {

	private static final String IMAGESPERTOR = ";";

	private static Logger logger = LoggerFactory.getLogger(CommentsServiceImpl.class);
	
	@Autowired
	private CommentsMapper commentsMapper;
	
	@Autowired
	private CommentsScoreItemsMapper commentsScoreItemsMapper;
	
	@Autowired
	private ScenicSellerMapper scenicSellerMapper;
	
	@Autowired
	private DictionaryService dataDictionaryService;
	
	@Override
	public List<Comments> getEvaluateListData(Comments comment, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(comment.getPageNum(), 12);
			}
			List<Comments> comments = commentsMapper.getCommentsList(comment);
			return comments;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public CommentsScoreItems getCommentsScoreItem(CommentsScoreItems item) {
		try {
			return commentsScoreItemsMapper.getCommentsScoreItem(item);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<CommentsScoreItems> getEvaluateItemListData(CommentsScoreItems item, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(item.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<CommentsScoreItems> items = commentsScoreItemsMapper.getEvaluateItemList(item);
			return items;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int updateEvaluateItem(AuthUser user, CommentsScoreItems item) {
		try {
			CommentsScoreItems itemExample = commentsScoreItemsMapper.getCommentsScoreItem(item);
			itemExample.setType(item.getType());
			itemExample.setSubType(item.getSubType());
			itemExample.setValid(item.getValid());
			itemExample.setRemark(item.getRemark());
			itemExample.setTitle(item.getTitle());
			itemExample.setUpdateTime(new Date());
			itemExample.setUpdateUser(user.getId());
			return commentsScoreItemsMapper.updateEvaluateItem(itemExample);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int updateEvaluateItemValid(AuthUser user,CommentsScoreItems item) {
		try {
			CommentsScoreItems itemExampler = commentsScoreItemsMapper.getCommentsScoreItem(item);
			itemExampler.setUpdateTime(new Date());
			itemExampler.setUpdateUser(user.getId());
			itemExampler.setValid(item.getValid());
			itemExampler.setId(item.getId());
			return commentsScoreItemsMapper.updateEvaluateItem(itemExampler);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public int saveEvaluateItem(AuthUser user, CommentsScoreItems item) {
		try {
			item.setCreateTime(new Date());
			item.setCreateUser(user.getId());
			return commentsScoreItemsMapper.saveEvaluateItem(item);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public CommentsImage getCommentsImage(CommentsImage image) {
		try {
			return commentsMapper.getCommentsImage(image);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int auditEvaluate(AuthUser user,Comments comments) {
		try {
			Comments  commentsExampler = new Comments();
			commentsExampler.setId(comments.getId());
			commentsExampler.setStatus(comments.getStatus());
			return commentsMapper.updateComment(comments);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void downEvaluateFile(HttpServletResponse response) {
		int itemIndex = 4;
		int maxColCnt = 0;
		int itemStartIndex = 4;
		List<ScenicSeller> scenicSellers;
		List<CommentsScoreItems> commentsScoreItems;
		Map<String, List<Dictionary>> dicMap;
		String headers[] = new String[]{"景区/商户ID","人均","点评内容","图片（多图用英文‘;’隔开）"};
		try {
			ScenicSeller seller = new ScenicSeller();
			seller.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			scenicSellers = scenicSellerMapper.getScenicSellerList(seller);
			CommentsScoreItems commentItemsExample = new CommentsScoreItems();
			commentItemsExample.setValid(Short.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			commentsScoreItems = commentsScoreItemsMapper.getEvaluateItemList(commentItemsExample);
			dicMap = dataDictionaryService.initDictionary(new Dictionary());
			if(scenicSellers==null||scenicSellers.isEmpty() || commentsScoreItems==null||commentsScoreItems.isEmpty()){
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			}else{
				response.setContentType("application/octet-stream;charset=UTF-8");
				response.setHeader("Content-disposition", "attachment;filename="+new String("景区商户点评模板.xlsx".getBytes("GBK"), "ISO8859-1"));
				ServletOutputStream outputStream = response.getOutputStream();
				maxColCnt = itemIndex + (commentsScoreItems.size()*2);
				
				XSSFWorkbook workbook = new XSSFWorkbook();
				
				XSSFSheet sheet = workbook.createSheet("点评");
				sheet.setDefaultColumnWidth((short) 20);
				
				XSSFColor blackColor = new XSSFColor(Color.BLACK);

				XSSFCellStyle styleData = workbook.createCellStyle();
				styleData.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				styleData.setTopBorderColor(blackColor);
				styleData.setBottomBorderColor(blackColor);
				styleData.setLeftBorderColor(blackColor);
				styleData.setRightBorderColor(blackColor);
				styleData.setBorderTop(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderRight(XSSFCellStyle.BORDER_THIN);
				
				XSSFCellStyle styleHeader = workbook.createCellStyle();
				styleHeader.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				styleHeader.setTopBorderColor(blackColor);
				styleHeader.setBottomBorderColor(blackColor);
				styleHeader.setLeftBorderColor(blackColor);
				styleHeader.setRightBorderColor(blackColor);
				styleHeader.setBorderTop(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderRight(XSSFCellStyle.BORDER_THIN);
				
				XSSFFont font = workbook.createFont();
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				styleHeader.setFont(font);
				
				XSSFCellStyle redHeader = workbook.createCellStyle();
				redHeader.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				redHeader.setTopBorderColor(blackColor);
				redHeader.setBottomBorderColor(blackColor);
				redHeader.setLeftBorderColor(blackColor);
				redHeader.setRightBorderColor(blackColor);
				redHeader.setBorderTop(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderRight(XSSFCellStyle.BORDER_THIN);
				
				XSSFFont redFont = workbook.createFont();
				redFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				redFont.setColor(XSSFFont.COLOR_RED);
				redHeader.setFont(redFont);
				
				//产生表格标题行
				XSSFRow row = sheet.createRow(0);
				XSSFCell cell = row.createCell(0);
				cell.setCellValue(new XSSFRichTextString("景区点评excel模板"));
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, maxColCnt-1));
				cell.setCellStyle(styleHeader);
				
				//产生表格表头行
				XSSFRichTextString text = null;
				row = sheet.createRow(1);
				for (short i = 0; i < headers.length; i++) {
					cell = row.createCell(i);
					text = new XSSFRichTextString(headers[i]);
					cell.setCellValue(text);
					if(i<(headers.length-1)){
						cell.setCellStyle(redHeader);
					}else{
						cell.setCellStyle(styleHeader);
					}
				}
				for (int x = itemStartIndex; x < maxColCnt; x++) {
					cell = row.createCell(x);
					if(x%2==0){
						text = new XSSFRichTextString("评分项ID");
						cell.setCellValue(text);
						cell.setCellStyle(styleHeader);
					}else{
						text = new XSSFRichTextString("评分");
						cell.setCellValue(text);
					      cell.setCellStyle(styleHeader);
					}
				}
				
				createScenicSellerSheet(workbook,styleHeader,styleData,scenicSellers,dicMap);
				
				createCommentScoreItemSheet(workbook,styleHeader,styleData,commentsScoreItems,dicMap.get("MAIN_TYPE"));
				
				workbook.write(outputStream);
				outputStream.close();
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	private void createCommentScoreItemSheet(XSSFWorkbook workbook,XSSFCellStyle styleHeader, XSSFCellStyle styleData,List<CommentsScoreItems> commentsScoreItems, List<Dictionary> dics) {
		try {
			CommentsScoreItems scoreItem = null;
			XSSFCell cell = null;
			XSSFRichTextString text = new XSSFRichTextString();
			String scenicSellerHeaders[] = new String[]{"评分项ID","评分项","类别"};
			XSSFSheet sheet = workbook.createSheet("评分项");
			sheet.setDefaultColumnWidth((short) 20);
			XSSFRow row = sheet.createRow(0);
			for (short i = 0; i < scenicSellerHeaders.length; i++) {
				text.setString(scenicSellerHeaders[i]);
				cell = row.createCell(i);
				cell.setCellValue(text);
				cell.setCellStyle(styleHeader);
			}
			for (int i = 0; i < commentsScoreItems.size(); i++) {
				row = sheet.createRow(i+1);
				scoreItem = commentsScoreItems.get(i);
				for (int j = 0; j < 3; j++) {
					cell = row.createCell(j);
					cell.setCellStyle(styleData);
					if(j==0){
						text.setString(scoreItem.getId().toString());
						cell.setCellValue(text);
					}else if(j==1){
						text.setString(scoreItem.getTitle());
						cell.setCellValue(text);
					}else if(j==2){
						text.setString(getDicName(scoreItem.getType().toString(),dics));
						cell.setCellValue(text);
					}
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	private void createScenicSellerSheet(XSSFWorkbook workbook, XSSFCellStyle styleHeader, XSSFCellStyle styleData, List<ScenicSeller> scenicSellers, Map<String, List<Dictionary>> dicMap) {
		try {
			ScenicSeller seller = null;
			XSSFCell cell = null;
			XSSFRichTextString text = new XSSFRichTextString();
			String scenicSellerHeaders[] = new String[]{"商户ID","商户名称","商户地址","类型"};
			XSSFSheet sheet = workbook.createSheet("景区商户");
			sheet.setDefaultColumnWidth((short) 20);
			XSSFRow row = sheet.createRow(0);
			for (short i = 0; i < scenicSellerHeaders.length; i++) {
				cell = row.createCell(i);
				text.setString(scenicSellerHeaders[i]);
				cell.setCellValue(text);
				cell.setCellStyle(styleHeader);
			}
			for (int i = 0; i < scenicSellers.size(); i++) {
				row = sheet.createRow(i+1);
				seller = scenicSellers.get(i);
				for (int j = 0; j < 4; j++) {
					cell = row.createCell(j);
					cell.setCellStyle(styleData);
					if(j==0){
						text.setString(seller.getId().toString());
						cell.setCellValue(text);
					}else if(j==1){
						text.setString(seller.getName());
						cell.setCellValue(text);
					}else if(j==2){
						text.setString(seller.getAddress());
						cell.setCellValue(text);
					}else if(j==3){
						if(SysEnum.MAIN_TYPE_SCENIC.getCode().equals(seller.getType())){
							text.setString(getDicName(seller.getTypeCategory(), dicMap.get("SCENIC_TYPE")));
						}else{
							text.setString(getDicName(seller.getTypeCategory(), dicMap.get("SELLER_TYPE")));
						}
						cell.setCellValue(text);
					}
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	private String getDicName(String value, List<Dictionary> dics){
		for (Dictionary dataDictionary : dics) {
			if(dataDictionary.getValue().equals(value)){
				return dataDictionary.getName();
			}
		}
		return null;
	}


	@Override
	public List<MessageData> saveEvaluateImportData(AuthUser user,Map<String, List<MultipartFile>> filesMap, String key) {
		List<MessageData> errors = new ArrayList<MessageData>();
		Date now = DateUtil.getNow();
		try {
			List<ScenicSeller> scenicSellers = scenicSellerMapper.getScenicSellerList(new ScenicSeller());
			List<CommentsScoreItems> commentsScoreItems = commentsScoreItemsMapper.getEvaluateItemList(new CommentsScoreItems());
			
			if(scenicSellers==null||scenicSellers.isEmpty() || commentsScoreItems==null||commentsScoreItems.isEmpty()){
				errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"系统未获取到景区、商户或点评项数据！"));
				return errors;
			}
			Map<Integer,String[]> sellerMap = toSellerMap(scenicSellers);
			Map<Integer,String> itemMap = toItemMap(commentsScoreItems);
			
			int itemIndex = 4;
			int itemStartIndex = 4;
			int maxColCnt = itemIndex + (itemMap.size()*2);
		
			boolean hasFile = MultiPartUtil.checkHasMultipartFile(filesMap,key);
			if(!hasFile){
				errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"未获取到导入的附件！"));
				return errors;
			}
			
			List<MultipartFile> multipartFiles = filesMap.get(key);
			MultipartFile multipartFile = multipartFiles.get(0);
			XSSFWorkbook workbook07 = new XSSFWorkbook(multipartFile.getInputStream());
			XSSFSheet sheet = workbook07.getSheetAt(0);
			XSSFRow row = null;
			XSSFCell cell = null;
			Comments comment = null; 
			CommentsOption option = null;
			List<CommentsImage> images;
			List<CommentsOption> options;
			int sucCnt=0,failCnt=0;
			int rowCnt = sheet.getLastRowNum();
			for (int i = sheet.getFirstRowNum()+2; i <= rowCnt; i++) {
				Integer sellerId =null,optionId=null,optionScore=null,totalScore=0;
				String perCapitaFees=null,evaluateContent=null,evaluateImage=null,optionName=null;
				images= new ArrayList<CommentsImage>();
				options = new ArrayList<CommentsOption>();
				comment = new Comments();
				row = sheet.getRow(i);
				for (int j = 0; j < itemIndex; j++) {
					cell = row.getCell(j);
					if(cell!=null){
						cell.setCellType(XSSFCell.CELL_TYPE_STRING);
						if(j==0){
							try {
								sellerId = cell==null?null:(StringUtils.isBlank(cell.getStringCellValue())?null:Integer.valueOf(cell.getStringCellValue()));
							} catch (Exception e) {
								sellerId = -1;
								e.printStackTrace();
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行景区/商户ID应为数字！"));
							}
						}else if(j==1){
							perCapitaFees = cell==null?null:cell.getStringCellValue().trim();
						}else if(j==2){
							evaluateContent = cell==null?null:cell.getStringCellValue().trim();
						}else if(j==3){
							evaluateImage = cell==null?null:cell.getStringCellValue().trim();
						}
					}
				}
				logger.info("第："+(i+1)+" 行： sellerId："+sellerId+" perCapitaFees："+perCapitaFees+" evaluateContent："+evaluateContent+" evaluateImage："+evaluateImage);
				boolean  flag = true;
				//1、判断为空和是否存在该景区、商户
				if(sellerId==null || sellerId==0){
					flag = false;
					errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行景区/商户ID为空！"));
				}else{
					if(sellerMap.containsKey(sellerId)){
						comment.setCmmtMainId(sellerId);
						comment.setOutType(sellerMap.get(sellerId)[0]==null?null:Short.valueOf(sellerMap.get(sellerId)[0]));
						comment.setOutSubType(sellerMap.get(sellerId)[1]==null?null:Short.valueOf(sellerMap.get(sellerId)[1]));
					}else{
						flag = false;
						errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行景区/商户ID不存在！"));
					}
				}
				
				//2、判断为空
				if(StringUtils.isBlank(perCapitaFees)){
					flag = false;
					errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行人均为空！"));
				}else{
					comment.setPerCapitaFees(perCapitaFees);
				}
				//3、判断为空
				if(StringUtils.isBlank(evaluateContent)){
					flag = false;
					errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评内容为空！"));
				}else{
					if(evaluateContent.length()>500){
						flag = false;
						errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评内容超过500个字符！"));
					}else{
						comment.setCmmtContent(evaluateContent);
					}
				}
				//4、判断为空
				if(StringUtils.isNotBlank(evaluateImage)){
					List<MessageData> checkImage = checkEvaluateImage(i,evaluateImage);
					if(checkImage !=null && !checkImage.isEmpty()){
						flag = false;
						errors.addAll(checkImage);
					}else{
						images = createEvaluateImages(user,evaluateImage);
					}
				}
				itemStartIndex = itemIndex;
				options = new ArrayList<CommentsOption>();
				for (int x = itemStartIndex; x < maxColCnt; x++) {
					try {
						cell = row.getCell(itemStartIndex);
						if(cell!=null){
							cell.setCellType(XSSFCell.CELL_TYPE_STRING);
							try {
								optionId = cell==null?null:(StringUtils.isBlank(cell.getStringCellValue())?null:Integer.valueOf(cell.getStringCellValue()));
							} catch (Exception e) {
								e.printStackTrace();
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID应为数字！"));
								break;
							}
							if(optionId==null || optionId==0){
								flag = false;
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID："+optionId+" 不存在！"));
								break;
							}
							itemStartIndex++;
							cell = row.getCell(itemStartIndex);
							cell.setCellType(XSSFCell.CELL_TYPE_STRING);
							try {
								optionScore = cell==null?null:(StringUtils.isBlank(cell.getStringCellValue())?null:Integer.valueOf(cell.getStringCellValue()));
							} catch (Exception e) {
								e.printStackTrace();
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID："+optionId+" 评分应为数字！"));
								break;
							}
							if(optionScore==null){
								flag = false;
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID："+optionId+" 评分须在1-5分之间！"));
								break;
							}
							if(!itemMap.containsKey(optionId)){
								flag = false;
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID："+optionId+" 不存在！"));
								break;
							}else{
								optionName = itemMap.get(optionId).toString();
							}
							if(optionScore==0 || optionScore>5){
								flag = false;
								errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行点评ID："+optionId+" 评分须在1-5分之间！"));
								break;
							}else{
								totalScore+=optionScore;
							}
							itemStartIndex++;
							logger.info("第："+(i+1)+" 行："+" optionId："+optionId+" optionScore："+optionScore);
							
							option = creatOption(optionId,optionName,optionScore,user);
							options.add(option);
						}else{
							break;
						}
					} catch (Exception e) {
						flag = false;
						e.printStackTrace();
						errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行评分数据解析异常！"));
					}
				}
				
				if(!checkRepeatOptions(options)){
					flag = false;
					errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行存在重复评分项！"));
				}
				if(options.isEmpty()){
					flag = false;
					errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+(i+1)+" 行无评分数据！"));
				}
				
				if(flag){
					comment.setCreateUser(user.getId());
					comment.setCreateTime(now);
					comment.setPublishTime(now);
					comment.setMemberid(user.getId());
					comment.setStatus(Short.valueOf(SysEnum.CONTENT_STATUS_UNAPPROVE.getCode()));
					comment.setCmmtFrom(Short.valueOf(SysEnum.CONTENT_FROM_IMPORT.getCode()));
					comment.setTotalScore(CalculateUtil.toBigDecimal(CalculateUtil.div(Double.valueOf(totalScore.toString()),options.size()),0,BigDecimal.ROUND_HALF_UP));
					commentsMapper.saveComment(comment);
					if(!images.isEmpty()){
						for (CommentsImage commentsImage : images) {
							commentsImage.setCmmtId(comment.getSequence());
						}
						commentsMapper.saveBatchCommentImages(images);
					}
					if(!options.isEmpty()){
						for (CommentsOption commentsOption : options) {
							commentsOption.setCmmtId(comment.getSequence());
						}
						commentsMapper.saveBatchCommentOptions(options);
					}
					sucCnt ++;
				}else{
					failCnt ++;
				}
				totalScore = 0;
			}
			logger.info("成功导入："+sucCnt+" 条数据，导入失败："+failCnt+" 条！");
			errors.add(new MessageData(SysConstant.OPERATE_SUCCESS, "成功导入："+sucCnt+" 条数据，导入失败："+failCnt+" 条！"));
			return errors;
		} catch (Exception e) {
			e.printStackTrace();
			errors.add(new MessageData(SysConstant.OPERATE_FAILURE,"系统异常，导入失败！"));
			return errors;
		}
	}

	/**
	 * @Description 验证点评项是否可重复
	 * @param options
	 * @return boolean true:不重复、false：重复
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	private boolean checkRepeatOptions(List<CommentsOption> options) {
		Set<Integer> set = new HashSet<Integer>();
		for (CommentsOption commentsOption : options) {
			set.add(commentsOption.getScoreItemsId());
		}
		return set.size()==options.size();
	}



	private CommentsOption creatOption(Integer optionId, String optionName,Integer optionScore, AuthUser user) {
		CommentsOption commentsOption = new CommentsOption();
		commentsOption.setScoreItemsId(optionId);
		commentsOption.setScoreItemsTitle(optionName);
		commentsOption.setScore(optionScore);
		commentsOption.setCreateTime(new Date());
		commentsOption.setCreateUser(user.getId());
		return commentsOption;
	}

	//点评项转成Map
	private Map<Integer, String> toItemMap(List<CommentsScoreItems> commentsScoreItems) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		for (CommentsScoreItems commentsScoreItem : commentsScoreItems) {
			map.put(commentsScoreItem.getId(), commentsScoreItem.getTitle());
		}
		return map;
	}

	//景区商户转成Map
	private Map<Integer, String[]> toSellerMap(List<ScenicSeller> scenicSellers) {
		Map<Integer, String[]> map = new HashMap<Integer, String[]>();
		for (ScenicSeller scenicSeller : scenicSellers) {
			map.put(scenicSeller.getId(), new String[]{scenicSeller.getType(),scenicSeller.getTypeCategory(),scenicSeller.getName()});
		}
		return map;
	}

	//创建图片集合
	private List<CommentsImage> createEvaluateImages(AuthUser user, String evaluateImage) {
		CommentsImage commentsImage = null;
		List<CommentsImage> commentsImages = new ArrayList<CommentsImage>();
		String images[] = evaluateImage.split(IMAGESPERTOR);
		for (String imageUrl : images) {
			commentsImage = new CommentsImage();
			commentsImage.setCmmtId(null);
			commentsImage.setImageUrl(imageUrl);
			commentsImage.setCreateTime(new Date());
			commentsImage.setCreateUser(user.getId());
			commentsImages.add(commentsImage);
		}
		return commentsImages;
	}

	//验证图片格式
	private List<MessageData> checkEvaluateImage(Integer index ,String evaluateImage) {
		String suffix = "";
		List<MessageData> messageDatas = new ArrayList<MessageData>();
		if(StringUtils.isNotBlank(evaluateImage)){
			String images[] = evaluateImage.split(IMAGESPERTOR);
			for (String imageUrl : images) {
				suffix = imageUrl.substring(imageUrl.lastIndexOf(".")+1, imageUrl.length());
				if("jpg、png、jpeg、gif、bmp".indexOf(suffix.toLowerCase())==-1){
					messageDatas.add(new MessageData(SysConstant.OPERATE_FAILURE,"第："+index+" 行图片格式不正确！"));
				}
			}
		}
		return messageDatas;
	}
	

}
