package com.spring.scenic.content.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.content.application.TravelNoteService;
import com.spring.scenic.content.domain.TravelNotes;
import com.spring.scenic.content.domain.TravelNotesDetails;
import com.spring.scenic.content.infrastructure.TravelNotesMapper;
import com.spring.scenic.member.domain.MemberMsg;
import com.spring.scenic.member.infrastructure.MemberMsgMapper;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.common.util.PropertiesUtil;;

/**
 * @Description 游记攻略业务实现类
 * @author 006568（shuchang）
 * @date 2016年12月26日
 */
@Service
public class TravelNoteServiceImpl implements TravelNoteService {

	@Autowired
	private TravelNotesMapper travelNotesMapper;
	
	@Autowired
    private MemberMsgMapper memberMsgMapper;
	
	@Resource(name="fastDFSStorageService")
	private StorageService fastDFSStorageService;
	
	@Override
	public List<TravelNotes> getTravelNoteList(TravelNotes travelNote,Boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(travelNote.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<TravelNotes> travelNotes = travelNotesMapper.getTravelNoteList(travelNote);
			return travelNotes;
		} catch (Exception e) {
		    e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveTravelNote(AuthUser user, TravelNotes travelNote, Map<String, List<MultipartFile>> filesMap,String coversImageFile) {
		try {
			Date now = DateUtil.getNow();
			travelNote.setPublishDate(now);
			travelNote.setValid(Short.valueOf(SysEnum.COMMON_VALID_NO.getCode()));
			travelNote.setStatus(Short.valueOf(SysEnum.CONTENT_STATUS_UNAPPROVE.getCode()));
			travelNote.setCreateUser(user.getId());
			travelNote.setCreateTime(now);
			travelNote.setCreateUserType(2);//1、会员；2、系统用户
			//封面图片上传
			if(filesMap!=null && !filesMap.isEmpty()){
				List<MultipartFile> coversImageFiles = filesMap.get(coversImageFile);
				if(coversImageFiles!=null && !coversImageFiles.isEmpty()){
					MultipartFile coversImage = coversImageFiles.get(0);
					String coversImageExtensionName = FilenameUtils.getExtension(coversImage.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(coversImageExtensionName, coversImage.getBytes(), null);
					travelNote.setCoversImageUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
					travelNote.setCoversImageName(coversImage.getOriginalFilename());
				}
			}
			
			//保存游记、攻略基础信息
			int count = travelNotesMapper.saveTravelNote(travelNote);
			//保存游记内容信息
			List<TravelNotesDetails> travelNotesDetails = travelNote.getTravelNotesDetails();
			Iterator<TravelNotesDetails> travelNotesDetailIterator = travelNotesDetails.iterator();
			while(travelNotesDetailIterator.hasNext()){
				TravelNotesDetails travelNotesDetail = travelNotesDetailIterator.next();
				if(null==travelNotesDetail.getType()){
					travelNotesDetailIterator.remove();
				}
			}
			if(travelNotesDetails!=null && !travelNotesDetails.isEmpty()){
				for (int i = 0; i < travelNotesDetails.size(); i++) {
					TravelNotesDetails travelNotesDetail = travelNotesDetails.get(i);
					travelNotesDetail.setTravelNotesId(travelNote.getSequence());
					travelNotesDetail.setCreateUser(user.getId());
					travelNotesDetail.setCreateTime(now);
					if(SysEnum.CONTENT_TYPE_PICTURE.getCode().equals(travelNotesDetail.getType())
							||SysEnum.CONTENT_TYPE_VOICE.getCode().equals(travelNotesDetail.getType())
							||SysEnum.CONTENT_TYPE_VIDEO.getCode().equals(travelNotesDetail.getType())){
						List<MultipartFile> currentFiles = filesMap.get(travelNotesDetail.getFileBindKey());
						if(currentFiles!=null&&!currentFiles.isEmpty()){//新增或编辑新增了或编辑了附件
							//目前仅单个上传
							MultipartFile multipartFile = currentFiles.get(0);
							String fileExtensionName = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
							String fileUrl = fastDFSStorageService.uploadResource(fileExtensionName, multipartFile.getBytes(), null);
							travelNotesDetail.setUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
							travelNotesDetail.setFileName(multipartFile.getOriginalFilename());
						}
					}else if(SysEnum.CONTENT_TYPE_WORD.getCode().equals(travelNotesDetail.getType())){
						travelNotesDetail.setTitle(null);
					}else if(SysEnum.CONTENT_TYPE_TITLE.getCode().equals(travelNotesDetail.getType())){
						travelNotesDetail.setWords(null);
					}
				}
				travelNotesMapper.saveBatchTravelNotes(travelNotesDetails);
			}
			return count;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public int updateTravelNote(AuthUser user, TravelNotes travelNote,Map<String, List<MultipartFile>> filesMap, String coversImageFile) {
		try {
			Date now = DateUtil.getNow();
			TravelNotes travelNoteExample = new TravelNotes();
			travelNoteExample.setId(travelNote.getId());
			TravelNotes exsitedTravelNote = travelNotesMapper.getTravelNote(travelNoteExample);
			exsitedTravelNote.setTitle(travelNote.getTitle());
			exsitedTravelNote.setAuthorName(travelNote.getAuthorName());
			exsitedTravelNote.setType(travelNote.getType());
			exsitedTravelNote.setDepartureDate(travelNote.getDepartureDate());
			exsitedTravelNote.setFee(travelNote.getFee());
			exsitedTravelNote.setPersons(travelNote.getPersons());
			exsitedTravelNote.setDays(travelNote.getDays());
			exsitedTravelNote.setUpdateUser(user.getId());
			exsitedTravelNote.setUpdateTime(now);
			//封面图片上传
			if(filesMap!=null && !filesMap.isEmpty()){
				List<MultipartFile> coversImageFiles = filesMap.get(coversImageFile);
				if(coversImageFiles!=null && !coversImageFiles.isEmpty()){
					if(StringUtils.isNotBlank(exsitedTravelNote.getCoversImageUrl())){
						fastDFSStorageService.deleteResourceByPath(exsitedTravelNote.getCoversImageUrl().replace(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL), ""));
					}
					MultipartFile coversImage = coversImageFiles.get(0);
					String coversImageExtensionName = FilenameUtils.getExtension(coversImage.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(coversImageExtensionName, coversImage.getBytes(), null);
					exsitedTravelNote.setCoversImageUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
					exsitedTravelNote.setCoversImageName(coversImage.getOriginalFilename());
				}
			}
			int count = travelNotesMapper.updateTravelNote(exsitedTravelNote);
			//保存游记、攻略基础信息
			if(travelNote.getTravelNotesDetails()!=null){
				//保存游记内容信息
				List<TravelNotesDetails> updateTravelNotesDetails = new ArrayList<TravelNotesDetails>();
				List<TravelNotesDetails> travelNotesDetails = travelNote.getTravelNotesDetails();
				Iterator<TravelNotesDetails> travelNotesDetailIterator = travelNotesDetails.iterator();
				while(travelNotesDetailIterator.hasNext()){
					TravelNotesDetails travelNotesDetail = travelNotesDetailIterator.next();
					if(null==travelNotesDetail.getType()){
						travelNotesDetailIterator.remove();
					}
				}
				if(travelNotesDetails!=null && !travelNotesDetails.isEmpty()){
					for (int i = 0; i < travelNotesDetails.size(); i++) {
						TravelNotesDetails exsitedTravelNotesDetail = null;
						TravelNotesDetails travelNotesDetail = travelNotesDetails.get(i);
						travelNotesDetail.setTravelNotesId(exsitedTravelNote.getId());
						travelNotesDetail.setCreateUser(user.getId());
						travelNotesDetail.setCreateTime(now);
						if(SysEnum.CONTENT_TYPE_PICTURE.getCode().equals(travelNotesDetail.getType())
								||SysEnum.CONTENT_TYPE_VOICE.getCode().equals(travelNotesDetail.getType())
								||SysEnum.CONTENT_TYPE_VIDEO.getCode().equals(travelNotesDetail.getType())){
							
							if(travelNotesDetail.getId()!=null){//原有数据
								exsitedTravelNotesDetail = travelNotesMapper.getTravelNoteDetail(travelNotesDetail);
							}
							List<MultipartFile> currentFiles = filesMap.get(travelNotesDetail.getFileBindKey());
							if(currentFiles!=null&&!currentFiles.isEmpty()){//已编辑附件
								if(exsitedTravelNotesDetail!=null && StringUtils.isNotBlank(exsitedTravelNotesDetail.getUrl())){
									fastDFSStorageService.deleteResourceByPath(exsitedTravelNotesDetail.getUrl().replace(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL), ""));
								}
								MultipartFile multipartFile = currentFiles.get(0);
								String fileExtensionName = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
								String fileUrl = fastDFSStorageService.uploadResource(fileExtensionName, multipartFile.getBytes(), null);
								travelNotesDetail.setUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
								travelNotesDetail.setFileName(multipartFile.getOriginalFilename());
							}else{//未处理附件
								if(exsitedTravelNotesDetail!=null){
									travelNotesDetail.setUrl(exsitedTravelNotesDetail.getUrl());
									travelNotesDetail.setFileName(exsitedTravelNotesDetail.getFileName());
								}
							}
							travelNotesDetail.setWords(null);
							travelNotesDetail.setTitle(null);
						}else if(SysEnum.CONTENT_TYPE_WORD.getCode().equals(travelNotesDetail.getType())){
							travelNotesDetail.setTitle(null);
						}else if(SysEnum.CONTENT_TYPE_TITLE.getCode().equals(travelNotesDetail.getType())){
							travelNotesDetail.setWords(null);
						}
						updateTravelNotesDetails.add(travelNotesDetail);
					}
					travelNotesMapper.deleteTravelNoteDetails(travelNote);
					travelNotesMapper.saveBatchTravelNotes(updateTravelNotesDetails);
				}else{
					travelNotesMapper.deleteTravelNoteDetails(travelNote);
				}
			}else{
				travelNotesMapper.deleteTravelNoteDetails(travelNote);
			}
			return count;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public TravelNotes getTravelNoteWithDetail(TravelNotes travelNote) {
		try {
			TravelNotes exsitTravelNote = travelNotesMapper.getTravelNote(travelNote);
			if(exsitTravelNote == null){
				return new TravelNotes();
			}else{
				TravelNotesDetails travelNotesDetail = new TravelNotesDetails();
				travelNotesDetail.setTravelNotesId(exsitTravelNote.getId());
				List<TravelNotesDetails> travelNotesDetails = travelNotesMapper.getTravelNoteDetailList(travelNotesDetail);
				if(travelNotesDetails!=null && !travelNotesDetails.isEmpty()){
					exsitTravelNote.setTravelNotesDetails(travelNotesDetails);
				}			
				return exsitTravelNote;
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveAuditTravelNote(AuthUser user, TravelNotes travelNote) {
		try {
			TravelNotes travelNoteExampler = new TravelNotes();
			travelNoteExampler.setId(travelNote.getId());
			TravelNotes exsitedTravelNote = travelNotesMapper.getTravelNote(travelNoteExampler);
			exsitedTravelNote.setStatus(travelNote.getStatus());
			exsitedTravelNote.setReviewedUser(user.getId());
			exsitedTravelNote.setUpdateTime(new Date());
			exsitedTravelNote.setUpdateUser(user.getId());
			int cpunt = travelNotesMapper.updateTravelNote(exsitedTravelNote);
			//如果审核的是会员的游记，保存系统消息。 创建人类别：1：是会员；2：是后台人员
			if(exsitedTravelNote.getCreateUserType()==Integer.valueOf(SysEnum.SYSTEM_USER_MEMBER.getCode())) {
			    //新增会员游记审核通过/不通过提示消息
			    MemberMsg memberMsg = new MemberMsg();
			    memberMsg.setMemberId(exsitedTravelNote.getCreateUser());
			    //消息默认为未阅读状态
			    memberMsg.setMsgStatus(0);
			    //消息类别：1、首次注册；2、密码更改；3、订单状态更改；4、公共消息
			    memberMsg.setMsgType(4);
			    memberMsg.setCreateTime(new Date());
			    if(exsitedTravelNote.getStatus()==Short.valueOf(SysEnum.CONTENT_STATUS_PASS.getCode())){//通过
			        memberMsg.setMsgTitle("恭喜您,您的游记已审核通过!");
			        memberMsg.setMsgContent("恭喜您,您的游记"+exsitedTravelNote.getTitle()+"已审核通过!");
			        exsitedTravelNote.setValid(Short.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			    }else{//不通过
			        memberMsg.setMsgTitle("很抱歉,您的游记审核未通过!");
			        memberMsg.setMsgContent("很抱歉,您的游记"+exsitedTravelNote.getTitle()+"审核未通过!");
			        exsitedTravelNote.setValid(Short.valueOf(SysEnum.COMMON_VALID_NO.getCode()));
			    }
			    return memberMsgMapper.addMemberMsg(memberMsg);
			}
			return cpunt;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Keyword> getKeywordListById(Integer id) {
		try {
			return travelNotesMapper.getKeywordListById(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	
	 
}
