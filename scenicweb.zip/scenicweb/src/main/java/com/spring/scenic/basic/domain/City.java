package com.spring.scenic.basic.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class City extends Entity<City> {
	/**
	 * 主键id
	 */
	private Integer id;
	/**
	 * 
	 */
	private Integer userId;
	/**
	 * 城市名称
	 */
	private String name;
	/**
	 * 城市名称(用作于城市页面传到对应区域页面的值)
	 */
	private String cityName;
	/**
	 * 省份名称
	 */
	private String provinceName;
	/**
	 * 国家id
	 */
	private String countryid;
	/**
	 * 省份id
	 */
	private Integer provinceId;
	/**
	 * 三字码
	 */
	private String code;
	/**
	 * 国家
	 */
	private Integer country;
	/**
	 * 国家id
	 */
	private Integer countryId;
	/**
	 * 英文名称
	 */
	private String enName;
	/**
	 * 全拼
	 */
	private String pinyin;
	/**
	 * 简拼
	 */
	private String jianPin;
	/**
	 * 拼音首字母
	 */
	private String initialLetter;
	/**
	 * 状态 1：有效, 0：无效
	 */
	private String valid;
	/**
	 * 状态 1：有效, 0：无效
	 */
	/**
	 * 省份是否有效 1：有效, 0：无效
	 */
	private Integer provinceValid;
	/**
	 * 国家是否有效 1：有效, 0：无效
	 */
	private Integer countryValid;
	
	public Integer getProvinceValid() {
		return provinceValid;
	}

	public void setProvinceValid(Integer provinceValid) {
		this.provinceValid = provinceValid;
	}

	private Integer status;
	/**
	 * 洲际id
	 */
	private String continentid;
	
	private String lng;
	
	private String lat;
	/**
	 * 创建时间
	 */
	private Date createDate;
	/**
	 * 创建人id
	 */
	private Integer createUser;
	/**
	 * 更新时间
	 */
	private Date updateDate;
	/**
	 * 更新人id
	 */
	private Integer updateUser;
	/**
	 * 创建人姓名
	 */
	private String createName;
	/**
	 * 更新人姓名
	 */
	private String updateName;
	/**
	 * 国家名称
	 */
	private String countryName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountryid() {
		return countryid;
	}

	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getPinyin() {
		return pinyin;
	}

	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}

	public String getValid() {
		return valid;
	}

	public void setValid(String valid) {
		this.valid = valid;
	}

	public String getContinentid() {
		return continentid;
	}

	public void setContinentid(String continentid) {
		this.continentid = continentid;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCountry() {
		return country;
	}

	public void setCountry(Integer country) {
		this.country = country;
	}

	public Integer getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getCountryValid() {
		return countryValid;
	}

	public void setCountryValid(Integer countryValid) {
		this.countryValid = countryValid;
	}

    public String getJianPin() {
        return jianPin;
    }

    public void setJianPin(String jianPin) {
        this.jianPin = jianPin;
    }

    public String getInitialLetter() {
        return initialLetter;
    }

    public void setInitialLetter(String initialLetter) {
        this.initialLetter = initialLetter;
    }

 
}