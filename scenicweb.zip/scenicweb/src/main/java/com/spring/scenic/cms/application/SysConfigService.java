/**
 * 
 */
package com.spring.scenic.cms.application;

import java.util.List;

import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.basic.domain.KeywordRef;
import com.spring.scenic.cms.domain.SysConfig;
import com.spring.scenic.cms.domain.SysConfigPic;
import com.spring.scenic.system.domain.AuthUser;

/** 
 *  @Description 系统配置service接口
 *  @author：ranmaoping
 *  @date:下午2:50:47 2017年3月6日
 *  @version:1.0
 *
 */
public interface SysConfigService {

	/**
	 * @param sysConfig
	 * @param pageTrue
	 * @return
	 */
	List<SysConfig> getsysConfigList(SysConfig sysConfig, boolean pageAble);

	/**
	 * @param userInfo
	 * @param sysConfig
	 */
	void updateSysConfigStatus(AuthUser userInfo, SysConfig sysConfig);

	/**
	 * @param sysConfig
	 * @return
	 */
	SysConfig getSysConfigInfoById(SysConfig sysConfig);

	/**
	 * @param user
	 * @param sysConfig
	 */
	void saveSysConfig(AuthUser user, SysConfig sysConfig);

	/**
	 * @param sysConfigPic
	 * @param pageTrue
	 * @return
	 */
	List<SysConfigPic> getSysConfigPic(SysConfigPic sysConfigPic,boolean pageAble);

	/**
	 * @param user
	 * @param sysConfigPic
	 */
	void saveSysConfigPic(AuthUser user, SysConfigPic sysConfigPic);

	/**
	 * @param sysConfigPic
	 * @return
	 */
	SysConfigPic getSysConfigPicInfoById(SysConfigPic sysConfigPic);

	/**
	 * @param sysConfigPic
	 */
	void deleteSysConfigPic(SysConfigPic sysConfigPic);

	/**
	 * @param keyword
	 * @return
	 */
	List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword);

	/**
	 * @param user
	 * @param keywordRef
	 * @param keyword
	 */
	KeywordRef saveSysConfigKeyword(AuthUser user, KeywordRef keywordRef,Keyword keyword);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月16日     
     * @memo ：   
     **
     */
    List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月16日     
     * @memo ：   
     **
     */
    void deleteSysConfigKeyword(KeywordRef keywordRef);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月16日     
     * @memo ：   
     **
     */
    void updateSysConfigKeywordOrder(KeywordRef keywordRef);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月17日     
     * @memo ：   
     **
     */
    SysConfig getSysConfigInfoByPicId(Integer id);

}
