package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.AuthDepartment;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.DepartmentItem;
import com.spring.scenic.system.domain.ZtreeDept;


public interface DepartmentMapper {
	
	
    List<Department> selectDepartmentForManager(Department department);

	void deleteByPrimaryId(Integer id);

	void deleteChildrenByParentId(Integer parentId);

	void insertDepartment(Department department);

	void updateDepartment(Department department);

	List<Department> initParentDeptOptions(Department department);

	Department selectDeptByPrimaryKey(Integer id);

	List<DepartmentItem> selectDepartmentItemForManager(Department department);

	void updateForbiddenOrUseData(Department department);

	List<Department> initItemDeptOptions(Department department);

	void updateForbiddenItemDept(Department department);

	List<Department> selectByPrimaryIdList(
			List<String> parentIdList);

	List<AuthDepartment> getDepartmentList(Department department);

	AuthDepartment getDepartmentById(Integer id);

	List<ZtreeDept> initParentDeptOptionsNew(Department department);

	List<Department> selectDepartmentForManagerNew(Department department);
}