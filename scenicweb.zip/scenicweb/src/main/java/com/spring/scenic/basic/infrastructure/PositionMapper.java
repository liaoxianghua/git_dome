package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.basic.domain.Position;

public interface PositionMapper {

	/**
	 * @Description 删除位置信息
	 * @param position
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月8日
	 */
	int deletePosition(Position position);

	/**
	 * @Description 批量保存位置信息
	 * @param positions
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月8日
	 */
	int saveBatchPosition(List<Position> positions);


	/**
	 * @Description 根据外键、类别查询其位置信息
	 * @param positionExample
	 * @return List<Position>
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	List<Position> getPositionList(Position positionExample);
}