package com.spring.scenic.basic.domain;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.spring.scenic.common.domain.Entity;

public class Province extends Entity<Province> {
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 操作人id
	 */
	private Integer userId;
	/**
	 * 省份名称
	 */
	private String name;
	/**
	 * 国家id
	 */
	private String countryid;
	/**
	 * 国家
	 */
	private Integer country;
	/**
	 * 国家id
	 */
	private Integer countryId;
	/**
	 * 英语名称
	 */
	private String enName;
	/**
	 * 拼音
	 */
	private String pinyin;
	/**
	 * 状态 1：有效 ,0：无效
	 */
	private String valid;
	/**
	 * 状态 1：有效 ,0：无效
	 */
	private Integer status;
	/**
	 * 国家状态 1:有效 0：无效
	 */
	private Integer countryValid;
	/**
	 * 洲际id
	 */
	private String continentid;
	/**
	 * 
	 */
	private String lng;
	
	private String lat;
	/**
	 * 创建时间
	 */
	private Date createDate;
	/**
	 * 创建人
	 */
	private Integer createUser;
	/**
	 * 更新时间
	 */
	private Date updateDate;
	/**
	 * 更新人
	 */
	private Integer updateUser;
	/**
	 * 创建人
	 */
	private String createName;
	/**
	 * 国家
	 */
	private String countryName;

	/**
	 * 操作人
	 */
	private String updateName;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountryid() {
		return countryid;
	}

	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}

	public String getEnName() {
		return StringUtils.isBlank(enName)?null:enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getPinyin() {
		return pinyin;
	}

	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}

	public String getValid() {
		return valid;
	}

	public void setValid(String valid) {
		this.valid = valid;
	}

	public String getContinentid() {
		return continentid;
	}

	public void setContinentid(String continentid) {
		this.continentid = continentid;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Integer getUpdateuser() {
		return updateUser;
	}

	public void setUpdateuser(Integer updateuser) {
		this.updateUser = updateuser;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCountry() {
		return country;
	}

	public void setCountry(Integer country) {
		this.country = country;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public Integer getCountryValid() {
		return countryValid;
	}

	public void setCountryValid(Integer countryValid) {
		this.countryValid = countryValid;
	}

}