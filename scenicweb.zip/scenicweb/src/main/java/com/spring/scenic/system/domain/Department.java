package com.spring.scenic.system.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class Department extends Entity<Department> implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4781551213306603473L;
	private Integer id;
	private String name;//部门名称
	private Integer parentId;//父部门id
	private String parentStrId;
	private String parentName;//父部门名称
	private String remarks;//备注
	private Integer type;//1 平台 2 景区 3 商户 4 其他
	private Integer valid;//有效 无效
	private Date createTime;//创建时间
	private Integer createUserId;
	private AuthUser createUser;//创建人信息
	private String createUserName;
	private Date updateTime;//修改时间
	private String updateUserName;
	private AuthUser updateUser;//修改人信息
	private Integer updateUserId;
	private List<Department> children;
	private String guid;
	private Date times;
	
	
	private String flag;//标识启用禁用 0禁用 1启用
	
	
	public Date getTimes() {
		return times;
	}
	public void setTimes(Date times) {
		this.times = times;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getParentStrId() {
		return parentStrId;
	}
	public void setParentStrId(String parentStrId) {
		this.parentStrId = parentStrId;
	}
	public String getCreateUserName() {
		return createUserName;
	}
	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	public String getUpdateUserName() {
		return updateUserName;
	}
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}
	public Integer getCreateUserId() {
		return createUserId;
	}
	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}
	public Integer getUpdateUserId() {
		return updateUserId;
	}
	public void setUpdateUserId(Integer updateUserId) {
		this.updateUserId = updateUserId;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getValid() {
		return valid;
	}
	public void setValid(Integer valid) {
		this.valid = valid;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public AuthUser getCreateUser() {
		return createUser;
	}
	public void setCreateUser(AuthUser createUser) {
		this.createUser = createUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public AuthUser getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(AuthUser updateUser) {
		this.updateUser = updateUser;
	}
	public List<Department> getChildren() {
		return children;
	}
	public void setChildren(List<Department> children) {
		this.children = children;
	}
	@Override
	public int hashCode() {
		String in = String.valueOf(id);
		return in.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		Department temp=(Department)obj;
		return id.equals(temp.id);
	}
	
}
