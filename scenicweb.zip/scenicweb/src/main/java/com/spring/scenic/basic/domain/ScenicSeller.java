package com.spring.scenic.basic.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class ScenicSeller extends Entity<ScenicSeller>{
    /**
     */
    private Integer id;

    /**
     */
    private String name;

    /**
     */
    private String type;

    /**
     */
    private String typeCategory;

    /**
     */
    private Integer parentId;

    /**
     */
    private Integer cityId;

    /**
     */
    private Integer cityAreaId;

    /**
     */
    private String address;

    /**
     */
    private String tel;

    /**
     */
    private Integer valid;

    /**
     */
    private String businessTime;

    /**
     */
    private String starLevel;

    /**
     */
    private String guid;

    /**
     */
    private Integer autyStatus;

    /**
     */
    private Date createTime;

    /**
     */
    private Integer createUser;

    /**
     */
    private Date updateTime;

    /**
     */
    private Integer updateUser;

    /**
     */
    private String coversImageUrl;

    /**
     */
    private String coversImageName;
    /**
     */
    private String traffics;

    /**
     */
    private String introduce;

    /**
     */
    private String tips;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeCategory() {
		return typeCategory;
	}

	public void setTypeCategory(String typeCategory) {
		this.typeCategory = typeCategory;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getCityAreaId() {
		return cityAreaId;
	}

	public void setCityAreaId(Integer cityAreaId) {
		this.cityAreaId = cityAreaId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public Integer getValid() {
		return valid;
	}

	public void setValid(Integer valid) {
		this.valid = valid;
	}

	public String getBusinessTime() {
		return businessTime;
	}

	public void setBusinessTime(String businessTime) {
		this.businessTime = businessTime;
	}

	public String getStarLevel() {
		return starLevel;
	}

	public void setStarLevel(String starLevel) {
		this.starLevel = starLevel;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public Integer getAutyStatus() {
		return autyStatus;
	}

	public void setAutyStatus(Integer autyStatus) {
		this.autyStatus = autyStatus;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getCoversImageUrl() {
		return coversImageUrl;
	}

	public void setCoversImageUrl(String coversImageUrl) {
		this.coversImageUrl = coversImageUrl;
	}

	public String getCoversImageName() {
		return coversImageName;
	}

	public void setCoversImageName(String coversImageName) {
		this.coversImageName = coversImageName;
	}

	public String getTraffics() {
		return traffics;
	}

	public void setTraffics(String traffics) {
		this.traffics = traffics;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public String getTips() {
		return tips;
	}

	public void setTips(String tips) {
		this.tips = tips;
	}

}