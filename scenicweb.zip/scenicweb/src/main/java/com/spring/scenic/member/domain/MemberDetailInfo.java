package com.spring.scenic.member.domain;

import java.util.Date;
import java.util.List;

public class MemberDetailInfo {
 
    private Integer id;
    
    private Integer memberId;

    private Integer fkId;//外部关联id

    private Short type;//1 会员 2 常旅客

    private String nameCh;//常旅客中文姓名

    private String nameChPin;//常旅客中文拼音

    private String nameEnF;

    private String nameEnS;//英文名

    private Short sex;//1 男 0 女

    private String nationality;//国籍

    private Date birthday;//生日

    private String phoneCh;//大陆移动电话

    private String phoneOverseas;//海外手机

    private String fixTelArea;//固定电话区号

    private String fixTel;//固定电话

    private String fixTelExtension;//固定电话分机

    private String mail;//邮箱

    private Integer countryId;//国家id

    private Integer provinceId;//省份id

    private Integer cityId;//城市id

    private Date createTime;

    private Integer createUser;

    private Date updateTime;

    private Integer updateUser;
    
    private Integer degreeEdu;
    
    private Integer profession;

    private String imgUrl;
    
    private String birthdayDate;
    
    List<MemberDocument> documents;
    
    //常旅客是否为会员本人（1：是0：否）
    private Integer isSelf; 
    
    //常旅客类型（1:成人 、2:儿童、3:婴儿）
    private Integer passengerType; 
    
    
    public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public String getBirthdayDate() {
		return birthdayDate;
	}

	public void setBirthdayDate(String birthdayDate) {
		this.birthdayDate = birthdayDate;
	}

	public List<MemberDocument> getDocuments() {
		return documents;
	}

	public void setDocuments(List<MemberDocument> documents) {
		this.documents = documents;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFkId() {
        return fkId;
    }

    public void setFkId(Integer fkId) {
        this.fkId = fkId;
    }

    public String getNameCh() {
        return nameCh;
    }

    public void setNameCh(String nameCh) {
        this.nameCh = nameCh == null ? null : nameCh.trim();
    }

    public String getNameChPin() {
        return nameChPin;
    }

    public void setNameChPin(String nameChPin) {
        this.nameChPin = nameChPin == null ? null : nameChPin.trim();
    }

    public String getNameEnF() {
        return nameEnF;
    }

    public void setNameEnF(String nameEnF) {
        this.nameEnF = nameEnF == null ? null : nameEnF.trim();
    }

    public String getNameEnS() {
        return nameEnS;
    }

    public void setNameEnS(String nameEnS) {
        this.nameEnS = nameEnS == null ? null : nameEnS.trim();
    }

    public Short getSex() {
        return sex;
    }

    public void setSex(Short sex) {
        this.sex = sex;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality == null ? null : nationality.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getPhoneCh() {
        return phoneCh;
    }

    public void setPhoneCh(String phoneCh) {
        this.phoneCh = phoneCh == null ? null : phoneCh.trim();
    }

    public String getPhoneOverseas() {
        return phoneOverseas;
    }

    public void setPhoneOverseas(String phoneOverseas) {
        this.phoneOverseas = phoneOverseas == null ? null : phoneOverseas.trim();
    }

    public String getFixTelArea() {
        return fixTelArea;
    }

    public void setFixTelArea(String fixTelArea) {
        this.fixTelArea = fixTelArea == null ? null : fixTelArea.trim();
    }

    public String getFixTel() {
        return fixTel;
    }

    public void setFixTel(String fixTel) {
        this.fixTel = fixTel == null ? null : fixTel.trim();
    }

    public String getFixTelExtension() {
        return fixTelExtension;
    }

    public void setFixTelExtension(String fixTelExtension) {
        this.fixTelExtension = fixTelExtension == null ? null : fixTelExtension.trim();
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail == null ? null : mail.trim();
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

	public Integer getDegreeEdu() {
		return degreeEdu;
	}

	public void setDegreeEdu(Integer degreeEdu) {
		this.degreeEdu = degreeEdu;
	}

	public Integer getProfession() {
		return profession;
	}

	public void setProfession(Integer profession) {
		this.profession = profession;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
    
	 public Integer getIsSelf() {
	        return isSelf;
	    }

    public void setIsSelf(Integer isSelf) {
        this.isSelf = isSelf;
    }

    public Integer getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(Integer passengerType) {
        this.passengerType = passengerType;
    }
}