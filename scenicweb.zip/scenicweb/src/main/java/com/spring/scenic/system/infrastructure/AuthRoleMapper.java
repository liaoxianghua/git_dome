package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;

public interface AuthRoleMapper {

	List<AuthRole> queryRoleList(AuthRole authRole);

	void insertRole(AuthRole authRole);

	void updateRole(AuthRole authRole);

	AuthRole selectByPrimaryKey(Integer id);

	void updateForbiddenOrUseData(AuthRole authRole);

	void updateByPrimaryKey(AuthRole aRole);

	List<AuthRole> getRoleListByUser(AuthUser authUser);

	List<AuthRole> setlectRoleByUserId(AuthUser authUser);

	List<AuthRole> getRoleList(AuthRole authRole);

	List<AuthRole> getRoleListByResource(AuthResource resource);

	AuthRole getRole(AuthRole authRole);
	
}