package com.spring.scenic.basic.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;
/**
 * 关键字管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "basic/keyword")
public class KeywordController {
	
	@Autowired
	private KeywordService keywordService;
	
	/**
	 *
	 *@Description:关键字管理跳转页面
	 *@Auth: lichangmao
	 *@2017年1月17日
	 */
	@RequestMapping(value = "keywordList")
	public String keywordList() {
		return "/basic/keyword/keywordList";
	}
	/**
	 * 添加关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	@RequestMapping(value = "keywordAdd")
	public String countryManagementEdit(HttpServletRequest request, HttpServletResponse response,Keyword keyword) {
		if (keyword.getId()!= null && !"".equals(keyword.getId())) {
			Keyword editVo = keywordService.selectByPrimaryKey(keyword.getId());
			request.setAttribute("keywordVo", editVo);
		}
		return "/basic/keyword/keywordAdd";
	}
	
	/**
	 * 
	  * @Description: 关键字管理信息详情
	  * @param @param userDTO
	  * @param @param dataGrid
	  * @param @return
	  * @return DataGridResponse
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:22
	 */
	@RequestMapping(value = "queryKeywordList" ,method=RequestMethod.POST)
	@ResponseBody
	public EntityData queryKeywordList(HttpServletRequest request, HttpServletResponse response,Keyword keyword) {
		keyword.initDataTableParam(request);
		List<Keyword> list = keywordService.queryKeywordList(keyword, SysConstant.PAGE_TRUE);
		PageInfo<Keyword> page = new PageInfo<Keyword>(list);
		EntityData data = new EntityData(keyword,page);
		return data;
	}
	/**
	 * 新增修改关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月17日
	 */
	@ResponseBody
	@RequestMapping(value = "addKeyword" ,method=RequestMethod.POST)
	public  MessageData addKeyword(HttpServletRequest request, HttpServletResponse response,Keyword keyword){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (keyword.getId() == null) {
			keywordService.addKeyword(keyword,userInfo);
		}else {
			keywordService.updateByPrimaryKey(keyword, userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,Keyword keyword){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysConstant.IS_FORBIDDEN_FLAG_NO.equals(keyword.getFlag())) {
			keyword.setValid(Integer.valueOf(SysConstant.VALITY_NO));
		}else {
			keyword.setValid(Integer.valueOf(SysConstant.VALITY_YES));
		}
		keywordService.updateKeywordById(keyword,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 查询游记攻略中关键字下拉联想内容
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	@ResponseBody
	@RequestMapping(value = "selectKeywordList" ,method=RequestMethod.POST)
	public List<Keyword> selectKeywordList(HttpServletRequest request, HttpServletResponse response,Keyword keyword){
		return keywordService.selectKeywordList(keyword);
	}
	/**
	 * 增加游记管理相关关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	@ResponseBody
	@RequestMapping(value = "addTravelNoteKeyword" ,method=RequestMethod.POST)
	public Keyword addTravelNoteKeyword(HttpServletRequest request, HttpServletResponse response,Keyword keyword){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		Keyword keyword2 = new Keyword();
		
		try {
			int count = keywordService.getTravelKeywordRef(keyword);
			if (count>0) {
				keyword2.setFlag(SysConstant.OPT_FAIL); 
				return keyword2;
			}else {
				keyword2 = keywordService.addTravelNoteKeyword(keyword,userInfo);
				keyword2.setFlag(SysConstant.OPT_SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return keyword2;
	}
	
	
}
