package com.spring.scenic.material.infrastructure;

import java.util.List;

import com.spring.scenic.material.domain.Pictures;

public interface PicturesMapper {

	List<Pictures> getPictureList(Pictures picture);

	Pictures getPicture(Pictures picture);

	int updatePicture(Pictures pictureExample);

	int deletePicture(Pictures picture);

	int saveBatchPictures(List<Pictures> pictures);

	List<Pictures> getPictureListByReIdAndType(Pictures picture);

	void updatePictureList(List<Pictures> pictures);

	int updatePictureByFK(Pictures picture);
}