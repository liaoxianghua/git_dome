/**
 * 
 */
package com.spring.scenic.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

/**
 * 日期工具
 * 2016-07-15
 */
public class DateUtil {
	/**
	 *@author 012404
	 *获取日期所在月的第一天
	 */
	public static Calendar getFirstDayOfMonthByDate(Date currentDate){
		Calendar firstDayOfMonth = new GregorianCalendar();
		firstDayOfMonth.setTime(currentDate);
		firstDayOfMonth.set(Calendar.DAY_OF_MONTH, 1);
		return firstDayOfMonth;
	}
	/**
	 *@author 012404 
	 *获取日期所在月的最后一天
	 */
	public static Calendar getLastDayOfMonthByDate(Date currentDate){
		Calendar lastDayOfMonth = new GregorianCalendar();
		lastDayOfMonth.setTime(currentDate);
		lastDayOfMonth.set(Calendar.DAY_OF_MONTH, 1);
		lastDayOfMonth.add(Calendar.MONTH, 1);
		lastDayOfMonth.add(Calendar.DAY_OF_MONTH, -1);
		return lastDayOfMonth;
	}
	/**
	 *@author 012404 
	 *获取日期所在周的周日
	 */
	public static Calendar getSundayByDate(Date currentDate){
		Calendar sunday = new GregorianCalendar();
		sunday.setTime(currentDate);
		sunday.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		return sunday;
	}
	/**
	 *@author 012404 
	 *获取日期所在周的周六
	 */
	public static Calendar getSaturdayByDate(Date currentDate){
		Calendar saturday = new GregorianCalendar();
		saturday.setTime(currentDate);
		saturday.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		return saturday;
	}
	
	/**
	 * 判断两个日期是否同一天
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isSameDate(Date date1, Date date2) {
		if(date1 == null || date2 == null)
			return false;
		Calendar calendarDate1 = Calendar.getInstance();
		Calendar calendarDate2 = Calendar.getInstance();
		calendarDate1.setTime(date1);
		calendarDate2.setTime(date2);
		if(calendarDate1.get(Calendar.YEAR)==calendarDate2.get(Calendar.YEAR) &&
			calendarDate1.get(Calendar.MONTH)==calendarDate2.get(Calendar.MONTH) &&
			calendarDate1.get(Calendar.DATE)==calendarDate2.get(Calendar.DATE))
			return true;
		return false;
	}
	
	/**
	 * 判断两个日期是否同一个月
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isSameMonth(Date date1, Date date2) {
		if (date1 == null || date2 == null)
			return false;

		Calendar calendarDate1 = Calendar.getInstance();
		Calendar calendarDate2 = Calendar.getInstance();

		// 设日历为相应日期
		calendarDate1.setTime(date1);
		calendarDate2.setTime(date2);

		if (calendarDate1.get(Calendar.YEAR) == calendarDate2.get(Calendar.YEAR) && calendarDate1.get(Calendar.MONTH) == calendarDate2.get(Calendar.MONTH))
			return true;

		return false;
	}
	/**
	 * 按指定格式，格式化日期
	 * yyyy-MM-dd yyyy-MM-dd HH:mm:ss
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static String formatDate(Date date,String pattern){
		if(date==null)
			return null;
		SimpleDateFormat df = new SimpleDateFormat(pattern);
		String formatDate = df.format(date);
		return formatDate;
	}
	/**
	 * 根据指定日期获取上一个月
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getPreviousMonth(Date date){
		if(date==null)
			return null;
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		return c.get(Calendar.MONTH)+1;
	}
	/**
	 * 根据指定日期获取上一个月的年份
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getYearOfPreviousMonth(Date date){
		if(date==null)
			return null;
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		return c.get(Calendar.YEAR);
	}
	/**
	 * 根据指定日期获取下一个月
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getNextMonth(Date date){
		if(date==null)
			return null;
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		c.add(Calendar.MONTH, 1);
		return c.get(Calendar.MONTH)+1;
	}
	/**
	 * 根据指定日期获取下一个月的年份
	 * 
	 * @param date
	 * @return
	 */
	public static Integer getYearOfNextMonth(Date date){
		if(date==null)
			return null;
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		c.add(Calendar.MONTH, 1);
		return c.get(Calendar.YEAR);
	}
	/**
	 * 根据日期返回时间，格式：HH:MM
	 * 
	 * @param date
	 * @return
	 */
	public static String getTime(Date date){
		if(date==null)
			return null;
		String timeStr="";
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int minute = c.get(Calendar.MINUTE);
		if(hour<10)
			timeStr = "0"+hour;
		else
			timeStr = ""+hour;
		if(minute<10)
			timeStr = timeStr + ":" +"0" + minute;
		else
			timeStr = timeStr + ":" + minute;
		return timeStr;
	}
	
	public static String getDisplayWeek(int dayOfWeek){
		MessageSource messageSource = (MessageSource)ApplicationContentUtil.getBean("messageSource");
        String[] args = null;
		switch(dayOfWeek) {
			case 1: return messageSource.getMessage("lable.selfCourseQuery.monday", args, Locale.CHINA);
			case 2: return messageSource.getMessage("lable.selfCourseQuery.tuesday", args, Locale.CHINA);
			case 3: return messageSource.getMessage("lable.selfCourseQuery.wednesday", args, Locale.CHINA);
			case 4: return messageSource.getMessage("lable.selfCourseQuery.thursday", args, Locale.CHINA);
			case 5: return messageSource.getMessage("lable.selfCourseQuery.friday", args, Locale.CHINA);
			case 6: return messageSource.getMessage("lable.selfCourseQuery.saturday", args, Locale.CHINA);
			case 0: return messageSource.getMessage("lable.selfCourseQuery.sunday", args, Locale.CHINA);
			default: return "";
		}
	}
	
	public static String getDateOfNextWeek(Date currentDate){
		String dateStr = "";
		if(currentDate==null)
			return dateStr;
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.WEEK_OF_MONTH, 1);
		dateStr = formatDate(calendar.getTime(), "yyyy-MM-dd");
		return dateStr;
	}
	
	public static String getDateOfPreviousWeek(Date currentDate){
		String dateStr = "";
		if(currentDate==null)
			return dateStr;
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.WEEK_OF_MONTH, -1);
		dateStr = formatDate(calendar.getTime(), "yyyy-MM-dd");
		return dateStr;
	}
	public static Date stringToDate(String str){
		if(StringUtils.isBlank(str)){
			return null;
		}
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		try {
			date=sdf.parse(str);
		} catch (ParseException e) {
	       	e.printStackTrace();
	       
		}
		return date;
	}
	public static Date stringToDate1(String str){
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy年MM月dd日");
		try {
			date=sdf.parse(str);
		} catch (ParseException e) {
	       	e.printStackTrace();
	       
		}
		return date;
		
		
	}
	public static String dateToString(Date date){
		String str="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		try {
			str=sdf.format(date);
		} catch (Exception e) {
           	e.printStackTrace();
		}
		return str;
	}
	public static String dateToString1(Date date){
		String str="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy年MM月dd日");
		try {
			str=sdf.format(date);
		} catch (Exception e) {
           	e.printStackTrace();
		}
		return str;
	}
	public static String dateToString2(Date date){
		String str="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
		try {
			str=sdf.format(date);
		} catch (Exception e) {
           	e.printStackTrace();
			
		}
		return str;
	}
	public static String dateToStringfull(Date date){
		String str="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			str=sdf.format(date);
		} catch (Exception e) {
           	e.printStackTrace();
		}
		return str;
	}
	
	public static Date getNow() {
		return new Date();
	}
	
	
	public static void main(String[] args) {
		//System.out.println(getDateOfNextWeek(new Date()));
		//System.out.println(getDateOfPreviousWeek(new Date()));
		/*System.out.println(stringToDate("1989/8/5"));*/
		//System.out.println(Long.parseLong("100"));
		/*String str="150610006";
		System.out.println(str.substring(0, 6));*/
		System.out.println(stringToDate("15555555"));
		/*Log4JLogger l=new Log4JLogger("log4j.properties");
		l.debug("dug记录");
	    l.error("日志正在记录");
	    l.info("消息记录中。。。");
		try {
			Log4JLogger ll=null;
			ll.debug("----");
		} catch (Exception e) {
			l.debug(e, e.fillInStackTrace());
			l.error(e, e.fillInStackTrace());
		}*/
	}

}
