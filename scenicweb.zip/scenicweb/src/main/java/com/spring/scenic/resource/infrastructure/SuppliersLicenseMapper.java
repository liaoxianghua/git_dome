package com.spring.scenic.resource.infrastructure;

import java.util.List;

import com.spring.scenic.resource.domain.SuppliersLicense;

/**
 * Created by lenovo on 2017/1/25.
 */
public interface SuppliersLicenseMapper {

    /**
     * 查询供应商证照管理列表信息
     * @param suppliersLicense
     * @return
     */
    List<SuppliersLicense> getSuppliersLicenseList(SuppliersLicense suppliersLicense) throws Exception;

    /**
     * 新增供应商证件信息
     * @param suppliersLicense
     */
    void addSuppliersLicense(SuppliersLicense suppliersLicense) throws Exception;

    /**
     * 删除供应商证件信息
     * @param suppliersLicense
     * @throws Exception
     */
    void deleteSuppliersLicense(SuppliersLicense suppliersLicense) throws Exception;

    /**
     * 删除供应商证件图片
     * @throws Exception
     */
    void updateSuppliersLicense(SuppliersLicense suppliersLicense) throws Exception;
}
