package com.spring.scenic.busi.infrastructure;

import com.spring.scenic.busi.domain.BusiSellerUser;

public interface BusiSellerUserMapper {
    
    BusiSellerUser getSellerAccountById(Integer id);

    int addBusiSellerUser(BusiSellerUser busiSellerUser);

    BusiSellerUser getSellerAccount(BusiSellerUser busiSellerUser);

    int updateBusiSellerUser(BusiSellerUser busiSellerUserExample);

    /**   
     * 此处为类方法说明:商户账号不能重复，新增编辑时，做重复校验
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月23日     
     * @memo ：   
     **
     */
    int selectAccountCountByParam(BusiSellerUser busiSellerUser);
}