package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.basic.domain.ScenicSeller;

public interface ScenicSellerMapper {

	List<ScenicSeller> getScenicSellerList(ScenicSeller scenicSeller);
	
}