package com.spring.scenic.system.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.application.AuthRoleService;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.AuthUserRole;

/**
 *@Description:角色管理
 *@Auth: lichangmao
 *@2017年1月6日
 */
@Controller
@RequestMapping("system/role")
public class AuthRoleController {
	
	@Autowired
	private AuthRoleService authRoleService;

	/**
	 *@Description:角色主页面
	 *@Auth: lichangmao
	 *@2017年1月6日
	 */
	@RequestMapping(value="roleManagement")
	public String roleManagement(){
		return "/system/role/roleManagementMain";
	}
	
	/**
	 * @Description 点击权限管理进入分配权限界面
	 * @param request
	 * @param authRole
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年2月6日
	 */
	@RequestMapping(value="roleResourceAssign")
	public String assignRoleResource(HttpServletRequest request,AuthRole authRole){
		authRole = authRoleService.getRole(authRole);
		request.setAttribute("role", authRole);
		return "/system/role/roleResourceAssign";
	}
	
	
	/**
	 * @Description 点击查看用户进入用户列表界面
	 * @param request
	 * @param authRole
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年2月6日
	 */
	@RequestMapping(value="roleUsersShow")
	public String showRoleUsers(HttpServletRequest request,AuthRole authRole){
		request.setAttribute("authRole", authRole);
		return "/system/role/roleUsersShow";
	}
	/**
	 * @Description 查看角色用户信息列表
	 * @param request
	 * @param authUserRole
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年2月6日
	 */
	@ResponseBody
	@RequestMapping(value = "getRoleUserList" ,method=RequestMethod.POST)
	public EntityData getRoleUserList(HttpServletRequest request, HttpServletResponse response,AuthUserRole authUserRole) {
		authUserRole.initDataTableParam(request);
		List<AuthUserRole> list = authRoleService.getRoleUserList(authUserRole, SysConstant.PAGE_TRUE);
		PageInfo<AuthUserRole> page = new PageInfo<AuthUserRole>(list);
		EntityData data = new EntityData(authUserRole,page);
		return data;
	}
	/**
	 * @Description 移除角色中的用户
	 * @param request
	 * @param authUserRole
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年2月6日
	 */
	@ResponseBody
	@RequestMapping(value = "deleteRoleUser" ,method=RequestMethod.POST)
	public MessageData deleteRoleUser(HttpServletRequest request, HttpServletResponse response,AuthUserRole authUserRole) {
		authRoleService.deleteRoleUser(authUserRole);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 *@Description:编辑角色页面
	 *@Auth: lichangmao
	 *@2017年1月6日
	 */
	@RequestMapping(value="roleManagementEdit")
	public String roleManagementEdit(HttpServletRequest request, HttpServletResponse response,AuthRole authRole){
		if (authRole.getId()!=null) {
			AuthRole auRole = authRoleService.selectByPrimaryKey(authRole.getId());
			request.setAttribute("roleVo", auRole);
		}
		return "/system/role/roleManagementEdit";
	}
	@ResponseBody
	@RequestMapping(value = "queryRoleList" ,method=RequestMethod.POST)
	public EntityData queryRoleList(HttpServletRequest request, HttpServletResponse response,AuthRole authRole) {
		authRole.initDataTableParam(request);
		List<AuthRole> list = authRoleService.queryRoleList(authRole, SysConstant.PAGE_TRUE);
		PageInfo<AuthRole> page = new PageInfo<AuthRole>(list);
		EntityData data = new EntityData(authRole,page);
		return data;
	}
	/**
	 * 新增修改数据
	 * @param request
	 * @param response
	 * @param department
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "operateRole" ,method=RequestMethod.POST)
	public  MessageData operateRole(HttpServletRequest request, HttpServletResponse response,AuthRole authRole) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (authRole.getId()==null || "".equals(authRole.getId())) {
			authRoleService.addRole(authRole,userInfo);
		}else {
			authRoleService.updateRole(authRole,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,AuthRole authRole){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysEnum.COMMON_USEABLE_NO.getCode().equals(authRole.getFlag())) {
			authRole.setValid(Short.valueOf(SysConstant.VALITY_NO));
		}else {
			authRole.setValid(Short.valueOf(SysConstant.VALITY_YES));
		}
		authRoleService.updateForbiddenOrUseData(authRole,userInfo);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
	@ResponseBody
	@RequestMapping(value = "updatePermission" ,method=RequestMethod.POST)
	public MessageData updatePermission(HttpServletRequest request,Integer resourceId,Integer roleId,Integer status){
		if(resourceId==null || roleId==null || status==null){
			return new MessageData(SysConstant.OPERATE_FAILURE,SysConstant.OPERATE_FAILURE_MESSAGE);
		}else{
			AuthUser user =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
			authRoleService.updatePermission(resourceId,roleId,status,user);
			return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE);
		}
		
	}
	
}
