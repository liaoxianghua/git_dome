package com.spring.scenic.common.extend;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 页面标签验证
 * @author 006568（shuchang）
 * @date 2017年2月13日
 */
public class AuthTag extends TagSupport {

	private static final long serialVersionUID = 8760956338107811609L;
	
	private static final Logger logger = Logger.getLogger(AuthTag.class);
	
	private String code;
	
	private ServletContext servletContext;
	
	private HttpServletRequest servletRequest;
	
	@Override
	public int doStartTag() throws JspException {
		try {
			AuthUserService userService = WebApplicationContextUtils.getWebApplicationContext(servletContext).getBean(AuthUserService.class);
			AuthUser user = (AuthUser) servletRequest.getSession(false).getAttribute(SysConstant.SESSION_USER);
			logger.info("AuthTag start to authorityUser(code: "+code+" —— userId: "+user.getId()+" ) ...");
			if(StringUtils.isNotBlank(code) && user!=null){
				if(userService.authorityUser(code,user)){
					return EVAL_BODY_INCLUDE;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("AuthTag start to authorityUser happen some  Exception ...",e);
			return SKIP_BODY;
		}
		return SKIP_BODY;
	}

	@Override
	public void setPageContext(PageContext pageContext) {
		servletRequest = (HttpServletRequest)pageContext.getRequest();
		servletContext = pageContext.getServletContext();
		super.setPageContext(pageContext);
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
