package com.spring.scenic.material.infrastructure;

import java.util.List;

import com.spring.scenic.material.domain.Material;

public interface MaterialMapper {

	/**
	 * @Description 批量保存素材信息
	 * @param materials
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	int saveBatchMaterials(List<Material> materials);

	/**
	 * @Description 查询素材列表数据
	 * @param material
	 * @return List<Material>
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	List<Material> getMaterialList(Material material);

	/**
	 * @Description 查询单个素材
	 * @param material
	 * @return Material
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	Material getMaterial(Material material);

	/**
	 * @Description 删除素材
	 * @param material
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int deleteMaterial(Material material);

	/**
	 * @Description 修改素材库信息
	 * @param materialExample
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	int updateMaterial(Material materialExample);
	
} 