package com.spring.scenic.cms.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class SysConfigKeyword extends Entity<SysConfigKeyword>{
   /**
    * 主键id
    */
    private Integer id;
    /**
     * 关键字id
     */
    private Integer keywordId;
    /**
     * 系统配置id
     */
    private Integer sysConfigId;
    /**
     * 排序序号
     */
    private Integer ord;
    /**
     * 创建人
     */
    private Integer createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private Integer updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getKeywordId() {
        return keywordId;
    }

    public void setKeywordId(Integer keywordId) {
        this.keywordId = keywordId;
    }

    public Integer getSysConfigId() {
        return sysConfigId;
    }

    public void setSysConfigId(Integer sysConfigId) {
        this.sysConfigId = sysConfigId;
    }

	public Integer getOrd() {
		return ord;
	}

	public void setOrd(Integer ord) {
		this.ord = ord;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
    
}