/**
 * 
 */
package com.spring.scenic.cms.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.basic.domain.KeywordRef;
import com.spring.scenic.basic.infrastructure.KeywordMapper;
import com.spring.scenic.cms.application.SysConfigService;
import com.spring.scenic.cms.domain.SysConfig;
import com.spring.scenic.cms.domain.SysConfigPic;
import com.spring.scenic.cms.infrastructure.SysConfigMapper;
import com.spring.scenic.cms.infrastructure.SysConfigPicMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.system.domain.AuthUser;

/** @Description 系统配置service接口实现类
 *  @author：ranmaoping
 *  @date:下午2:51:51 2017年3月6日
 *  @version:1.0
 *
 */
@Service
public class SysConfigServiceImpl implements SysConfigService {
	
	@Autowired 
	SysConfigMapper sysConfigMapper;
	@Autowired 
	SysConfigPicMapper sysConfigPicMapper;
	@Autowired 
	KeywordMapper keywordMapper;
	
	/**
	 * 查询系统配置列表
	 */
	@Override
	public List<SysConfig> getsysConfigList(SysConfig sysConfig,boolean pageAble) {
		try {
			if (pageAble) {
				PageHelper.startPage(sysConfig.getPageNum(),SysConstant.PAGE_PAGESIZE);
			}
			List<SysConfig> list = sysConfigMapper.getsysConfigList(sysConfig);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 更新系统配置状态
	 */
	@Override
	public void updateSysConfigStatus(AuthUser userInfo, SysConfig sysConfig) {
		try {
			sysConfig.setUpdateTime(new Date());
			sysConfig.setUpdateUser(userInfo.getId());
			sysConfigMapper.updateSysConfigStatus(sysConfig);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 根据id查询配置信息，填充编辑页面的值
	 */
	@Override
	public SysConfig getSysConfigInfoById(SysConfig sysConfig) {
		try {
			SysConfig sysConfigInfo = sysConfigMapper.getSysConfigInfoById(sysConfig);
			return sysConfigInfo;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 保存系统配置信息
	 */
	@Override
	public void saveSysConfig(AuthUser user, SysConfig sysConfig) {
		try {
			if(null==sysConfig.getId()) {
				sysConfig.setCreateTime(new Date());
				sysConfig.setCreateUser(user.getId());
				sysConfig.setUpdateTime(new Date());
				sysConfig.setUpdateUser(user.getId());
				sysConfigMapper.addSysConfig(sysConfig);
			}else{
				SysConfig sysConfigExample = sysConfigMapper.getSysConfigInfoById(sysConfig);
				sysConfigExample.setLocationCode(sysConfig.getLocationCode());
				sysConfigExample.setLocationName(sysConfig.getLocationName());
				sysConfigExample.setValid(sysConfig.getValid());
				sysConfigExample.setLocationType(sysConfig.getLocationType());
				sysConfigExample.setSysType(sysConfig.getSysType());
				sysConfigExample.setRemark(sysConfig.getRemark());
				sysConfigExample.setUpdateTime(new Date());
				sysConfigExample.setUpdateUser(user.getId());
				sysConfigMapper.updateSysConfig(sysConfigExample);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
		
		
	}
	/**
	 * 查询图文链接类型的内容信息
	 */
	@Override
	public List<SysConfigPic> getSysConfigPic(SysConfigPic sysConfigPic,boolean pageAble) {
		try {
			if (pageAble) {
				PageHelper.startPage(sysConfigPic.getPageNum(),SysConstant.PAGE_PAGESIZE);
			}
			List<SysConfigPic> list = sysConfigPicMapper.getSysConfigPic(sysConfigPic);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 保存内容配置图文链接信息
	 */
	@Override
	public void saveSysConfigPic(AuthUser user, SysConfigPic sysConfigPic) {
		try {
			if(null==sysConfigPic.getId()) {
				sysConfigPic.setCreateTime(new Date());
				sysConfigPic.setCreateUser(user.getId());
				sysConfigPic.setUpdateTime(new Date());
				sysConfigPic.setUpdateUser(user.getId());
				sysConfigPicMapper.addsysConfigPic(sysConfigPic);
			}else{
				SysConfigPic sysConfigPicExample = sysConfigPicMapper.getSysConfigPicInfoById(sysConfigPic);
				sysConfigPicExample.setTitle(sysConfigPic.getTitle());
				sysConfigPicExample.setSubTitle(sysConfigPic.getSubTitle());
				sysConfigPicExample.setMaterialId(sysConfigPic.getMaterialId());
				sysConfigPicExample.setPicSize(sysConfigPic.getPicSize());
				sysConfigPicExample.setUrl(sysConfigPic.getUrl());
				sysConfigPicExample.setStartTime(sysConfigPic.getStartTime());
				sysConfigPicExample.setEndTime(sysConfigPic.getEndTime());
				sysConfigPicExample.setOrd(sysConfigPic.getOrd());
				sysConfigPicExample.setUpdateTime(new Date());
				sysConfigPicExample.setUpdateUser(user.getId());
				sysConfigPicMapper.updateSysConfigPic(sysConfigPicExample);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 根据id查询图文链接信息
	 */
	@Override
	public SysConfigPic getSysConfigPicInfoById(SysConfigPic sysConfigPic) {
		try {
			SysConfigPic sysConfigPicInfo = sysConfigPicMapper.getSysConfigPicInfoById(sysConfigPic);
			return sysConfigPicInfo;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 删除图文链接信息
	 */
	@Override
	public void deleteSysConfigPic(SysConfigPic sysConfigPic) {
		try {
			sysConfigPicMapper.deleteSysConfigPic(sysConfigPic);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
		
	}
	/**
	 * 联想查询关键字
	 */
	@Override
	public List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword) {
		try {
			keyword.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			List<Keyword> list = keywordMapper.getSysConfigKeywordsByImagine(keyword);
			return list;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}
	/**
	 * 如果系统有该关键字，直接插入系统配置-关键字关联表，
	 * 如果没有，就将该关键字插入关键字表，再将其id 
	 * 插入系统配置-关键字关联表
	 */
	@Override
	public KeywordRef saveSysConfigKeyword(AuthUser user, KeywordRef keywordRef,Keyword keyword) {
		try {
            //查询系统配置关键字的数量,用于得到排序序号
            keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_SYSCONFIG.getCode()));
            int currentOrd = keywordMapper.getSysConfigKeywordCount(keywordRef);
            keywordRef.setOrd((currentOrd+1));
            keywordRef.setCreateTime(new Date());
            keywordRef.setCreateUser(user.getId());
            keywordRef.setUpdateTime(new Date());
            keywordRef.setUpdateUser(user.getId());
            //系统有该关键字
            if(null!=keywordRef.getKeywordId()&&null!=keywordRef.getOutRelatedId()) {
                //查询系统配置当前keywordId的数量，如果>0 ,则重复，返回
                int currentKeywordIdCount = keywordMapper.getCurrentKeywordIdCount(keywordRef);
                if(currentKeywordIdCount > 0) {
                    keywordRef.setFlag(SysConstant.OPT_FAIL);
                    return keywordRef;
                }else{
                    keywordMapper.addTravelNoteKeyword(keywordRef);
                    int type = keywordMapper.getkeywordTypeByid(keyword);
                    keyword.setType(type);
                    keywordRef.setKeyword(keyword);
                    keywordRef.setFlag(SysConstant.OPT_SUCCESS);
                    //return keywordRef;
                }
            }
            //系统无该关键字（根据有无关键字id来判断）
            if(null==keywordRef.getKeywordId()&&null!=keywordRef.getOutRelatedId()) {
                
            	if(StringUtil.isNotEmpty(keyword.getName())) {
            	    //规避联想插件造成的名为单个字符的关键字，第二次添加不联想绑定id的问题
            	    keyword.setType(1);
            	    keyword.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
            	    keyword.setOutRelatedId(keywordRef.getOutRelatedId());
            	    keyword.setOutRelatedType(keywordRef.getOutRelatedType());
            	    int count = keywordMapper.selectKeyNameCountByParam(keyword);
            	    if(count>0) {
            	        keywordRef.setFlag(SysConstant.OPT_FAIL);
                        return keywordRef;
            	    }        
            		keyword.setCreateTime(new Date());
            		keyword.setCreateUser(user.getId());
            		keyword.setUpdateTime(new Date());
            		keyword.setUpdateUser(user.getId());
            		keywordMapper.insertSelective(keyword);
            		int id = keyword.getId();
            		keywordRef.setKeywordId(id);
            		keywordMapper.addTravelNoteKeyword(keywordRef);
            		keywordRef.setFlag(SysConstant.OPT_SUCCESS);
            		keywordRef.setKeyword(keyword);
            		//return keywordRef;
            	}
            }
            return keywordRef;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
	}
	/**
	 * 查询系统配置相关的关键字
	 */
    @Override
    public List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef) {
        try {
            keywordRef.setOutRelatedType(Integer.valueOf(SysEnum.KEYWORD_RELEVANCE_TYPE_SYSCONFIG.getCode()));
            List<KeywordRef> keywordRefList = keywordMapper.getRealtiveKeywordList(keywordRef);
            return keywordRefList;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e); 
        }
    }
    /**
     * 删除系统配置相关的关键字
     */
    @Override
    public void deleteSysConfigKeyword(KeywordRef keywordRef) {
        try {
            keywordMapper.deleteSysConfigKeyword(keywordRef);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
        
    }
    /**
     * 系统配置关键字拖拽排序
     */
    @Override
    public void updateSysConfigKeywordOrder(KeywordRef keywordRef) {
       String [] idArray;
       String ids = keywordRef.getIds();
       if(StringUtil.isNotEmpty(ids)) {
           List<KeywordRef> list = new ArrayList<KeywordRef>();
           idArray = ids.split(",");
           for (int i = 0; i < idArray.length; i++) {
               KeywordRef keywordRefDto = new KeywordRef();
               String id = idArray[i];
               keywordRefDto.setId(Integer.valueOf(id));
               keywordRefDto.setOrd(i+1);
               list.add(keywordRefDto);
        }
           keywordMapper.updateSysConfigKeywordOrder(list);
       }
        
    }
    /**
     * 根据图文链接的id查询系统配置位置名称
     */
    @Override
    public SysConfig getSysConfigInfoByPicId(Integer id) {
        SysConfig sysConfig = sysConfigMapper.getSysConfigInfoByPicId(id);
        return sysConfig;
    }
}
