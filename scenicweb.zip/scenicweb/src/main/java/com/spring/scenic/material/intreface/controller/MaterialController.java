package com.spring.scenic.material.intreface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.material.domain.Material;
import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 素材上传、查询接口
 * @author 006568（shuchang）
 * @date 2017年1月5日
 */
@Controller
@RequestMapping("material/material")
public class MaterialController extends BaseController {
	
	@Autowired
	private MaterialService materialService;
	
	@Autowired
	private AuthUserService userService;
	
	
	/**
	 * @Description 菜单-素材上传
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@RequestMapping(value="materialUpload",method=RequestMethod.GET)
	public String materialUpload(HttpServletRequest request){
		return "material/material/materialUpload";
	}
	
	/**
	 * @Description 菜单-素材查询
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@RequestMapping(value="materialList",method=RequestMethod.GET)
	public String materialList(HttpServletRequest request){
		return "material/material/materialList";
	}
	
	/**
	 * @Description 我的历史上传
	 * @param request
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	@RequestMapping(value="materialHisList",method=RequestMethod.GET)
	public String materialHisList(HttpServletRequest request){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		request.setAttribute("user", user);
		return "material/material/materialHisList";
	}
	
	/**
	 * @Description 素材查看页面
	 * @param request
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	@RequestMapping(value="materialView",method=RequestMethod.GET)
	public String materialView(HttpServletRequest request,Material material){
		Material viewMaterial = materialService.getMaterial(material);
		request.setAttribute("materials", viewMaterial);
		return "material/material/materialView";
	}
	
	/**
	 * @Description 素材审核页面
	 * @param request
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	@RequestMapping(value="materialAudit",method=RequestMethod.GET)
	public String materialAudit(HttpServletRequest request,Material material){
		Material viewMaterial = materialService.getMaterial(material);
		request.setAttribute("materials", viewMaterial);
		return "material/material/materialAudit";
	}
	
	/**
	 * @Description 素材查询、我的上传历史分页数据
	 * @param request
	 * @param material
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="getMaterialListData",method=RequestMethod.POST)
	public EntityData getMaterialListDate(HttpServletRequest request,Material material){
		material.initDataTableParam(request);
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		if(material.getCreateUser()==null){
			if(!userService.authorityUser("R050203", user)){
				material.setExamineStatus(Integer.parseInt(SysEnum.MATERIAL_STATUS_PASS.getCode()));
			}
		}
		List<Material> materials = materialService.getMaterialList(material,SysConstant.PAGE_TRUE);
		PageInfo<Material> page = new PageInfo<Material>(materials);
		EntityData data = new EntityData(material,page);
		return data;
	}
	
	/**
	 * @Description 素材上传默认空表格数据
	 * @param request
	 * @param material
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年1月4日
	 */
	@ResponseBody
	@RequestMapping(value="materialUploadDefault",method=RequestMethod.POST)
	public EntityData materialUploadDefault(HttpServletRequest request,Material material){
		return new EntityData(new ArrayList<Material>());
	}
	
	/**
	 * @Description 批量保存素材信息
	 * @param request
	 * @param descriptions 描述
	 * @param types 类型
	 * @param usertypes 使用类型
	 * @param authorizedIds 授权信息
	 * @param keys 关键字
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="saveMaterialUpload",method=RequestMethod.POST)
	public MessageData saveMaterialUpload(HttpServletRequest request,String descriptions[],Integer types[],Integer usertypes[],Integer authorizedIds[],String names[],String keys[]){
		if(keys!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
			Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
			materialService.saveMaterialUpload(user,filesMap,descriptions,types,usertypes,authorizedIds,keys,names);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
	}
	
	/**
	 * @Description 删除素材
	 * @param request
	 * @param material
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="deleteMaterial",method=RequestMethod.POST)
	public MessageData deleteMaterial(HttpServletRequest request,Material material){
		if(material.getId()!=null){
			materialService.deleteMaterial(material);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
	}
	
	/**
	 * @Description 素材审核
	 * @param request
	 * @param material
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="auditMaterial",method=RequestMethod.POST)
	public MessageData auditMaterial(HttpServletRequest request,Material material){
		if(material.getId()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			materialService.auditMaterial(user,material);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}else{
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
	}
	
}
