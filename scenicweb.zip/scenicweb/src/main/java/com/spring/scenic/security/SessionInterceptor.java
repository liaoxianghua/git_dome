package com.spring.scenic.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.system.domain.AuthUser;

public class SessionInterceptor extends HandlerInterceptorAdapter{
	@Override
	public void afterCompletion(HttpServletRequest req,
			HttpServletResponse rsp, Object obj, Exception e)
			throws Exception {
	}

	@Override
	public void postHandle(HttpServletRequest req, HttpServletResponse rsp,
			Object obj, ModelAndView mode) throws Exception {
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
			Object obj) throws Exception {
			AuthUser loginUser = (AuthUser)request.getSession().getAttribute(SysConstant.SESSION_USER);
			if(loginUser==null){
			    response.setHeader("sessionstatus", "timeout");
			}
		   return true;
	}
}
