package com.spring.scenic.basic.infrastructure;

import java.util.List;

import com.spring.scenic.basic.domain.CommercialApprove;
import com.spring.scenic.basic.domain.MapMessage;
import com.spring.scenic.basic.domain.ScenicCommercial;
import com.spring.scenic.basic.domain.ScenicCommercialApprove;
import com.spring.scenic.basic.domain.ScenicCommercialItem;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.Dictionary;
import com.spring.scenic.system.domain.ZtreeDept;

public interface ScenicCommercialMapper {
	
    int deleteByPrimaryKey(Integer id);

    int addScenicCommercial(ScenicCommercial record);

    ScenicCommercial selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(ScenicCommercial record);
    
    List<ScenicCommercial> selectByScenicCommercialCriteria(ScenicCommercial criteria);
    
    List<ScenicCommercial> selectScenicCommercialForManager(ScenicCommercial criteria);
    
    int updateValid(Integer id);

	int addCommercialApprove(CommercialApprove commercialApprove);
	
	void updateCommercialInfo(ScenicCommercial scenicCommercial);

	List<Dictionary> initScenicSelectOption(Integer id);

	Integer getIdByScenicType(ScenicCommercial scenicCommercial);

	List<ScenicCommercial> initScenicParentOptions(
			ScenicCommercial scenicCommercial);

	List<ScenicCommercial> initScenicCityOptions(
			ScenicCommercial scenicCommercial);

	List<ScenicCommercial> initScenicCityAreaOptions(
			ScenicCommercial scenicCommercial);

	ScenicCommercialApprove getCommercialAttestById(Integer scenicSellerId);

	void addScenicCommercialAttest(ScenicCommercialApprove commercialApprove);

	void updateScenicCommercialAttest(ScenicCommercialApprove commercialApprove);

	void updateValid(ScenicCommercial scenicCommercial);

	void insertScenicMapMsg(List<MapMessage> insertMaps);

	List<MapMessage> selectScenicMapListById(Integer id);

	void updateScenicMapMsg(MapMessage updateMaps);

	void deleteScenicMapMsg(MapMessage mapMessage);

	List<ScenicCommercialItem> selectScenicCommercialItemForManager(
			ScenicCommercial scenicCommercial);

	List<ScenicCommercial> selectByPrimaryIdList(List<String> parentIdList);

	void updateForbiddenItemScenic(ScenicCommercial scenicCommercial);

	/**
	 * @Description 查询单个景区商户信息
	 * @param scenicCommercial
	 * @return ScenicCommercial
	 * @author 006568（shuchang）
	 * @date 2017年1月7日
	 */
	ScenicCommercial getScenicCommercial(ScenicCommercial scenicCommercial);

	/**
	 * @Description 修改景区、商户信息
	 * @param scenicCommercialExample
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月7日
	 */
	int updateScenicCommercial(ScenicCommercial scenicCommercialExample);

	List<ScenicCommercial> queryScenicCommercial(
			ScenicCommercial scenicCommercial);

	/**
	 * @param mapMessage
	 * @return
	 */
	List<MapMessage> selectLandMarkMapListByParam(MapMessage mapMessage);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    List<ZtreeDept> initParentScenic(Department department);

}