package com.spring.scenic.member.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class Order extends Entity<Order>{
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 订单号
     */
    private String orderNo;
    /**
     * 第三方订单号
     */
    private String thirdNo;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 产品编码
     */
    private String productCode;
    /**
     * 产品id
     */
    private Integer productId;
    /**
     * 套餐名称
     */
    private String mealsName;
    /**
     * 套餐id
     */
    private Integer mealsId;
    /**
     * 订单状态
     */
    private Integer orderStatus;
    /**
     * 支付状态
     */
    private Integer payStatus;
    /**
     * 联系人
     */
    private String linkMan;
    /**
     * 联系电话
     */
    private String phone;
    /**
     * 电子邮箱
     */
    private String email;
    /**
     * 订单金额
     */
    private BigDecimal orderPrice;
    /**
     * 订单数量
     */
    private Integer orderCount;
    /**
     * 订单类型（1、景点；2：购物；3、旅游线路）
     */
    private Integer orderType;
    /**
     * 游客备注
     */
    private String remark;
    /**
     * 商户备注
     */
    private String sellerRemark;
    /**
     * 产品单价（景点、购物类产品）
     */
    private BigDecimal productPrice;
    /**
     * 成人价（旅游线路类产品）
     */
    private BigDecimal adultPrice;
    /**
     * 成人数量（旅游线路类产品）
     */
    private Integer adultCount;
    /**
     * 儿童价（旅游线路类产品）
     */
    private BigDecimal childPrice;
    /**
     * 儿童数量（旅游线路类产品）
     */
    private Integer childCount;
    /**
     * 来源
     */
    private Integer src;
    /**
     * 确认时间
     */
    private Date confirmTime;
    /**
     * 用户须知
     */
    private String userKnow;
    /**
     * 创建人（下单人）
     */
    private Integer createUser;
    /**
     * 创建时间（下单时间）
     */
    private Date createTime;
    /**
     * 修改人
     */
    private Integer updateUser;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 商户ID
     */
    private Integer sellerId;
    /**
     * 会员id
     */
    private Integer memberId;
    /**
     * 会员账号
     */
    private String memberAccount;
    /**
     * 出发日期
     */
    private Date travelTime;
    
    private String createUserName;
    
    private String orderFollowName;
    
    private String productname;
    /**
     * 产品类  1景点  2线路  3购物 
     */
    private Integer productType;
    
    private Integer productSubType;
    
    private String mealsname;   
    /**
     * 是否开发票 1：是，0：否
     */
    private Integer needInvoice;
    
    private BigDecimal moneyShouldPay;
    
    private BigDecimal moneyPaid; 
    /**
     * 调整金额对象集合
     */
    private List<OrderMoneyChangeRec> orderMoneyChangeRecList;
    /**、
     * 支付记录对象集合
     */
    private List<OrderPayRecord> orderPayRecordList;
    /**
     * 发票信息
     */
    private OrderInvoice orderInvoice;
    /**
     * 应付金额
     */
    private BigDecimal payPrice;
    /**
     * 已付金额
     */
    private BigDecimal payedPrice;
    /**
     * 单房差
     */
    private BigDecimal singleRoomPrice;
    /**
     * 制单人
     */
    private Integer makeUser;
    /**
     * 订单取消时间
     */
    private Date cancelTime;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getThirdNo() {
        return thirdNo;
    }

    public void setThirdNo(String thirdNo) {
        this.thirdNo = thirdNo == null ? null : thirdNo.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode == null ? null : productCode.trim();
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getMealsName() {
        return mealsName;
    }

    public void setMealsName(String mealsName) {
        this.mealsName = mealsName == null ? null : mealsName.trim();
    }

    public Integer getMealsId() {
        return mealsId;
    }

    public void setMealsId(Integer mealsId) {
        this.mealsId = mealsId;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(Integer payStatus) {
        this.payStatus = payStatus;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan == null ? null : linkMan.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }
   
    public Integer getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSellerRemark() {
        return sellerRemark;
    }

    public void setSellerRemark(String sellerRemark) {
        this.sellerRemark = sellerRemark == null ? null : sellerRemark.trim();
    }

    public BigDecimal getAdultPrice() {
        return adultPrice;
    }

    public void setAdultPrice(BigDecimal adultPrice) {
        this.adultPrice = adultPrice;
    }

    public Integer getAdultCount() {
        return adultCount;
    }

    public void setAdultCount(Integer adultCount) {
        this.adultCount = adultCount;
    }

    public BigDecimal getChildPrice() {
        return childPrice;
    }

    public void setChildPrice(BigDecimal childPrice) {
        this.childPrice = childPrice;
    }

    public Integer getChildCount() {
        return childCount;
    }

    public void setChildCount(Integer childCount) {
        this.childCount = childCount;
    }

    public Integer getSrc() {
        return src;
    }

    public void setSrc(Integer src) {
        this.src = src;
    }

    public Date getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(Date confirmTime) {
        this.confirmTime = confirmTime;
    }

    public String getUserKnow() {
        return userKnow;
    }

    public void setUserKnow(String userKnow) {
        this.userKnow = userKnow == null ? null : userKnow.trim();
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount == null ? null : memberAccount.trim();
    }

    public Date getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(Date travelTime) {
        this.travelTime = travelTime;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public String getOrderFollowName() {
        return orderFollowName;
    }

    public void setOrderFollowName(String orderFollowName) {
        this.orderFollowName = orderFollowName;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public Integer getProductType() {
        return productType;
    }

    public void setProductType(Integer productType) {
        this.productType = productType;
    }

    public Integer getProductSubType() {
        return productSubType;
    }

    public void setProductSubType(Integer productSubType) {
        this.productSubType = productSubType;
    }

    public String getMealsname() {
        return mealsname;
    }

    public void setMealsname(String mealsname) {
        this.mealsname = mealsname;
    }

    public Integer getNeedInvoice() {
        return needInvoice;
    }

    public void setNeedInvoice(Integer needInvoice) {
        this.needInvoice = needInvoice;
    }

    public BigDecimal getMoneyShouldPay() {
        return moneyShouldPay;
    }

    public void setMoneyShouldPay(BigDecimal moneyShouldPay) {
        this.moneyShouldPay = moneyShouldPay;
    }

    public BigDecimal getMoneyPaid() {
        return moneyPaid;
    }

    public void setMoneyPaid(BigDecimal moneyPaid) {
        this.moneyPaid = moneyPaid;
    }

    public List<OrderMoneyChangeRec> getOrderMoneyChangeRecList() {
        return orderMoneyChangeRecList;
    }

    public void setOrderMoneyChangeRecList(List<OrderMoneyChangeRec> orderMoneyChangeRecList) {
        this.orderMoneyChangeRecList = orderMoneyChangeRecList;
    }

    public List<OrderPayRecord> getOrderPayRecordList() {
        return orderPayRecordList;
    }

    public void setOrderPayRecordList(List<OrderPayRecord> orderPayRecordList) {
        this.orderPayRecordList = orderPayRecordList;
    }

    public OrderInvoice getOrderInvoice() {
        return orderInvoice;
    }

    public void setOrderInvoice(OrderInvoice orderInvoice) {
        this.orderInvoice = orderInvoice;
    }

    public BigDecimal getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(BigDecimal orderPrice) {
        this.orderPrice = orderPrice;
    }

    public BigDecimal getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    public BigDecimal getPayPrice() {
        return payPrice;
    }

    public void setPayPrice(BigDecimal payPrice) {
        this.payPrice = payPrice;
    }

    public BigDecimal getPayedPrice() {
        return payedPrice;
    }

    public void setPayedPrice(BigDecimal payedPrice) {
        this.payedPrice = payedPrice;
    }

    public BigDecimal getSingleRoomPrice() {
        return singleRoomPrice;
    }

    public void setSingleRoomPrice(BigDecimal singleRoomPrice) {
        this.singleRoomPrice = singleRoomPrice;
    }

    public Integer getMakeUser() {
        return makeUser;
    }

    public void setMakeUser(Integer makeUser) {
        this.makeUser = makeUser;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }
    
    
}