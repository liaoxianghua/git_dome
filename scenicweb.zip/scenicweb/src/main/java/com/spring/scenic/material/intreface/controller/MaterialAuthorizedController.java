package com.spring.scenic.material.intreface.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.material.application.MaterialAuthorizedService;
import com.spring.scenic.material.domain.MaterialAuthorized;
import com.spring.scenic.system.domain.AuthUser;

@Controller
@RequestMapping("material/authorized")
public class MaterialAuthorizedController extends BaseController {
	
	@Autowired
	private MaterialAuthorizedService materialAuthorizedService;
	
	/**
	 * @Description 菜单-授权管理
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@RequestMapping(value="authorizedList",method=RequestMethod.GET)
	public String authorizedList(HttpServletRequest request){
		return "material/authorized/authorizedList";
	}
	
	/**
	 * @Description 菜单-授权管理新增、编辑界面
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@RequestMapping(value="authorizedEdit",method=RequestMethod.GET)
	public String authorizedEdit(HttpServletRequest request,MaterialAuthorized authorized){
		if(authorized.getId()!=null){
			MaterialAuthorized materialAuthorized = materialAuthorizedService.getMaterialAuthorized(authorized);
			request.setAttribute("authorized", materialAuthorized);
		}
		return "material/authorized/authorizedEdit";
	}
	
	/**
	 * @Description 获取素材授权列表
	 * @param authorized
	 * @param pageAble 是否分页
	 * @return
	 * @return List<MaterialAuthorized>
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="getAuthorizedListData",method=RequestMethod.POST)
	public EntityData getAuthorizedListData(HttpServletRequest request,MaterialAuthorized authorized){
		authorized.initDataTableParam(request);
		List<MaterialAuthorized> authorizeds = materialAuthorizedService.getMaterialAuthorizedList(authorized,SysConstant.PAGE_TRUE);
		PageInfo<MaterialAuthorized> page = new PageInfo<MaterialAuthorized>(authorizeds);
		EntityData data = new EntityData(authorized,page);
		return data;
	}
	
	/**
	 * @Description 新增、编辑素材授权信息
	 * @param user
	 * @param material
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="saveMaterialAuthorized",method=RequestMethod.POST)
	public MessageData saveMaterialAuthorized(HttpServletRequest request,MaterialAuthorized authorized){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		if(authorized.getId()==null){
			materialAuthorizedService.saveMaterialAuthorized(user,authorized);
		}else{
			materialAuthorizedService.updateMaterialAuthorized(user,authorized);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	
	/**
	 * @Description 审核素材授权信息
	 * @param request
	 * @param authorized
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="auditMaterialAuthorized",method=RequestMethod.POST)
	public MessageData auditMaterialAuthorized(HttpServletRequest request,MaterialAuthorized authorized){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		if(authorized.getId()!=null){
			materialAuthorizedService.auditMaterialAuthorized(user,authorized);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
	}
	
	
	/**
	 * @Description 授权下拉数据
	 * @param request
	 * @param authorized
	 * @return List<MaterialAuthorized>
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="authorizedList",method=RequestMethod.POST)
	public List<MaterialAuthorized> authorizedList(HttpServletRequest request,MaterialAuthorized authorized){
		return materialAuthorizedService.getMaterialAuthorizedList(authorized, SysConstant.PAGE_FALSE);
	}
	
	
}
