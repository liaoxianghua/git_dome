package com.spring.scenic.security.authority;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.spring.scenic.system.application.AuthUserService;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	private static Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);
	
	@Autowired
	private AuthUserService authUserService;
	
	/**
	 * 根据登陆的用户名加载用户的所有角色权限
	 */
	@Override
	public UserDetails loadUserByUsername (String username) throws UsernameNotFoundException{
		AuthUser authUser = new AuthUser();
		try {
			authUser = authUserService.getUserByAccount(username);
			if(authUser!=null){
				List<AuthRole> authRoles = authUserService.getUserAuthRoleList(authUser);
				if(authRoles!=null&&!authRoles.isEmpty()){
					authUser.setRoleList(authRoles);
				}
				List<AuthResource> authResources = authUserService.getUserAuthResourceList(authUser);
				if(authResources!=null&&!authResources.isEmpty()){
					authUser.setResourceList(authResources);
				}
			}
		} catch (Exception e) {
			logger.error("数据库不存在该用户:"+username);
			throw new UsernameNotFoundException("error:User :"+username+" dose not exsited...");
		}
		String password = authUser.getPassword().toUpperCase();
		if(authUser.getPassword()==null||"".equals(authUser.getPassword())){
			throw new UsernameNotFoundException("error:User :"+username+" password is empty...");
		}
		Set<GrantedAuthority> grantedAuths = obtionGrantedAuthorities(authUser.getRoleList());
		UserDetails userDetails = new User(username, password, true, true, true, true,grantedAuths);
		//MDC.put("username", userDetails.getUsername());
		return userDetails;
	}
	private Set<GrantedAuthority> obtionGrantedAuthorities(List<AuthRole> authRoles) {
		Set<GrantedAuthority> set = new HashSet<GrantedAuthority>();
		for (AuthRole authRole : authRoles) {
			set.add(new SimpleGrantedAuthority(authRole.getRoleName()));
		}	
		return set;
	}
}