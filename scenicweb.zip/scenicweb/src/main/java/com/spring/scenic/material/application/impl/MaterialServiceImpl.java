package com.spring.scenic.material.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.material.domain.Material;
import com.spring.scenic.material.infrastructure.MaterialMapper;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;
import com.spring.scenic.system.domain.AuthUser;

@Service
public class MaterialServiceImpl implements MaterialService {

	@Autowired
	private MaterialMapper materialMapper;
	
	@Resource(name="fastDFSStorageService")
	private StorageService fastDFSStorageService;
	
	@Override
	public int saveMaterialUpload(AuthUser user,Map<String, List<MultipartFile>> filesMap, String[] descriptions,
			Integer[] types, Integer[] usertypes, Integer[] authorizedIds,String[] keys,String names[]) {
		Date now = DateUtil.getNow();
		List<Material> materials = new ArrayList<Material>();
		try {
			for (int i = 0; i < keys.length; i++) {
				String key = keys[i];
				Material material = new Material();
				material.setType(types[i]);
				material.setUsertype(usertypes[i]);
				material.setDescriptions(descriptions[i]);
				material.setAuthorizedId(authorizedIds==null? null : authorizedIds[i]);
				material.setExamineStatus(Integer.valueOf(SysEnum.MATERIAL_STATUS_UNAPPROVE.getCode()));
				material.setExamineTime(null);
				material.setExamineRemarks(null);
				material.setValid(Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode()));
				material.setCreateTime(now);
				material.setCreateUser(user.getId());
				material.setUpdateTime(null);
				material.setUpdateUser(null);
				List<MultipartFile> materialFiles = filesMap.get(key);
				if(materialFiles!=null && !materialFiles.isEmpty()){
					MultipartFile materialFile = materialFiles.get(0);
					String fileType = FilenameUtils.getExtension(materialFile.getOriginalFilename());
					String fileUrl = fastDFSStorageService.uploadResource(fileType, materialFile.getBytes(), null);
					material.setName(names[i]);
					material.setUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL)+fileUrl);
				}
				materials.add(material);
			}
			if(!materials.isEmpty()){
				return materialMapper.saveBatchMaterials(materials);
			}else{
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Material> getMaterialList(Material material, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(material.getPageNum(), material.getPageSize()==null?SysConstant.PAGE_PAGESIZE:material.getPageSize());
			}
			List<Material> materials = materialMapper.getMaterialList(material);
			return materials;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Material getMaterial(Material material) {
		try {
			return materialMapper.getMaterial(material);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int deleteMaterial(Material material) {
		try {
			Material exsitMaterial = materialMapper.getMaterial(material);
			if(StringUtils.isNotBlank(exsitMaterial.getUrl())){
				fastDFSStorageService.deleteResourceByPath(exsitMaterial.getUrl().replace(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL), ""));
			}
			return materialMapper.deleteMaterial(material);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int auditMaterial(AuthUser user,Material material) {
		try {
			Material materialExample = materialMapper.getMaterial(material);
			materialExample.setId(material.getId());
			materialExample.setExamineTime(new Date());
			materialExample.setExamineUser(user.getId());
			materialExample.setExamineStatus(material.getExamineStatus());
			materialExample.setExamineRemarks(material.getExamineRemarks());
			if(material.getExamineStatus().equals(Integer.valueOf(SysEnum.MATERIAL_STATUS_PASS.getCode()))){
				materialExample.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
			}else{
				materialExample.setValid(Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode()));
			}
			return materialMapper.updateMaterial(materialExample);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	
}
