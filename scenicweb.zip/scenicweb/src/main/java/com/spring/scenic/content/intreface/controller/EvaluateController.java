package com.spring.scenic.content.intreface.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.ApplicationContentUtil;
import com.spring.scenic.content.application.CommentsService;
import com.spring.scenic.content.domain.Comments;
import com.spring.scenic.content.domain.CommentsImage;
import com.spring.scenic.content.domain.CommentsScoreItems;
import com.spring.scenic.system.domain.AuthUser;

/**
 * 内容管理-评价管理
 * @author shuc
 */
@Controller
@RequestMapping("content/evaluate")
public class EvaluateController extends BaseController{
	
	@Autowired
	private CommentsService commentsService;
	
	@RequestMapping("evaluateList")
	public String evaluateList(){
		
		return "content/evaluate/evaluateList";
	}
	
	
	/**
	 * @Description 分页点评数据（12个一页）
	 * @param request
	 * @param travelNote
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2016年12月30日
	 */
	@ResponseBody
	@RequestMapping(value="getEvaluateListData",method=RequestMethod.POST)
	public EntityData getEvaluateListData(HttpServletRequest request,Comments comment){
		comment.initDataTableParam(request);
		List<Comments> comments = commentsService.getEvaluateListData(comment,SysConstant.PAGE_TRUE);
		PageInfo<Comments> page = new PageInfo<Comments>(comments);
		EntityData data = new EntityData(comment,page);
		return data;
	}
	
	/**
	 * @Description 查看评价图片
	 * @param request
	 * @param image
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月2日
	 */
	@RequestMapping(value="imageView",method=RequestMethod.GET)
	public String imageView(HttpServletRequest request,CommentsImage image){
		CommentsImage exsitImage = commentsService.getCommentsImage(image);
		request.setAttribute("image", exsitImage);
		return "content/evaluate/imageView";
	}
	
	/**
	 * @Description 审核评论
	 * @param request
	 * @param comments
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月2日
	 */
	@ResponseBody
	@RequestMapping(value="auditEvaluate",method=RequestMethod.POST)
	public MessageData auditEvaluate(HttpServletRequest request,Comments comments){
		if(comments.getId()!=null&&comments.getStatus()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			commentsService.auditEvaluate(user,comments);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}
		return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
	}

	/**
	 * @Description 下载点评模板
	 * @param response
	 * @return void
	 * @author 006568（shuchang）
	 * @date 2017年1月2日
	 */
	@RequestMapping(value="downEvaluateFile",method=RequestMethod.GET)
	public void downEvaluateFile(HttpServletResponse response){
		commentsService.downEvaluateFile(response);
	}
	
	/**
	 * @Description 进入点评项维护界面
	 * @param request
	 * @param image
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月2日
	 */
	@RequestMapping(value="evaluateItemList",method=RequestMethod.GET)
	public String evaluateItemList(HttpServletRequest request,CommentsScoreItems item){
		return "content/evaluate/evaluateItemList";
	}
	
	/**
	 * @Description 获取点评项集合数据
	 * @param request
	 * @param item
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="getEvaluateItemListData",method=RequestMethod.POST)
	public EntityData getEvaluateItemListData(HttpServletRequest request,CommentsScoreItems item){
		item.initDataTableParam(request);
		List<CommentsScoreItems> items = commentsService.getEvaluateItemListData(item,SysConstant.PAGE_TRUE);
		PageInfo<CommentsScoreItems> page = new PageInfo<CommentsScoreItems>(items);
		EntityData data = new EntityData(item,page);
		return data;
	}
	
	
	@ResponseBody
	@RequestMapping(value="updateEvaluateItemValid",method=RequestMethod.POST)
	public MessageData updateEvaluateItemValid(HttpServletRequest request,CommentsScoreItems item){
		if(item.getId()!=null||item.getValid()!=null){
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			commentsService.updateEvaluateItemValid(user,item);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}
		return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);	
	}
	
	
	/**
	 * @Description 添加点评项
	 * @param request
	 * @param item
	 * @return String
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@RequestMapping(value="evaluateItemAdd",method=RequestMethod.GET)
	public String evaluateItemAdd(){
		return "content/evaluate/evaluateItemAdd";
	}
	
	@RequestMapping(value="evaluatItemEdit",method=RequestMethod.GET)
	public String evaluatItemEdit(HttpServletRequest request,CommentsScoreItems item){
		if(item.getId()!=null){
			CommentsScoreItems scoreItem = commentsService.getCommentsScoreItem(item);
			request.setAttribute("scoreItem", scoreItem);
		}
		return "content/evaluate/evaluateItemAdd";
	}
	
	
	@RequestMapping(value="evaluateImport",method=RequestMethod.GET)
	public String evaluateImport(){
		return "content/evaluate/evaluateImport";
	}
	
	@ResponseBody
	@RequestMapping(value="saveEvaluateImportData",method=RequestMethod.POST)
	public MessageData saveEvaluateImportData(HttpServletRequest request,CommentsScoreItems item,String key){
		try {
			AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
			MultipartHttpServletRequest  multipartRequest = (MultipartHttpServletRequest)request;
			Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
			List<MessageData> messageDatas = commentsService.saveEvaluateImportData(user,filesMap,key);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, messageDatas);
		} catch (Exception e) {
			e.printStackTrace();
			return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
	}
	
	/**
	 * @Description 保存点评项
	 * @param request
	 * @param item
	 * @return MessageData
	 * @author 006568（shuchang）
	 * @date 2017年1月3日
	 */
	@ResponseBody
	@RequestMapping(value="saveEvaluateItem",method=RequestMethod.POST)
	public MessageData saveEvaluateItem(HttpServletRequest request,CommentsScoreItems item){
		AuthUser user = (AuthUser) ApplicationContentUtil.getHttpSession().getAttribute(SysConstant.SESSION_USER);
		if(item.getId()==null){
			commentsService.saveEvaluateItem(user,item);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}else{
			commentsService.updateEvaluateItem(user,item);
			return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, null);
		}
	}
}
