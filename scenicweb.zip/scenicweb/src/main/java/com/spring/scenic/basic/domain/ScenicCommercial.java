package com.spring.scenic.basic.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class ScenicCommercial extends Entity<ScenicCommercial> implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1387299469145065287L;
	private Integer id;
	private String name;// 景区商户名称
	private String type;// 景区商户类别
	private String typeName;//类别名称
	private String typeCategory;// 类别的分类
	private String typeCategoryName;//类别分类名称
	private String fullTypeName;//类型全称
	private Integer cityId;//城市id
	private String cityName;//城市名称
	private Integer cityAreaId;//城市地区id
	private String cityAreaName;//城市地区名称
	private Integer starLevel;//等级
	private Integer valid;// 1 有效 0 无效
	private String address;//详细地址
	private String tel;//电话
	private Integer parentId;//上级景区id
	private String parentStrId;
	private String businessTime;//营业时间
	private String traffics;//交通方式
	private String introduce;//详情介绍
	private String tips;//小贴士
	private String guid;
	private Integer autyStatus;//认证状态 0 未认证 1 已认证
	private Integer positionType;//地标类型
	private Integer outRelatedType;//1:地标 2:城市 3：景区 商户
	private Integer mapType;//地图类型1 百度 2 谷歌 3 高德 4 腾讯
	private String lgn;//经度
	private String lat;//纬度
    private Integer createUser;
    private String createuserName;
    private Date createTime;
    private Integer updateUser;
    private String updateUserName;
    private Date updateTime;
    private List<MapMessage> liMapMessages;
    
    private String fullAddress;//地址全称
    private String parentName;//上级景区名称
    private String flag;//标识是禁用还是启用  0为禁用，1为启用
    /**
     * 封面图片地址
     */
    private String coversImageUrl;
    
    /**
     * 封面图片名称
     */
    private String coversImageName;
    
    private List<ScenicCommercial> children;
    
    
    /**
     * 业务字段：经纬度列表
     */
    private List<Position> positions;
    
	public String getParentStrId() {
		return parentStrId;
	}
	public void setParentStrId(String parentStrId) {
		this.parentStrId = parentStrId;
	}
	public String getUpdateUserName() {
		return updateUserName;
	}
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}
	
	public List<ScenicCommercial> getChildren() {
		return children;
	}
	public void setChildren(List<ScenicCommercial> children) {
		this.children = children;
	}
	public String getFullTypeName() {
		return fullTypeName;
	}
	public void setFullTypeName(String fullTypeName) {
		this.fullTypeName = fullTypeName;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getTypeCategoryName() {
		return typeCategoryName;
	}
	public void setTypeCategoryName(String typeCategoryName) {
		this.typeCategoryName = typeCategoryName;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	public String getCoversImageUrl() {
		return coversImageUrl;
	}
	public void setCoversImageUrl(String coversImageUrl) {
		this.coversImageUrl = coversImageUrl;
	}
	public String getCoversImageName() {
		return coversImageName;
	}
	public void setCoversImageName(String coversImageName) {
		this.coversImageName = coversImageName;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public List<MapMessage> getLiMapMessages() {
		return liMapMessages;
	}
	public void setLiMapMessages(List<MapMessage> liMapMessages) {
		this.liMapMessages = liMapMessages;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeCategory() {
		return typeCategory;
	}
	public void setTypeCategory(String typeCategory) {
		this.typeCategory = typeCategory;
	}
	public Integer getCityId() {
		return cityId;
	}
	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
	public Integer getCityAreaId() {
		return cityAreaId;
	}
	public void setCityAreaId(Integer cityAreaId) {
		this.cityAreaId = cityAreaId;
	}
	
	public Integer getStarLevel() {
		return starLevel;
	}
	public void setStarLevel(Integer starLevel) {
		this.starLevel = starLevel;
	}
	public Integer getValid() {
		return valid;
	}
	public void setValid(Integer valid) {
		this.valid = valid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public String getBusinessTime() {
		return businessTime;
	}
	public void setBusinessTime(String businessTime) {
		this.businessTime = businessTime;
	}
	public String getTraffics() {
		return traffics;
	}
	public void setTraffics(String traffics) {
		this.traffics = traffics;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getTips() {
		return tips;
	}
	public void setTips(String tips) {
		this.tips = tips;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public Integer getAutyStatus() {
		return autyStatus;
	}
	public void setAutyStatus(Integer autyStatus) {
		this.autyStatus = autyStatus;
	}
	public Integer getPositionType() {
		return positionType;
	}
	public void setPositionType(Integer positionType) {
		this.positionType = positionType;
	}
	public Integer getOutRelatedType() {
		return outRelatedType;
	}
	public void setOutRelatedType(Integer outRelatedType) {
		this.outRelatedType = outRelatedType;
	}
	public String getLgn() {
		return lgn;
	}
	public void setLgn(String lgn) {
		this.lgn = lgn;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public Integer getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public String getCreateuserName() {
		return createuserName;
	}
	public void setCreateuserName(String createuserName) {
		this.createuserName = createuserName;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getMapType() {
		return mapType;
	}
	public void setMapType(Integer mapType) {
		this.mapType = mapType;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityAreaName() {
		return cityAreaName;
	}
	public void setCityAreaName(String cityAreaName) {
		this.cityAreaName = cityAreaName;
	}
    
	@Override
	public int hashCode() {
		String in = String.valueOf(id);
		return in.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		ScenicCommercial temp=(ScenicCommercial)obj;
		return id.equals(temp.id);
	}
	public List<Position> getPositions() {
		return positions;
	}
	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}
    
}
