/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 * 
 */
package com.spring.scenic.busi.application;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;

/**
 * 此处为类说明：商户管理接口
 * @author rmp
 * @date 2017年3月20日
 */
public interface BusiSellerService {

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    List<BusiSeller> getBusiSellerList(BusiSeller busiSeller, boolean pageAble);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    int updateBusiSellerStatus(AuthUser userInfo, BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月20日     
     * @memo ：   
     **
     */
    BusiSeller getBusiSellerById(BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    List<ZtreeDept> initParentScenic(Department department);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    int saveBusiSeller(AuthUser userInfo, BusiSeller busiSeller);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月21日     
     * @memo ：   
     **
     */
    BusiSellerUser getSellerAccountById(Integer id);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月22日     
     * @memo ：   
     **
     */
    MessageData saveBusiSellerUser(AuthUser userInfo, BusiSellerUser busiSellerUser);

}
