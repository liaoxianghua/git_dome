package com.spring.scenic.content.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description 内容管理-评分项维护
 * @author 006568（shuchang）
 * @date 2016年12月30日
 */
public class CommentsScoreItems extends Entity<CommentsScoreItems>{
	
    /**
     * 主键
     */
    private Integer id;

    /**
     * 适用类别（字典数据：景区、商户）
     */
    private Short type;

    /**
     * 适用类别-子类（字典数据：古镇、名胜等）
     */
    private Short subType;

    /**
     * 标题
     */
    private String title;

    /**
     * 是否有效
     */
    private Short valid;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private Integer updateUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 业务字段：修改人名
     */
    private String updateUserName;
    
    /**
     * 业务字段：创建人
     */
    private String createUserName;
    
	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Short getSubType() {
		return subType;
	}

	public void setSubType(Short subType) {
		this.subType = subType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Short getValid() {
		return valid;
	}

	public void setValid(Short valid) {
		this.valid = valid;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
    
}