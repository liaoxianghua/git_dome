package com.spring.scenic.material.application.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.material.application.MaterialAuthorizedService;
import com.spring.scenic.material.domain.MaterialAuthorized;
import com.spring.scenic.material.infrastructure.MaterialAuthorizedMapper;
import com.spring.scenic.system.domain.AuthUser;

@Service
public class MaterialAuthorizedServiceImpl implements MaterialAuthorizedService {

	@Autowired
	private MaterialAuthorizedMapper materialAuthorizedMapper;
	
	@Override
	public List<MaterialAuthorized> getMaterialAuthorizedList(MaterialAuthorized authorized, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(authorized.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<MaterialAuthorized> authorizeds = materialAuthorizedMapper.getMaterialAuthorizedList(authorized);
			return authorizeds;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public MaterialAuthorized getMaterialAuthorized(MaterialAuthorized authorized) {
		try {
			return materialAuthorizedMapper.getMaterialAuthorized(authorized);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveMaterialAuthorized(AuthUser user,MaterialAuthorized authorized) {
		try {
			authorized.setCreateTime(new Date());
			authorized.setCreateUser(user.getId());
			return materialAuthorizedMapper.saveMaterialAuthorized(authorized);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int updateMaterialAuthorized(AuthUser user,MaterialAuthorized authorized) {
		try {
			MaterialAuthorized authorizedExample = materialAuthorizedMapper.getMaterialAuthorized(authorized);
			authorizedExample.setId(authorized.getId());
			authorizedExample.setUpdateTime(new Date());
			authorizedExample.setUpdateUser(user.getId());
			authorizedExample.setCode(authorized.getCode());
			authorizedExample.setAuthOrg(authorized.getAuthOrg());
			authorizedExample.setAuthPerson(authorized.getAuthPerson());
			authorizedExample.setAuthStartDate(authorized.getAuthStartDate());
			authorizedExample.setAuthEndDate(authorized.getAuthEndDate());
			authorizedExample.setSignDate(authorized.getSignDate());
			authorizedExample.setValid(authorized.getValid());
			return materialAuthorizedMapper.updateMaterialAuthorized(authorizedExample);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int auditMaterialAuthorized(AuthUser user,MaterialAuthorized authorized) {
		try {
			MaterialAuthorized authorizedExample = materialAuthorizedMapper.getMaterialAuthorized(authorized);
			authorizedExample.setId(authorized.getId());
			authorizedExample.setUpdateTime(new Date());
			authorizedExample.setUpdateUser(user.getId());
			authorizedExample.setValid(authorized.getValid());
			return materialAuthorizedMapper.updateMaterialAuthorized(authorizedExample);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



}
