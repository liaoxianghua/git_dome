package com.spring.scenic.cms.infrastructure;

import java.util.List;

import com.spring.scenic.cms.domain.SysConfig;

public interface SysConfigMapper {
    
    int deleteByPrimaryKey(Integer id);

    int insert(SysConfig record);

    int insertSelective(SysConfig record);

    SysConfig selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SysConfig record);

    int updateByPrimaryKey(SysConfig record);

	List<SysConfig> getsysConfigList(SysConfig sysConfig);

	void updateSysConfigStatus(SysConfig sysConfig);

	SysConfig getSysConfigInfoById(SysConfig sysConfig);

	void updateSysConfig(SysConfig sysConfigExample);

	void addSysConfig(SysConfig sysConfig);
    
    SysConfig getSysConfigInfoByPicId(Integer id);
}