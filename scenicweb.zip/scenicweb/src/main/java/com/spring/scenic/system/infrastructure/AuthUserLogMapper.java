package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.dto.UserLogVo;


public interface AuthUserLogMapper {

	void addUserLog(UserLogVo userLogVo);

	List<UserLogVo> queryUserLogList(UserLogVo logVo);

	
}