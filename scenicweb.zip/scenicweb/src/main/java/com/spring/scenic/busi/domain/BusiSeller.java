package com.spring.scenic.busi.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class BusiSeller extends Entity<BusiSeller>{
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 商户名称
     */
    private String sellerName;
    /**
     * 所属景区
     */
    private Integer scenicSellerId;
    /**
     * 描述
     */
    private String remark;
    /**
     * 是否有效 1：有效 0：无效
     */
    private Integer valid;

    private Integer sellerId;
    /**
     * 创建人
     */
    private Integer createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private Integer updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人姓名
     */
    private String updateUserName;
    /**
     * 所属景区
     */
    private String scenicName;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName == null ? null : sellerName.trim();
    }

    public Integer getScenicSellerId() {
        return scenicSellerId;
    }

    public void setScenicSellerId(Integer scenicSellerId) {
        this.scenicSellerId = scenicSellerId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getValid() {
        return valid;
    }

    public void setValid(Integer valid) {
        this.valid = valid;
    }

    public Integer getSellerUserId() {
        return sellerId;
    }

    public void setSellerUserId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserName() {
        return updateUserName;
    }

    public void setUpdateUserName(String updateUserName) {
        this.updateUserName = updateUserName;
    }

    public String getScenicName() {
        return scenicName;
    }

    public void setScenicName(String scenicName) {
        this.scenicName = scenicName;
    }
    
    
}