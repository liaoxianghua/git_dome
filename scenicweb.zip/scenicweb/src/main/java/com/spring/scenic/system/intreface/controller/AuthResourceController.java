package com.spring.scenic.system.intreface.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.system.application.AuthResourceService;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
/**
 * 菜单管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "system/menu")
public class AuthResourceController extends BaseController{
	private static final String addType = "add";
	private static final String updateType = "update";
	@Autowired
	private AuthResourceService menuService;
	
	/**
	 * 
	  * @Description: 菜单管理页面跳转
	  * @param @return
	  * @return String
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:04
	 */
	@RequestMapping(value = "menuManagement")
	public String menuManagement() {
		return "/system/menu/menuManagementMain";
	}
	
	/**
	 * 点击编辑弹出页面
	 * @param request
	 * @param response
	 * @param menu
	 * @return
	 */
	@RequestMapping(value = "menuManagementEdit")
	public String menuManagementEdit(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		if (menu.getId()!= null &&! "".equals(menu.getId()) && (menu.getParentId() == null || "".equals(menu.getParentId()))) {
			AuthResource mu = menuService.selectByPrimaryKey(menu.getId());
			request.setAttribute("memuVo", mu);
			request.setAttribute("optType", "editMenu");//设置编辑
			return "/system/menu/menuManagementEdit";
		}
		if (menu.getId()!= null && !"".equals(menu.getId()) && (menu.getParentId() != null || !"".equals(menu.getParentId()))) {
			AuthResource muItem = menuService.selectByPrimaryKey(menu.getId());
			request.setAttribute("menuItemVo", muItem);
			request.setAttribute("optType", "editMenuItem");//设置编辑
			return "/system/menu/addNextMenuEdit";
		}
		return "/system/menu/menuManagementEdit";
	}
	/**
	 * 弹出新增菜单编辑框
	 * @param request
	 * @param response
	 * @param menu
	 * @return
	 */
	@RequestMapping(value = "addNextMenuEdit")
	public String addNextMenuEdit(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		AuthResource muMenu = menuService.selectByPrimaryKey(menu.getId());
		AuthResource muVo = new AuthResource();
		muVo.setParentId(menu.getId());
		muVo.setParentName(muMenu.getName());
		request.setAttribute("menuItemVo", muVo);
		return "/system/menu/addNextMenuEdit";

	}
	/**
	 * 
	 *@Description:查看功能
	 *@Auth: lichangmao
	 *@2017年1月10日
	 */
	@RequestMapping(value = "menuFunctionViewEdit")
	public String menuFunctionViewEdit(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		AuthResource muMenu = menuService.selectByPrimaryKey(menu.getId());
		AuthResource muVo = new AuthResource();
		muVo.setId(muMenu.getId());
		muVo.setParentId(menu.getId());
		muVo.setParentName(muMenu.getName());
		request.setAttribute("menuItemVo", muVo);
		return "/system/menu/menuFunctionViewEdit";

	}
	
	/**
	 * 弹出新增菜单功能窗口
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月6日
	 */
	@RequestMapping(value = "menuFunctionViewAdd")
	public String menuFunctionViewAdd(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		String optType = addType;
		AuthResource muMenu = menuService.selectByPrimaryKey(menu.getParentId());
		request.setAttribute("menuItemAddVo", muMenu);
		AuthResource editVo = new AuthResource(); 
		if (menu.getId()!=null && !"".equals(menu.getId())) {
			editVo = menuService.selectByPrimaryKey(menu.getId());
			optType = updateType;
		}
		request.setAttribute("menuItemAddEditVo", editVo);
		request.setAttribute("optType", optType);
		return "/system/menu/menuFunctionViewAdd";

	}
	
	
	
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,AuthResource menu){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysEnum.COMMON_USEABLE_NO.getCode().equals(menu.getFlag())) {
			menu.setValid(Integer.valueOf(SysConstant.VALITY_NO));
		}else {
			menu.setValid(Integer.valueOf(SysConstant.VALITY_YES));
		}
		if (menu.getParentIdStr()==null || StringUtil.isEmpty(menu.getParentIdStr()) || "0".equals(menu.getParentIdStr())) {//禁用父部门及其子部门
			menuService.updateForbiddenItemMenu(menu,userInfo);
		}else {
			menuService.updateForbiddenOrUseData(menu,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	/**
	 * 
	  * @Description: 菜单管理信息详情
	  * @param @param userDTO
	  * @param @param dataGrid
	  * @param @return
	  * @return DataGridResponse
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:22
	 */
	@ResponseBody
	@RequestMapping(value = "queryMenuList" ,method=RequestMethod.POST)
	public EntityData queryMenuList(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		menu.initDataTableParam(request);
		List<AuthResource> list = menuService.queryMenuList(menu, SysConstant.PAGE_FALSE);
		PageInfo<AuthResource> page = new PageInfo<AuthResource>(list);
		EntityData data = new EntityData(menu,page);
		return data;
	}
	
	/**
	 * @Description 查看资源列表（被角色包含的会被标记）
	 * @param request
	 * @param role 角色信息
	 * @param resource 资源信息
	 * @return EntityData
	 * @author 006568（shuchang）
	 * @date 2017年2月6日
	 */
	@ResponseBody
	@RequestMapping(value = "getResourceList" ,method=RequestMethod.POST)
	public List<AuthResource> getResourceList(HttpServletRequest request,AuthRole role,AuthResource resource,Integer roleId,String key) {
		AuthUser user =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		resource.initDataTableParam(request);
		if(roleId!=null){
			role.setId(roleId);
		}
		if(StringUtils.isNotBlank(key)){
			resource.setName(key);
		}
		List<AuthResource> list = menuService.getResourceList(resource,role,user, SysConstant.PAGE_FALSE);
//		PageInfo<AuthResource> page = new PageInfo<AuthResource>(list);
//		EntityData data = new EntityData(resource,page);
		return list;
	}
	
	/**
	 * 查询菜单功能列表数据
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月6日
	 */
	@ResponseBody
	@RequestMapping(value = "queryMenuFunctionList" ,method=RequestMethod.POST)
	public EntityData queryMenuFunctionList(HttpServletRequest request, HttpServletResponse response,AuthResource menu) {
		menu.initDataTableParam(request);
		List<AuthResource> list = menuService.queryMenuFunctionList(menu, SysConstant.PAGE_TRUE);
		PageInfo<AuthResource> page = new PageInfo<AuthResource>(list);
		EntityData data = new EntityData(menu,page);
		return data;
	}
	
	
	
	/**
	 * 新增修改参数模块
	 * @param request
	 * @param response
	 * @param menu
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "operateMenu" ,method=RequestMethod.POST)
	public  MessageData operateMenu(HttpServletRequest request, HttpServletResponse response,AuthResource menu){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (menu.getId() == null) {
			menuService.addMenu(menu,userInfo);
		}else {
			menuService.updateMenu(menu,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 新增菜单功能
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月6日
	 */
	@ResponseBody
	@RequestMapping(value = "addMenuFunction" ,method=RequestMethod.POST)
	public  MessageData addMenuFunction(HttpServletRequest request, HttpServletResponse response,AuthResource menu){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (menu.getId() == null) {
			menuService.addMenuFunction(menu,userInfo);
		}else {
			menuService.updateMenuFunction(menu,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	
	
	/**
	 * 新增修改参数模块
	 * @param request
	 * @param response
	 * @param menu
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "operateMenuItem" ,method=RequestMethod.POST)
	public  MessageData operateMenuItem(HttpServletRequest request, HttpServletResponse response,AuthResource menu){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (menu.getId() == null) {
			menuService.addMenuItem(menu,userInfo);
		}else {
			menuService.updateMenuItem(menu,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}
	/**
	 * 校验功能代码是否重复
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月8日
	 */
	@ResponseBody
	@RequestMapping(value = "checkMenuCodeByParam" ,method=RequestMethod.POST)
	public  Map<String, Object> checkMenuCodeByParam(HttpServletRequest request, HttpServletResponse response,AuthResource menu){
		Map<String, Object> resultmMap = new HashMap<String, Object>();
		int count = 0;
		if (addType.equals(menu.getOptType())) {
			count = menuService.checkMenuCodeByParam(menu);
		}
		if (count>0) {
			resultmMap.put("error", "已存在");
		}else {
			resultmMap.put("ok", "ok");
		}
		return resultmMap;
	}
	
	
	
}
