/*
 * Copyright(c) 2012-2017 SpringTour.Ltd. All Rights Reserved.
 * 
 */
package com.spring.scenic.busi.application.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.busi.application.BusiNoticeService;
import com.spring.scenic.busi.domain.BusiNotice;
import com.spring.scenic.busi.infrastructure.BusiNoticeMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.MultiPartUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.storage.fastdfs.util.FilenameUtils;
import com.spring.scenic.system.domain.AuthUser;

/**
 * 此处为类说明：商户中心公告接口实现类
 * @author rmp
 * @date 2017年3月22日
 */
@Service
public class BusiNoticeServiceImpl implements BusiNoticeService {
    
    @Autowired
    private BusiNoticeMapper busiNoticeMapper; 
    @Resource(name = "fastDFSStorageService")
    private StorageService fastDFSStorageService;
    @Override
    public List<BusiNotice> getBusiNoticeList(BusiNotice busiNotice, boolean pageAble) {
        try {
            if (pageAble) {
                PageHelper.startPage(busiNotice.getPageNum(),SysConstant.PAGE_PAGESIZE);
            }
            List<BusiNotice> list = busiNoticeMapper.getBusiNoticeList(busiNotice);
            return list;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
    }
    /**
     * 启用禁用公告状态
     */
    @Override
    public int updateBusiNoticeStatus(AuthUser userInfo, BusiNotice busiNotice) {
        try {
            BusiNotice busiNoticeExample = busiNoticeMapper.getBusiNoticeById(busiNotice);
            busiNoticeExample.setUpdateTime(new Date());
            busiNoticeExample.setUpdateUser(userInfo.getId());
            //如果禁用，设置为无效
            if(busiNotice.getValid()==Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode())) {
                busiNoticeExample.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
            }else{//如果无效，且当前为置顶状态，取消置顶
                if(busiNotice.getIsTop()==Integer.valueOf(SysEnum.COMMON_TOP_YES.getCode())) {
                    busiNoticeExample.setIsTop(Integer.valueOf(SysEnum.COMMON_TOP_NO.getCode()));
                }
                busiNoticeExample.setValid(Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode()));
            }
            return busiNoticeMapper.updateBusiNotice(busiNoticeExample);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
        
    }
    /**
     * 置顶公告规则：仅有一条公告可置顶，置顶的时候，将原置顶公告取消置顶。无效公告不可置顶
     */
    @Override
    public int updateBusiNoticeToTop(AuthUser userInfo, BusiNotice busiNotice) {
        try {
            //先把已置顶的公告取消置顶
            BusiNotice busiNoticeDto = new BusiNotice();
            busiNoticeDto.setUpdateTime(new Date());
            busiNoticeDto.setUpdateUser(userInfo.getId());
            busiNoticeDto.setIsTop(Integer.valueOf(SysEnum.COMMON_TOP_YES.getCode()));
            busiNoticeMapper.updateBusiNoticeToCommon(busiNoticeDto);
            //置顶选择的公告
            BusiNotice busiNoticeExample = busiNoticeMapper.getBusiNoticeById(busiNotice);
            busiNoticeExample.setUpdateTime(new Date());
            busiNoticeExample.setUpdateUser(userInfo.getId());
            busiNoticeExample.setIsTop(busiNotice.getIsTop());
            return busiNoticeMapper.updateBusiNotice(busiNoticeExample);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
        
    }
    @Override
    public MessageData saveBusiNotice(AuthUser user, Map<String, List<MultipartFile>> filesMap, String key, BusiNotice busiNotice) {
        try {
            MessageData messageData = new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE);
            // 合同附件上传服务器，返回附件地址
            if (filesMap != null && !filesMap.isEmpty()) {
                List<MultipartFile> multipartFiles = filesMap.get(key);
                if (multipartFiles != null && !multipartFiles.isEmpty()) {
                    MultipartFile multipartFile = multipartFiles.get(0);
                    
                    String fileType = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
                    String fileName = multipartFile.getOriginalFilename();
                    long fileSize = multipartFile.getSize();
                    //如果附件的大小超过20M
                    String contractType = "xlsx、xls、doc、docx、pdf、pptx、ppt、rar、zip";
                    if(contractType.indexOf(fileType) == -1){
                        messageData.setStatusCode(201);
                        messageData.setMessage(SysConstant.FILE_FORMAT_ERROR);
                        return messageData;
                    }
                    if(fileSize>1024*1024*20) {
                        messageData.setStatusCode(201);
                        messageData.setMessage(SysConstant.FILE_SIZE_EXCESS);
                        return messageData;
                    }
                    if (null != busiNotice.getId()&& null != busiNotice.getFileUrl()) {
                        fastDFSStorageService.deleteResourceByPath(busiNotice.getFileUrl().replace(
                            PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL),""));
                    }
                    String fileUrl = fastDFSStorageService.uploadResource(fileType, multipartFile.getBytes(), null);
                    busiNotice.setFileUrl(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL) + fileUrl);
                    busiNotice.setFileName(fileName);
                }
            }
            // 新增合同信息
            if (null == busiNotice.getId()|| "".equals(busiNotice.getId())) {
                busiNotice.setValid(Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode()));
                busiNotice.setIsTop(Integer.valueOf(SysEnum.COMMON_TOP_NO.getCode()));
                busiNotice.setReadCount(0);
                busiNotice.setCreateTime(new Date());
                busiNotice.setCreateUser(user.getId());
                busiNotice.setUpdateTime(new Date());
                busiNotice.setUpdateUser(user.getId());
                busiNoticeMapper.addBusiNotice(busiNotice);
            } else {
                // 修改合同信息
                BusiNotice busiNoticetExample = busiNoticeMapper.getBusiNoticeById(busiNotice);
                busiNoticetExample.setTitle(busiNotice.getTitle());
                busiNoticetExample.setOutline(busiNotice.getOutline());
                busiNoticetExample.setContent(busiNotice.getContent());
                if (filesMap != null && !filesMap.isEmpty()) {
                    busiNoticetExample.setFileName(busiNotice.getFileName());
                    busiNoticetExample.setFileUrl(busiNotice.getFileUrl());
                }
                busiNoticetExample.setUpdateTime(new Date());
                busiNoticetExample.setUpdateUser(user.getId());
                busiNoticeMapper.updateBusiNotice(busiNoticetExample);
            }
            return messageData;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
    }
    
    @Override
    public BusiNotice getBusiNoticeById(BusiNotice busiNotice) {
        try {
            BusiNotice busiNoticeInfo = busiNoticeMapper.getBusiNoticeById(busiNotice);
            return busiNoticeInfo;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }
    }
    
    @Override
    public void noticeAttachDownload(HttpServletResponse response, BusiNotice busiNotice) {
        try {
            BusiNotice dto = busiNoticeMapper.getBusiNoticeById(busiNotice);
            if(dto!=null) {
                String fileUrl = dto.getFileUrl();
                if(StringUtils.isNotBlank(fileUrl)) {
                    String groupId = PropertiesUtil.getProperty(SysConstant.FASTDFS_GROUP_ID);
                    String remoteUrl =  fileUrl.substring(fileUrl.indexOf(groupId)+(groupId.length()+1),fileUrl.length());
                    MultiPartUtil.downloadFromFastDfs(response, groupId, remoteUrl, dto.getFileName());         
                }
            }else{
                throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
            }
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }

    }

}
