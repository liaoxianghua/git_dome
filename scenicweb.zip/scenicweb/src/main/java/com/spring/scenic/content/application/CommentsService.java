package com.spring.scenic.content.application;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.content.domain.Comments;
import com.spring.scenic.content.domain.CommentsImage;
import com.spring.scenic.content.domain.CommentsScoreItems;
import com.spring.scenic.system.domain.AuthUser;

public interface CommentsService {

	List<Comments> getEvaluateListData(Comments comment, boolean pageAble);

	CommentsImage getCommentsImage(CommentsImage image);

	int auditEvaluate(AuthUser user, Comments comments);

	void downEvaluateFile(HttpServletResponse response);

	List<CommentsScoreItems> getEvaluateItemListData(CommentsScoreItems item,boolean pageAble);

	int updateEvaluateItemValid(AuthUser user, CommentsScoreItems item);

	int saveEvaluateItem(AuthUser user, CommentsScoreItems item);

	List<MessageData> saveEvaluateImportData(AuthUser user,Map<String, List<MultipartFile>> filesMap, String key);

	CommentsScoreItems getCommentsScoreItem(CommentsScoreItems item);

	int updateEvaluateItem(AuthUser user, CommentsScoreItems item);

}
