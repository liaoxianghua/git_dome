package com.spring.scenic.system.domain.dto;

import java.io.Serializable;

/**
 * 密码
 * @author ranmaoping
 * 2017-01-14
 */
public class PasswordVo implements Serializable {
	
	private static final long serialVersionUID = -7780679957569654380L;
	private String oldPassword;//旧密码
	private String newPassword;//新密码
	private String confirmPass;//确认密码
	private Integer userId;//用户id
	private String loginPassword;//登录密码
	
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmPass() {
		return confirmPass;
	}
	public void setConfirmPass(String confirmPass) {
		this.confirmPass = confirmPass;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	
	
}	
