package com.spring.scenic.system.application;

import java.util.List;

import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;

public interface DepartmentService {
	

	/**
	 * @param userCriteria
	 * @return
	 */
	public List<Department> queryDepartment(Department department,boolean pageAble);

	/**
	 * 删除数据
	 * @param dictionary
	 */
	public void deleteByPrimaryKey(Department department);

	/**
	 * 新增部门
	 * @param department
	 * @param userInfo
	 */
	public void addDepartment(Department department, AuthUser userInfo);

	/**
	 * 修改部门
	 * @param department
	 * @param userInfo
	 */
	public void updateDepartment(Department department, AuthUser userInfo);
	
	/**
	 *  加载父部门下拉框
	 * @param department
	 * @return
	 */
	public List<Department> initParentDeptOptions(Department department);
	/**
	 * 通过id查询部门
	 * @param id
	 * @return
	 */
	public Department selectDeptByPrimaryKey(Integer id);
	
	/**
	 * 启用禁用数据
	 * @param department
	 * @param userInfo
	 */
	public void updateForbiddenOrUseData(Department department, AuthUser userInfo);

	/**
	 * 禁用父部门及其子部门
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月10日
	 */
	public void updateForbiddenItemDept(Department department,
			AuthUser userInfo);

	public String getDeptNameById(Department department);

	List<ZtreeDept> initParentDeptOptionsNew(Department department);
	
}
