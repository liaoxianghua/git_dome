package com.spring.scenic.basic.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.basic.application.CityLandMarkService;
import com.spring.scenic.basic.domain.CityLandMark;
import com.spring.scenic.basic.domain.MapMessage;
import com.spring.scenic.basic.infrastructure.CityLandMarkMapper;
import com.spring.scenic.basic.infrastructure.ScenicCommercialMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

@Service("cityLandMarkService")
public class CityLandMarkServiceImpl implements CityLandMarkService {
	
	@Autowired
	private CityLandMarkMapper cityLandMarkMapper;
	
	@Autowired
	private ScenicCommercialMapper scenicCommercialMapper;
	/**
	 * @param cityLandMark
	 * @return
	 */
	public List<CityLandMark> getCityLandMarkList(CityLandMark cityLandMark) {
		try {
			PageHelper.startPage(cityLandMark.getPageNum(), SysConstant.PAGE_PAGESIZE);
			/*if(cityLandMark.getOrderByClause().equals("ID ASC")){
				cityLandMark.setOrderByClause("id desc");
			}*/
			//组装地标信息，用于页面展示
			List<CityLandMark> cityLandMarkList = cityLandMarkMapper.getCityLandMarkList(cityLandMark);
			return cityLandMarkList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}

	/**根據id查詢經緯度位置信息
	 * @param cityLandMark
	 * @return
	 */
	public CityLandMark getCityLandMarkInfoById(CityLandMark cityLandMark) {
		try {
			CityLandMark dto = (CityLandMark) cityLandMarkMapper.getCityLandMarkInfoById(cityLandMark);
			//查询地标地图信息
			MapMessage mapMessage = new MapMessage();
			mapMessage.setOutRelatedId(cityLandMark.getId());
			mapMessage.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
			List<MapMessage> liMapMessages = scenicCommercialMapper.selectLandMarkMapListByParam(mapMessage);
			dto.setLiMapMessages(liMapMessages);
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	/**
	 * 通过id查询经纬度信息，并且组装
	 * @param cityLandMark
	 * @return
	 */
	public CityLandMark getCityLandMarkInfoAndPositionInfoById(CityLandMark cityLandMark) {
		try {
			CityLandMark dto = new CityLandMark();
			cityLandMark.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
			List<CityLandMark> list = cityLandMarkMapper.getPositionList(cityLandMark);
			if(null!=list && list.size()>0) {
				for (CityLandMark cldDto : list) {
					if(cldDto.getTypeId()==1) {
						dto.setBaiduLgn("百度："+cldDto.getLgn()+"/");
						dto.setBaiduLat(cldDto.getLat()+"<br>");
					}else if(cldDto.getTypeId()==2) {
						dto.setGoogleLgn("谷歌："+cldDto.getLgn()+"/");
						dto.setGoogleLat(cldDto.getLat()+"<br>");
					}else if(cldDto.getTypeId()==3) {
						dto.setGaodeLgn("高德："+cldDto.getLgn()+"/");
						dto.setGaodeLat(cldDto.getLat()+"<br>");
					}else if(cldDto.getTypeId()==4) {
						dto.setTxLgn("腾讯："+cldDto.getLgn()+"/");
						dto.setTxLat(cldDto.getLat());
					}
				}
			}
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	
	/**
	 * 查询经纬度信息
	 */
	public CityLandMark getPositionList(CityLandMark cityLandMark) {
		return cityLandMark;
		
	}
	/**
	 * 根据主键id查询经纬度信息，并拼装所有的经纬度信息
	 */
	public CityLandMark getPositionInfoById(CityLandMark cityLandMark) {
		try {
			CityLandMark dto = this.getCityLandMarkInfoAndPositionInfoById(cityLandMark);
			//String positionInfo = dto.getBaiduLat()+dto.getBaiduLgn()+dto.getGoogleLat()+dto.getGoogleLgn()+dto.getGaodeLat()+dto.getGaodeLgn()+dto.getTxLat()+dto.getTxLgn();
			if(null!=dto) {
				String positionInfo = dto.getBaiduLgn()+dto.getBaiduLat()+dto.getGoogleLgn()+dto.getGoogleLat()+dto.getGaodeLgn()+dto.getGaodeLat()+dto.getTxLgn()+dto.getTxLat();
				String position = positionInfo.replace("null", "");
				dto.setPositionInfo(position);
			}
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * @param cityLandMark
	 */
	public void saveCityLandMark1(CityLandMark cityLandMark) {
		
		try {
			//校验地图类型是否重复,以及是否为空
			validataMap(cityLandMark.getLiMapMessages());
			cityLandMark.setCreateTime(new Date());
			Integer valid =  Integer.parseInt(cityLandMark.getValid());
			cityLandMark.setStatus(valid);
			if(null==(cityLandMark.getId())||"".equals(cityLandMark.getId())){
				List<CityLandMark> list = new ArrayList<CityLandMark>();
				//百度经纬度
				if(null!=cityLandMark.getBaiduLat()&&!"".equals(cityLandMark.getBaiduLat())&&null!=cityLandMark.getBaiduLgn()&&!"".equals(cityLandMark.getBaiduLgn())) {
					CityLandMark clmDto = new CityLandMark();
					clmDto.setStatus(1);
					clmDto.setOutRelatedId(cityLandMark.getSequence());
					clmDto.setOutRelatedType(1);
					clmDto.setCreateTime(new Date());
					clmDto.setCreateUser(cityLandMark.getCreateUser());
					clmDto.setTypeId(1);
					clmDto.setLat(cityLandMark.getBaiduLat());
					clmDto.setLgn(cityLandMark.getBaiduLgn());
					list.add(clmDto);
				}
				//腾讯经纬度
				if(null!=cityLandMark.getTxLat()&&!"".equals(cityLandMark.getTxLat())&&null!=cityLandMark.getTxLgn()&&!"".equals(cityLandMark.getTxLgn())) {
					CityLandMark clmDto = new CityLandMark();
					clmDto.setStatus(1);
					clmDto.setOutRelatedId(cityLandMark.getSequence());
					clmDto.setOutRelatedType(1);
					clmDto.setCreateTime(new Date());
					clmDto.setCreateUser(cityLandMark.getCreateUser());
					clmDto.setTypeId(4);
					clmDto.setLat(cityLandMark.getTxLat());
					clmDto.setLgn(cityLandMark.getTxLgn());
					list.add(clmDto);
				}
				//高德经纬度
				if(null!=cityLandMark.getGaodeLat()&&!"".equals(cityLandMark.getGaodeLat())&&null!=cityLandMark.getGaodeLgn()&&!"".equals(cityLandMark.getGaodeLgn())) {
					CityLandMark clmDto = new CityLandMark();
					clmDto.setStatus(1);
					clmDto.setOutRelatedId(cityLandMark.getSequence());
					clmDto.setOutRelatedType(1);
					clmDto.setCreateTime(new Date());
					clmDto.setCreateUser(cityLandMark.getCreateUser());
					clmDto.setTypeId(3);
					clmDto.setLat(cityLandMark.getGaodeLat());
					clmDto.setLgn(cityLandMark.getGaodeLgn());
					list.add(clmDto);
				}
				//谷歌经纬度
				if(null!=cityLandMark.getGoogleLat()&&!"".equals(cityLandMark.getGoogleLat())&&null!=cityLandMark.getGoogleLgn()&&!"".equals(cityLandMark.getGoogleLgn())) {
					CityLandMark clmDto = new CityLandMark();
					clmDto.setStatus(1);
					clmDto.setOutRelatedId(cityLandMark.getSequence());
					clmDto.setOutRelatedType(1);
					clmDto.setCreateTime(new Date());
					clmDto.setCreateUser(cityLandMark.getCreateUser());
					clmDto.setTypeId(2);
					clmDto.setLat(cityLandMark.getGoogleLat());
					clmDto.setLgn(cityLandMark.getGoogleLgn());
					list.add(clmDto);
				}
				cityLandMarkMapper.insertPosition(list);
			} else {
				 this.cityLandMarkMapper.updateCityLandMarkInfo(cityLandMark); // 修改
				 cityLandMark.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
				 List<CityLandMark> list = cityLandMarkMapper.getPositionList(cityLandMark);
				 if(null!=list && list.size()>0) {
						for (CityLandMark cldDto : list) {
							if(cldDto.getTypeId()==1) {
								cityLandMark.setLat(cityLandMark.getBaiduLat());
								cityLandMark.setLgn(cityLandMark.getBaiduLgn());
								cityLandMark.setTypeId(1);
								cityLandMarkMapper.updatePositionInfo(cityLandMark);
								continue;
							}else if(cldDto.getTypeId()==2) {
								cityLandMark.setLat(cityLandMark.getGoogleLat());
								cityLandMark.setLgn(cityLandMark.getGoogleLgn());
								cityLandMark.setTypeId(2);
								cityLandMarkMapper.updatePositionInfo(cityLandMark);
								continue;
							}else if(cldDto.getTypeId()==3) {
								cityLandMark.setLat(cityLandMark.getGaodeLat());
								cityLandMark.setLgn(cityLandMark.getGaodeLgn());
								cityLandMark.setTypeId(3);
								cityLandMarkMapper.updatePositionInfo(cityLandMark);
								continue;
							}else if(cldDto.getTypeId()==4) {
								cityLandMark.setLat(cityLandMark.getTxLat());
								cityLandMark.setLgn(cityLandMark.getTxLgn());
								cityLandMark.setTypeId(4);
								cityLandMarkMapper.updatePositionInfo(cityLandMark);
								continue;
							}
						}
						List<CityLandMark> listPosition = new ArrayList<CityLandMark>();
						//查看百度经纬是否为空，参数是否为空，参数不为空，数据库没有百度经纬度数据，则进行新增操作
						if(null!=cityLandMark.getBaiduLat()
								&&!"".equals(cityLandMark.getBaiduLat())&&null!=cityLandMark.getBaiduLgn()
								&&!"".equals(cityLandMark.getBaiduLgn())) {
							cityLandMark.setTypeId(1);
							int count = cityLandMarkMapper.getPositionCountByType(cityLandMark);
							if(count<1) {
								CityLandMark clmDto = new CityLandMark();
								clmDto.setStatus(1);
								clmDto.setOutRelatedId(cityLandMark.getId());
								clmDto.setOutRelatedType(1);
								clmDto.setCreateTime(new Date());
								clmDto.setCreateUser(cityLandMark.getCreateUser());
								clmDto.setTypeId(1);
								clmDto.setLat(cityLandMark.getBaiduLat());
								clmDto.setLgn(cityLandMark.getBaiduLgn());
								listPosition.add(clmDto);
							} 
						}
						//谷歌判断如上
						if(null!=cityLandMark.getGoogleLat()
								&&!"".equals(cityLandMark.getGoogleLat())
								&&null!=cityLandMark.getGoogleLgn()&&!"".equals(cityLandMark.getGoogleLgn())) {
							cityLandMark.setTypeId(2);
							int count = cityLandMarkMapper.getPositionCountByType(cityLandMark);
							if(count<1) {
								CityLandMark clmDto = new CityLandMark();
								clmDto.setStatus(1);
								clmDto.setOutRelatedId(cityLandMark.getId());
								clmDto.setOutRelatedType(1);
								clmDto.setCreateTime(new Date());
								clmDto.setCreateUser(cityLandMark.getCreateUser());
								clmDto.setTypeId(2);
								clmDto.setLat(cityLandMark.getGoogleLat());
								clmDto.setLgn(cityLandMark.getGoogleLgn());
								listPosition.add(clmDto);
							} 
						}
						//高德
						if(null!=cityLandMark.getGaodeLat()
								&&!"".equals(cityLandMark.getGaodeLat())
								&&null!=cityLandMark.getGaodeLgn()
								&&!"".equals(cityLandMark.getGaodeLgn())) {
							cityLandMark.setTypeId(3);
							int count = cityLandMarkMapper.getPositionCountByType(cityLandMark);
							if(count<1) {
								CityLandMark clmDto = new CityLandMark();
								clmDto.setStatus(1);
								clmDto.setOutRelatedId(cityLandMark.getId());
								clmDto.setOutRelatedType(1);
								clmDto.setCreateTime(new Date());
								clmDto.setCreateUser(cityLandMark.getCreateUser());
								clmDto.setTypeId(3);
								clmDto.setLat(cityLandMark.getGaodeLat());
								clmDto.setLgn(cityLandMark.getGaodeLgn());
								listPosition.add(clmDto);
							} 
						}
						//腾讯
						if(null!=cityLandMark.getTxLat()
								&&!"".equals(cityLandMark.getTxLat())
								&&null!=cityLandMark.getTxLgn()
								&&!"".equals(cityLandMark.getTxLgn())) {
							cityLandMark.setTypeId(4);
							int count = cityLandMarkMapper.getPositionCountByType(cityLandMark);
							if(count<1) {
								CityLandMark clmDto = new CityLandMark();
								clmDto.setStatus(1);
								clmDto.setOutRelatedId(cityLandMark.getId());
								clmDto.setOutRelatedType(1);
								clmDto.setCreateTime(new Date());
								clmDto.setCreateUser(cityLandMark.getCreateUser());
								clmDto.setTypeId(4);
								clmDto.setLat(cityLandMark.getTxLat());
								clmDto.setLgn(cityLandMark.getTxLgn());
								listPosition.add(clmDto);
							} 
						}
						if(null!=listPosition&&listPosition.size()>0) {
							cityLandMarkMapper.insertPosition(listPosition);
						}
						
				 }
				 
			}
		} catch (Exception e) {
				throw new BussinessException(new BussinessExceptionBean("exception.error.systemsaverole"), e);
			}
		
	}

	
	public Integer saveCityLandMark(CityLandMark cityLandMark) {
		
		Integer id = null;
		List<MapMessage> mapInfoList = cityLandMark.getLiMapMessages();
		//校验地图类型是否重复,以及是否为空
		validCityLandMark(cityLandMark);
		validataMap(mapInfoList);
		
		try {
			cityLandMark.setCreateTime(new Date());
			Integer valid = Integer.parseInt(cityLandMark.getValid());
			cityLandMark.setStatus(valid);
			if(null==(cityLandMark.getId())||"".equals(cityLandMark.getId())) {
				id = this.cityLandMarkMapper.addCityLandMarkInfo(cityLandMark); // 新增
				List<CityLandMark> list = new ArrayList<CityLandMark>();
				Integer seqence = cityLandMark.getSequence();
				Integer outRelatedType = Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode());
				if(null!=mapInfoList&&mapInfoList.size()>0) {
					for (MapMessage mapMessage : mapInfoList) {
						if(null==mapMessage.getMapType()) continue;
						CityLandMark dto = new CityLandMark();
						dto.setTypeId(mapMessage.getMapType());
						dto.setLat(mapMessage.getMapLat());
						dto.setLgn(mapMessage.getMapLgn());
						dto.setOutRelatedId(seqence);
						dto.setOutRelatedType(outRelatedType);
						dto.setStatus(cityLandMark.getStatus());
						dto.setCreateTime(new Date());
						dto.setCreateUser(cityLandMark.getCreateUser());
						list.add(dto);
					}
					cityLandMarkMapper.insertPosition(list);
				}
			}else{
				//修改地标管理的基础信息
				this.cityLandMarkMapper.updateCityLandMarkInfo(cityLandMark); // 修改
				//状态为新增的地图类型集合
				List<CityLandMark> insertList = new ArrayList<CityLandMark>();
				//状态为修改的地图类型集合
				//List<CityLandMark> updateList = new ArrayList<CityLandMark>();
				//状态为删除的地图类型集合
				List<CityLandMark> deleteList = new ArrayList<CityLandMark>();
				//从前端传来的地图类型集合：mapInfoList
				//数据库当前outRelatedId下的地图类型集合
				MapMessage mapMessageInfo = new MapMessage();
				mapMessageInfo.setOutRelatedId(cityLandMark.getId());
				mapMessageInfo.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
				List<MapMessage> preMaplist = scenicCommercialMapper.selectLandMarkMapListByParam(mapMessageInfo);
				//mapInfoList与数据库已有的数据集合作比较，得到新增地图类型集合和修改地图类型集合
				for (MapMessage mapMessage : mapInfoList) {
					boolean flag = true;
					//
					CityLandMark insertDto = new CityLandMark();
					//
					CityLandMark updateDto = new CityLandMark();
					for (MapMessage premapMessage : preMaplist) {
						if(premapMessage.getMapType()==mapMessage.getMapType()) {
							flag = false;
							updateDto.setTypeId(mapMessage.getMapType());
							updateDto.setLat(mapMessage.getMapLat());
							updateDto.setLgn(mapMessage.getMapLgn());
							updateDto.setOutRelatedId(cityLandMark.getId());
							updateDto.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
							updateDto.setStatus(cityLandMark.getStatus());
							updateDto.setUpdateTime(new Date());
							updateDto.setUpdateUser(cityLandMark.getCreateUser());
							cityLandMarkMapper.updatePositionInfo(updateDto);
							//updateList.add(updateDto);
							break;
						}
					}
					if(flag&&null!=mapMessage.getMapType()) {
						insertDto.setTypeId(mapMessage.getMapType());
						insertDto.setLat(mapMessage.getMapLat());
						insertDto.setLgn(mapMessage.getMapLgn());
						insertDto.setOutRelatedId(cityLandMark.getId());
						insertDto.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
						insertDto.setStatus(cityLandMark.getStatus());
						insertDto.setCreateTime(new Date());
						insertDto.setCreateUser(cityLandMark.getCreateUser());
						insertList.add(insertDto);
					}
				}
				//数据库已有的数据集合与mapInfoList作比较，得到删除地图类型集合
				for (MapMessage premapMessage : preMaplist) {
					CityLandMark deleteDto = new CityLandMark();
					boolean flag = true;
					for (MapMessage mapMessage : mapInfoList) {
						if(premapMessage.getMapType()==mapMessage.getMapType()) {
							flag = false;
							break;
						}
					}
					if(flag) {
						deleteDto.setTypeId(premapMessage.getMapType());
						deleteDto.setOutRelatedId(cityLandMark.getId());
						deleteDto.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
						deleteList.add(deleteDto);
					}
				}
				
				//新增地图类型的经纬度
				if(null!=insertList&&insertList.size()>0) {
					cityLandMarkMapper.insertPosition(insertList);
				}
				//修改地图类型的经纬度
				/*if(null!=updateList&&updateList.size()>0) {
					cityLandMarkMapper.updateList(updateList);
				}*/
				//删除地图类型的经纬度
				if(null!=deleteList&&deleteList.size()>0) {
					cityLandMarkMapper.deleteList(deleteList);
				}
			}
			return id;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**校验地图类型是否重复,以及经纬度是否为空
	 * @param liMapMessages
	 */
	public void validataMap(List<MapMessage> liMapMessages) {
		if(null!=liMapMessages&&liMapMessages.size()>0) {
			for (MapMessage mapMessageCompared : liMapMessages) {
				int count = 0;
				for (MapMessage mapMessage : liMapMessages) {
					//如果当前地图类型的经纬度为空，提示经纬度不能为空，
					if(null!=mapMessageCompared.getMapType()) {
						if(StringUtil.isEmpty(mapMessageCompared.getMapLat())||StringUtil.isEmpty(mapMessageCompared.getMapLgn())) {
							throw new BussinessException(new BussinessExceptionBean("exception.lgnAndLatIsNotNull"));
						}
					}
					if(null!=mapMessageCompared.getMapType()&&mapMessageCompared.getMapType()==mapMessage.getMapType()) {
						count++;
						if(count>1){
							throw new BussinessException(new BussinessExceptionBean("exception.mapTypeIsExist"));
						}
						
					}
					
				}
			}
		}
		
	}
	
	/**
	 * 启动禁用地标
	 */
	public void updateCityLandMarkStatus(CityLandMark clmDto) {
		try {
			cityLandMarkMapper.updateCityLandMarkStatus(clmDto);
			clmDto.setOutRelatedType(Integer.valueOf(SysEnum.POSITION_TYPE_LANDMARK.getCode()));
			cityLandMarkMapper.updatePositionStatus(clmDto);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**
	 * 校验地标是否重复
	 * 
	 */
	private void validCityLandMark(CityLandMark cityLandMark) {
		if(null!=cityLandMark&&null==cityLandMark.getCityId()) {
			throw new BussinessException(new BussinessExceptionBean("exception.cityIsInvalid"));
		}
		int count = cityLandMarkMapper.getCityLandMarkCount(cityLandMark);
		if(count>0) {
			throw new BussinessException(new BussinessExceptionBean("exception.cityLandMarkNameIsExisted"));
		}
	}
} 
