package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.system.domain.AuthUser;

public interface CountryService {

	/**
	 * @param userCriteria
	 * @return
	 */
	public List<Country> queryCountry(Country country,boolean pageAble);

	/**添加国家信息
	 * @param user
	 * @return
	 */
	public int addCountry(Country country,AuthUser user);

	/**修改国家信息
	 * @param user
	 * @return
	 */
	public int updateByPrimaryKey(Country country,AuthUser user);

	/**根据主键查询
	 * @param id
	 * @return
	 */
	public Country selectByPrimaryKey(Integer id);

	/**
	 * 禁用数据
	 * @param country
	 */
	public void updateCountryById(Country country,AuthUser user);
	
	
}
