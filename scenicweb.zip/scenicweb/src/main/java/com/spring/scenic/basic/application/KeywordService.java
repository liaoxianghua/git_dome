package com.spring.scenic.basic.application;

import java.util.List;

import com.spring.scenic.basic.domain.Keyword;
import com.spring.scenic.system.domain.AuthUser;

public interface KeywordService {

	/**
	 * @param userCriteria
	 * @return
	 */
	public List<Keyword> queryKeywordList(Keyword keyword,boolean pageAble);

	/**添加关键字信息
	 * @param user
	 * @return
	 */
	public int addKeyword(Keyword keyword,AuthUser user);

	/**修改关键字信息
	 * @param user
	 * @return
	 */
	public int updateByPrimaryKey(Keyword keyword,AuthUser user);

	/**根据主键查询
	 * @param id
	 * @return
	 */
	public Keyword selectByPrimaryKey(Integer id);

	/**
	 * 禁用数据
	 * @param country
	 */
	public void updateKeywordById(Keyword keyword,AuthUser user);
	
	/**
	 * 查询有效的关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月18日
	 */
	public List<Keyword> selectKeywordList(Keyword keyword);

	/**
	 * 添加游记攻略关键字
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	public Keyword addTravelNoteKeyword(Keyword keyword,AuthUser authUser);
	
	/**
	 * 校验游记关键字是否存在
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	public int getTravelKeywordRef(Keyword keyword);
	/**
	 * 游记关键字list
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月19日
	 */
	public List<Keyword> selectByTravelNoteKeywordList(Keyword keyword);

	/**
	 * 删除关键字关联表数据(根据关键字id和外键id和类型)
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年2月16日
	 */
	public void delTravelNoteKeyword(Keyword keyword);
	
	
}
