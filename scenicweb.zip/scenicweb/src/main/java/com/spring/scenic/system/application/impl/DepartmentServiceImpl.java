package com.spring.scenic.system.application.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.application.DepartmentService;
import com.spring.scenic.system.domain.AuthDepartment;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;
import com.spring.scenic.system.infrastructure.DepartmentMapper;


@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Resource
	private DepartmentMapper departmentMapper;

	/**
	 * 查询部门信息
	 */
	public List<Department> queryDepartment(Department department,boolean pageAble) {
			try {
				if(pageAble){
					PageHelper.startPage(department.getPageNum(), SysConstant.PAGE_PAGESIZE);
				}
				List<Department> allList = departmentMapper.selectDepartmentForManagerNew(department);
				List<Department> rootDepartments = new ArrayList<Department>();
				if(allList!=null && !allList.isEmpty()){
					for (Department currentDepartment : allList) {
						recursionDepartment(currentDepartment,allList);
					}
					for (Department currentDepartment : allList) {
						if(currentDepartment.getParentId()==null){
							rootDepartments.add(currentDepartment);
						}
					}
				}
				return rootDepartments;
			} catch (NumberFormatException e) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}
	
	public void recursionDepartment(Department compareDepartment,List<Department> departments){
		try {
			List<Department> authDepartments = new ArrayList<Department>();
			for (Department currentDepartment : departments) {
				if(currentDepartment.getParentId()!=null && currentDepartment.getParentId().equals(compareDepartment.getId())){
					authDepartments.add(currentDepartment);
				}
			}
			compareDepartment.setChildren(authDepartments.isEmpty()?null:authDepartments);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public void deleteByPrimaryKey(Department department) {
		/*
		 * 这里应该加入判断，删除的数据是否被引用，如果被引用就不做删除操作
		 */
		
		//如果字典id不等于空且字典分类id等于空则删除字典下所有的数据
		try {
			if (department.getId()!=null && (department.getParentId()==null||"".equals(department.getParentId()))) {
				departmentMapper.deleteByPrimaryId(department.getId());
				departmentMapper.deleteChildrenByParentId(department.getParentId());
			}
			if (department.getParentId()!=null && !"".equals(department.getParentId())) {
				departmentMapper.deleteChildrenByParentId(department.getId());
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void addDepartment(Department department, AuthUser userInfo) {
		try {
			department.setCreateUserId(userInfo.getId());
			department.setCreateTime(new Date());
			departmentMapper.insertDepartment(department);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateDepartment(Department department, AuthUser userInfo) {
		try {
			Department departmentVo = new Department();
			departmentVo = departmentMapper.selectDeptByPrimaryKey(department.getId());
			departmentVo.setName(department.getName());
			departmentVo.setParentId(department.getParentId());
			departmentVo.setRemarks(department.getRemarks());
			departmentVo.setValid(department.getValid());
			departmentVo.setUpdateUserId(userInfo.getId());
			departmentVo.setUpdateTime(new Date());
			departmentMapper.updateDepartment(departmentVo);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Department> initParentDeptOptions(Department department) {
		try {
			List<Department> resultList = departmentMapper.initParentDeptOptions(department);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Department selectDeptByPrimaryKey(Integer id) {
		try {
			return departmentMapper.selectDeptByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateForbiddenOrUseData(Department department, AuthUser userInfo) {
		try {
			department.setUpdateUserId(userInfo.getId());
			department.setUpdateTime(new Date());
			departmentMapper.updateForbiddenOrUseData(department);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateForbiddenItemDept(Department department,
			AuthUser userInfo) {
		try {
			department.setUpdateUserId(userInfo.getId());
			department.setUpdateTime(new Date());
			departmentMapper.updateForbiddenOrUseData(department);
//			departmentMapper.updateForbiddenItemDept(department);
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public String getDeptNameById(Department department) {
		try {
			String deptName = "";
			List<String> aboutDepartments = new ArrayList<String>();
			List<AuthDepartment> departments = departmentMapper.getDepartmentList(new Department());
			if(departments!=null && !departments.isEmpty()){
				AuthDepartment currentDept = departmentMapper.getDepartmentById(department.getId());
				if(currentDept!=null){
					aboutDepartments.add(currentDept.getName());
					aboutDepartments = recursionDept(aboutDepartments,currentDept,departments);
				}
				if(!aboutDepartments.isEmpty()){
					Collections.reverse(aboutDepartments);
					for (String dName : aboutDepartments) {
						deptName = StringUtils.isBlank(deptName)?dName:deptName+"-"+dName;
					}
					return deptName;
				}
			}
			return deptName;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	public List<String> recursionDept(List<String> aboutDepartments,AuthDepartment currentDept, List<AuthDepartment> departments){
		for (AuthDepartment tempDept : departments) {
			if(tempDept.getId().equals(currentDept.getParentId())){
				aboutDepartments.add(tempDept.getName());
				if(tempDept.getParentId()!=null){
					recursionDept(aboutDepartments,tempDept,departments);
				}
			}
		}
		return aboutDepartments;
	}

	@Override
	public List<ZtreeDept> initParentDeptOptionsNew(Department department) {
		try {
			List<ZtreeDept> resultList = departmentMapper.initParentDeptOptionsNew(department);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
}
