package com.spring.scenic.basic.application.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.basic.application.CountryService;
import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.basic.infrastructure.CountryMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.domain.AuthUser;

@Service
public class CountryServiceImpl implements CountryService {

	@Resource
	private CountryMapper countryMapper;

	public List<Country> queryCountry(Country country,boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(country.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<Country> resultList = countryMapper.selectCountryForManager(country);
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public int addCountry(Country country,AuthUser user) {
		try {
			country.setCreateUser(user.getId());
			country.setCreateTime(new Date());
			if (StringUtil.isNotEmpty(country.getName())) {
				country.setName(country.getName().trim());
			}
			if (StringUtil.isNotEmpty(country.getEnName())) {
				country.setEnName(country.getEnName().trim());
			}
			if (StringUtil.isNotEmpty(country.getCode())) {
				country.setCode(country.getCode().trim());
			}
			return countryMapper.addCountry(country);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public int updateByPrimaryKey(Country country,AuthUser user) {
		try {
			country.setUpdateUser(user.getId());
			country.setUpdateTime(new Date());
			if (StringUtil.isNotEmpty(country.getName())) {
				country.setName(country.getName().trim());
			}
			if (StringUtil.isNotEmpty(country.getEnName())) {
				country.setEnName(country.getEnName().trim());
			}
			if (StringUtil.isNotEmpty(country.getCode())) {
				country.setCode(country.getCode().trim());
			}
			return countryMapper.updateByPrimaryKey(country);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public Country selectByPrimaryKey(Integer id) {
		try {
			return countryMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateCountryById(Country country,AuthUser user) {
		 try {
			country.setUpdateUser(user.getId());
			 country.setUpdateTime(new Date());
			 countryMapper.updateCountryById(country);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



}
