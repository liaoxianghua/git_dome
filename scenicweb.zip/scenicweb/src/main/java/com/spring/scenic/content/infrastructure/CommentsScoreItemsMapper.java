package com.spring.scenic.content.infrastructure;

import java.util.List;

import com.spring.scenic.content.domain.CommentsScoreItems;

public interface CommentsScoreItemsMapper {

	List<CommentsScoreItems> getEvaluateItemList(CommentsScoreItems item);

	int saveEvaluateItem(CommentsScoreItems item);

	int updateEvaluateItem(CommentsScoreItems item);

	CommentsScoreItems getCommentsScoreItem(CommentsScoreItems item);
	
}