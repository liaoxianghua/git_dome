package com.spring.scenic.content.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * @Description 内容管理-点评项关系
 * @author 006568（shuchang）
 * @date 2016年12月30日
 */
public class CommentsOption extends Entity<CommentsOption>{
	
    /**
     * 主键
     */
    private Integer id;

    /**
     * 点评ID
     */
    private Integer cmmtId;

    /**
     * 点评名称
     */
    private String scoreItemsTitle;

    /**
     * 点评项ID
     */
    private Integer scoreItemsId;

    /**
     * 得分
     */
    private Integer score;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private Integer updateUser;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCmmtId() {
		return cmmtId;
	}

	public void setCmmtId(Integer cmmtId) {
		this.cmmtId = cmmtId;
	}

	public String getScoreItemsTitle() {
		return scoreItemsTitle;
	}

	public void setScoreItemsTitle(String scoreItemsTitle) {
		this.scoreItemsTitle = scoreItemsTitle;
	}

	public Integer getScoreItemsId() {
		return scoreItemsId;
	}

	public void setScoreItemsId(Integer scoreItemsId) {
		this.scoreItemsId = scoreItemsId;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

}