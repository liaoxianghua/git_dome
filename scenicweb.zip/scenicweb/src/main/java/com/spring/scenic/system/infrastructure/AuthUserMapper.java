package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.dto.PasswordVo;

public interface AuthUserMapper {

	AuthUser getUserByAccount(String username);

	List<AuthRole> getUserAuthRoleList(AuthUser authUser);

	List<AuthResource> getUserAuthResourceList(AuthUser authUser);

	List<AuthUser> queryUserList(AuthUser authUser);

	void addUser(AuthUser userInfo);

	void updateByPrimaryKey(AuthUser userInfo);

	List<Department> initDeptOptions(AuthUser userInfo);

	void updateForbiddenOrUseData(AuthUser authUser);

	int queryUserByUserName(AuthUser authUser);

	AuthUser selectUserByPrimaryKey(Integer id);

	void updateUserById(AuthUser userInfo);

	void updateUserPassword(AuthUser authUser);

	/**
	 * @param id
	 * @return
	 */
	AuthUser queryUserInfoById(Integer id);

	/**
	 * @param vo
	 */
	void updatePassword(PasswordVo vo);

	/**
	 * @param authUser
	 */
	void updateContactInfo(AuthUser authUser);

    /**   
     * 此处为类方法说明：校验username 是否重复 ，如果重复，提示
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月23日     
     * @memo ：   
     **
     */
    int selectCountByParam(AuthUser authUser);
	
}