package com.spring.scenic.common.extend;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.context.request.WebRequest;

import com.spring.scenic.system.domain.AuthUser;

/**
 * @Description 接口基类
 * @author 006568（shuchang）
 * @date 2016年12月23日
 */
public class BaseController{
	
	@InitBinder
	public void initBinder(WebDataBinder binder, WebRequest request) {
		binder.registerCustomEditor(Date.class, new CustomerDateEditor(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"), true));  
	}
	
	/**
	 * 重新加载登录用户信息
	 * @author huangpeng
	 * @param request
	 * @param user
	 *
	 */	
	public void reloadLoginUser(HttpServletRequest request,AuthUser user){
		request.getSession().setAttribute("user", user);
	}
	 
}
