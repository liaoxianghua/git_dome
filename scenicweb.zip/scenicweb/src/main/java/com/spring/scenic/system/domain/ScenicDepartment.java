package com.spring.scenic.system.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;
public class ScenicDepartment  extends Entity<ScenicDepartment> implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String name;//名称
	private String remarks;//备注
	private Integer type;//类别 1 平台 2 景区 3 商户 4 其他
	private Integer parentId;//父级id
	private String valid; //0无效  1有效
	private String guid;
    private Integer createUser;
    private String createUserName;
    private Date createTime;
    private Integer updateUser;
    private Date updateTime;
    private String flag;//标识禁用或者启用 0禁用，1启用
    
    
	public String getCreateUserName() {
		return createUserName;
	}
	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public String getValid() {
		return valid;
	}
	public void setValid(String valid) {
		this.valid = valid;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public Integer getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}


 
}