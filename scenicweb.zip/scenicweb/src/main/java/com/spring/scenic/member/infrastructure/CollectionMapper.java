package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.Collection;

public interface CollectionMapper {

    List<Collection> getMemberCollections(Collection collection);
}