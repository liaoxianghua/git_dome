package com.spring.scenic.content.infrastructure;

import java.util.List;

import com.spring.scenic.content.domain.Comments;
import com.spring.scenic.content.domain.CommentsImage;
import com.spring.scenic.content.domain.CommentsOption;

public interface CommentsMapper {

	/**
	 * @Description 查询点评数据（包含点评主体名称）
	 * @param comment
	 * @return List<Comments>
	 * @author 006568（shuchang）
	 * @date 2016年12月30日
	 */
	List<Comments> getCommentsList(Comments comment);

	/**
	 * @Description 查询图片信息
	 * @param image
	 * @return CommentsImage
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	CommentsImage getCommentsImage(CommentsImage image);

	/**
	 * @Description 修改点评
	 * @param comments
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int updateComment(Comments comments);

	/**
	 * @Description 保存点评
	 * @param comment
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int saveComment(Comments comment);

	/**
	 * @Description 保存点评图片
	 * @param images
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int saveBatchCommentImages(List<CommentsImage> images);

	/**
	 * @Description 保存点评项数据
	 * @param options
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	int saveBatchCommentOptions(List<CommentsOption> options);
}