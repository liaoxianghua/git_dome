package com.spring.scenic.busi.infrastructure;

import java.util.List;

import com.spring.scenic.busi.domain.BusiNotice;

public interface BusiNoticeMapper {

    List<BusiNotice> getBusiNoticeList(BusiNotice busiNotice);
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月22日     
     * @memo ：   
     **
     */
    BusiNotice getBusiNoticeById(BusiNotice busiNotice);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月22日     
     * @memo ：   
     **
     */
    int updateBusiNotice(BusiNotice busiNotice);
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月23日     
     * @memo ：   
     **
     */
    void updateBusiNoticeToCommon(BusiNotice busiNoticeDto);
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月24日     
     * @memo ：   
     **
     */
    void addBusiNotice(BusiNotice busiNotice);
}