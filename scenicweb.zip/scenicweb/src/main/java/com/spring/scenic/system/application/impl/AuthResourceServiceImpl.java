package com.spring.scenic.system.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.application.AuthResourceService;
import com.spring.scenic.system.domain.AuthPermission;
import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.infrastructure.AuthPermissionMapper;
import com.spring.scenic.system.infrastructure.AuthResourceMapper;


@Service
public class AuthResourceServiceImpl implements AuthResourceService {

	@Autowired
	private AuthResourceMapper authResourceMapper;

	@Autowired
	private AuthPermissionMapper permissionMapper;
	
	@Autowired
	private AuthResourceMapper resourceMapper;

	@Override
	public AuthResource selectByPrimaryKey(Integer id) {
		return authResourceMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateForbiddenOrUseData(AuthResource menu, AuthUser userInfo) {
		try {
			menu.setUpdateUser(userInfo.getId());
			menu.setUpdateTime(new Date());
			authResourceMapper.forbiddenOrUseData(menu);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<AuthResource> queryMenuList(AuthResource resource, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(resource.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			List<AuthResource> resources = authResourceMapper.selectMenuListNew(resource);
			List<AuthResource> rootResources = new ArrayList<AuthResource>();
			if(resources!=null && !resources.isEmpty()){
				for (AuthResource currentResource : resources) {
					recursionResource(currentResource,resources);
				}
				for (AuthResource currentResource : resources) {
					if(currentResource.getParentId()==null){
						rootResources.add(currentResource);
					}
				}
			}
			return rootResources;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public List<AuthResource> getUserPermissionByRole(Integer userId,Integer roleId) {
		try {
			AuthRole roleExample = new AuthRole();
			roleExample.setId(roleId);
			List<AuthResource> resources = resourceMapper.getResourceListByRole(roleExample);
			List<AuthResource> rootResources = new ArrayList<AuthResource>();
			if(resources!=null && !resources.isEmpty()){
				for (AuthResource currentResource : resources) {
					currentResource.setAssigned(Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode()));
					recursionResource(currentResource,resources);
				}
				
				for (AuthResource currentResource : resources) {
					if(currentResource.getParentId()==null){
						rootResources.add(currentResource);
					}
				}
			}
			return rootResources;
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void addMenu(AuthResource menu, AuthUser userInfo) {
		try {
			menu.setCreateUser(userInfo.getId());
			menu.setCreateTime(new Date());
			menu.setType(Integer.valueOf(SysEnum.RESOURCE_TYPE_MODULE.getCode()));
			menu.setSystemid(Integer.valueOf(SysEnum.RESOURCE_SYSTEM_SCENIC.getCode()));
			//自动生成功能code
			if (menu.getParentId()!=null && !"".equals(menu.getParentId())) {
				AuthResource authResource = authResourceMapper.selectByPrimaryKey(menu.getParentId());
				int count = authResourceMapper.getFunctionCountByParentId(menu);
				String code = "";
				if (count<10) {
					code = authResource.getCode()+"0"+count;
				}else {
					code = authResource.getCode()+count;
				}
				menu.setCode(code);
			}else {
				int count = authResourceMapper.getModuleCount(menu);
				String code = "";
				if (count<9) {
					code = "R0"+(count+1);
				}else {
					code = "R"+(count+1);
				}
				menu.setCode(code);
			}
			authResourceMapper.insertMenu(menu);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	@Override
	public void updateMenu(AuthResource menu, AuthUser userInfo) {
		try {
			AuthResource authResource = new AuthResource();
			authResource = authResourceMapper.selectByPrimaryKey(menu.getId());
			authResource.setName(menu.getName());
			authResource.setValid(menu.getValid());
			authResource.setRemarks(menu.getRemarks());
			authResource.setUpdateTime(new Date());
			authResource.setUpdateUser(userInfo.getId());
			authResourceMapper.updateMenu(authResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public void addMenuItem(AuthResource menu, AuthUser userInfo) {
		try {
			menu.setCreateUser(userInfo.getId());
			menu.setCreateTime(new Date());
			menu.setType(Integer.valueOf(SysEnum.RESOURCE_TYPE_MENU.getCode()));
			menu.setSystemid(Integer.valueOf(SysEnum.RESOURCE_SYSTEM_SCENIC.getCode()));
			//自动生成功能code
			if (menu.getParentId()!=null && !"".equals(menu.getParentId())) {
				AuthResource authResource = authResourceMapper.selectByPrimaryKey(menu.getParentId());
				int count = authResourceMapper.getFunctionCountByParentId(menu);
				String code = "";
				if (count<9) {
					code = authResource.getCode()+"0"+(count+1);
				}else {
					code = authResource.getCode()+(count+1);
				}
				menu.setCode(code);
			}
			authResourceMapper.insertMenu(menu);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}		
	}



	@Override
	public void updateMenuItem(AuthResource menu, AuthUser userInfo) {
		try {
			AuthResource authResource = new AuthResource();
			authResource = authResourceMapper.selectByPrimaryKey(menu.getId());
			authResource.setName(menu.getName());
			authResource.setParentId(menu.getParentId());
			authResource.setUrl(menu.getUrl());
			authResource.setValid(menu.getValid());
			authResource.setRemarks(menu.getRemarks());
			authResource.setUpdateUser(userInfo.getId());
			authResource.setUpdateTime(new Date());
			authResourceMapper.updateByPrimaryKey(authResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}		
	}



	@Override
	public List<AuthResource> getAuthResourceList(AuthResource authResource) {
		try {
			return authResourceMapper.getAuthResourceList(authResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public void updateForbiddenItemMenu(AuthResource menu, AuthUser userInfo) {
		try {
			menu.setUpdateUser(userInfo.getId());
			menu.setUpdateTime(new Date());
			authResourceMapper.forbiddenOrUseData(menu);
			authResourceMapper.updateForbiddenItemMenu(menu);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}




	@Override
	public void addMenuFunction(AuthResource menu, AuthUser userInfo) {
		try {
			menu.setCreateTime(new Date());
			menu.setCreateUser(userInfo.getId());
			menu.setType(Integer.valueOf(SysEnum.RESOURCE_TYPE_FUNCTION.getCode()));
			menu.setSystemid(Integer.valueOf(SysEnum.RESOURCE_SYSTEM_SCENIC.getCode()));
			//自动生成功能code
			if (menu.getParentId()!=null && !"".equals(menu.getParentId())) {
				AuthResource authResource = authResourceMapper.selectByPrimaryKey(menu.getParentId());
				int count = authResourceMapper.getFunctionCountByParentId(menu);
				String code = "";
				if (count<9) {
					code = authResource.getCode()+"0"+(count+1);
				}else {
					code = authResource.getCode()+(count+1);
				}
				menu.setCode(code);
			}
			authResourceMapper.insertMenu(menu);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}



	@Override
	public List<AuthResource> queryMenuFunctionList(AuthResource menu,
			boolean pageTrue) {
		try {
			if(pageTrue){
				PageHelper.startPage(menu.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			menu.setType(Integer.valueOf(SysEnum.RESOURCE_TYPE_FUNCTION.getCode()));
			List<AuthResource> allList = authResourceMapper.queryMenuFunctionList(menu);
			return allList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public List<AuthResource> getResourceListByRole(AuthRole authRole) {
		try {
			return resourceMapper.getResourceListByRole(authRole);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	public void resetResourceChildren(AuthResource compareResource,List<AuthResource> resources){
		try {
			List<AuthResource> authResources = new ArrayList<AuthResource>();
			for (AuthResource currentResource : resources) {
				if(!compareResource.getId().equals(currentResource.getId())){
					if(currentResource.getParentId()!=null && currentResource.getParentId().equals(compareResource.getId())){
						authResources.add(currentResource);
					}
				}
			}
			compareResource.setChildren(authResources.isEmpty()?null:authResources);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	@Override
	public List<AuthResource> getResourceList(AuthResource resource,AuthRole role,AuthUser user, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(resource.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			Map<Integer,Integer> permissionMap = null;
			List<AuthResource> rootResources = new ArrayList<AuthResource>();
			
			if(role!=null && role.getId()!=null){
				AuthPermission permissionExpample = new AuthPermission();
				permissionExpample.setRoleId(role.getId());
				List<AuthPermission> permissions = permissionMapper.getPermissionList(permissionExpample);
				permissionMap = toPermissionMap(permissions);
			}
			//设置树形层次
			resource.setValid(Integer.parseInt(SysEnum.COMMON_VALID_YES.getCode()));
			Map<String,Object> selectMap = new HashMap<String,Object>();
			selectMap.put("valid", resource.getValid());
			selectMap.put("userId", user.getId());
			if(StringUtils.isNotBlank(resource.getName())){//筛选后的
				selectMap.put("name", resource.getName().trim());
				List<AuthResource> selectedResources = authResourceMapper.getValidOrAssignedResourceList(selectMap);
				for (AuthResource selectedResource : selectedResources) {
					resetResourceChildren(selectedResource,selectedResources);
				}
				for (AuthResource currentResource : selectedResources) {
					//如果角色包含资源则标记
					if(permissionMap!=null && permissionMap.containsKey(currentResource.getId())){
						currentResource.setAssigned(Integer.parseInt(SysEnum.COMMON_BOOL_YES.getCode()));
					}
					//recursionResource(currentResource,defualtAllresources);
				}
				
				
				for (AuthResource currentResource : selectedResources) {
					if(currentResource.getParentId()==null){
						resetUnUseAbleChild(currentResource,resource.getName().trim());
						rootResources.add(currentResource);
					}
				}
				return rootResources;
			}else{//未筛选的
				//List<AuthResource> ValidAndAssignedResource = authResourceMapper.getResourcesByUser(user);
				List<AuthResource> defualtAllresources = authResourceMapper.getDefaultOrAssignedResourceList(selectMap);
				if(defualtAllresources!=null && !defualtAllresources.isEmpty()){
					for (AuthResource currentResource : defualtAllresources) {
						//如果角色包含资源则标记
						if(permissionMap!=null && permissionMap.containsKey(currentResource.getId())){
							currentResource.setAssigned(Integer.parseInt(SysEnum.COMMON_BOOL_YES.getCode()));
						}
						recursionResource(currentResource,defualtAllresources);
					}
					
					for (AuthResource currentResource : defualtAllresources) {
						if(currentResource.getParentId()==null){
							rootResources.add(currentResource);
						}
					}
				}
			}
			return rootResources;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	private void resetUnUseAbleChild(AuthResource currentResource, String keyWord) {
		if(currentResource.getChildren()!=null){
			Iterator<AuthResource> resourceIterator = currentResource.getChildren().iterator();
			while (resourceIterator.hasNext()) {
				AuthResource resource = resourceIterator.next();
				if(resource.getChildren()!=null){
					resetUnUseAbleChild(resource,keyWord);
				}
				if(resource.getChildren()==null || resource.getChildren().isEmpty()){
					if(!resource.getName().contains(keyWord)){
						resourceIterator.remove();
					}
				}
			}
			if(currentResource==null || currentResource.getChildren().isEmpty()){
				currentResource.setChildren(null);
			}
		}
	}

	public void recursionResource(AuthResource compareResource,List<AuthResource> resources){
		try {
			List<AuthResource> authResources = new ArrayList<AuthResource>();
			for (AuthResource currentResource : resources) {
				if(currentResource.getParentId()!=null && currentResource.getParentId().equals(compareResource.getId())){
					authResources.add(currentResource);
				}
			}
			compareResource.setChildren(authResources.isEmpty()?null:authResources);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	private Map<Integer, Integer> toPermissionMap(List<AuthPermission> permissions) {
		try {
			if(permissions==null){
				return null;
			}
			Map<Integer, Integer> map = new HashMap<Integer, Integer>();
			for (AuthPermission permission : permissions) {
				map.put(permission.getResourceId(), permission.getRoleId());
			}
			return map;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int checkMenuCodeByParam(AuthResource menu) {
		try {
			int count = authResourceMapper.checkMenuCodeByParam(menu);
			return count;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateMenuFunction(AuthResource menu, AuthUser userInfo) {
		try {
			AuthResource authResource = new AuthResource();
			authResource = authResourceMapper.selectByPrimaryKey(menu.getId());
			authResource.setName(menu.getName());
			authResource.setValid(menu.getValid());
			authResource.setRemarks(menu.getRemarks());
			authResource.setUpdateTime(new Date());
			authResource.setUpdateUser(userInfo.getId());
			authResourceMapper.updateMenu(authResource);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
}
