package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.OrderPayRecord;

public interface OrderPayRecordMapper {

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    List<OrderPayRecord> getPayRecListList(String orderNo);
    
}