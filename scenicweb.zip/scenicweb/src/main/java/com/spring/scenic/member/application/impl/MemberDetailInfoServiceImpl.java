package com.spring.scenic.member.application.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.MemberDocument;
import com.spring.scenic.member.infrastructure.MemberDetailInfoMapper;
import com.spring.scenic.member.infrastructure.MemberDocumentMapper;
import com.spring.scenic.system.domain.AuthUser;

/** @Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:13:53 2017年1月17日
 *  @version:1.0
 *
 */
@Service
public class MemberDetailInfoServiceImpl implements MemberDetailInfoService{
	
	@Resource
	private MemberDetailInfoMapper memberDetailInfoMapper;
	@Resource
	private MemberDocumentMapper memberDocumentMapper;
	
	@Override
	public List<MemberDetailInfo> queryCommonTripManList(MemberBasic member) {
		//查询会员常出行人
		List<MemberDetailInfo> memberDetailInfos;
		try {
			MemberDetailInfo detailInfo = new MemberDetailInfo();
			List<Integer> passengerIdList = new ArrayList<Integer>();
			detailInfo.setFkId(member.getId());
			detailInfo.setType(Short.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
			memberDetailInfos = memberDetailInfoMapper.queryCommonTripManList(detailInfo);
			//拿到常出行人的idlist
			for (MemberDetailInfo memberDetailInfo : memberDetailInfos) {
				passengerIdList.add(memberDetailInfo.getId());
			}
			//查询常出行人证件信息
			List<MemberDocument> documents = new ArrayList<MemberDocument>();
			if (passengerIdList.size()>0) {
				documents = memberDocumentMapper.queryMemberDocumentList(passengerIdList);
			}
			List<MemberDocument> dList = null;
			for (MemberDetailInfo meDetailInfo : memberDetailInfos) {
				dList = new ArrayList<MemberDocument>();
				for (MemberDocument memberDocument : documents) {
					if (memberDocument.getType() == 2 &&meDetailInfo.getId().equals(memberDocument.getFkId())) {
						dList.add(memberDocument);
					}
				}
				meDetailInfo.setDocuments(dList);
			}
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		return memberDetailInfos;
	}

	@Override
	public void addMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo,
			AuthUser userInfo) {
		try {
			memberDetailInfo.setCreateUser(userInfo.getId());
			//新增常旅客默认为非会员本身
			memberDetailInfo.setIsSelf(0);
			
			memberDetailInfo.setCreateTime(new Date());
			memberDetailInfo.setUpdateTime(new Date());
			memberDetailInfo.setUpdateUser(userInfo.getId());
			memberDetailInfo.setBirthday(DateUtil.stringToDate(memberDetailInfo.getBirthdayDate()));
			memberDetailInfo.setType(Short.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
			memberDetailInfoMapper.insert(memberDetailInfo);
			//得到证件信息
			List<MemberDocument> memberDocuments = memberDetailInfo.getDocuments();
			if(memberDocuments!=null && !memberDocuments.isEmpty()){
				List<MemberDocument> addDocuments = new ArrayList<MemberDocument>();
				MemberDocument adDocument = null;
				Iterator<MemberDocument> memberDocumentsIterator = memberDocuments.iterator();
				while (memberDocumentsIterator.hasNext()) {
					adDocument = memberDocumentsIterator.next();
					if(adDocument.getDocumentType()!=null){
						adDocument.setFkId(memberDetailInfo.getId());
						adDocument.setCreateTime(new Date());
						adDocument.setCreateUser(userInfo.getId());
						adDocument.setUpdateTime(new Date());
						adDocument.setUpdateUser(userInfo.getId());
						adDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
						adDocument.setDocumentexpiredate(DateUtil.stringToDate(adDocument.getCredentialsValidity()));
						adDocument.setValid(SysConstant.VALITY_YES);
						addDocuments.add(adDocument);
					}
				}
				if (addDocuments.size()>0) {
					memberDocumentMapper.addPassengerDocumentInfo(addDocuments);
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void updateMemberCommonPassengerInfo(MemberDetailInfo memberDetailInfo, AuthUser userInfo) {
		try {
			MemberDetailInfo tempVo = memberDetailInfoMapper.selectByPrimaryKey(memberDetailInfo.getId());
			tempVo.setNameCh(memberDetailInfo.getNameCh());
			tempVo.setNameChPin(memberDetailInfo.getNameChPin());
			tempVo.setNameEnS(memberDetailInfo.getNameEnS());
			tempVo.setNameEnF(memberDetailInfo.getNameEnF());
			tempVo.setSex(memberDetailInfo.getSex());
			tempVo.setNationality(memberDetailInfo.getNationality());
			tempVo.setPhoneCh(memberDetailInfo.getPhoneCh());
			tempVo.setFixTel(memberDetailInfo.getFixTel());
			tempVo.setFixTelArea(memberDetailInfo.getFixTelArea());
			tempVo.setFixTelExtension(memberDetailInfo.getFixTelExtension());
			tempVo.setCreateUser(userInfo.getId());
			tempVo.setCreateTime(new Date());
			tempVo.setBirthday(DateUtil.stringToDate(memberDetailInfo.getBirthdayDate()));
			tempVo.setType(Short.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
//			//得到证件信息
//			List<MemberDocument> memberDocuments = memberDetailInfo.getDocuments();
//			List<MemberDocument> addDocuments = new ArrayList<MemberDocument>();
//			List<MemberDocument> updateDocuments = new ArrayList<MemberDocument>();
//			List<MemberDocument> deleteDocuments = new ArrayList<MemberDocument>();
//			MemberDocument addDocument = null;
//			MemberDocument updateDocument = null;
//			
//			//通过常旅客id查询出对应的证件list信息
//			List<MemberDocument> oldDocuments = memberDocumentMapper.queryDocumentByCommonPassengerId(memberDetailInfo);
//			
//			if (memberDocuments!=null) {
//				for (MemberDocument document : memberDocuments) {
//					if (document.getDocumentType()!=null) {
//						if (document.getPrimaryId()==null || "".equals(document.getPrimaryId())) {
//							addDocument = new MemberDocument();
//							addDocument.setFkId(memberDetailInfo.getId());
//							addDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
//							addDocument.setCreateTime(new Date());
//							addDocument.setCreateUser(userInfo.getId());
//							addDocument.setDocumentNo(document.getDocumentNo());
//							addDocument.setDocumentType(document.getDocumentType());
//							addDocument.setDocumentexpiredate(DateUtil.stringToDate(document.getCredentialsValidity()));
//							addDocument.setValid(SysConstant.VALITY_YES);
//							addDocuments.add(addDocument);
//						}else {
//							updateDocument = new MemberDocument();
//							updateDocument.setId(Integer.valueOf(document.getPrimaryId()));
//							updateDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
//							updateDocument.setCreateTime(new Date());
//							updateDocument.setCreateUser(userInfo.getId());
//							updateDocument.setDocumentNo(document.getDocumentNo());
//							updateDocument.setDocumentType(document.getDocumentType());
//							updateDocument.setDocumentexpiredate(DateUtil.stringToDate(document.getCredentialsValidity()));
//							updateDocument.setValid(SysConstant.VALITY_YES);
//							updateDocuments.add(updateDocument);
//						}
//						
//					}
//				}
//			}else {
//				deleteDocuments.addAll(oldDocuments);
//			}
//			oldDocuments.removeAll(updateDocuments);
//			deleteDocuments.addAll(oldDocuments);
//			
//			if (addDocuments.size()>0) {
//				memberDocumentMapper.addPassengerDocumentInfo(addDocuments);
//			}
//			if (updateDocuments.size()>0) {
//				for (MemberDocument memberDocument : updateDocuments) {
//					memberDocumentMapper.updateByPrimaryKeySelective(memberDocument);
//				}
//			}
//			if (deleteDocuments.size()>0) {
//				for (MemberDocument memberDocument : deleteDocuments) {
//					memberDocumentMapper.deleteByPrimaryKey(memberDocument.getId());
//				}
//			}
			memberDetailInfoMapper.updateByPrimaryKey(tempVo);
			//得到证件信息
			List<MemberDocument> memberDocuments = memberDetailInfo.getDocuments();
			if(memberDocuments!=null && !memberDocuments.isEmpty()){
				List<MemberDocument> addDocuments = new ArrayList<MemberDocument>();
				MemberDocument adDocument = null;
				Iterator<MemberDocument> memberDocumentsIterator = memberDocuments.iterator();
				while (memberDocumentsIterator.hasNext()) {
					adDocument = memberDocumentsIterator.next();
					if(adDocument.getDocumentType()!=null){
						adDocument.setFkId(memberDetailInfo.getId());
						adDocument.setCreateTime(new Date());
						adDocument.setCreateUser(userInfo.getId());
						adDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
						adDocument.setDocumentexpiredate(DateUtil.stringToDate(adDocument.getCredentialsValidity()));
						adDocument.setValid(SysConstant.VALITY_YES);
						addDocuments.add(adDocument);
					}
				}
				memberDocumentMapper.deleteDocumentByMemberDetail(memberDetailInfo);
				if (addDocuments.size()>0) {
					memberDocumentMapper.addPassengerDocumentInfo(addDocuments);
				}
			}
			
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public MemberDetailInfo updateMemberCommonTripMan(
			MemberDetailInfo memberDetailInfo) {
		MemberDetailInfo resultDocument;
		try {
			memberDetailInfo.setType(Short.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
			List<MemberDocument> memberDocuments = memberDocumentMapper.queryDocumentByCommonPassengerId(memberDetailInfo);
			resultDocument = memberDetailInfoMapper.selectByPrimaryKey(memberDetailInfo.getId());
			for (MemberDocument memberDocument : memberDocuments) {
				memberDocument.setCredentialsValidity(DateUtil.dateToString(memberDocument.getDocumentexpiredate()));
			}
			resultDocument.setDocuments(memberDocuments);
			resultDocument.setBirthdayDate(DateUtil.dateToString(resultDocument.getBirthday()));
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		return resultDocument;
	}

	@Override
	public void deleteInfo(MemberDetailInfo memberDetailInfo) {
		//删除常出行人
		try {
			memberDetailInfoMapper.deleteByPrimaryKey(memberDetailInfo.getId());
			//删除常用人证件信息
			MemberDocument memberDocument = new MemberDocument();
			memberDocument.setFkId(memberDetailInfo.getId());
			memberDocument.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_COMMON_TRIPMAN.getCode()));
			memberDocumentMapper.deleteByPassageId(memberDocument);
		} catch (NumberFormatException e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}


	
}
