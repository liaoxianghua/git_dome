package com.spring.scenic.basic.application;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.basic.domain.CommercialApprove;
import com.spring.scenic.basic.domain.ScenicCommercial;
import com.spring.scenic.basic.domain.ScenicCommercialApprove;
import com.spring.scenic.material.domain.Pictures;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Dictionary;

public interface ScenicCommercialService {

	/**
	 * @param userCriteria
	 * @return
	 */
	public List<ScenicCommercial> queryScenicCommercial(ScenicCommercial scenicCommercial,boolean pageAble);

	/**添加用户
	 * @param user
	 * @return
	 */
	public int addScenicCommercial(ScenicCommercial scenicCommercial,AuthUser user);

	/**修改用户
	 * @param user
	 * @return
	 */
	public int updateByPrimaryKey(ScenicCommercial scenicCommercial,AuthUser user,
			Map<String, List<MultipartFile>> filesMap,String coversImageFile);

	/**根据主键查询
	 * @param id
	 * @return
	 */
	public ScenicCommercial selectByPrimaryKey(Integer id);
	/**
	 * 添加商户认证信息
	 * @param commercialApprove
	 * @return
	 */
	public int addCommercialApprove(CommercialApprove commercialApprove,AuthUser user); 
	/**
	 * 禁用
	 * @param scenicCommercial
	 */
	public void updateValid(ScenicCommercial scenicCommercial,AuthUser user);

	/**
	 * 更新景区商户详细信息
	 * @param scenicCommercial
	 * @param userInfo
	 */
	public void updateCommercialInfo(ScenicCommercial scenicCommercial,
			AuthUser userInfo);

	/**
	 * 加载下拉框数据
	 * @param scenicCommercial
	 * @return
	 */
	public List<Dictionary> initScenicSelectOption(
			Integer id);

	/**
	 * 通过类型获取id
	 * @param scenicCommercial
	 * @return
	 */
	public Integer getIdByScenicType(ScenicCommercial scenicCommercial);

	/**
	 * 加载景区上级商户下拉数据
	 * @param scenicCommercial
	 * @return
	 */
	public List<ScenicCommercial> initScenicParentOptions(
			ScenicCommercial scenicCommercial);

	/**
	 * 加载城市下拉数据
	 * @param scenicCommercial
	 * @return
	 */
	public List<ScenicCommercial> initScenicCityOptions(
			ScenicCommercial scenicCommercial);

	/**
	 * 加载城市区域下拉数据
	 * @param scenicCommercial
	 * @return
	 */
	public List<ScenicCommercial> initScenicCityAreaOptions(
			ScenicCommercial scenicCommercial);
	/**
	 * 通过景区商户id得到景区商户认证信息
	 * @param scenicSellerId
	 * @return
	 */
	public ScenicCommercialApprove getCommercialAttestById(
			Integer scenicSellerId);

	/**
	 * 添加商户认证信息
	 * @param commercialApprove
	 */
	public void addScenicCommercialAttest(
			ScenicCommercialApprove commercialApprove,AuthUser user);

	/**
	 * 更新景区商户认证信息
	 * @param commercialApprove
	 * @param userInfo
	 */
	public void updateScenicCommercialAttest(
			ScenicCommercialApprove commercialApprove, AuthUser userInfo);

	/**
	 * 删除数据
	 * @param parseInt
	 */
	public void deleteByPrimaryKey(Integer parseInt);

	/**
	 * 启用禁用商户及其子商户
	 *@Description:
	 *@Auth: lichangmao
	 *@2017年1月11日
	 */
	public void updateForbiddenItemScenic(ScenicCommercial scenicCommercial,AuthUser userInfo);

	/**
	 * @Description 景区商户详情-上部修改
	 * @param user
	 * @param scenicCommercial
	 * @param scenicImageFile
	 * @param filesMap
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月8日
	 */
	public int updatScenicCommercial(AuthUser user,ScenicCommercial scenicCommercial,String scenicImageFile, Map<String, List<MultipartFile>> filesMap);

	/**
	 * @Description 景区商户详情-下部信息修改
	 * @param user
	 * @param scenicCommercial
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月8日
	 */
	public int updatScenicCommercialBasic(AuthUser user,ScenicCommercial scenicCommercial);

	/**
	 * @Description 景区商户单个查询
	 * @param scenicCommercial
	 * @return ScenicCommercial
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	public ScenicCommercial getScenicCommercial(ScenicCommercial scenicCommercial);

	/**
	 * @Description 景区商户图片查询
	 * @param pictures
	 * @param pageTrue
	 * @return List<Pictures>
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	public List<Pictures> getScenicCommercialPhotoList(Pictures pictures,boolean pageTrue);

	/**
	 * @Description 设置为log
	 * @param user
	 * @param picture
	 * @return Pictures
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	public Pictures savePictureLogo(AuthUser user, Pictures picture);

	/**
	 * @Description 删除图片关联关系
	 * @param picture
	 * @return
	 * @return int
	 * @author 006568（shuchang）
	 * @date 2017年1月9日
	 */
	public int deletePicture(Pictures picture);

	/**
	 * @Description 保存景区商户、图片关系
	 * @param scenicCommercial
	 * @param materialIds
	 * @return int
	 * @author 006568（shuchang）
	 * @param user 
	 * @date 2017年1月10日
	 */
	public int saveScenicCommercialPictures(AuthUser user, ScenicCommercial scenicCommercial,Integer[] materialIds);


	
}
