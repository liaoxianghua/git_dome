/**
 * 
 */
package com.spring.scenic.basic.intreface.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.basic.application.ProvinceService;
import com.spring.scenic.basic.domain.Province;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.AuthUser;

/**
 *  @Description:省份信息查询
 *  @author：ranmaoping
 *  @date:上午11:18:49 2016年12月22日
 *  @version:1.0
 *
 */
@Controller
@RequestMapping("basic/province")
public class ProvinceController {
	
	
	@Autowired
	private ProvinceService provinceService;
	
	/**
	 * 加载省份管理页面
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="provincePage",method=RequestMethod.GET)
	public String provinceManage(HttpServletRequest request,HttpServletResponse response){
		return "basic/province/provinceList";
	}
	
	/**
	 * @Description: 进入省份信息分页界面
	 * @param request
	 * @param response
	 * @param province
	 * @return EntityData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="provinceInfoList",method=RequestMethod.POST)
	public EntityData provinceInfoList(HttpServletRequest request,HttpServletResponse response,Province province){
		province.initDataTableParam(request);
		List<Province> list = provinceService.getProvinceList(province,SysConstant.PAGE_TRUE);
		PageInfo<Province> page = new PageInfo<Province>(list);
		EntityData data = new EntityData(province,page);
		return data;
	}
	
	/**
	 * @Description: 进入省份新增界面
	 * @param request
	 * @param response
	 * @param province
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="provinceAdd",method=RequestMethod.GET)
	public String provinceAdd(HttpServletRequest request,HttpServletResponse response,Province province){
		request.setAttribute("operate", "new");
		return "basic/province/provinceEdit";
	}
	
	/**
	 * @Description: 进入省份名称修改界面、初始化省份名称信息
	 * @param request
	 * @param response
	 * @param province
	 * @return String
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@RequestMapping(value="provinceUpdate",method=RequestMethod.GET)
	public String provinceUpdate(HttpServletRequest request,HttpServletResponse response,Province province){
		if(province.getId()!=null){
			Province dto = provinceService.getProvinceInfoById(province);
			request.setAttribute("provinceInfo", dto);
			request.setAttribute("operate", "edit");
		}
		return "basic/province/provinceEdit";
	}
	/**
	 * @Description: 保存省份名称基本信息
	 * @param request
	 * @param response
	 * @param province
	 * @return MessageData
	 * @author ranmaoping
	 * @date 上午11:18:49 2016年12月22日
	 */
	@ResponseBody
	@RequestMapping(value="saveProvince",method=RequestMethod.POST)
	public MessageData updateAvSchool(HttpServletRequest request,HttpServletResponse response,Province province){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		province.setCreateDate(new Date());
		province.setCreateUser(userInfo.getId());
		this.provinceService.saveProvince(province);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	/**
	 * 启动禁用省份
	 * @param id
	 * @return
	 */
	@RequestMapping(value ="updateProvinceStatus",method=RequestMethod.POST)
	@ResponseBody
	public MessageData updateProvinceStatus(HttpServletRequest request,@RequestParam(value="id") Integer id, @RequestParam(value="status") Integer status){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute("user");
		if(userInfo==null){
		    return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
		}
		Province province = new Province();
		province.setId(id);
		province.setStatus(status);
		province.setUpdateDate(new Date());
		province.setUpdateuser(userInfo.getId());
		provinceService.updateProvinceStatus(province);
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
		
	}
	/**
	 * 查询国家信息,填充下拉框
	 * @return
	 */
	@RequestMapping(value= "countryList",method=RequestMethod.POST)
	@ResponseBody
	public List<Province> getCountryList() {
		List<Province> list  = provinceService.getCountryList();
		return list;
	}
	/**
	 * 查询选中国家的省份信息,填充下拉框
	 * @return
	 */
	@RequestMapping(value= "allProvinceList",method=RequestMethod.POST)
	@ResponseBody
	public List<Province> getAllProvinceList() {
		List<Province> list  = provinceService.getAllProvinceList();
		return list;
	}
	/**
	 * 查询所有省份信息,填充下拉框
	 * @return
	 */
	@RequestMapping(value= "provinceList",method=RequestMethod.POST)
	@ResponseBody
	public List<Province> getProvinceList(@RequestParam(value="id") Integer id) {
		List<Province> list  = provinceService.getProvinceList(id);
		return list;
	}
	/**
	 * 查询所有城市信息,填充下拉框
	 * @return
	 */
	@RequestMapping(value= "cityList",method=RequestMethod.POST)
	@ResponseBody
	public List<Province> getCityList() {
		List<Province> list  = provinceService.getCityList();
		return list;
	}
	/**
	 * 查询选中国家、省份下的城市信息，填充下拉框
	 */
	@RequestMapping(value= "cityInProvinceAndCountryList",method=RequestMethod.POST)
	@ResponseBody
	public List<Province> getCityListByIdParam(Province province) {
		List<Province> list  = provinceService.getCityListByIdParam(province);
		return list;
	}
}
