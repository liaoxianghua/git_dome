package com.spring.scenic.member.infrastructure;

import java.util.List;

import com.spring.scenic.member.domain.Order;

public interface OrderMapper {
    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月29日     
     * @memo ：   
     **
     */
    List<Order> getMemberOrders(Order order);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：rmp  
     * @date ：2017年3月31日     
     * @memo ：   
     **
     */
    Order getMemberOrderDetail(Order order);
}