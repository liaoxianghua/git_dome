package com.spring.scenic.system.intreface.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.EntityData;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.system.application.DepartmentService;
import com.spring.scenic.system.domain.AuthUser;
import com.spring.scenic.system.domain.Department;
import com.spring.scenic.system.domain.ZtreeDept;
import com.spring.scenic.system.infrastructure.DepartmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * 部门管理
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "system/department")
public class DepartmentController {
	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private DepartmentMapper departmentMapper;
	
	/**
	 * 
	  * @Description: 部门管理页面跳转
	  * @param @return
	  * @return String
	  * @author 李cm
	  * @date 2016-12-14 上午11:53:04
	 */
	@RequestMapping(value = "departmentManagement")
	public String menuManagement() {
		return "/system/department/departmentManagementMain";
	}
	
	@RequestMapping(value = "deptManagementEdit")
	public String deptManagementEdit(HttpServletRequest request, HttpServletResponse response,Department department) {
		if (department.getId()!= null && !"".equals(department.getId())) {
			Department departmentVo = departmentService.selectDeptByPrimaryKey(department.getId());
			request.setAttribute("departmentVo", departmentVo);
		}
		return "/system/department/departmentManagementEdit";
	}
	
	/**
	 * 禁用数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "forbiddenOrUseData" ,method=RequestMethod.POST)
	@ResponseBody
	public MessageData forbiddenOrUseData(HttpServletRequest request, HttpServletResponse response,Department department){
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (SysEnum.COMMON_USEABLE_NO.getCode().equals(department.getFlag())) {
			department.setValid(Integer.valueOf(SysConstant.VALITY_NO));
		}else {
			department.setValid(Integer.valueOf(SysConstant.VALITY_YES));
		}
		if (department.getParentStrId()==null || StringUtil.isEmpty(department.getParentStrId())) {//禁用父部门及其子部门
			departmentService.updateForbiddenItemDept(department,userInfo);
		}else {
			departmentService.updateForbiddenOrUseData(department,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}


	/**
	 * 部门管理详情页面
	 * @param request
	 * @param response
	 * @param department
	 * @return
	 * lichangmao
	 */
	@ResponseBody
	@RequestMapping(value = "queryDepartmentList" ,method=RequestMethod.POST)
	public EntityData queryDepartmentList(HttpServletRequest request,Department department) {
		department.initDataTableParam(request);
		List<Department> list = departmentService.queryDepartment(department, SysConstant.PAGE_FALSE);
		PageInfo<Department> page = new PageInfo<Department>(list);
		EntityData data = new EntityData(department,page);
		return data;
	}
	/**
	 * 新增修改数据
	 * @param request
	 * @param response
	 * @param department
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "insertDepartment" ,method=RequestMethod.POST)
	public  MessageData insertDepartment(HttpServletRequest request, HttpServletResponse response,Department department) throws Exception{
		AuthUser userInfo =(AuthUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (department.getId()==null || "".equals(department.getId())) {
			departmentService.addDepartment(department,userInfo);
		}else {
			departmentService.updateDepartment(department,userInfo);
		}
		return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
	}

	@ResponseBody
	@RequestMapping(value = "initParentDeptOptions")
	public List<Department> initParentDeptOptions(HttpServletRequest request, HttpServletResponse response,Department department) throws Exception {
		List<Department> resultList = departmentService.initParentDeptOptions(department);
		return resultList;
	}
	
	@ResponseBody
	@RequestMapping(value = "getDeptNameById")
	public MessageData getDeptNameById(HttpServletRequest request, Department department) throws Exception {
		if(department.getId()!=null){
			String deptName = departmentService.getDeptNameById(department);
			return new MessageData(SysConstant.OPERATE_SUCCESS, deptName);
		}else{
			return new MessageData(SysConstant.OPERATE_SUCCESS, "无");
		}
	}

	/**
	 * Ztree初始化部门信息方法
	 * @param request
	 * @param response
	 * @param
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "initParentDeptOptionsNew")
	public List<ZtreeDept> initParentDeptOptionsNew(HttpServletRequest request, HttpServletResponse response,Department department) throws Exception {
		List<ZtreeDept> resultList = departmentService.initParentDeptOptionsNew(department);
		return resultList;
	}
	
}
