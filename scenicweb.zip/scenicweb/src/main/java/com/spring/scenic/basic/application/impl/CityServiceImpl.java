package com.spring.scenic.basic.application.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.basic.application.CityService;
import com.spring.scenic.basic.domain.City;
import com.spring.scenic.basic.domain.CityArea;
import com.spring.scenic.basic.domain.CityBusinessArea;
import com.spring.scenic.basic.infrastructure.CityMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

@Service("cityService")
public class CityServiceImpl implements CityService {
	
	@Autowired
	private CityMapper cityMapper;
	/**查询城市信息,在后台组装数据，
	 * 当被引用的国家省份无用时，背景置灰
	 * @param city
	 * @return
	 */
	@Override
	public List<City> getCityList(City city) {
		try {
			PageHelper.startPage(city.getPageNum(), SysConstant.PAGE_PAGESIZE);
			/*if(city.getOrderByClause().equals("ID ASC")){
				city.setOrderByClause("id desc");
			}*/
			List<City> cityList = cityMapper.getCityInfoList(city);
			return cityList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	/**
	 * 查询城市对应的区域信息
	 */
	
	public List<CityArea> getCityAreaList1(CityArea cityArea,boolean pageFalse) {
		try {
			if(pageFalse) {
				PageHelper.startPage(cityArea.getPageNum(), SysConstant.PAGE_PAGESIZE);
				if(cityArea.getOrderByClause().equals("ID ASC")){
					cityArea.setOrderByClause("id desc");
				}
			}
			List<CityArea> cityAreaList = cityMapper.getCityAreaInfoList(cityArea);
			//组装行政商业区域信息，用于页面展示,一个或多个商业区从属于一个行政区
			List<CityArea> cityAreaInfoList = new ArrayList<CityArea>();
			if(null!=cityAreaList&&cityAreaList.size()>0) {
				for (CityArea cityAreaDto : cityAreaList) {
					if(null!=cityAreaDto.getInnerReleatedId()) continue;
					CityArea dto = new CityArea();
					dto.setId(cityAreaDto.getId());
					dto.setCityId(cityAreaDto.getCityId());
					Integer typeId = cityAreaDto.getTypeId();
					if(typeId==Integer.valueOf(SysEnum.AREA_TYPE_CANTON.getCode())) {
						dto.setName(cityAreaDto.getName()+"-"+SysEnum.AREA_TYPE_CANTON.getDescription());
					}else{
						dto.setName(cityAreaDto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
					}
					dto.setValid(cityAreaDto.getValid());
					dto.setUpdateTime(cityAreaDto.getUpdateTime());
					dto.setUpdateName(cityAreaDto.getUpdateName()+"("+cityAreaDto.getUserId()+")");
					//组装行政区域下的商业区信息
					List<CityBusinessArea> children = new ArrayList<CityBusinessArea>();
					List<CityBusinessArea> cityBusinessAreaList = cityAreaDto.getChildren();
					if(null!=cityBusinessAreaList&&cityBusinessAreaList.size()>0) {
						for (CityBusinessArea cityBusinessArea : cityBusinessAreaList) {
							CityBusinessArea cbaDto = new CityBusinessArea();
							cbaDto.setId(cityBusinessArea.getId());
							cbaDto.setCityId(cityAreaDto.getCityId());
							cbaDto.setName(cityBusinessArea.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
							cbaDto.setValid(cityBusinessArea.getValid());
							cbaDto.setUpdateTime(cityBusinessArea.getUpdateTime());
							cbaDto.setUpdateName(cityBusinessArea.getUpdateName()+"("+cityBusinessArea.getUserId()+")");
							children.add(cbaDto);
						}
					}
					dto.setChildren(children);
					cityAreaInfoList.add(dto);
				}
			}
			return cityAreaInfoList;
			//return cityAreaList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	
	//Datagrid树状页面方法重写
	public List<CityArea> getCityAreaList2(CityArea cityArea,boolean pageFalse) {
		try {
			if(pageFalse) {
				PageHelper.startPage(cityArea.getPageNum(), SysConstant.PAGE_PAGESIZE);
				if(cityArea.getOrderByClause().equals("ID ASC")){
					cityArea.setOrderByClause("id desc");
				}
			}
			List<CityArea> cityAreaList = cityMapper.getCityAreaInfoList(cityArea);
			List<CityArea> newCityAreaList = new ArrayList<CityArea>();
			//对区域集进行遍历，组装数据结构
			if(null!=cityAreaList&&cityAreaList.size()>0) {
				for (CityArea dto : cityAreaList) {
					Integer id = dto.getId();
					Integer innerId = dto.getInnerReleatedId();
					Integer typeId = dto.getTypeId();
					if(null!=innerId&&null!=cityArea.getTypeId()&&2==cityArea.getTypeId()) {
						dto.setName(dto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
						dto.setUpdateName(dto.getUpdateName()+"("+dto.getUserId()+")");
						newCityAreaList.add(dto);
					}
					if(null==innerId&&2==typeId) {
						dto.setName(dto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
						dto.setUpdateName(dto.getUpdateName()+"("+dto.getUserId()+")");
						newCityAreaList.add(dto);
						continue;
					}
					if(null==innerId&&1==typeId) {
						List<CityBusinessArea> children = new ArrayList<CityBusinessArea>();
						for (CityArea compareDto : cityAreaList) {
							Integer compareId = compareDto.getId();
							Integer compareInnerId = compareDto.getInnerReleatedId();
							if(id!=compareId) {
								if(id==compareInnerId) {
									CityBusinessArea cbaDto = new CityBusinessArea();
									cbaDto.setId(compareDto.getId());
									cbaDto.setCityId(compareDto.getCityId());
									cbaDto.setName(compareDto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
									cbaDto.setValid(compareDto.getValid());
									cbaDto.setUpdateTime(compareDto.getUpdateTime());
									cbaDto.setUpdateName(compareDto.getUpdateName()+"("+compareDto.getUserId()+")");
									children.add(cbaDto);
								}
							}
						}
						dto.setName(dto.getName()+"-"+SysEnum.AREA_TYPE_CANTON.getCode());
						dto.setUpdateName(dto.getUpdateName()+"("+dto.getUserId()+")");
						dto.setChildren(children);
						newCityAreaList.add(dto);
					}
				}
			}
			return newCityAreaList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	
	/**
	 * 查询区域信息-树形结构图
	 */
	public List<CityArea> getCityAreaList(CityArea cityArea,boolean pageFalse) {
		try {
			if(pageFalse){
				PageHelper.startPage(cityArea.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			//查询所有的商业区
			List<CityArea> cityAreaList = cityMapper.getCityAreaInfoList(cityArea);
			List<CityArea> resultList = new ArrayList<CityArea>();
			//有上级行政区的商业区的集合
			List<CityBusinessArea> businessAreas = new ArrayList<CityBusinessArea>();
			Set<String> parentIdSet = new HashSet<String>();
			if(null!=cityAreaList&&cityAreaList.size()>0) {
				for (CityArea areaDto : cityAreaList) {
					//遍历出有上级行政区的商业区
					if(null!=areaDto.getInnerReleatedId()) {
						CityBusinessArea cbaDto = new CityBusinessArea();
						cbaDto.setId(areaDto.getId());
						cbaDto.setCityId(areaDto.getCityId());
						cbaDto.setName(areaDto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
						cbaDto.setValid(areaDto.getValid());
						cbaDto.setUpdateTime(areaDto.getUpdateTime());
						cbaDto.setUpdateName(areaDto.getUpdateName()+"("+areaDto.getUserId()+")");
						cbaDto.setInnerReleatedId(areaDto.getInnerReleatedId());
						businessAreas.add(cbaDto);
						parentIdSet.add(String.valueOf(areaDto.getInnerReleatedId()));
					}
					//遍历出行政区或者没有上级行政区的商业区
					if(null==areaDto.getInnerReleatedId()) {
						CityArea dto = new CityArea();
						dto.setId(areaDto.getId());
						dto.setCityId(areaDto.getCityId());
						Integer typeId = areaDto.getTypeId();
						if(typeId==Integer.valueOf(SysEnum.AREA_TYPE_CANTON.getCode())) {
							dto.setName(areaDto.getName()+"-"+SysEnum.AREA_TYPE_CANTON.getDescription());
						}else{
							dto.setName(areaDto.getName()+"-"+SysEnum.AREA_TYPE_BUSINESS.getDescription());
						}
						dto.setValid(areaDto.getValid());
						dto.setUpdateTime(areaDto.getUpdateTime());
						dto.setUpdateName(areaDto.getUpdateName()+"("+areaDto.getUserId()+")");
						resultList.add(dto);
					}
				}
			}
			List<CityArea> parentList = new ArrayList<CityArea>();
			List<CityArea> parenAreatList = new ArrayList<CityArea>();
			List<String> parentIdList = new ArrayList<String>(parentIdSet); 
			//根据子项id（innerReleatedId）集合批量查询得到所有父级行政区
			if (null!=parentIdList && parentIdList.size()>0) {
				parentList.addAll(cityMapper.selectByParentIdList(parentIdList));
				if(null!=parentList && parentList.size()>0) {
					for (CityArea cityArea1 : parentList) {
						CityArea area = new CityArea();
						area.setId(cityArea1.getId());
						area.setCityId(cityArea1.getCityId());
						area.setName(cityArea1.getName()+"-"+SysEnum.AREA_TYPE_CANTON.getDescription());
						area.setValid(cityArea1.getValid());
						area.setUpdateTime(cityArea1.getUpdateTime());
						area.setUpdateName(cityArea1.getUpdateName()+"("+cityArea1.getUserId()+")");
						parenAreatList.add(area);
					}
				}
			}
			resultList.addAll(parenAreatList);
			//去掉重复数据
			Set<CityArea> set=new HashSet<CityArea>();
			set.addAll(resultList);
			resultList.clear();
			resultList.addAll(set);
			
			List<CityBusinessArea> childrenList = null;
			for (CityArea dto : resultList) {
				childrenList = new ArrayList<CityBusinessArea>();
				for (CityBusinessArea cityBusinessArea : businessAreas) {
					if (dto!=null && dto.getId()!=null && dto.getId().equals(cityBusinessArea.getInnerReleatedId())) {
						childrenList.add(cityBusinessArea);
					}
				}
				if (dto!=null) {
					dto.setChildren(childrenList.isEmpty()?null:childrenList);
				}else {
					continue;
				}
			}
			return resultList;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**通过id查询城市信息
	 * @param city
	 * @return
	 */
	@Override
	public City getCityInfoById(City city) {
		try {
			City dto = (City) cityMapper.getCityInfoById(city);
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	/**
	 * 通过id查询城市区域信息
	 * @param cityArea
	 * @return
	 */
	@Override
	public CityArea getCityAreaInfoById(CityArea cityArea) {
		try {
			CityArea dto = (CityArea) cityMapper.getCityAreaInfoById(cityArea);
			return dto;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		
	}
	/**
	 * 查询当前城市的行政区集合
	 */
	public List<CityArea> getCantonList(CityArea cityArea) {
		try {
			//Integer valid = Integer.valueOf(SysEnum.COMMON_VALID_YES.getCode());
			if(null!=cityArea&&cityArea.getTypeId()==Integer.valueOf(SysEnum.AREA_TYPE_CANTON.getCode())) {
				//对行政区进行编辑，查询的行政区list中排除自身
				//cityArea.setValid(valid);
				List<CityArea> list  = cityMapper.getOtherCantonList(cityArea);
				return list;
			}else{
				//对商业区进行编辑，查询当前城市的所有的行政区list
				//cityArea.setValid(valid);
				cityArea.setTypeId(Integer.valueOf(SysEnum.AREA_TYPE_CANTON.getCode()));
				List<CityArea> list  = cityMapper.getCantonList(cityArea);
				return list;
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	
	/**对城市进行新增修改操作
	 * @param city
	 */
	@Override
	public void saveCity(City cityDto) {
		City city = validate(cityDto);
		try {
			Integer valid =  Integer.parseInt(city.getValid());
			city.setStatus(valid);
			if(null==(city.getId())||"".equals(city.getId())){
				this.cityMapper.addCityInfo(city); // 新增
			} else {
				this.cityMapper.updateCityInfo(city); // 修改
			}
		} catch (Exception e) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}
	/**
	 * 对城市区域进行新增修改操作
	 */
	@Override
	public void saveCityArea(CityArea cityArea) {
		validate(cityArea);
		/*try {*/
			if (null == (cityArea.getId()) || "".equals(cityArea.getId())) {
				this.cityMapper.addCityAreaInfo(cityArea); //新增
			} else {
				Integer typeId = cityArea.getTypeId();
				CityArea dto =(CityArea)cityMapper.getCityAreaInfoById(cityArea);
				if(typeId==dto.getTypeId()) {
					this.cityMapper.updateCityAreaInfo(cityArea); //修改
				}else if(typeId==Integer.valueOf(SysEnum.AREA_TYPE_BUSINESS.getCode())) {
					//行政区域类型变为商业区
					if(null!=cityArea.getInnerReleatedId()) {
						//行政区域类型变为商业区(有父级行政区)，查询该行政区下的商业区集合，比较名称，相同则不能更新
						String name = cityArea.getName();
						List<CityArea> businessAreaHaveCommonParentList = cityMapper.getBusinessAreaHaveCommonParentList(cityArea);
						if(null!=businessAreaHaveCommonParentList&&businessAreaHaveCommonParentList.size()>0) {
							for (CityArea  businessAreaParent: businessAreaHaveCommonParentList) {
								if(name.equals(businessAreaParent.getName())) {
									throw new BussinessException(new BussinessExceptionBean("exception.cityAreaNameIsExisted"));
								}
							}
						}
					}
					this.cityMapper.updateCityAreaInfo(cityArea); //修改
					//查询行政区下面的商业区集合
					List<CityArea> list = cityMapper.getBusinessAreaListByInnerReleatedId(cityArea);
					//新建一个list用于装商业区集合重新组装的数据
					List<CityArea> businessList = new ArrayList<CityArea>();
					if(null!=list&&list.size()>0) {
						for (CityArea cityArea2 : list) {
							CityArea cityAreaDto = new CityArea();
							cityAreaDto.setId(cityArea2.getId());
							cityAreaDto.setName(cityArea2.getName());
							cityAreaDto.setInnerReleatedId(null);
							cityAreaDto.setUpdateTime(cityArea.getCreateTime());
							cityAreaDto.setUpdateUser(cityArea.getCreateUser());
							businessList.add(cityAreaDto);
						}
						if(null!=businessList&&businessList.size()>0) {
							//查询当前城市区域类型为商业区（不属于任何行政区）的集合
							cityArea.setInnerReleatedId(null);
							List<CityArea> businessNoParentlist = cityMapper.getBusinessNoParentlistByCityId(cityArea);
							//当前修改的行政区下面附属商业区与当前城市下没有父级行政区的商业区名称对比较，如果相同，提示区域名已存在，修改失败
							if(null!=businessNoParentlist&&businessNoParentlist.size()>0) {
								for (CityArea businessArea : businessList) {
									for (CityArea businessNoParentArea : businessNoParentlist) {
										if(null!=businessArea.getName()&&null!=businessNoParentArea.getName()) {
											if(businessArea.getName().equals(businessNoParentArea.getName())) {
												throw new BussinessException(new BussinessExceptionBean("exception.cityAreaNameIsExisted"));
											}
										}
										
									}
								}
							}
							cityMapper.updateBusinessList(businessList);
						}
					}
				}else if(typeId==Integer.valueOf(SysEnum.AREA_TYPE_CANTON.getCode())) {
					//商业区变为行政区
					cityArea.setInnerReleatedId(null);
					cityMapper.updateCityAreaInfo(cityArea);
				}
				//this.cityMapper.updateCityAreaInfo(cityArea); //修改
			}
		/*} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}*/
	}
	
	/**校验区域名是否重复
	 * @param cityArea
	 */
	private void validate(CityArea cityArea) {
		if(null!=cityArea.getId()) {
			CityArea dto = cityMapper.getCantonInfoById(cityArea);
			if(null==cityArea.getInnerReleatedId()&&dto.getTypeId()==Integer.valueOf(SysEnum.AREA_TYPE_BUSINESS.getCode())&&
					dto.getCantonValid()==Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode())) {
				throw new BussinessException(new BussinessExceptionBean("exception.cityAreaIsInvalid"));
			}
		}
		int count = cityMapper.getCityAreaCount(cityArea);
		if(count>0) {
			throw new BussinessException(new BussinessExceptionBean("exception.cityAreaNameIsExisted"));
		}
	
	}
	/**校验城市名是否重复
	 * @param province
	 */
	private City validate(City city) {
		if(null!=city.getId()) {
			City dto = cityMapper.getCountryProvinceInfoById(city);
			if(null==city.getCountryId()&&
					dto.getCountryValid()==Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode())) {
				throw new BussinessException(new BussinessExceptionBean("exception.countryIsInvalid"));
			}
			if(null==city.getProvinceId()&&
					dto.getProvinceValid()==Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode())) {
				throw new BussinessException(new BussinessExceptionBean("exception.provinceIsInvalid"));
			}
		}
		
		int count = cityMapper.getCityCount(city);
		if(count>0) {
			throw new BussinessException(new BussinessExceptionBean("exception.cityNameIsExisted"));
		}
		Integer provinceId = city.getProvinceId();
		if(provinceId==-1) {
			city.setProvinceId(null);
		}
		return city;
	}
	/**
	 * 启用禁用城市
	 */
	@Override
	public void updateCityStatus(City city) {
		try {
			cityMapper.updateCityStatus(city);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * 启用禁用城市下
	 */
	@Override
	public void updateCityAreaStatus(CityArea cityArea) {
		try {
			cityMapper.updateCityAreaStatus(cityArea);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * 根据国家或者省份查询城市信息
	 */
	@Override
	public List<City> getCityByCountryOrProvince(City city) {
		try {
			return cityMapper.getCityByCountryOrProvince(city);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
		 
	}
	
	
}
