/**
 * 
 */
package com.spring.scenic.member.application.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.Collection;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberDetailInfo;
import com.spring.scenic.member.domain.Order;
import com.spring.scenic.member.domain.OrderInvoice;
import com.spring.scenic.member.domain.OrderMoneyChangeRec;
import com.spring.scenic.member.domain.OrderPayRecord;
import com.spring.scenic.member.infrastructure.CollectionMapper;
import com.spring.scenic.member.infrastructure.MemberBasicMapper;
import com.spring.scenic.member.infrastructure.MemberDetailInfoMapper;
import com.spring.scenic.member.infrastructure.OrderInvoiceMapper;
import com.spring.scenic.member.infrastructure.OrderMapper;
import com.spring.scenic.member.infrastructure.OrderMoneyChangeRecMapper;
import com.spring.scenic.member.infrastructure.OrderPayRecordMapper;

/** @Description：会员管理接口实现类
 *  @author：ranmaoping
 *  @date:下午3:13:53 2017年1月17日
 *  @version:1.0
 *
 */
@Service
public class MemberBasicServiceImpl implements MemberBasicService{
	
    @Autowired
	private MemberBasicMapper memberBasicMapper;
	@Autowired
	private MemberDetailInfoMapper memberDetailInfoMapper;
	@Autowired
	private OrderMapper orderMapper;
	@Autowired
    private CollectionMapper collectionMapper;
	@Autowired
	private OrderInvoiceMapper orderInvoiceMapper;
	@Autowired
	private OrderMoneyChangeRecMapper orderMoneyChangeRecMapper;
	@Autowired
	private OrderPayRecordMapper orderPayRecordMapper;
	
	@Override
	public List<MemberBasic> getMemberList(MemberBasic member, boolean pageAble) {
		try {
			if(pageAble){
				PageHelper.startPage(member.getPageNum(), SysConstant.PAGE_PAGESIZE);
			}
			member.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
			List<MemberBasic> members = memberBasicMapper.getMemberList(member);
			return members;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public MemberBasic getMemberDetailInfo(MemberBasic member) {
		try {
			member.setType(Integer.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
			MemberBasic memberDetail = memberBasicMapper.selectByPrimaryKey(member.getId());
			MemberDetailInfo tempVoDetailInfo = new MemberDetailInfo();
			tempVoDetailInfo.setFkId(member.getId());
			tempVoDetailInfo.setType(Short.valueOf(SysEnum.PASSENGER_DETAIL_TYPE_MEMBER.getCode()));
			MemberDetailInfo memberDetailInfo = memberDetailInfoMapper.queryCommonTripMan(tempVoDetailInfo);
			memberDetail.setMemberDetail(memberDetailInfo);
			return memberDetail;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public void saveMemberBasicInfo(MemberBasic member) {
		MemberBasic memberBasic = validata(member);
		try {
			//更新会员基本信息
			memberBasicMapper.updateMemberBasicInfo(memberBasic);
			//更新会员详情信息
			if(null!=memberBasic) {
				MemberDetailInfo  memberDetailInfo = memberBasic.getMemberDetail();
				memberDetailInfo.setUpdateTime(memberBasic.getUpdateTime());
				memberDetailInfo.setUpdateUser(memberBasic.getUpdateUser());
				memberBasicMapper.updateMemberDetailInfo(memberDetailInfo);
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**校验国家省份城市是否有效
	 * @param member
	 * @return
	 */
	private MemberBasic validata(MemberBasic member) {
		if(null!=member.getMemberDetail()) {
			Integer countryId = member.getMemberDetail().getCountryId();
			Integer provinceId = member.getMemberDetail().getProvinceId();
			Integer cityId = member.getMemberDetail().getCityId();
			if(null==countryId) {
				throw new BussinessException(new BussinessExceptionBean("exception.countryIsInvalid"));
			}
			if(null==provinceId){
				throw new BussinessException(new BussinessExceptionBean("exception.provinceIsInvalid"));
			}
			if(null==cityId){
				throw new BussinessException(new BussinessExceptionBean("exception.cityIsInvalid"));	
			}
			if(countryId==-1) {
				member.getMemberDetail().setCountryId(null);
			}
			if(provinceId==-1) {
				member.getMemberDetail().setProvinceId(null);
			}
			if(cityId==-1) {
				member.getMemberDetail().setCityId(null);
			}
		}
		return member;
	}
	/**
	 * 会员订单tab页展示
	 */
    @Override
    public List<Order> getMemberOrders(Order order, boolean pageAble) {
        try {
            if(pageAble){
                PageHelper.startPage(order.getPageNum(), SysConstant.PAGE_PAGESIZE);
            }
            List<Order> orderList = orderMapper.getMemberOrders(order);
            return orderList;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    /**
     * 会员订单tab页展示
     */
    @Override
    public List<Collection> getMemberCollections(Collection collection, boolean pageAble) {
        try {
            if(pageAble){
                PageHelper.startPage(collection.getPageNum(), SysConstant.PAGE_PAGESIZE);
            }
            List<Collection> collectionList = collectionMapper.getMemberCollections(collection);
            return collectionList;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public Order getMemberOrderDetail(Order order) {
        Order orderInfo = orderMapper.getMemberOrderDetail(order);
        if(null!=orderInfo) {
            //应付金额
            //BigDecimal orderPrice = orderInfo.getOrderPrice();
            //调整金额
            //BigDecimal moneyChanged = new BigDecimal(0.00);
            //应付金额
            // moneyShouldPay = new BigDecimal(0.00);
            //已付金额
            //BigDecimal moneyPaid = new BigDecimal(0.00);
            //查询金额调整记录
            List<OrderMoneyChangeRec> orderMoneyChangeRecList = orderMoneyChangeRecMapper.getChangeRecList(order.getOrderNo());
            //计算应付金额  应付金额 = 订单金额 +调整金额之和
            if(null!=orderMoneyChangeRecList&&orderMoneyChangeRecList.size()>0) {
                orderInfo.setOrderMoneyChangeRecList(orderMoneyChangeRecList);
//                for (OrderMoneyChangeRec orderMoneyChangeRec : orderMoneyChangeRecList) {
//                    moneyChanged = moneyChanged.add(orderMoneyChangeRec.getMoney());
//                }
            }
            //moneyShouldPay = orderPrice.add(moneyChanged);
            //查询订单支付记录
            List<OrderPayRecord> orderPayRecordList = orderPayRecordMapper.getPayRecListList(order.getOrderNo());
            //计算已付金额 已付金额 = 付款记录之和
            if(null!=orderPayRecordList&&orderPayRecordList.size()>0) {
                orderInfo.setOrderPayRecordList(orderPayRecordList);
//                for (OrderPayRecord orderPayRecord : orderPayRecordList) {
//                    moneyPaid = moneyPaid.add(orderPayRecord.getTotalPrice());
//                }
            }
            //如果订单有开发票，查询发票信息
            if(orderInfo.getNeedInvoice()==Integer.valueOf(SysEnum.COMMON_BOOL_YES.getCode())) {
                OrderInvoice orderInvoice = orderInvoiceMapper.getOrderInvoiceInfo(order.getOrderNo());
                orderInfo.setOrderInvoice(orderInvoice);
            }
            //orderInfo.setMoneyShouldPay(moneyShouldPay);
            //orderInfo.setMoneyPaid(moneyPaid);
        }
        return orderInfo;
    }

    @Override
    public OrderInvoice getOrderInvoiceInfo(String orderNo) {
        OrderInvoice orderInvoice = orderInvoiceMapper.getOrderInvoiceInfo(orderNo);
        return orderInvoice;
    }

    @Override
    public List<OrderMoneyChangeRec> getChangeRecList(String orderNo) {
        List<OrderMoneyChangeRec> orderMoneyChangeRecList = orderMoneyChangeRecMapper.getChangeRecList(orderNo);
        return orderMoneyChangeRecList;
    }

    @Override
    public List<OrderPayRecord> getPayRecListList(String orderNo) {
        List<OrderPayRecord> orderPayRecordList = orderPayRecordMapper.getPayRecListList(orderNo);
        return orderPayRecordList;
    }
	
}
