package com.spring.scenic.cms.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class SysConfig extends Entity<SysConfig>{
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 所属系统
     */
    private Short sysType;
    /**
     * 位置名称	
     */
    private String locationName;
    /**
     * 位置代码	
     */
    private String locationCode;
    /**
     * 类型 1：图文链接 2：产品推荐 3：搜索管理字
     */
    private Short locationType;
    /**
     * 是否有效 1有效 0无效
     */
    private Short valid;
    /**
     * 备注
     */
    private String remark;
    /**
     * 更新人姓名
     */
    private String updateUserName;
    private Integer createUser;

    private Date createTime;

    private Integer updateUser;

    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Short getSysType() {
        return sysType;
    }

    public void setSysType(Short sysType) {
        this.sysType = sysType;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }
   
    public Short getValid() {
        return valid;
    }

    public void setValid(Short valid) {
        this.valid = valid;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

    public Short getLocationType() {
        return locationType;
    }

    public void setLocationType(Short locationType) {
        this.locationType = locationType;
    }
    
}