package com.spring.scenic.resource.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class Suppliers extends Entity<Suppliers> implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1175124812159537216L;
	/**
	 * 主键id
	 */
    private Integer id;
    /**
     * 供应商名称
     */
    private String name;
    /**
     * 供应商编码
     */
    private String code;
    /**
     * 供应商简介
     */
    private String remarks;
    /**
     * 状态 1：有效 0：无效
     */
    private String valid;
    /**
     * 状态 1：临时 2：合格
     */
    private Short status;

    private String guid;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Integer createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private Integer updateUser;
    
    private String createUserName;
    /**
     * 更新人姓名
     */
    private String updateUserName;
    /**
     * 评审有效期
     */
    private Date reviewValidity;
    
    private List<SuppliersProductType> productType;
    
    
    public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getValid() {
        return valid;
    }

    public void setValid(String valid) {
        this.valid = valid == null ? null : valid.trim();
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid == null ? null : guid.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

	public List<SuppliersProductType> getProductType() {
		return productType;
	}

	public void setProductType(List<SuppliersProductType> productType) {
		this.productType = productType;
	}

	public Date getReviewValidity() {
		return reviewValidity;
	}

	public void setReviewValidity(Date reviewValidity) {
		this.reviewValidity = reviewValidity;
	}
    
}