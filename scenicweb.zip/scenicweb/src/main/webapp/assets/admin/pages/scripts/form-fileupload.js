var FormFileUpload = function () {

    return {
        //main function to initiate the module
        init: function (value) {
             // Initialize the jQuery File Upload widget:
            $('#'+value).fileupload({
                disableImageResize: false,
                autoUpload: false
            });

            // Enable iframe cross-domain access via redirect option:
            $('#'+value).fileupload(
                'option',
                'redirect',
                window.location.href.replace(
                    /\/[^\/]*$/,
                    '/cors/result.html?%s'
                )
            );
        }
    };

}();