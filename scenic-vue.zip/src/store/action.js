import {
	getUser,
	getAddressList
} from '../service/getData'
import {
	GET_USERINFO,
	SAVE_ADDRESS
} from './mutation-types.js'



export default {

	async getUserInfo({
		commit,
		state
	}) {
		let res = await getUser();
		if(res.status === 200){
      commit(GET_USERINFO, res.obj.memberBasic);
    }
		else{
      commit(GET_USERINFO, null);
    }
    return true;
	},
}
