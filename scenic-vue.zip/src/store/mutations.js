import {
  RECORD_SHOPDETAIL,
  RECORD_USERINFO,
  GET_USERINFO,
  CONFIRM_REMARK,
  CONFIRM_INVOICE,
  CHOOSE_SEARCH_ADDRESS,
  SAVE_GEOHASH,
  CONFIRM_ADDRESS,
  CHOOSE_ADDRESS,
  NEED_VALIDATION,
  SAVE_CART_ID_SIG,
  SAVE_ORDER_PARAM,
  CHANGE_ORDER_PARAM,
  ORDER_SUCCESS,
  SAVE_SHOPID,
  SAVE_ORDER,
  OUT_LOGIN,
  RETSET_NAME,
  SAVE_AVANDER,
  SAVE_ADDRESS,
  SAVE_ADDDETAIL,
  SAVE_QUESTION,
  ADD_ADDRESS,
  BUY_CART,

  INIT_PERSON,
  INIT_SELECTED_PERSON,
  SAVE_ORDER_STATUS,
  SAVE_MEAL,
  EDIT_COMMENTFAVOUR,

  INIT_SITE,
  INIT_LISTTRAVEL,
  INIT_MYTRAVEL,
  MUTUALLY_HANDLE,
  SAVE_STATISTRAVEL,
  SET_STARELSTATUS

} from './mutation-types.js'

import {
  setStore,
  getStore,
  setSessionStorage,
  getSessionStorage,
  removeSessionStorage
} from '../config/mUtils'

export default {
  //点赞，收藏，阅读，评论
  [MUTUALLY_HANDLE](state, {
                      like,
                      likestatus,
                      collect,
                      collectstatus,
                      comment,
                      read,
                      id
                    }){
    let handleGroup = state.handleGroup;

    handleGroup[id] = {
      like: like || 0,
      likestatus: likestatus,
      collect: collect || 0,
      collectstatus: collectstatus,
      read: read,
      comment: comment || 0,
    };

    state.handleGroup = {...handleGroup};
  },

  //产品评论点赞
  [EDIT_COMMENTFAVOUR](state, data){
    let commentFavour = state.commentFavour;

    commentFavour[data.id] = data;

    state.commentFavour = {...commentFavour};
  },

  [RECORD_SHOPDETAIL](state, detail) {
    state.shopDetail = detail;
  },

  // 记录用户信息
  [RECORD_USERINFO](state, info) {
    state.userInfo = info;
    state.login = true;
    let validity = 30;
    let now = new Date();
    now.setTime(now.getTime() + validity * 24 * 60 * 60 * 1000);
    window.sessionStorage.setItem('token', info.id);
    //保存用户城市到local
    if (info.cityName) setStore('cityName', info.cityName);
    //document.cookie = "USERID=" + info.id + ";expires=" + now.toGMTString();
    //document.cookie = "SID=huRyTRd9QLij7NkbpHJoj3PQrx1eRiO6bAiw" + ";expires=" + now.toGMTString();
  },
  //获取用户信息存入vuex
  [GET_USERINFO](state, info) {
    if (info) {
      state.userInfo = {...info};
      state.login = true;
      let validity = 30;
      let now = new Date();
      now.setTime(now.getTime() + validity * 24 * 60 * 60 * 1000);
      window.sessionStorage.setItem('token', info.id);
    } else {
      window.sessionStorage.removeItem('token');
      state.login = false;
      state.userInfo = null;
    }
  },
  //修改用户名
  [RETSET_NAME](state, username) {
    state.userInfo = Object.assign({}, state.userInfo, {username})
  },
  //保存商铺id
  [SAVE_SHOPID](state, shopid) {
    state.shopid = shopid;
  },
  //记录订单页面用户选择的备注, 传递给订单确认页面
  [CONFIRM_REMARK](state, {
                     remarkText,
                     inputText
                   }) {
    state.remarkText = remarkText;
    state.inputText = inputText;
  },
  //是否开发票
  [CONFIRM_INVOICE](state, invoice) {
    state.invoice = invoice;
  },
  //选择搜索的地址
  [CHOOSE_SEARCH_ADDRESS](state, place) {
    state.searchAddress = place;
  },
  //保存geohash
  [SAVE_GEOHASH](state, geohash) {
    state.geohash = geohash;
    if (true) {
    }
  },
  //选择的地址
  [CHOOSE_ADDRESS](state, {
                     address,
                     index
                   }) {
    state.choosedAddress = address;
    state.addressIndex = index;
  },
  //确认订单页添加新的的地址
  [CONFIRM_ADDRESS](state, newAddress) {
    state.newAddress.push(newAddress);
  },
  //保存下单需要验证的返回值
  [NEED_VALIDATION](state, needValidation) {
    state.needValidation = needValidation;
  },
  //保存下单后购物id 和 sig
  [SAVE_CART_ID_SIG](state, {
                       cart_id,
                       sig
                     }) {
    state.cart_id = cart_id;
    state.sig = sig;
  },
  //保存下单参数，用户验证页面调用
  [SAVE_ORDER_PARAM](state, orderParam) {
    state.orderParam = orderParam;
  },
  //修改下单参数
  [CHANGE_ORDER_PARAM](state, newParam) {
    state.orderParam = Object.assign({}, state.orderParam, newParam);
  },
  //下单成功，保存订单返回信息
  [ORDER_SUCCESS](state, order) {
    state.cartPrice = null;
    state.orderMessage = order;
  },
  //进入订单详情页前保存该订单信息
  [SAVE_ORDER](state, orderDetail) {
    state.orderDetail = orderDetail;
  },
  //退出登录
  [OUT_LOGIN](state) {
    state.userInfo = null;
    state.login = false;
  },
  //保存图片
  [SAVE_AVANDER](state, imgPath) {
    state.imgPath = imgPath;
  },
  //删除地址列表
  [SAVE_ADDRESS](state, newAdress) {
    state.removeAddress = newAdress
  },
  //添加地址name
  [SAVE_ADDDETAIL](state, addAddress){
    state.addAddress = addAddress;
  },
  //保存所选问题标题和详情
  [SAVE_QUESTION](state, question) {
    state.question = {...question};
  },
  //增加地址
  [ADD_ADDRESS](state, obj) {
    state.removeAddress = [obj, ...state.removeAddress];
  },
  //会员卡价格纪录
  [BUY_CART](state, price) {
    state.cartPrice = price;
  },

  //初始化出行人
  [INIT_PERSON](state, obj) {
    state.myPerson = obj;
  },
  //选择出行人
  [INIT_SELECTED_PERSON](state, arr) {
    state.selectedPerson = arr;
  },
  //订单状态
  [SAVE_ORDER_STATUS](state, obj){
    state.orderStatus.push(obj);
  },

  //常用信息
  [INIT_SITE](state, obj){
    state.mySite = obj;
  },

  //游记列表
  [INIT_LISTTRAVEL](state, arr) {
    state.listTravel = arr;
  },

  //我的游记
  [INIT_MYTRAVEL](state, arr) {
    state.mytravel = arr;
  },

  [SAVE_STATISTRAVEL](state, obj){
    state.mytravelStatis = obj;
  },

  [SET_STARELSTATUS](state, obj){
    state.mytravelStatus = obj;
  },

  //用户套餐数据
  [SAVE_MEAL](state, obj) {
    state.userMeal = obj;
  }

}
