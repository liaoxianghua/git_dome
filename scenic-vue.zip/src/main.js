import 'babel-polyfill'
import Vue from 'vue'
import VueRouter from 'vue-router'
import routes from './router/router'
import store from './store/'
import {routerMode} from './config/env'
import './config/rem'
import FastClick from 'fastclick'
import Mint from 'mint-ui'
import {messageBox, Toast, InfiniteScroll} from 'mint-ui'
import VueLazyload from 'vue-lazyload' // 懒加载
import {getSessionStorage} from './config/mUtils'


Vue.config.debug = false;

if ('addEventListener' in document) {
  document.addEventListener('DOMContentLoaded', function () {
    FastClick.attach(document.body);
  }, false);
}

Vue.use(VueRouter);
Vue.use(Mint);

Vue.use(VueLazyload, {
  preLoad: 1.3,
  error: require('./images/hz.png'),
  loading: require('./images/loading.jpg'),
  attempt: 1
})

const router = new VueRouter({
  routes,
  mode: routerMode,
  strict: process.env.NODE_ENV !== 'production'
});

router.beforeEach((to, from, next) => {
  if (to.meta.requireAuth) {
    let token = getSessionStorage('token');
    if (token) {
      next();
    }
    else {
      next({
        path: '/login',
        query: {redirect: to.fullPath, back: from.fullPath},
      });

    }
  }
  else {
    next();
  }
});

new Vue({
  router,
  store,
}).$mount('#app');

Vue.prototype.messageBox = messageBox;
Vue.prototype.Toast = Toast;



