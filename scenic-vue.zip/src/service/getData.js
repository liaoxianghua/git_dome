import fetch from '../config/axios'


/**
 * 创建临时数据
 */
const setpromise = data => {
  return new Promise((resolve, reject) => {
    resolve(data);
  })
}

//开发或编译环境使用真实数据
if (process.env.NODE_ENV == 'production' || process.env.NODE_ENV == 'development') {


  /**
   * 获取首页
   */
  var homeIndex = currentCity => fetch('POST', '/index/home', {
    city: currentCity
  });

  /**
   * 更多直播
   */
  var moreVideo = () => fetch('POST', '/index/directSeedingMore', {});

  /**
   * 直播点赞
   */
  var Praise = parameter => fetch('POST', '/praise/pushPraise', {
    praiseContentId: parameter.id,
    //type: parameter.type,
    praiseType: parameter.praiseType
  });

  /**
   * 最爱目的地
   */
  var likeDestination = cityType => fetch('POST', '/index/loveDestination', {
    type: cityType
  });

  /**
   * 游记列表
   */
  var travelList = parameters => fetch('POST', '/mystrategy/listMyStrategy', {
    pageSize: parameters.pageSize,
    pageNum: parameters.pageNum,
    city: parameters.city,
  });

  /**
   * 列表游记详情
   */
  var travelDetails = id => fetch('POST', '/mystrategy/travelNoteDetail', {
    id
  });

  /**
   * 游记详情历史记录
   */
  var travelHistory = id => fetch('POST', '/index/insertReadCountTravelNote', {
    id
  });

  /**
   * home游记详情
   */
  var homeTravelDetails = id => fetch('POST', '/index/indexTraveNotesDetail', {
    id
  });

  /**
   * home游记详情评论
   */
  var homeDetailsComment = parameters => fetch('POST', '/index/insertIndexTraveNotesDetailComments', {
    id: parameters.id,
    comments: parameters.commenttext
  });

  /**
   * home游记详情评论更新
   */
  var homeDetailsCommentUP = id => fetch('POST', '/index/indexTraveNotesDetailComments', {
    id
  });

  /**
   * 搜索页初始化
   */
  var initSearch = () => fetch('POST', '/search/init', {});

  /**
   * 清空搜索历史
   */
  var emptyHistory = () => fetch('POST', '/search/destory', {});

  /**
   * 获取搜索联想
   */
  var prepareSearch = keyword => fetch('POST', '/search/prepareSearch', {
    keyword
  });

  /**
   * 搜索结果
   */
  var search = (keyword, type, pageNum, pageSize, cityName, productType, productSubType) => fetch('POST', '/search/indexSearch', {
    keyword,
    type,
    pageNum,
    pageSize,
    cityName,
    productType,
    productSubType,
  });

  /**
   * 城市初始化
   */
  var cityInit = () => fetch('POST', '/city/init', {});


  /**
   * 修改城市
   */
  var selectCity = city => fetch('POST', '/city/changeCity', {
    cityName: city
  });

  /**
   * 城镇数据初始化
   */
  var initAddressData = () => fetch('POST', '/city/initAddressData');


  /**
   * 获取我的游记信息
   */
  var getmytravel = parameters => fetch('POST', '/mytravels/listMytravel', {
    type: parameters.status,
    pageNum: parameters.pageNum,
    pageSize: parameters.pageSize,
  });

  /**
   * 新建游记
   */
  var newmytravel = parameters => fetch('POST', '/mytravels/addMytravel', {
    arryStr: parameters
  });

  /**
   * 修改游记
   */
  var amendmytravel = parameters => fetch('POST', '/mytravels/updateMytravel', {
    arryStr: parameters
  });

  /**
   * 删除游记
   */
  var deletemytravel = travelId => fetch('POST', '/mytravels/deleteMytravel', {
    id: travelId
  });

  /**
   * 上传图片
   */
  var uploadPic = key => fetch('POST', '/common/saveUploadFile', {
    keyword: key
  });

  /**
   * 个人中心/常用地址查询
   */
  var siteQuery = () => fetch('POST', '/member/selectCommonAddressList');

  /**
   * 个人中心/常用地址新增
   */
  var siteAdd = parameters => fetch('POST', '/member/addCommonAddress', {
    receiveName: parameters.receiveName,
    receivePhone: parameters.receivePhone,
    addressDetail: parameters.addressDetail,
    postCode: parameters.postCode,
    countryId: parameters.countryId,
    provinceId: parameters.provinceId,
    cityId: parameters.cityId,
    isDefault: parameters.isDefault
  });

  /**
   * 个人中心/常用地址编辑
   */
  var siteEdit = (parameters, id) => fetch('POST', '/member/updateCommonAddress', {
    addressId: id,
    receiveName: parameters.receiveName,
    receivePhone: parameters.receivePhone,
    addressDetail: parameters.addressDetail,
    postCode: parameters.postCode,
    countryId: parameters.countryId,
    provinceId: parameters.provinceId,
    cityId: parameters.cityId,
    isDefault: parameters.isDefault
  });

  /**
   * 个人中心/我的游记查询
   */
  var userPageMyTravel = id => fetch('POST', '/mystrategy/selectMyFirstTravelNote');

  /**
   * 个人中心/常用地址删除
   */
  var siteDelete = id => fetch('POST', '/member/deleteCommonAddress', {
    addressId: id
  });

  /**
   * 个人中心/单个常用地址查询
   */
  var siteSingle = id => fetch('POST', '/member/selectCommonAddressInfo', {
    addressId: id
  });

  /**
   * 个人中心/历史记录查询
   */
  var historyQuery = (type, strId) => fetch('POST', '/MyBrowserHistory/listMyBrowserHistory', {
    type: type,
    strID: strId
  });

  /**
   * 获取短信验证码
   */

  var mobileCode = (phone, codeType) => fetch('POST', '/common/getVerifyCode', {
    phone: phone,
    verifyCodeType: codeType,
  });

  /**
   * 验证短信验证码
   */

  var validateMobileCode = (phone, code, token, codeType) => fetch('POST', '/common/validateVerifyCode', {
    phone,
    verifyCode: code,
    verifyCodeType: codeType,
    token
  });


  /**
   * 账号密码登录
   */

  var accountLogin = (phone, password, verifyCodeForPage) => fetch('POST', '/common/login', {
    phone,
    password,
    loginType: 1,
    captcha_code: 0,
    verifyCodeForPage
  });

  /**
   * 快速登录
   */
  var fastLogin = (phone, mobileCode, token) => fetch('POST', '/common/login', {
    phone,
    verifyCode: mobileCode,
    loginType: 2,
    verifyCodeType: 3,
    token,
  });

  /**
   * 注册账号
   */

  var accountRegister = (phone, password, rPassword, code, token) => fetch('POST', '/common/commonRegister', {
    phone,
    password,
    confirmPassword: rPassword,
    verifyCode: code,
    loginType: 2,
    verifyCodeType: 1,
    token
  });

  /**
   * 检测帐号是否存在
   */

  var checkExsis = checkNumber => fetch('POST', '/common/memberBand', {
    phone: checkNumber
  });

  /**
   * 检测是否登录
   */
  /*var checkLogin = () => {
   let cookie = document.cookie;
   //console.log(cookie);
   return !(cookie.indexOf('USERID=0;') !== -1 || !cookie);
   }*/

  /**
   * 重置密码
   */
  var reSetPassword = (phone, password, code, token) => fetch('POST', '/common/resetMemberPassword', {
    phone,
    newPassword: password,
    verifyCode: code,
    verifyCodeType: 4,
    token
  });

  /**
   * 退出登录
   */
  var logout = () => fetch('POST', '/common/logout', {});


  /**
   * 发送帐号
   */

  var sendMobile = (sendData, captcha_code, type, password) => fetch('POST', '/v1/mobile/verify_code/send', {
    action: "send",
    captcha_code,
    [type]: sendData,
    type: "sms",
    way: type,
    password,
  });

  /**
   * 获取用户信息
   */

  var getUser = () => fetch('POST', '/member/selectMemberInfo', {});

  /**
   * 获取国家列表
   */

  var getNationality = () => fetch('POST', '/member/selectCuntryList', {});

  /**
   * 获取证件类型列表
   */
  var getCredential = () => fetch('POST', '/member/selectCredentialTypes', {});

  /**
   * 出行人列表
   */
  var getPersonList = () => fetch('POST', '/member/selectCommonTripManList', {});

  /**
   * 出行人详情
   */
  var getPersonInfo = passengerId => fetch('POST', '/member/selectCommonTripManInfo', {
    passengerId
  });

  /**
   * 更新出行人
   */
  var updatePersonInfo = (passengerId, documentId, nameCh, nameEnF, nameEnS, sex, phoneCh, nationality, documentType, documentNo, isSelf, birthdayDate) => fetch('POST', '/member/updateCommonTripMan', {
    passengerId,
    documentId,
    nameCh,
    nameEnF,
    nameEnS,
    sex,
    phoneCh,
    nationality,
    documentType,
    documentNo,
    isSelf,
    birthdayDate
  });

  /**
   * 新增出行人
   */
  var addPersonInfo = (nameCh, nameEnF, nameEnS, sex, phoneCh, nationality, documentType, documentNo, isSelf, birthdayDate) => fetch('POST', '/member/addCommonTripMan', {
    nameCh,
    nameEnF,
    nameEnS,
    sex,
    phoneCh,
    nationality,
    documentType,
    documentNo,
    isSelf,
    birthdayDate
  });

  /**
   * 删除出行人
   */
  var deletePersonInfo = (passengerId) => fetch('POST', '/member/deleteCommonTripMan', {
    passengerId
  });

  /**
   * 商品分类
   */
  var goodsTypes = () => fetch('POST', '/product/selectProductTypes', {});

  /**
   * 商品列表
   */

  var goodsList = (cityName, productType, productSubType, pageSize, pageNum) => fetch('POST', '/product/selectListByParams', {
    cityName,
    productType,
    productSubType,
    pageSize,
    pageNum
  });

  /**
   * 商品详情
   */

  var goodsDetails = (productId, cityName) => fetch('POST', '/product/selectProductById', {
    productId,
    cityName
  });

  /**
   * 商品评论
   */
  var goodsComment = (productId, gread, pageSize, pageNum) => fetch('POST', '/product/selectCommentByProductId', {
    productId,
    gread,
    pageSize,
    pageNum,
  });

  /**
   * 商品套餐
   */

  var goodsCombo = (mealsId, playMonth) => fetch('POST', '/productStock/selectListByParams', {
    mealsId,
    playMonth
  });

  /**
   * 商品相册
   */
  var goodsAlbum = (productId) => fetch('POST', '/product/selectProductMoreImgList', {
    productId,
  });

  /**
   * save订单
   */
  var saveOrder = (productId, orderCount, mealsId, stockId, adultCount, childCount, passengers, linkMan, phoneCh, mail, weixin, captcha, businessType, remark, needInvoice, type, phone, title, email, gainType, takeAddress) => fetch('POST', '/order/saveOrder', {
    productId,
    orderCount,
    mealsId,
    stockId,
    adultCount,
    childCount,
    passengers,
    linkMan,
    phoneCh,
    mail,
    weixin,
    captcha,
    businessType,
    remark,
    needInvoice,
    type,
    phone,
    title,
    email,
    gainType,
    takeAddress,
    src: 1
  });

  /**
   * 订单列表
   */
  var orderList = (orderStatus, pageSize, pageNum) => fetch('POST', '/order/selectOrderList', {
    orderStatus,
    pageSize,
    pageNum
  });

  /**
   * 订单详情
   */
  var orderDetail = encode => fetch('POST', '/order/selectOrderDetail', {
    encode
  });

  var payment = (encode, payMoney, payType = 4) => fetch('POST', '/pay/simplepay', {
    encode,
    payMoney,
    payType
  });

  /**
   * 新增订单评论
   */
  var addComment = (productId, productName, encode, sellerId, content, gread, imgUrls, src) => fetch('POST', '/product/addProductComment', {
    productId,
    productName,
    encode,
    sellerId,
    content,
    gread,
    imgUrls,
    src: 2
  });

  /**
   * 取消订单
   */
  var cancelOrder = encode => fetch('POST', '/order/updateOrderStatus', {
    encode,
    orderStatus: 4,
  });

  /**
   * 设置订单状态
   */
  var setOrderStatus = (encode, orderStatus) => fetch('POST', '/order/updateOrderStatus', {
    encode,
    orderStatus,
  });

  /**
   * 新增反馈
   */
  var addfeedback = (feedbackContent, linkPhone, imgUrls) => fetch('POST', '/member/addMemberfeedback', {
    feedbackContent,
    linkPhone,
    imgUrls,
  });

  /**
   * 设置是否接受点赞消息
   */
  var changeSetting = (receivePraise, receiveComment) => fetch('POST', '/messages/updateMessageReceiveStatus', {
    receivePraise,
    receiveComment
  });

  /**
   * 点赞通知列表
   */
  var messagePraiseList = () => fetch('POST', '/messages/selectMemberPraiseList', {});

  /**
   * 评论消息列表
   */
  var messageCommentList = () => fetch('POST', '/messages/selectMemberCommentList', {});

  /**
   * 系统通知列表
   */
  var messageNoticeList = () => fetch('POST', '/messages/selectSystemNoticeList', {});

  /**
   * 系统通知详情
   */
  var messageNoticeDetails = (noticeId) => fetch('POST', '/messages/selectSystemNoticeDetail', {
    noticeId
  });

  /**
   * 删除消息
   */
  var messageDelete = (ids, type) => fetch('POST', '/messages/deleteMemberMessagesByBatch', {
    ids,
    type
  });


  /**
   * 收藏
   */
  var collectionEdit = (collectionType, collectionContentId, deleted) => fetch('POST', '/member/myCollectionEdit', {
    collectionType,
    collectionContentId,
    deleted
  });

  //我的收藏列表
  var myCollection = collectionType => fetch('POST', '/member/listMyCollection', {
    collectionType
  });

  var editUserInfo = (imageUrl, nameCh, phoneCh, sex, birthDay, countryId, provinceId, cityId, mail) => fetch('POST', '/member/updateMemberInfo', {
    imageUrl,
    nameCh,
    phoneCh,
    sex,
    birthDay,
    countryId,
    provinceId,
    cityId,
    mail
  });

  var verifyCode = () => fetch('POST', '/common/initVerifyCodeIoImage');

} else {

}


export {
  /* cityGuess,
   hotcity,
   groupcity,
   currentcity,
   searchplace,
   msiteAdress,
   msiteFoodTypes,
   shopList,
   foodCategory,
   foodDelivery,
   foodActivity,
   shopDetails,
   foodMenu,
   getRatingList,
   ratingScores,
   ratingTags,*/
  mobileCode,
  validateMobileCode,
  sendMobile,
  getUser,

  fastLogin,
  accountLogin,
  checkExsis,
  //checkLogin,
  accountRegister,
  reSetPassword,
  logout,
  saveOrder,//提交订单
  orderList,//订单列表
  orderDetail,//订单详情
  addComment,//新增订单评论
  cancelOrder,//取消订单
  setOrderStatus,//更改订单状态
  payment,//支付
  collectionEdit,//收藏
  myCollection,//收藏列表
  goodsDetails,//产品详情
  goodsTypes,//产品类型
  goodsList,//产品列表
  goodsCombo,//产品套餐
  goodsComment,//产品评论
  goodsAlbum,//产品相册
  getPersonList,//出行人列表
  getPersonInfo,//出行人详情
  updatePersonInfo,//编辑出行人
  addPersonInfo,//新增出行人
  deletePersonInfo,//删除出行人
  getNationality,//获取国家列表
  getCredential,//获取证件类型列表
  addfeedback,//新增意见反馈

  editUserInfo,//编辑用户信息
  changeSetting,//更改設置

  messagePraiseList,//点赞消息列表
  messageCommentList,//评论消息列表
  messageNoticeList,//系统消息列表
  messageNoticeDetails,//系统消息详情
  messageDelete,//删除消息

  initSearch,//初始化搜索
  prepareSearch,//预搜索
  emptyHistory,//清空历史
  search,//搜索结果

  homeIndex,
  moreVideo,//更多直播
  Praise,  //直播点赞
  likeDestination, //最爱目的地
  homeTravelDetails,  //首页获取详情页
  homeDetailsComment, //首页详情评论
  homeDetailsCommentUP, //评论局部刷新

  travelList, //游记攻略列表
  travelDetails,  //游记详情
  travelHistory,  //浏览历史

  cityInit, //城市页初始化
  selectCity, //城市选择
  initAddressData,  //初始化城镇数据

  siteQuery,  //个人中心，常用地址查询
  siteAdd,  //添加新的常用地址
  siteEdit, //编辑常用地址
  siteDelete, //删除常用地址
  siteSingle, //单个信息查询
  historyQuery, //历史记录查询
  userPageMyTravel, //我的游记查询

  getmytravel, //获取我的游记
  uploadPic, //图片上传
  newmytravel, //新建游记
  amendmytravel, //修改游记
  deletemytravel, //删除游记

  verifyCode,  //验证码
}
