/**
 * Created by lenovo on 2017/4/25.
 */
export const DllSearchData = [
  {
    "status": 200,
    "message": "操作成功",
    "obj": {
      "allSearch": [
        {
          "title": "产品",
          "url": "www.baidu.com"
        },
        {
          "title": "游记攻略",
          "url": "www.sina.com"
        }
      ],
      "prepareSearch": [
        {
          "title": "关于美女的全部产品",
          "url": "www.baidu.com?keyword=美女"
        },
        {

          "title": "关于美女全部游记攻略",
          "url": "www.sina.com?keyword=美女"

        }
      ]
    }
  }
]
