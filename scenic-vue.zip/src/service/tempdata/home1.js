/**
 * Created by lenovo on 2017/4/25.
 */
export const homeData ={
  "status": 200,
  "message": "成功",
  "obj": {
  "directSeeding": [
    {
      "id": 111,
      "title": "仙女山",
      "subTitle": "仙女山仙女山仙女",
      "skipUrl": "http://testwx.springtour.com/group1/M00/00/01/CiAAWlj9nDSAZfcKADntUaHVI-E567.mp4",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljBGkmAFLO5AAl5WLU-YRY187.png",
      "pointPraiseCount": 2
    },
    {
      "id": 112,
      "title": "九寨沟",
      "subTitle": "九寨沟",
      "skipUrl": "http://testwx.springtour.com/group1/M00/00/08/CiAAW1j9nF-AeGH7ADxB3wBEp-E132.mp4",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAW1jAHWqAGjDeAAzodQCbVVc966.jpg",
      "pointPraiseCount": 0
    }
  ],
    "travels": [
    {
      "id": 1,
      "authorName": "超级管理员",
      "title": "xxxxxxxxxx",
      "coversImageUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWli_5yeACzV-AAvWFkcZHjA629.jpg",
      "pointPraiseCount": 0,
      "comments": 0,
      "readCount": 60,
      "nowtime": "4小时前"
    }
  ],
    "carouselFigure": [
    {
      "id": 81,
      "skipUrl": "http://localhost:8080/commerce-scenic/notice/noticeDetail/50",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljAHWeABQFBAA1rIuRd3Es758.jpg"
    },
    {
      "id": 82,
      "skipUrl": "http://localhost:8080/commerce-scenic/notice/noticeDetail/50",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljBGkyAL8aBAAvea_OGt2M184.jpg"
    }
  ],
    "channelBar": [
    {
      "id": 101,
      "title": "最热",
      "skipUrl": "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=522616889,4100410198&fm=58",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAXFjBGk2ANFvLAAl5WLU-YRY685.png"
    },
    {
      "id": 102,
      "title": "温泉游",
      "skipUrl": "http://www.baidu.com/link?url=Dz4xq2Mg1omYa1A4POyVRuEXP6mLpC5i0GM8cU_h9H_QlgAeopCFIvNO4gYKJoft",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAW1jAHW2AFclpAAl5WLU-YRY194.png"
    },
    {
      "id": 103,
      "title": "自由行",
      "skipUrl": "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1834653896,3203745637&fm=58",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljAHWeABQFBAA1rIuRd3Es758.jpg"
    },
    {
      "id": 104,
      "title": "主题行",
      "skipUrl": "https://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWli_aZSAYG7OAAzodQCbVVc006.jpg"
    },
    {
      "id": 105,
      "title": "新春游",
      "skipUrl": "https://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljBGkyAL8aBAAvea_OGt2M184.jpg"
    }
  ],
    "loveDestination": [
    {
      "id": 110,
      "title": "乌克兰",
      "subTitle": "乌克兰美女比较多",
      "skipUrl": "http://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAXFjBGk2ANFvLAAl5WLU-YRY685.png",
      "type": null
    },
    {
      "id": 109,
      "title": "韩国",
      "subTitle": "韩国吃泡菜的国家",
      "skipUrl": "http://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAW1jBGlCASvZ-AAkVVGMybN8038.jpg",
      "type": null
    },
    {
      "id": 108,
      "title": "长白山",
      "subTitle": "山很白,具体没去过",
      "skipUrl": "http://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljBGkyAL8aBAAvea_OGt2M184.jpg",
      "type": null
    },
    {
      "id": 107,
      "title": "桂林",
      "subTitle": "桂林山水甲天下",
      "skipUrl": "http://www.baidu.com",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/07/CiAAW1jBGk2AOV3HAAkVVGMybN8452.jpg",
      "type": null
    },
    {
      "id": 106,
      "title": "三亚",
      "subTitle": "云淡风轻,养生的胜地",
      "skipUrl": "https://www.baidu.com/",
      "pictureUrl": "http://testwx.springtour.com/group1/M00/00/00/CiAAWljBGkmAFLO5AAl5WLU-YRY187.png",
      "type": null
    }
  ],
    "holidayhotel": [
      {
        "id": 2695,
        "productName": "上海虹桥机场华岗雅阁酒店ee",
        "minprice": "1",
        "city": "上海",
        "keywordholidayhotelvo": [
          {
            "name": "免费WIFI"
          },
          {
            "name": "商务出行"
          }
        ]
      }
    ],
}
}

