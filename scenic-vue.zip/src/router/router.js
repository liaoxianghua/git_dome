import App from '../App'


const city = r => require.ensure([], () => r(require('../page/city/city')), 'city');
const search = r => require.ensure([], () => r(require('../page/search/search')), 'search');
const productSearch = r => require.ensure([], () => r(require('../page/search/productSearch')), 'productSearch');

const login = r => require.ensure([], () => r(require('../page/login/login')), 'login')
const register = r => require.ensure([], () => r(require('../page/login/children/register')), 'register');
const registerRule = r => require.ensure([], () => r(require('../page/login/children/children/rule')), 'registerRule');
const fastRegister = r => require.ensure([], () => r(require('../page/login/children/fastRegister')), 'fastRegister');
const bindRegister = r => require.ensure([], () => r(require('../page/login/children/children/bindRegister')), 'bindRegister');
const reSetPassword = r => require.ensure([], () => r(require('../page/login/children/reSetPassword')), 'reSetPassword');


const single = r => require.ensure([], () => r(require('../page/single/single')), 'single');

const notes = r => require.ensure([], () => r(require('../page/notes/notes')), 'notes');
const notesDetails = r => require.ensure([], () => r(require('../page/notes/children/notesDetails')), 'notesDetails');

const strategy = r => require.ensure([], () => r(require('../page/strategy/strategy')), 'strategy');
const strategyDetails = r => require.ensure([], () => r(require('../page/strategy/children/strategyDetails')), 'strategyDetails');

const live = r => require.ensure([], () => r(require('../page/live/live')), 'live');
//const live2 = r => require.ensure([], () => r(require('../page/live/live2')), 'live2');

const message = r => require.ensure([], () => r(require('../page/message/message')), 'message');
const messageFavour = r => require.ensure([], () => r(require('../page/message/children/favour')), 'messageFavour');
const messageComment = r => require.ensure([], () => r(require('../page/message/children/comment')), 'messageComment');
const messageNotice = r => require.ensure([], () => r(require('../page/message/children/notice')), 'messageNotice');
const messageView = r => require.ensure([], () => r(require('../page/message/children/children/view')), 'messageView');

const goods = r => require.ensure([], () => r(require('../page/goods/list')), 'goods');
const linesDetails = r => require.ensure([], () => r(require('../page/goods/children/linesDetails')), 'linesDetails');
const linesOption = r => require.ensure([], () => r(require('../page/goods/children/lines/option')), 'linesOption');
const spotsDetails = r => require.ensure([], () => r(require('../page/goods/children/spotsDetails')), 'spotsDetails');
const spotsOption = r => require.ensure([], () => r(require('../page/goods/children/spots/option')), 'spotsOption');
const goodsDetails = r => require.ensure([], () => r(require('../page/goods/children/goodsDetails')), 'goodsDetails');
const goodsAlbum = r => require.ensure([], () => r(require('../page/goods/children/children/album')), 'album');
const goodsComment = r => require.ensure([], () => r(require('../page/comment/comment')), 'goodsComment');
const comment = r => require.ensure([], () => r(require('../page/comment/comment')), 'comment');
const goodsRouter = r => require.ensure([], () => r(require('../page/goods/children/router')), 'goodsRouter');
const goodsMap = r => require.ensure([], () => r(require('../page/goods/children/children/map')), 'goodsMap');


const confirmOrder = r => require.ensure([], () => r(require('../page/confirmOrder/confirmOrder')), 'confirmOrder');
const choosePerson = r => require.ensure([], () => r(require('../page/confirmOrder/children/choosePerson')), 'choosePerson');
const editPerson = r => require.ensure([], () => r(require('../page/confirmOrder/children/children/editPerson')), 'editPerson');
const payment = r => require.ensure([], () => r(require('../page/confirmOrder/children/payment')), 'payment');

/*我的*/
const user = r => require.ensure([], () => r(require('../page/user/user-index')), 'user')
/*我的——常用信息*/
const commentInfoIndex = r => require.ensure([], () => r(require('../page/user/children/inCommonUseInfo/commentInfo')), 'commentInfoIndex')
const figureEntering = r => require.ensure([], () => r(require('../page/confirmOrder/children/children/editPerson')), 'figureEntering')
const siteEditor = r => require.ensure([], () => r(require('../page/user/children/inCommonUseInfo/siteEditor')), ' siteEditor')
/*我的——历史记录*/
const browsingHistory = r => require.ensure([], () => r(require('../page/user/children/browsingHistory/browsingHistory')), 'browsingHistory')
/*我的——设置*/
const setingIndex = r => require.ensure([], () => r(require('../page/user/children/seting/setingIndex')), 'setingIndex')
const infoSeting = r => require.ensure([], () => r(require('../page/user/children/seting/infoSeting')), 'infoSeting')
const about = r => require.ensure([], () => r(require('../page/user/children/seting/about')), 'about')
const opinionEditor = r => require.ensure([], () => r(require('../page/user/children/seting/opinionEditor')), 'opinionEditor')
/*我的收藏*/
const collectIndex = r => require.ensure([], () => r(require('../page/user/children/myCollect/collectIndex')), 'collectIndex')
/*个人信息编辑*/
const infoEditorIndex = r => require.ensure([], () => r(require('../page/user/children/infoEditor/infoEditorIndex')), 'infoEditorIndex')
const editPassword = r => require.ensure([], () => r(require('../page/user/children/infoEditor/editPassword')), 'editPassword')

//我的订单
const order = r => require.ensure([], () => r(require('../page/order/order')), 'order');
const orderDetail = r => require.ensure([], () => r(require('../page/order/children/orderDetail')), 'orderDetail');
const orderComment = r => require.ensure([], () => r(require('../page/order/children/comment')), 'orderComment');

//我的遊記
const myTravelIndex = r => require.ensure([], () => r(require('../page/myTravel/myTravelIndex')), 'myTravelIndex');
const travelEditor = r => require.ensure([], () => r(require('../page/myTravel/children/travelEditor')), 'travelEditor');

//首页
const home = r => require.ensure([], () => r(require('../page/home/home')), 'home');
const destination = r => require.ensure([], () => r(require('../page/home/children/destination')), 'destination');

//游记详情
const homeTravelDetails = r => require.ensure([], () => r(require('../page/travelDetail/homeTravelDetails.vue')), 'homeTravelDetails');

//404
const error404 = r => require.ensure([], () => r(require('../page/error/404.vue')), 'error404');

export default [{
  path: '/',
  component: App, //顶层路由，对应index.html
  children: [ //二级路由。对应App.vue
    //地址为空时跳转home页面
    {
      path: '',
      redirect: '/home'
    },

    //商品
    {
      path: '/goods',
      component: goods,
      children: [{
        path: 'linesDetails',
        component: linesDetails,
        children: [{
          path: 'option',
          component: linesOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'goodsDetails',
        component: goodsDetails,
        children: [{
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'map',
          component: goodsMap
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'spotsDetails',
        component: spotsDetails,
        children: [{
          path: 'option',
          component: spotsOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'router',
        component: goodsRouter
      }]
    },
    //产品评论
    {
      path: '/comment',
      component: comment
    },
    //游记页面
    {
      path: '/notes',
      component: notes,
      children: [{
        path: 'notesDetails',
        component: notesDetails
      }]
    },
    //攻略页面
    {
      path: '/strategy',
      component: strategy,
      children: [
        {
          path: 'strategyDetails',
          component: strategyDetails
        },
        {
          path: 'homeTravelDetails',
          component: homeTravelDetails
        },
      ]
    },
    //直播
    {
      path: '/live',
      component: live
    },
    //消息中心
    {
      path: '/message',
      component: message,
      meta: {
        requireAuth: true,
      },
      children: [{
        path: 'favour',
        component: messageFavour,
        meta: {
          requireAuth: true,
        },
      }, {
        path: 'comment',
        component: messageComment,
        meta: {
          requireAuth: true,
        },
      }, {
        path: 'notice',
        component: messageNotice,
        meta: {
          requireAuth: true,
        },
        children: [{
          path: 'view',
          component: messageView,
          meta: {
            requireAuth: true,
          },
        }]
      }]
    },
    //个人中心
    {
      path: '/user',
      component: user,
      children: [
        {//常用信息
          path: 'commentInfoIndex',
          component: commentInfoIndex,
          meta: {
            requireAuth: true,
          },
          children: [
            {
              path: 'figureEntering',
              component: editPerson,
              meta: {
                requireAuth: true,
              },
            }, {
              path: 'siteEditor',
              component: siteEditor,
              meta: {
                requireAuth: true,
              },
            },
            {
              path: 'figureEntering',
              component: editPerson,
              meta: {
                requireAuth: true,
              },
            }
          ]
        },
        {//历史记录
          path: 'browsingHistory',
          component: browsingHistory
        },
        {//设置
          path: 'setingIndex',
          component: setingIndex,
          children: [
            {
              path: 'infoSeting',
              component: infoSeting,
              meta: {
                requireAuth: true,
              },
            },
            {
              path: 'about',
              component: about,
            },
            {
              path: 'opinionEditor',
              component: opinionEditor,
            }
          ]
        },
        {//我的收藏
          path: 'collectIndex',
          component: collectIndex,
          meta: {
            requireAuth: true,
          },
        },
        {//我的信息编辑
          path: 'infoEditorIndex',
          component: infoEditorIndex,
          meta: {
            requireAuth: true,
          },
          children: [
            {
              path: 'editPassword',
              component: editPassword,
              meta: {
                requireAuth: true,
              },
            }
          ]
        },
      ]
    },
    {//我的游记
      path: '/myTravelIndex',
      component: myTravelIndex,
      meta: {
        requireAuth: true,
      },
      children: [
        {
          path: 'travelEditor',
          component: travelEditor,
          meta: {
            requireAuth: true,
          },
        },
        {
          path: 'travelDetails',
          component: homeTravelDetails,
          meta: {
            requireAuth: true,
          },
        },
        {
          path: 'noTrueTravelDetails',
          component: strategyDetails,
          meta: {
            requireAuth: true,
          },
        }
      ]
    },
    //首页
    {
      path: '/home',
      component: home,
      children: [
        {
          path: 'destination',
          component: destination
        },
      ]
    },
    //游记详情
    {
      path: 'homeTravelDetails',
      component: homeTravelDetails
    },
    //当前选择城市页
    {
      path: '/city',
      component: city
    },
    //搜索页
    {
      path: '/search',
      component: search,
      children: [{
        path: 'linesDetails',
        component: linesDetails,
        children: [{
          path: 'option',
          component: linesOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'goodsDetails',
        component: goodsDetails,
        children: [{
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'map',
          component: goodsMap
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'spotsDetails',
        component: spotsDetails,
        children: [{
          path: 'option',
          component: spotsOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'strategyDetails',
        component: strategyDetails
      }, {
        path: 'homeTravelDetails',
        component: homeTravelDetails
      }, {
        path: 'router',
        component: goodsRouter
      }]
    },
    //产品搜索
    {
      path: '/productSearch',
      component: productSearch,
      meta: {
        keepAlive: true
      },
      children: [{
        path: 'linesDetails',
        component: linesDetails,
        children: [{
          path: 'option',
          component: linesOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'goodsDetails',
        component: goodsDetails,
        children: [{
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'map',
          component: goodsMap
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'spotsDetails',
        component: spotsDetails,
        children: [{
          path: 'option',
          component: spotsOption
        }, {
          path: 'album',
          component: goodsAlbum
        }, {
          path: 'comment',
          component: comment
        }]
      }, {
        path: 'router',
        component: goodsRouter
      }]
    },
    //确认订单页
    {
      path: '/confirmOrder',
      component: confirmOrder,
      children: [{
        path: 'choosePerson', //选择出行人
        component: choosePerson,
        meta: {
          requireAuth: true,
        },
        children: [{
          path: 'editPerson',//编辑出行人
          component: editPerson,
          meta: {
            requireAuth: true,
          },
        },]
      }, {
        path: 'payment', //付款页面
        component: payment,
        meta: {
          requireAuth: true,
        },
      }]
    },
    //登录注册页
    {
      path: '/login',
      component: login,
      children: [{
        path: 'register',
        component: register,
        children: [{
          path: 'rule',
          component: registerRule,
        }]
      }, {
        path: 'fastRegister',
        component: fastRegister,
        children: [{
          path: 'bindRegister',
          component: bindRegister,
        }]
      }, {
        path: 'reSetPassword',
        component: reSetPassword,
      }]
    },
    {
      path: '/single',
      component: single,
    },
    //订单列表页
    {
      path: '/order',
      component: order,
      meta: {
        requireAuth: true,
      },
      children: [{
        path: 'detail', //订单详情页
        component: orderDetail,
        meta: {
          requireAuth: true,
        },
        children: [{
          path: 'comment', //订单评价
          component: orderComment,
          meta: {
            requireAuth: true,
          },
        }]
      }, {
        path: 'comment', //订单评价
        component: orderComment,
        meta: {
          requireAuth: true,
        },
      }]
    },
    //404页面

  ]
},
//404
  {
    path: '*',
    component: error404,
  }]
