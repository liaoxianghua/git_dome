<template>
  <div class="ui-body ui-gray-bg page-padding">
    <head-top :headTitle="'当前城市：'+cityName">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <router-link to="/search" slot="btn" class="btn-all btn-right btn-search"></router-link>
    </head-top>
    <ul class="tab-btn-blcok">
      <li v-for="(item,index) in tabText" @click.prevent="tabChang(index,item.view)"
          :class="{active:activeIndex===index}">{{item.title}}

      </li>
    </ul>
    <div class="ui-container">
      <div class="country-inside" v-if="currentView==='view1'">
        <ul>
          <li v-for="(item,i) in destination" class="destination-block">
            <router-link :to="{path:'/goods', query:{city:item.title}}">
              <img v-lazy="item.pictureUrl" alt="">
              <div class="city-name">
                <h3>{{item.title}}</h3>
                <p>{{item.subTitle}}</p>
              </div>
            </router-link>
          </li>
        </ul>
      </div>
      <div class="country-outside" v-if="currentView==='view2'">
        <ul>
          <li class="destination-block" v-for="(item,i) in destination">
            <router-link :to="{path:'/goods', query:{city:item.title}}">
              <img v-lazy="item.pictureUrl" alt="">
              <div class="city-name">
                <h3>{{item.title}}</h3>
                <p>{{item.subTitle}}</p>
              </div>
            </router-link>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import headTop from '../../../components/header/head'
  import {likeDestination} from '../../../service/getData'
  import {getStore, setStore,} from 'src/config/mUtils'

  export default {
    components: {
      headTop,
    },
    data(){
      return {
        activeIndex: 0,
        currentView: 'view1',
        cityName: null,
        isdata: false,
        tabText: [
          {title: "国内", view: 'view1', type: 0},
          {title: "出境", view: 'view2', type: 1}
        ],
        destination: [],

        showLoading: true,
      }
    },
    mounted(){
      this.getdestination();
    },
    methods: {
      tabChang(index, currentView){
        this.activeIndex = index;
        this.currentView = currentView;
        this.getdestination();
      },
      async getdestination(){
        this.cityName = getStore('cityName') ? getStore('cityName') : '上海';
        await likeDestination(this.activeIndex).then(res => {
          if (res.status === 200) {
            this.destination = res.obj;
          }
        });
      }
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  .page-padding {
    padding-top: p2r(180);
    z-index: 2;
  }

  .destination-block {
    position: relative;
    > a {
      display: block;
    }
    img {
      width: 100%;
      height: p2r(350);
    }
    .city-name {
      width: 100%;
      position: absolute;
      text-align: center;
      top: 50%;
      transform: translateY(-50%);
      h3 {
        @include sc(p2r(30), $fc2);
        line-height: 1;
        margin-bottom: p2r(24);
      }
      p {
        @include sc(p2r(24), $fc2);
        line-height: 1;
      }
    }
  }

  .city-wrapper {
    padding-bottom: p2r(182);
  }

</style>
