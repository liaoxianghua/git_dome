<template>
  <div class="ui-body ui-white-bg ui-padding-footer">
    <div class="ui-container home-wrapper">
      <header class="block-wrapper ">
        <div class="search-block sides-mar">
          <router-link to="/city" class="city-location">
            <a href="#" class="current-city ellipsis">{{currentCity}}</a>
            <i class="iconfont icon-unfold"></i>
          </router-link>
          <router-link to="/search" class="search-input">
            <p>目的地/景点/酒店/攻略/游记</p>
            <i class="iconfont icon-search"></i>
          </router-link>
        </div>
        <div class="swipe-wrap">
          <swiper :options="swiperOptions" ref="swiper" class="banner-block">
            <template v-for="(item,key) in carouselFigure">
              <swiper-slide>
                <a :href="item.skipUrl">
                  <img v-lazy="item.pictureUrl" alt="">
                </a>
              </swiper-slide>
            </template>
          </swiper>
          <div ref="pagination" class="swipe-pagination">
            <span class="pagination-item" v-for="(item,i) in carouselFigure" :class="{'active':i===0}"></span>
          </div>
        </div>

        <ul class="theme-wrapper" v-if="channelBar">
          <li v-for="(item,i) in channelBar">
            <a :href="item.skipUrl"><img v-lazy="item.pictureUrl" alt=""></a>
            <p class="ellipsis" v-text="item.title"></p>
          </li>
        </ul>
      </header>
      <!--直播-->
      <section class="video-wapper block-wrapper" v-if="directSeeding.length">
        <child-title titleText="直播">
          <router-link to="/live" slot="more" class="more">更多</router-link>
        </child-title>
        <ul class="video-list">
          <li v-for="(time,i) in directSeeding" :key="time.id">
            <div class="video-block">
              <img v-lazy="time.pictureUrl" alt="">
              <!--播放按钮-->
              <router-link :to="{path: '/live', query:{playId: time.id}}" class="live-control"><a class="a-play"></a>
              </router-link>
            </div>
            <p class="inaline ellipsis">{{time.title}}</p>
          </li>
        </ul>
      </section>
      <!--游记-->
      <section class="travel-wrapper block-wrapper" v-if="travels.length">
        <child-title titleText="游记">
          <router-link to="/strategy" slot="more" class="more">更多</router-link>
        </child-title>
        <div class="item" v-for="(item,i) in travels" :key="item.id">
          <router-link :to="{path:'homeTravelDetails',query:{travelId:item.id,isFlag:item.isFlag}}">
            <div class="user-info"><img v-lazy="item.imageUrl" class="img-head"><span
              class="span-name ellipsis">{{item.authorName}}</span></div>
            <div class="notes-title ellipsis">
              <span class="span-title">{{item.title}}</span>
            </div>
            <div class="notes-text">
              <span class="span-text">{{item.subTitle}}</span>
            </div>
            <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
          </router-link>
          <like-group
            :item="item"
          ></like-group>
        </div>
      </section>
      <!--最爱目的地-->
      <section class="bourn-wrapper block-wrapper" v-if="loveDestination.length">
        <child-title titleText="最爱目的地">
          <router-link to="/home/destination" slot="more" class="more">更多</router-link>
          <img slot="img-title" src="../../images/mudidi.png" alt="">
        </child-title>
        <div class="bourn-content">
          <ul class="bourn-block sides-mar">
            <template v-for="(item,i) in loveDestination">
              <router-link tag="li" :to="{path:'/goods', query: {city:item.title}}">
                <img v-lazy="item.pictureUrl" alt="">
                <p>{{item.title}}</p>
              </router-link>
            </template>
          </ul>
        </div>
      </section>
      <!--度假酒店-->
      <section class="grogsgop-wrapper block-wrapper" v-if="holidayhotel.length">
        <child-title titleText="度假酒店">
          <router-link :to="{path:'/goods',query:{productType:3,productSubType:1}}" slot="more" class="more">
            <span>更多</span>
          </router-link>
          <img slot="img-title" src="../../images/jidian.png" alt="">
        </child-title>
        <template v-for="(item,i) in holidayhotel">
          <router-link :to="{path:'/goods/linesDetails',query:{id:item.id}}" class="grogshop-show">
            <img class="home-show-img" v-lazy="item.fileUrl" alt="">
            <a class="a-city" href="javascript:void(0)"> <i class="iconfont icon-shoucang"></i> {{item.city}} </a>
            <p>{{item.productName}}</p>
            <div class="price-show">
              <p class="home-price"><span> <i>￥</i>{{item.minprice}}</span>起</p>
              <a href="javascript:void(0)" class="ui-border" v-for="(text,i) in item.keywordholidayhotelvo"
                 :key="i">{{text.name}}</a>
            </div>
          </router-link>
        </template>
      </section>
      <!--自由行-->
      <section class="freedom-wrapper block-wrapper" v-if="tourist.length">
        <child-title titleText="自由行">
          <router-link :to="{path:'/goods',query:{productType:3,productSubType:2}}" slot="more" class="more">
            <span>更多</span>
          </router-link>
          <img slot="img-title" src="../../images/free.png" alt="">
        </child-title>
        <template v-for="(item,i) in tourist">
          <router-link :to="{path:'/goods/linesDetails',query:{id:item.id}}" class="Walk-blcok">
            <img class="home-show-img" v-lazy="item.fileUrl" alt="">
            <a href="javascript:void(0)"> <i class="iconfont icon-shoucang"></i> {{item.city}} </a>
            <p>{{item.productName}}</p>
            <div class="price-show">
              <p class="home-price"><span> <i>￥</i>{{item.minprice}}</span>起</p>
              <a href="javascript:void(0)">{{item.saleNum}}人出游</a>
            </div>
          </router-link>
        </template>
      </section>
      <!--直通车-->
      <section class="freedom-wrapper block-wrapper" v-if="throughtrains.length">
        <child-title titleText="直通车">
          <router-link :to="{path:'/goods',query:{productType:3,productSubType:3}}" slot="more" class="more">
            <span>更多</span>
          </router-link>
          <img slot="img-title" src="../../images/throughcar.png" alt="">
        </child-title>
        <template v-for="(item,i) in throughtrains">
          <router-link :to="{path:'/goods/linesDetails',query:{id:item.id}}" class="Walk-blcok">
            <img class="home-show-img" v-lazy="item.fileUrl" alt="">
            <a href="javascript:void(0)"> <i class="iconfont icon-shoucang"></i> {{item.city}} </a>
            <p>{{item.productName}}</p>
            <div class="price-show">
              <p class="home-price"><span> <i>￥</i>{{item.minprice}}</span>起</p>
              <a href="javascript:void(0)">{{item.saleNum}}人出游</a>
            </div>
          </router-link>
        </template>
      </section>
    </div>
    <foot-guide></foot-guide>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import childTitle from 'src/components/common/travelblock/traveTitle'
  import likeGroup from 'src/components/common/like'
  import footGuide from 'src/components/footer/footGuide'

  import {swiper, swiperSlide} from 'vue-awesome-swiper'
  import Swiper from "../../../node_modules/vue-awesome-swiper/swiper";
  import SwiperSlide from "../../../node_modules/vue-awesome-swiper/slide";

  import {homeIndex, moreVideo, collectionEdit, Praise} from '../../service/getData'
  import {getStore} from 'src/config/mUtils'

  export default {
    data: function () {
      let _this = this;
      return {

        currentCity: null,
        directSeeding: [], //直播
        travels: [], //游記
        carouselFigure: [], //轮播
        channelBar: [], //主题栏
        loveDestination: [], //最爱目的地
        holidayhotel: [], //酒店
        throughtrains: [],  //直通车
        tourist: [], //自由行
        //isCollection: null,

        videoWrapper: {},

        preventRepeatRequest: false, //接口节流

        swiperOptions: {
          autoplay: 3000,
          onSlideChangeStart: function (swiper) {
            for (let i = 0; i < _this.$refs.pagination.children.length; i++) {
              if (i === swiper.activeIndex) {
                _this.$refs.pagination.children[i].className = 'pagination-item active';
              } else {
                _this.$refs.pagination.children[i].className = 'pagination-item';
              }
            }
          }
        }
      }
    },
    components: {
      headTop,
      childTitle,
      footGuide,
      likeGroup,
      Swiper,
      SwiperSlide,
    },
    computed: {},
    mounted(){
      this.$nextTick(() => {
        this.getCity();
        this.initDate();
      });
    },
    methods: {
      goplay(vid){
        this.$router.push({path: '/live', query: {playid: vid}})
      },

      getCity(){
        let selectCity = this.$route.query.cityName;
        if (selectCity) {
          this.currentCity = selectCity;
        } else if (getStore('cityName')) {
          this.currentCity = getStore('cityName')
        } else {
          this.currentCity = '上海';
        }
      },

      //收藏
      collectionEdit: async function (collectionId, index) {
        if (this.preventRepeatRequest) {
          return false;
        }

        this.preventRepeatRequest = true;
        await collectionEdit(2, collectionId, this.travels[index].isCollection ? 0 : 1).then(res => {
          if (res.status === 200) {
            this.travels[index].isCollection = this.travels[index].isCollection ? 0 : 1;
            this.preventRepeatRequest = false;
          }
        });
      },
      //点赞
      async travelPraise(collectionId, index){
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await Praise({
          id: collectionId,
          praiseType: 1
        }).then(res => {
          if (res.status === 200) {
            this.travels[index].addend = parseInt(res.obj.directSeed);
            this.preventRepeatRequest = false;
          }
        });
      },

      async initDate(){
        await homeIndex(this.currentCity).then(data => {
          if (data.status === 200) {
            this.directSeeding = data.obj.directSeeding;
            let travelsList = data.obj.travels;
            this.carouselFigure = data.obj.carouselFigure;
            this.channelBar = data.obj.channelBar;
            this.loveDestination = data.obj.loveDestination;
            this.holidayhotel = data.obj.holidayhotel;
            this.throughtrains = data.obj.throughtrains;
            this.tourist = data.obj.tourist;

            travelsList.forEach(item => {
              item.isCollection = item.isFlagCollect > 0 ? 1 : 0;
              item.addend = item.isFlag > 0 ? -1 : 0;
            });

            this.travels = travelsList;
          }
        });
      }
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .home-wrapper {
    padding-top: 0;
  }

  .content-wrapper {
    height: 100%;
    overflow: auto;
  }

  /*头部  搜索-banner块-主题块*/
  header.block-wrapper {
    position: relative;
    border-top: none;
  }

  .search-block {
    padding: 0 p2r(20);
    display: flex;
    align-items: center;
    width: 100%;
    position: absolute;
    top: p2r(0);
    z-index: 2;
  }

  .city-location {
    display: flex;
    align-items: center;
    font-size: p2r(30);
    padding-right: p2r(30);
    white-space: nowrap;
    overflow: hidden;
    position: relative;
    .current-city {
      max-width: p2r(146);
      display: inline-block;
      overflow: hidden;
    }
    i {
      position: absolute;
      right: 0;
      font-size: p2r(30);
    }
  }

  .search-input {
    flex: 5;
    padding: p2r(10);
    width: 100%;
    display: flex;
    position: relative;
    i {
      font-size: p2r(24);
    }
    > p {
      @include sc(p2r(26), $fc);
      line-height: p2r(56);
      @include wh(100%, p2r(56));
      background: $bgc2;
      border: none;
      border-radius: p2r(8);
      padding-left: p2r(48);
      overflow: hidden;
    }
    .icon-search {
      position: absolute;
      top: 50%;
      left: p2r(20);
      transform: translateY(-50%);
      color: $fc;
    }
  }

  .banner-block {
    height: p2r(350);
    img {
      width: 100%;
      height: 100%;
    }
  }

  .swipe-wrap {
    position: relative;

    .swipe-pagination {
      bottom: 0;
      width: 100%;
      position: absolute;
      text-align: center;
      z-index: 2;
      .pagination-item {
        margin: 0 5px;
        width: 8px;
        height: 8px;
        display: inline-block;
        border-radius: 100%;
        background: #000;
        opacity: 0.7;
      }
      .active {
        opacity: 1;
        background: #fff;
      }
    }
  }

  .theme-wrapper {
    background: $bgc2;
    overflow: auto;
    white-space: nowrap;
    li {
      display: inline-block;
      padding: p2r(6) 0 p2r(24) 0;
      a {
        box-sizing: content-box;
        display: block;
        width: p2r(100);
        padding: p2r(24) p2r(29);
      }
      p {
        font-size: p2r(24);
        text-align: center;
        line-height: 1.2;
        margin: 0 p2r(8);
      }
      img {
        overflow: hidden;
        @include wh(p2r(100), p2r(100));
      }
    }
  }

  //直播
  .video-wapper, .block-wrapper, .travel-wrapper, .bourn-wrapper, .grogsgop-wrapper {
    @include bmb;
  }

  .video-list {
    padding: p2r(20) p2r(30);
    justify-content: space-between;
    display: flex;
    li {
      width: 270/580*100%;
      p {
        line-height: (44/26);
        font-size: p2r(26);
        text-align: center;
      }
    }
  }

  .video-block {
    position: relative;
    height: p2r(135);
    img {
      width: 100%;
      height: 100%;
    }
    .live-control {
      position: absolute;
      display: block;
      width: 100%;
      top: 0;
      bottom: 0;
      background: rgba(0, 0, 0, .3);
      a {
        display: inline-block;
        @include wh(p2r(60), p2r(60));
      }
      .a-play {
        @include center;
        @include bis("../../images/icon/icon_live_play.png");
      }
      .a-pause {
        border-radius: 50%;
        background: rgba(0, 0, 0, .7);
        text-align: center;
      }
      .a-pause:after {
        content: '';
        display: inline-block;
        width: p2r(20);
        height: p2r(40);
        border-left: p2r(5) solid rgba(255, 255, 255, .8);
        border-right: p2r(5) solid rgba(255, 255, 255, .8);
        margin-top: p2r(20);
      }
    }
  }

  .home-wrapper {
    //游记
    .item:last-child {
      .notes-fav {
        border-bottom: none;
      }
    }

    .item {
      position: relative;
      width: 100%;
      overflow: hidden;
      padding: 0 p2r(20);
      &:first-child {
        margin-top: 0;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
          border-radius: 50%;
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
          float: left;
          display: block;
          width: 80%;
        }
      }
      .notes-info {
        overflow: hidden;
        li {
          width: 50%;
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(20);
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(20);
          }
          span {
            @include sc(p2r(24), $mc);
          }
        }
        .icon-time {
          @include bis('../../images/icon/icon_time.png')
        }
        .icon-money {
          @include bis('../../images/icon/icon_money.png')
        }
        .icon-like {
          @include bis('../../images/icon/icon_like.png')
        }
        .icon-day {
          @include bis('../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        @include ellipsisrows(4);
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }

      .notes-title {
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(360));
        margin-top: p2r(12);
        overflow: hidden;
        .img-thum {
          width: 100%;
        }
      }
      .notes-fav {
        @include fj(left);
        position: relative;
        border-bottom: 1px solid $bc;
        li {
          padding-bottom: p2r(16);
          span {
            @include sc(p2r(24), $fc);
            height: p2r(35);
            line-height: p2r(35);
            padding: 0 p2r(30) 0 p2r(55);
            background-size: auto 100%;
            background-repeat: no-repeat;
          }
          .span-fav {
            background-image: url(../../images/icon/icon_list_fav.png);
          }
          .span-msg {
            background-image: url(../../images/icon/icon_list_msg.png);
          }
          .span-collect {
            background-image: url(../../images/icon/icon_list_collect.png);
          }
          .span-view {
            background-image: url(../../images/icon/icon_list_view.png);
          }
          .span-share {
            background-image: url(../../images/icon/share-icon.png);
          }
          .i-text {
            display: inline-block;
            border: 1px solid $bc;
            @include borderRadius(p2r(13));
            @include sc(p2r(20), $fc);
            line-height: p2r(30);
            font-style: normal;
            padding: 0 p2r(12);
          }
        }

        .time {
          @include ct;
          right: 0;
        }
      }
    }
  }

  /*最爱目的地*/
  .bourn-content {
    overflow: auto;
  }

  .bourn-block {
    padding: p2r(20) p2r(10);
    overflow: auto;
    white-space: nowrap;
    li {
      display: inline-block;
      @include wh(p2r(320), p2r(200));
      overflow: hidden;
      position: relative;
      padding: 0 p2r(10) p2r(20) p2r(10);
      p {
        position: absolute;
        bottom: p2r(20);
        left: p2r(25);
        line-height: (42/24);
        @include sc(p2r(24), $fc2);
      }
      img {
        width: 100%;
        min-height: p2r(200);
        @include ct;
      }
    }
  }

  //酒店
  .grogshop-show:last-child {
    .price-show {
      border-bottom: none;
    }
  }

  .grogshop-show {
    padding: p2r(20);
    display: block;
    position: relative;
    padding-bottom: 0;
    .a-city {
      position: absolute;
      color: $fc2;
      font-size: p2r(24);
      background: rgba(0, 0, 0, .5);
      top: p2r(20);
      vertical-align: middle;
      padding: 0 p2r(15);
      line-height: (30/24);
    }
    img {
      width: 100%;
      height: p2r(360);
    }
    > p {
      font-size: p2r(30);
      line-height: 1.4;
    }
    .price-show {
      /*display: flex;
      flex-wrap: wrap;*/
      padding-bottom: p2r(20);
      border-bottom: 1px solid $bc;
      overflow: hidden;
      p, a {
        float: left;
      }
      a {
        margin-bottom: p2r(5);
        margin-right: p2r(5);
        padding: 0 p2r(12);
        border: 1px solid $blue;
        color: $blue;
        border-radius: p2r(5);
        font-size: p2r(24);
        text-align: center;
      }
    }

  }

  //价格样式
  .home-price {
    color: $fc;
    margin-right: p2r(5);
    font-size: p2r(24);
    span {
      color: $fc3;
      font-size: p2r(30);
      font-weight: bold;
      margin-right: p2r(5);
      i {
        font-size: p2r(20);
        font-style: normal;
      }
    }
  }

  //自由行
  .Walk-blcok:last-child {
    .price-show {
      flex-wrap: wrap;
      border-bottom: none;
    }
  }

  .Walk-blcok {
    display: block;
    padding: p2r(20);
    padding-bottom: 0;
    position: relative;
    > img {
      width: 100%;
      height: p2r(360);
    }
    > p {
      font-size: p2r(30);
      line-height: (42/30);
      padding: p2r(6) 0;
    }
    > a {
      position: absolute;
      color: $fc2;
      font-size: p2r(24);
      background: rgba(0, 0, 0, .5);
      top: p2r(20);
      vertical-align: middle;
      padding: 0 p2r(15);
      line-height: (30/24);
    }
    .price-show {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      border-bottom: 1px solid $bc;
      padding-bottom: p2r(20);
      a {
        color: $fc;
        font-size: p2r(24);
        align-self: center;
      }
    }
  }
</style>
