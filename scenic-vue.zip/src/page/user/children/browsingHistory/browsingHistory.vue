<template>
  <div class="ui-body page-padding ui-white-bg">
    <head-top headTitle="浏览历史">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <div slot="btn" class="btn-all btn-right btn-char" @click="clearHistory">清空</div>
    </head-top>
    <ul class="tab-btn-blcok tab-pattern2">
      <li v-for="(item,index) in tabText" @click.prevent="tabChang(index,item.view)"
          :class="{active:activeIndex===index}"><span>{{item.title}}</span></li>
    </ul>
    <div class="ui-container">
      <section class="tab-content-blcok">
        <div id="view1" v-if="currentView==='view1'">
          <div class="time-node-block" v-if="productList.length">
            <template v-for="(product,key) in productList">
              <h3 class="time-text">{{product.t | formatDate}}</h3>
              <ul class="browse-list">
                <li v-for="item in product.id">
                  <router-link :to="{path:'/goods/'+reControllerName(item.productType),query:{id:item.id}}" tag="div">
                    <div class="img-box">
                      <img v-lazy="item.pictuerName">
                      <p>{{item.productSubTypeName}}</p>
                      <i class="current-city">{{item.cityName}}</i>
                    </div>
                    <div class="describe-box">
                      <p class="text-describe">{{item.productName}}</p>
                      <div class="label">
                        <span v-for="v in item.keyWordProduct">{{v.name}}</span>
                      </div>
                      <div class="price">
                        <p>
                          <span><i>￥</i>{{item.price}}</span>
                          <template v-if="item.productType != 2">起</template>
                        </p>
                        <p>{{item.saledNum}}人购买</p>
                      </div>
                    </div>
                  </router-link>
                </li>
              </ul>
            </template>
          </div>
          <p v-else class="no-hint">暂时没有浏览历史，快去浏览吧</p>
        </div>
        <div id="view2" class="history-travel" v-if="currentView==='view2'">
          <div class="time-node-block" v-if="strategyList.length">
            <template v-for="strategy in strategyList">
              <h3 class="time-text">{{strategy.t | formatDate}}</h3>
              <div class="item" v-for="item in strategy.id">
                <router-link :to="{path:'/homeTravelDetails',query:{travelId:item.id}}">
                  <div class="user-info"><span class="span-name ellipsis">{{item.title}}</span></div>
                  <div class="notes-title"><span class="span-title">{{item.subTitle}}</span></div>
                  <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
                </router-link>
                <like-group
                  :item="item"
                ></like-group>
              </div>
            </template>
          </div>
          <p v-else class="no-hint">暂时没有浏览历史，快去浏览吧</p>
        </div>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import likeGroup from 'src/components/common/like'

  import {myCollection, goodsTypes, historyQuery} from 'src/service/getData'

  import {setStore, getStore} from 'src/config/mUtils'

  export default {
    components: {
      headTop,
      likeGroup,
    },
    data(){
      return {
        activeIndex: 0,
        currentView: 'view1',
        isdata: false,
        tabText: [
          {title: "产品", view: 'view1'},
          {title: "游记攻略", view: 'view2'},
        ],
        productList: [],//收藏产品列表
        strategyList: [],//攻略游记列表
        productViewList: [],

        type: null,
        productId: '',
        strategyId: '',
        historyData: null,
        productData: [],
        strategyData: [],
        dateTimes: [],
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
    },
    mounted(){
      this.getHistory();
    },
    methods: {
      getHistory(){
        if (!getStore('browseHistory')) {
          return
        }
        this.historyData = JSON.parse(getStore('browseHistory'));
        let history = this.historyData.product;
        for (let key in history) {
          //history[key].id = history[key].id.reverse();
          this.productData.push(history[key]);
        }
        this.productData = this.productData.sort((a, b) => {
          return b.t - a.t;
        });

        if (this.productData.length) {
          for (let i = 0; i < this.productData.length; i++) {
            this.productId += (this.productId === '' ? '' : ',') + this.productData[i].id.join(',');
          }
        }

        history = this.historyData.strategy;
        for (let key in history) {
          //history[key].id = history[key].id.reverse();
          this.strategyData.push(history[key]);
        }

        this.strategyData = this.strategyData.sort((a, b) => {
          return b.t - a.t;
        });
        if (this.strategyData.length) {
          this.strategyId = '';
          for (let i = 0; i < this.strategyData.length; i++) {
            this.strategyId += (this.strategyId === '' ? '' : ',') + this.strategyData[i].id.join(',');
          }
        }

        this.initData();

      },

      initData: async function () {
        let list = [];
        if (this.strategyId) {
          let res = await historyQuery(2, this.strategyId);
          if (res.status !== 200) {
            return;
          }
          list = res.obj.myConllectionOfTravel;
          if (this.strategyData.length) {
            for (let key = 0; key < this.strategyData.length; key++) {
              let item = this.strategyData[key].id;
              let arr = [];
              for (let i = 0; i < item.length; i++) {
                for (let j = 0; j < list.length; j++) {
                  if (list[j].id == item[i]) {
                    arr.push(list[j]);
                  }
                }
              }
              if (arr.length) {
                this.strategyList.push(this.strategyData[key]);
                this.strategyData[key].id = arr;
              }
            }
          }
        }

        if (this.productId) {
          list = [];
          let res = await historyQuery(1, this.productId)
          if (res.status !== 200) {
            return;
          }
          list = res.obj.myPushPraiseOfProduct;

          if (this.productData.length) {
            for (let key = 0; key < this.productData.length; key++) {
              let item = this.productData[key].id;
              let arr = [];
              for (let i = 0; i < item.length; i++) {
                for (let j = 0; j < list.length; j++) {
                  if (list[j].id == item[i]) {
                    arr.push(list[j]);
                  }
                }
              }
              if (arr.length) {
                this.productList.push(this.productData[key]);
                this.productList[key].id = arr;
              }
            }
          }
        }
      },

      async clearHistory(){
        if (!getStore('browseHistory')) {
          return
        }
        let history = JSON.parse(getStore('browseHistory'));
        await this.messageBox.confirm('是否清空历史记录？');
        if (this.activeIndex) {
          history.strategy = {};
          this.strategyData = [];
          this.strategyList = [];
        } else {
          history.product = {};
          this.productData = [];
          this.productList = [];
        }
        setStore('browseHistory', JSON.stringify(history));
      },

      reControllerName: function (productType) {
        if (productType === 1) {
          return 'spotsDetails';
        }
        else if (productType === 2) {
          return 'goodsDetails';
        }
        else if (productType === 3) {
          return 'linesDetails';
        }
      },

      tabChang(index, currentView){
        this.activeIndex = index;
        this.currentView = currentView;
      },
    }

  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .page-padding{
    padding-top: p2r(180);
  }

  .empty {
    @include sc(p2r(28), $fc);
    text-align: center;
    margin: p2r(64) 0;
  }

  .history-travel {
    .item {
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      overflow: hidden;
      padding: 0 p2r(20);
      &:first-child {
        margin-top: 0;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(6) p2r(12) 0 0;
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
        }
        .span-name {
          @include sc(p2r(32), $mc);
          line-height: p2r(40);
          display: block;
          width: 100%;
        }
      }
      .notes-info {
        overflow: hidden;
        li {
          width: 50%;
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(20);
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(20);
          }
          span {
            @include sc(p2r(24), $mc);
          }
        }
        .icon-times {
          @include bis('../../../../images/icon/icon_time.png')
        }
        .icon-moneys {
          @include bis('../../../../images/icon/icon_money.png')
        }
        .icon-likes {
          @include bis('../../../../images/icon/icon_like.png')
        }
        .icon-days {
          @include bis('../../../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        line-height: 2;
        .span-title {
          @include sc(p2r(26), $mc);
          @include ellipsisrows(4);
        }
      }
      .notes-text {
        .span-text {
          @include sc(p2r(24), $mc);
          @include ellipsisrows(4);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        margin-top: p2r(12);
        .img-thum {
          width: 100%;
        }
      }
    }
  }

  .time-node-block {
    h3 {
      @include sc(p2r(24), $fc);
      line-height: (70/24);
      padding: 0 p2r(20);
      font-weight: 100;
      background: $bc;
    }
    > ul {
      > li {
        padding: p2r(20);
        background: $fc2;
        & > div {
          width: 100%;
          display: flex;
        }
      }
      /*图片盒子*/
      .img-box {
        width: (180/600)*100%;
        position: relative;
        i {
          position: absolute;
          left: 0;
          top: 0;
          @include sc(p2r(24), $fc2);
          background: rgba(0, 0, 0, .5);
          padding: p2r(2) p2r(15) p2r(2) p2r(5);
        }
        i:before {
          content: '';
          display: inline-block;
          width: p2r(15);
          height: p2r(20);
          @include bis('../../../../images/icon/location-icon.png');
          vertical-align: middle;
          margin-right: p2r(10);
        }
        img {
          @include wh(p2r(180), p2r(150));
        }
        p {
          @include sc(p2r(24));
          background: $bgc;
          line-height: (40/24);
          text-align: center;
        }
      }
      /*简介盒子*/
      .describe-box {
        width: (400/600)*100%;
        padding-left: p2r(20);
        /*简介文字*/
        .text-describe {
          @include sc(p2r(28));
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        /*标签*/
        .label {
          /*display: flex;
          flex-wrap: wrap;*/
          padding: p2r(15) 0;
          overflow: hidden;
          span {
            @include sc(p2r(24), $blue);
            padding: 0 p2r(15);
            border: 1px solid $blue;
            border-radius: p2r(3);
            margin-right: p2r(10);
            margin-top: p2r(2);
            margin-bottom: p2r(2);
            display: inline-block;
            float: left;
          }
          span:last-child {
            margin-right: 0;
          }
        }
        /*价格*/
        .price {
          display: flex;
          @include fj(space-between);
          p {
            @include sc(p2r(22), $fc);
          }
          span:first-child {
            @include sc(p2r(30), $fc3);
            font-weight: bold;
            i {
              @include sc(p2r(22), $fc3);
            }
          }
        }
      }
    }
  }
</style>
