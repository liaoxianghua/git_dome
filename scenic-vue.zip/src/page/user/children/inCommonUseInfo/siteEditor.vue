<template>
  <div class="ui-body ui-padding ui-gray-bg">
    <head-top headTitle="新增常用地址">
      <a class="btn-left btn-char btn-all" href="#" @click.prevent="$router.go(-1)" slot="btn">取消</a>
      <a class="btn-right btn-char btn-all" href="#" @click.prevent="addsiteInfo" slot="btn">保存</a>
    </head-top>
    <div class="ui-container">
      <ul class="site-list">
        <li><p>收件人</p><input type="text" placeholder="姓名" v-model="sitedata.receiveName" maxlength="25"></li>
        <li><p>联系手机</p><input type="tel" placeholder="手机号" maxlength="11" v-model="sitedata.receivePhone"></li>
        <li class="next-icon"><p>所在地区</p>
          <a @click="changeShowSited" class="sitedisplay" type="text"
             :class="{'sitedisplay-active':sitedata.countryName}">
            {{sitedata.countryName ? sitedata.countryName + ' ' + (sitedata.provinceName || "") + ' ' + (sitedata.cityName || "")  : '请选择地址'}}
        </a>
        </li>
        <li><p>详细地址</p><input type="text" placeholder="街道/村镇" v-model="sitedata.addressDetail" maxlength="150"></li>
        <li><p>邮政编码</p><input type="tel" placeholder="123456" v-model="sitedata.postCode" maxlength="6"></li>
      </ul>
      <div class="set-self">
        <p>设为默认地址</p>
        <comp-switch :isOff="sitedata.isDefault" @changer="changSelf"></comp-switch>
      </div>
      <div class="delete-btn" v-if="id"><span @click="deleteSiteInfo"><i
        class="icon iconfont icon-delete"></i><br>删除</span>
      </div>
      <transition name="router-slid" mode="out-in">
        <address-selecrt @siteData="changeData" @closeSiteSelect='changeShowSited' v-if="isSited"></address-selecrt>
      </transition>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>
<script>
  import headTop from 'src/components/header/head'
  import addressSelecrt  from 'src/components/common/regionSelect'
  import compSwitch from 'src/components/common/switch'

  import {mapState, mapMutations} from 'vuex'
  import {rightPhoneNumber} from 'src/config/mUtils.js'
  import {siteAdd, siteDelete, siteEdit, siteSingle, siteQuery} from 'src/service/getData'

  export default {
    components: {
      headTop,
      addressSelecrt,
      compSwitch
    },
    data(){
      return {
        id: null,  //地址id
        isamend: true,
        isSited: false,


        sitedata: {
          receiveName: null,
          receivePhone: null,
          addressDetail: null,
          postCode: null,
          countryId: null,
          countryName: null,
          provinceId: null,
          provinceName: null,
          cityId: null,
          cityName: null,
          isDefault: 0,
        },
      }
    },
    mounted(){
      if (this.$route.query.id) {
        this.id = this.$route.query.id;
        this.singleSiteInfo();
      }
    },
    computed: {
      ...mapState([
        'mySite',
      ])
    },
    methods: {
      ...mapMutations([
        'INIT_SITE'
      ]),

      //数据更新
      changeData(obj){
        this.sitedata.countryId = obj.state;
        this.sitedata.provinceId = obj.province || null;
        this.sitedata.cityId = obj.city;

        this.sitedata.countryName = obj.State;
        this.sitedata.provinceName = obj.Province || null;
        this.sitedata.cityName = obj.City || null ;
      },

      //关闭/打开城镇选择页面
      changeShowSited(){
        this.isSited = !this.isSited;
      },

      changSelf: function () {
        this.sitedata.isDefault = this.sitedata.isDefault ? 0 : 1;
      },

      async addsiteInfo(){
        if (!this.sitedata.receiveName) {
          this.Toast("请输入收件人");
          return
        }
        if (!this.sitedata.receivePhone) {
          this.Toast("请输入联系手机");
          return
        }
        if (!rightPhoneNumber(this.sitedata.receivePhone)) {
          this.Toast("手机格式不正确");
          return
        }
        if (!this.sitedata.countryId) {
          this.Toast("请选择所在地区");
          return
        }
        if (!this.sitedata.addressDetail) {
          this.Toast("请输入详细地址");
          return
        }
        if (!this.sitedata.postCode) {
          this.Toast("请输入邮政编码");
          return
        }
        if (this.id) {
          //编辑单个地址信息
          let res = await siteEdit(this.sitedata, this.id);
          if (res.status === 200) {
            this.initSiteInfo();
            await this.messageBox.alert(res.message);
            this.$router.go(-1);
          }
        } else {
          //添加单个地址信息
          let res = await siteAdd(this.sitedata);
          if (res.status === 200) {
            this.initSiteInfo();
            await this.messageBox.alert(res.message);
            this.$router.go(-1);
          }
        }
      },

      //删除单个地址信息提交
      async deleteSiteInfo(){
        await this.messageBox.confirm('确认要删除该地址？');

        let res = await siteDelete(this.id);
        if (res.status === 200) {
          this.initSiteInfo();
          await this.messageBox.alert(res.message);
          this.$router.go(-1);
        }
      },

      //查询单个地址信息
      async singleSiteInfo(){
        await siteSingle(this.id).then(res => {
          if (res.status = 200) {
            let key = null;
            for (key in this.sitedata) {
              this.sitedata[key] = res.obj.memberAddressInfo[key];
            }
          }
        });
      },

      //常用信息列表
      async initSiteInfo(){
        await siteQuery().then(res => {
          if (res.status === 200) {
            this.INIT_SITE(res.obj.memberAddressList);
          }
        });
      }
    },
    watch: {}
  }
</script>

<style lang="scss">
  @import '../../../../style/mixin';
  /*编辑列表表单*/
  .site-list {
    li {
      display: flex;
      padding: 0 p2r(30);
      background: $bgc2;
      border-bottom: 1px solid $bc;
      p {
        width: 172/(640-60)*100%;
        font-size: p2r(26);
        height:p2r(80);
        line-height: (80/26);
      }
      input {
        height:p2r(80);
        flex: 1;
        font-size:p2r(26);
      }
      .sitedisplay {
        height:p2r(80);
        line-height: p2r(80);
        flex: 1;
        display: block;
        font-size: p2r(26);
        color: $fc;
      }
      .sitedisplay-active {
        color: $mc;
      }
    }
  }

  /*设为常用地址*/
  .set-self {
    margin-top: p2r(50);
    @include fj(space-between);
    align-items: center;
    border-top: 1px solid $bc;
    border-bottom: 1px solid $bc;
    font-size: p2r(28);
    padding: p2r(10) p2r(20);
    background: $fc2;

  }

  /*删除按钮*/
  .delete-btn {
    margin: p2r(24) 0;
    text-align: center;
    @include sc(p2r(24), $mc);
    line-height: 1.2;
    .icon {
      @include sc(p2r(56), $blue);
      display: inline-block;
    }
  }

  .next-icon {
    position: relative;
  }

  .next-icon:after {
    content: '';
    display: inline-block;
    width: p2r(16);
    height: p2r(27);
    @include bis('../../../../images/icon/enter-icon.png');
    @include ct();
    right: p2r(30);
  }
</style>
