<template>
  <div class="ui-body ui-gray-bg page-padding">
    <head-top headTitle="常用信息">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <ul class="tab-btn-blcok tab-pattern1">
      <li v-for="(item,index) in tabText" @click.prevent="tabChang(index,item.view)"
          :class="{active:activeIndex===index}">{{item.title}}
        </li>
    </ul>
    <div class="ui-container">
      <section class="tab-content-blcok">
        <div id="view1" v-if="currentView==='view1'">
          <router-link to='commentInfoIndex/figureEntering' class="add-btn" href="#"><span>+</span>新增常用旅客</router-link>
          <p class="no-hint" v-show="!myPerson.length">您还没有常用旅客，赶快添加吧</p>
          <ul class="info-list  clear" v-show="myPerson.length">
            <li v-for="item in myPerson">
              <router-link :to="{path:'commentInfoIndex/figureEntering',query:{id:item.id}}">
                <p><span>{{item.nameCh}}</span><span>{{item.nameEnF}}<template
                  v-if="item.nameEnF && item.nameEnS">\</template>{{item.nameEnS}}</span><i class="self-icon"
                                                                                            v-if="item.isSelf">本人</i>
                </p>
                <template v-if="item.documents.length && item.phoneCh">
                  <p>
                    <span>{{documentType[item.documents[0].documentType]}}：</span>
                    <span>{{item.documents[0].documentNo}}</span>
                  </p>
                  <p><span>手机号码：</span><span>{{item.phoneCh}}</span></p>
                </template>
                <template v-else>
                  <span class="a-router">信息不全，点击补全</span>
                </template>
              </router-link>
            </li>
          </ul>
        </div>
        <div id="view2" v-if="currentView==='view2'">
          <router-link to="/user/commentInfoIndex/siteEditor" class="add-btn"><span>+</span>新增常用地址</router-link>
          <p class="no-hint" v-show="!mySite.length">您还没有常用地址，赶快添加吧</p>
          <ul class="info-list  clear" v-show="mySite.length">
            <li v-for="(item,i) in mySite">
              <router-link :to="{path:'/user/commentInfoIndex/siteEditor', query:{id:item.id}}">
                <p><span>{{item.receiveName}}</span><span>{{item.receivePhone}}</span><i class="self-icon"
                                                                                         v-if="item.isDefault">默认</i>
                </p>
                <p><span>地址</span><span>{{item.addressDetail}}</span></p>
                <p><span>邮编</span><span>{{item.postCode}}</span></p>
              </router-link>
            </li>
          </ul>
        </div>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {mapState, mapMutations} from 'vuex'
  import {getPersonList, getCredential, siteQuery} from 'src/service/getData'

  export default {
    components: {
      headTop
    },
    data(){
      return {
        activeIndex: 0,
        currentView: 'view1',
        tabText: [
          {title: "出行人", view: 'view1'},
          {title: "地址", view: 'view2'}
        ],

        documentType: {},
        commonSite: [],
      }
    },
    mounted(){
      this.initData();
    },
    computed: {
      ...mapState([
        'myPerson', 'mySite'
      ]),
    },
    methods: {
      ...mapMutations([
        'INIT_PERSON', 'INIT_SITE'
      ]),
      tabChang(index, currentView){
        this.activeIndex = index;
        this.currentView = currentView;
      },
      async initData(){
        let res = await getCredential();
        if (res.status !== 200) {
          return;
        }

        res.obj.credentialTypes.forEach((val) => {
          this.documentType[val.value] = val.name;
        });

        res = await getPersonList();
        if (res.status !== 200) {
          return;
        }

        this.INIT_PERSON(res.obj.commonTripManList);

        await siteQuery().then(res => {
          if (res.status === 200) {
            this.INIT_SITE(res.obj.memberAddressList);
          }
        });
      }
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .page-padding{
    padding-top: p2r(176);
  }

  .tab-content-blcok {
    .add-btn {
      width: 461/640*100%;
      display: block;
      text-align: center;
      background: $blue;
      @include sc(p2r(30), $fc2);
      margin: p2r(33) auto;
      line-height: (80/30);
      border-radius: p2r(4);
      span {
        @include sc(p2r(40), $fc2);
        line-height: 1;
        margin-right: p2r(10);
        font-weight: 100;
      }
    }

    .isdata {
      text-align: center;
      @include sc(p2r(22), $fc);
    }

    .info-list {
      border-top: 1px solid $bc;
      li {
        border-bottom: 1px solid $bc;
        background: $bgc2;
        padding: p2r(15) p2r(32);
        .self-icon {
          vertical-align: super;
          @include sc(p2r(22), $fc3);
          border-radius: p2r(3);
          border: 1px solid $fc3;
          padding: 0 p2r(6);
          height: p2r(30);
          line-height: p2r(26);
          margin-left: p2r(10);
        }
        > a {
          position: relative;
          display: block;
          padding-right: p2r(24);
        }
        > a:after {
          content: '';
          display: inline-block;
          width: p2r(16);
          height: p2r(27);
          @include bis('../../../../images/icon/enter-icon.png');
          @include ct;
          right: 0;
        }
        p {
          line-height: (36/24);
          overflow: hidden;
          span {
            @include sc(p2r(24), $fc);
            text-align: left;
            float: left;
            display: inline-block;
          }
          span:first-child {
            width: 30%;
          }
          span:last-child {
            width: 70%;
          }
        }
        .a-router {
          @include sc(p2r(24), $blue);
          width: 100%;
        }
        p:first-child {
          line-height: (48/30);
          align-items: center;
          span {
            @include sc(p2r(30), $mc);
          }
        }

      }
    }
  }
</style>
