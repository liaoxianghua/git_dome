<template>
  <div class="ui-body collect-padding ui-white-bg">
    <head-top headTitle="我的收藏">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <ul class="tab-btn-blcok tab-pattern2">
      <li v-for="(item,index) in tabText" @click.prevent="tabChange(index,item.view)"
          :class="{active:activeIndex===index}">
        <span>{{item.title}}</span>
      </li>
    </ul>
    <div class="ui-container" v-if="!showLoading" ref="container">
      <section class="tab-content-blcok">
        <div id="view1" v-if="currentView==='view1'">
          <div class="time-node-block">
            <ul class="browse-list" v-show="productList.length">
              <li v-for="item in productList">
                <router-link :to="{path:'/goods/'+reControllerName(item.productType),query:{id:item.id}}" tag="div">
                  <div class="img-box">
                    <img v-lazy="item.pictuerName">
                    <p>{{item.productSubTypeName}}</p>
                    <i class="current-city">{{item.cityName}}</i>
                  </div>
                  <div class="describe-box">
                    <p class="text-describe">{{item.productName}}</p>
                    <div class="label">
                      <span v-for="v in item.keyWordProduct">{{v.name}}</span>
                    </div>
                    <div class="price">
                      <p>
                        <span><i>￥</i>{{item.price}}</span>
                        <template v-if="item.productType != 2">起</template>
                      </p>
                      <p>{{item.saledNum}}人购买</p>
                    </div>
                  </div>
                </router-link>
              </li>
            </ul>
            <p class="no-hint" v-show="!productList.length">还没有收藏的产品哦！</p>
          </div>
        </div>
        <div id="view2" class="collect_travel" v-if="currentView==='view2'">
          <div class="item" v-show="strategyList.length" v-for="(item,i) in strategyList">
            <router-link :to="{path:'/homeTravelDetails',query:{travelId:item.id}}">
              <div class="user-info ellipsis"><span class="span-name">{{item.title}}</span></div>
              <div class="notes-title"><span class="span-title">{{item.subTitle}}</span></div>
              <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
            </router-link>
            <like-group
              :item="item"
              @updataCollect="collectUpdata = !collectUpdata"
            ></like-group>
          </div>
          <p class="no-hint" v-show="!strategyList.length">还没有收藏的游记哦！</p>
        </div>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import likeGroup from 'src/components/common/like'
  import {myCollection, goodsTypes, collectionEdit, Praise} from 'src/service/getData'

  export default {
    components: {
      headTop,
      likeGroup
    },
    data(){
      return {
        activeIndex: 0,
        currentView: 'view1',
        tabText: [
          {title: "产品", view: 'view1'},
          {title: "游记攻略", view: 'view2'},
        ],
        productList: [],//收藏产品列表
        strategyList: [],//攻略游记列表
        showLoading: true, //显示加载动画

        collectUpdata: false, //刷新数据开关

        preventRepeatRequest: false, //接口节流
      }
    },
    mounted(){
      this.initData();
    },
    methods: {
      initData: async function () {
        let res = await myCollection(1);
        if (res.status !== 200) {
          return;
        }
        this.productList = res.obj.myPushPraiseOfProduct;

        res = await myCollection(2);
        if (res.status !== 200) {
          return;
        }
        res.obj.myConllectionOfTravel.forEach(item => {
          item.isCollection = 0;
          item.addend = 0;
        });
        this.strategyList = res.obj.myConllectionOfTravel;
        this.showLoading = false;
      },

      reControllerName: function (productType) {
        if (productType === 1) {
          return 'spotsDetails';
        }
        else if (productType === 2) {
          return 'goodsDetails';
        }
        else if (productType === 3) {
          return 'linesDetails';
        }
      },
      tabChange(index, currentView){
        this.$refs.container.scrollTop = 0;
        this.activeIndex = index;
        this.currentView = currentView;
      },
    },
    watch: {
      collectUpdata(val){
        this.initData();
      }
    }

  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .collect-padding {
    padding-top: p2r(196);
  }

  .collect_travel {
    .item {
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      margin-bottom: p2r(10);
      &:first-child {
        margin-top: 0;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(6) p2r(12) 0 0;
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
        }
        .span-name {
          @include sc(p2r(32), $mc);
          line-height: p2r(40);
        }
      }
      .notes-info {
        overflow: hidden;
        li {
          width: 50%;
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(20);
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(20);
          }
          span {
            @include sc(p2r(24), $mc);
          }
        }
        .icon-times {
          @include bis('../../../../images/icon/icon_time.png')
        }
        .icon-moneys {
          @include bis('../../../../images/icon/icon_money.png')
        }
        .icon-likes {
          @include bis('../../../../images/icon/icon_like.png')
        }
        .icon-days {
          @include bis('../../../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        line-height: 2;
        .span-title {
          @include sc(p2r(26), $mc);
          @include ellipsisrows(4);
        }
      }
      .notes-text {
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        margin-top: p2r(12);
        .img-thum {
          width: 100%;
        }
      }
    }
  }

  .time-node-block {
    h3 {
      @include sc(p2r(24), $fc);
      line-height: (70/24);
      padding: 0 p2r(20);
      font-weight: 100;
    }
    ul {
      li {
        padding: p2r(20);
        background: $fc2;
        & > div {
          width: 100%;
          display: flex;
        }
      }
      /*图片盒子*/
      .img-box {
        width: (180/600)*100%;
        position: relative;
        i {
          position: absolute;
          left: 0;
          top: 0;
          @include sc(p2r(24), $fc2);
          background: rgba(0, 0, 0, .5);
          padding: p2r(2) p2r(15) p2r(2) p2r(5);
        }
        i:before {
          content: '';
          display: inline-block;
          width: p2r(15);
          height: p2r(20);
          @include bis('../../../../images/icon/location-icon.png');
          vertical-align: middle;
          margin-right: p2r(10);
        }
        img {
          @include wh(p2r(180), p2r(150));
        }
        p {
          @include sc(p2r(24));
          background: $bgc;
          line-height: (40/24);
          text-align: center;
        }
      }
      /*简介盒子*/
      .describe-box {
        width: (400/600)*100%;
        padding-left: p2r(20);
        /*简介文字*/
        .text-describe {
          @include sc(p2r(28));
          overflow: hidden;
        }
        /*标签*/
        .label {
          padding: p2r(15) 0;
          overflow: hidden;
          span {
            @include sc(p2r(24), $blue);
            padding: 0 p2r(15);
            border: 1px solid $blue;
            border-radius: p2r(3);
            margin: p2r(2) p2r(10) p2r(2) 0;
            display: inline-block;
            float: left;
          }
          span:last-child {
            margin-right: 0;
          }
        }
        /*价格*/
        .price {
          display: flex;
          @include fj(space-between);
          p {
            @include sc(p2r(22), $fc);
          }
          span:first-child {
            @include sc(p2r(30), $fc3);
            font-weight: bold;
            i {
              @include sc(p2r(22), $fc3);
            }
          }
        }
      }
    }
  }
</style>
