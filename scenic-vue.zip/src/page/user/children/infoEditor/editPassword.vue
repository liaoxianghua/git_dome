<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top headTitle="修改密码">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <div class="edit-password-wrapper">
        <ul class="nav-box edit-password">
          <li>
            <div class="border-box">
              <i class="phone-icon"></i>
              <input type="text" placeholder="请输入您的手机号" maxlength="11" v-model="phoneNumber" readonly>
              <span class="verify-btn" @click="getVerifyCode" v-show="!mobileCodeNum && !computedTime">获取验证码</span>
              <span class="verify-btn" @click="getVerifyCode" v-show="mobileCodeNum && !computedTime">重新获取</span>
              <span class="verify-btn verify-btn-gray btn-char-gray" v-show="computedTime">{{computedTime}}秒可重发</span>
            </div>
          </li>
          <li>
            <div class="border-box">
              <i class="password-icon"></i>
              <input type="text" placeholder="请输入验证码" maxlength="4" v-model="mobileCode">
            </div>
          </li>
          <li>
            <div class="border-box">
              <i class="password-icon"></i>
              <input type="text" placeholder="请输入8-16位新密码" maxlength="16" v-model="passWord">
            </div>
          </li>
        </ul>
        <div class="btn"><span class="ui-btn submit-btn" @click="sendReSetPassword">确认修改</span></div>
      </div>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {mapState, mapMutations} from 'vuex'
  import {mobileCode, validateMobileCode, reSetPassword} from 'src/service/getData'
  import {rightPhoneNumber, rightMobileCode, rightPassword} from 'src/config/mUtils'
  import md5 from 'blueimp-md5'

  export default {
    data(){
      return {
        step: 0, //步骤
        showPassword: false, // 是否显示密码
        phoneNumber: null, //电话号码
        mobileCode: null, //短信验证码
        validate_token: null, //获取短信时返回的验证值，登录时需要
        computedTime: 0, //倒数记时
        mobileCodeNum: 0,//验证码发送次数
        agreeRule: true, //同意条款
        passWord: null, //新密码
      }
    },
    components: {
      headTop,
    },
    created(){
    },
    mounted(){
      this.init();
    },
    computed: {
      ...mapState([
        'userInfo',
      ]),
    },
    methods: {
      init: function () {
        if (this.userInfo.memberAccount) this.phoneNumber = this.userInfo.memberAccount;
      },
      changeShowPassword(){
        this.showPassword = !this.showPassword;
      },
      //获取短信验证码
      async getVerifyCode(){
        if (!this.phoneNumber) {
          this.Toast({message: '请输入手机号码', position: 'middle'});
          return;
        }
        if (!rightPhoneNumber(this.phoneNumber)) {
          this.Toast({message: '手机号码格式有误', position: 'middle'});
          return;
        }
        //发送短信验证码
        let sms = await mobileCode(this.phoneNumber, 4);
        if (sms.status !== 200) {
          return
        }

        this.mobileCodeNum++;

        this.validate_token = sms.obj.token;

        this.computedTime = 60;
        this.timer = setInterval(() => {
          this.computedTime--;
          if (this.computedTime === 0) {
            clearInterval(this.timer)
          }
        }, 1000);
      },
      //发送密码修改
      async sendReSetPassword(){
        if (!this.phoneNumber) {
          this.Toast({message: '请输入手机号码', position: 'middle'});
          return;
        }
        if (!rightPhoneNumber(this.phoneNumber)) {
          this.Toast({message: '手机号码格式有误', position: 'middle'});
          return;
        }
        if (!this.validate_token) {
          this.Toast({message: '请先获取短信验证码', position: 'middle'});
          return;
        }
        if (!this.mobileCode) {
          this.Toast({message: '请输入短信验证码', position: 'middle'});
          return
        }
        if (!this.passWord) {
          this.Toast({message: '请输入新密码', position: 'middle'});
          return
        }
        if (!rightPassword(this.passWord)) {
          this.Toast({message: '您的密码安全等级太弱，请设置8-16位数字和字母的组合', position: 'middle'});
          return
        }

        let passWord = md5(this.passWord).toUpperCase();
        let res = await reSetPassword(this.phoneNumber, passWord, this.mobileCode, this.validate_token);
        if (res.status !== 200) {
          return;
        }

        await this.messageBox.alert(res.message);
        this.$router.go(-1);
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .edit-password-wrapper {
    height: 100%;
    background: $bgc2;
    padding-top: p2r(33);
    .btn{
      text-align: center;
    }
    .submit-btn {
      margin-top: p2r(64);
      @include wh(80%, p2r(70));
      background-color: $blue;
      @include sc(p2r(28), $fc2);
      line-height: p2r(70);
      display: inline-block;
      @include borderRadius(p2r(12));
    }
  }

  .edit-password {
    border-bottom: none;
    li {
      > div {
        display: flex;
        align-items: center;
        position: relative;
        i {
          margin-right: p2r(20);
        }
      }
    }
    li:last-child > .border-box {
      border-bottom: 1px solid $bc;
    }
  }

  .verify-btn {
    color: $blue;
    border: 1px solid $blue;
    border-radius: p2r(6);
    font-size: p2r(26);
    display: inline-block;
    padding: 0 p2r(18);
    line-height: (40/26);
    @include ct;
    right: p2r(24);
  }

  .verify-btn-gray {
    border-color: #ccc;
    background-color: #ccc;
    color: $fc2;
  }

  .phone-icon {
    background: url('../../../../images/icon/phone-icon.png') no-repeat p2r(4);
    background-size: auto 100%;
    display: block;
    width: p2r(40);
    height: p2r(42);
  }

  .password-icon {
    @include bis('../../../../images/icon/icon_register_code.png');
    display: block;
    width: p2r(40);
    height: p2r(42);
  }
</style>
