<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top headTitle="编辑个人资料">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <ul class="basis1 nav-box">
        <li class="next-icon">
          <div class="border-box edit-head">
            头像<img :src="userImg" v-if="userImg"><img src="../../../../images/hz.png" v-else><label for="img"></label>
            <input id="img" type="file" class="upload-input" accept="image/*"
                   @change="onload($event)" ref="isfiles">
          </div>
        </li>
        <li>
          <div class="border-box edit-input">
            姓名
            <input type="text" placeholder="姓名" v-model="userName" maxlength="30">
          </div>
        </li>
        <li>
          <div class="border-box edit-input">
            手机号
            <input type="text" placeholder="手机号" v-model="userTel" maxlength="11">
          </div>
        </li>
        <li class="next-icon edit-password">
          <router-link to="/user/infoEditorIndex/editPassword" class="border-box">修改密码</router-link>
        </li>
      </ul>

      <ul class="basis2 nav-box">
        <li>
          <div class="border-box edit-sex">
            <span>性别</span>
            <div>
              <div @click="changeSex(1)" class="man" :class="{active:userSex}">
                <span>男</span>
              </div>
              <div @click="changeSex(0)" :class="{active:!userSex}">
                <span>女</span>
              </div>
            </div>
          </div>
        </li>
        <li class="next-icon ">
          <div class="border-box edit-input">
            生日
            <input type="text" v-model="userBirthday" placeholder="生日" @click="selectDate" readonly>
          </div>
        </li>
        <li class="next-icon">
          <div class="border-box edit-input">
            常居地
            <input type="text" placeholder="地址" @click="changeShowRegionSelect" v-model="userRegionText" readonly>
          </div>
        </li>
        <li>
          <div class="border-box edit-input">
            邮箱
            <input type="email" placeholder="邮箱" v-model="userEmail" maxlength="25">
          </div>
        </li>
      </ul>
      <span class="ui-btn submit-btn" @click="infoSub">完成</span>
    </div>
    <mt-datetime-picker v-model="userBirthdayPickerValue" ref="birthday" type="date" :endDate="new Date()"
                        :startDate="new Date('1900-01-01')" @confirm="changeBirthday()"></mt-datetime-picker>
    <transition name="router-slid" mode="out-in">
      <region-select v-show="showRegionSelect" @closeSiteSelect="changeShowRegionSelect"
                     @siteData="changRegion"></region-select>
    </transition>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import axios from 'axios'
  import {mapMutations, mapState, mapActions} from 'vuex'
  import {editUserInfo, uploadPic} from 'src/service/getData'
  import {rightPhoneNumber, rightEmailAddress} from 'src/config/mUtils'
  import headTop from 'src/components/header/head'
  import regionSelect from 'src/components/common/regionSelect'
  import {baseUrl} from 'src/config/env'

  export default {
    data(){
      return {
        userImg: null,
        userName: null,
        userSex: 1,//1男0女
        userEmail: null,
        userTel: null,
        userBirthday: null,
        userBirthdayPickerValue: null,
        userCountryId: null,//国家ID
        userProvinceId: null,//省份ID
        userCityId: null,//城市ID
        userRegionText: null,
        showRegionSelect: false,//区域SELECT
      }
    },
    components: {
      headTop,
      regionSelect,
    },
    mounted(){
      this.getUserInfo();
      this.init();
    },
    computed: {
      ...mapState([
        'userInfo', 'login'
      ]),
    },
    methods: {
      ...mapActions([
        'getUserInfo'
      ]),
      init: function () {
        if (this.login) {
          if (this.userInfo.imageUrl) this.userImg = this.userInfo.imageUrl;
          if (this.userInfo.memberDetail.nameCh) this.userName = this.userInfo.memberDetail.nameCh;
          if (this.userInfo.memberDetail.phoneCh) this.userTel = this.userInfo.memberDetail.phoneCh;
          if (this.userInfo.memberDetail.birthday) this.userBirthday = this.formatDate(this.userInfo.memberDetail.birthday);
          if (this.userInfo.memberDetail.birthday) this.userBirthdayPickerValue = new Date(this.userInfo.memberDetail.birthday).toLocaleString();
          if (this.userInfo.memberDetail.sex !== null) this.userSex = this.userInfo.memberDetail.sex;
          if (this.userInfo.memberDetail.mail) this.userEmail = this.userInfo.memberDetail.mail;
          if (this.userInfo.memberDetail.cityId) this.userCityId = this.userInfo.memberDetail.cityId;
          if (this.userInfo.memberDetail.countryId) this.userCountryId = this.userInfo.memberDetail.countryId;
          if (this.userInfo.memberDetail.provinceId) this.userProvinceId = this.userInfo.memberDetail.provinceId;

          if (this.userInfo.countryName) {
            this.userRegionText = this.userInfo.countryName
          }
          if (this.userInfo.provinceName) {
            this.userRegionText += ' ' + this.userInfo.provinceName
          }
          if (this.userInfo.cityName) {
            this.userRegionText += ' ' + this.userInfo.cityName
          }
        }

        //Datetime Picker 默认日期
        if (!this.userBirthdayPickerValue) this.userBirthdayPickerValue = new Date('2000-01-01').toLocaleString();
      },
      //选择性别
      changeSex: function (sex) {
        this.userSex = sex
      },
      infoSub: async function () {
        if (this.userTel && !rightPhoneNumber(this.userTel)) {
          this.Toast({message: '手机号码格式有误', position: 'bottom'});
          return;
        }
        if (this.userEmail && !rightEmailAddress(this.userEmail)) {
          this.Toast({message: '邮箱地址格式有误', position: 'bottom'});
          return;
        }
        let res = await editUserInfo(this.userImg, this.userName, this.userTel, this.userSex, this.userBirthday, this.userCountryId, this.userProvinceId, this.userCityId, this.userEmail);
        if (res.status !== 200) {
          return
        }

        await this.messageBox.alert(res.message);
        this.getUserInfo();
        this.$router.go(-1);
      },
      formatDate: function (val) {
        let mDate = new Date(val);
        let month = mDate.getMonth() + 1;
        let day = mDate.getDate();
        if (month < 10) {
          month = '0' + month;
        }
        if (day < 10) {
          day = '0' + day;
        }
        return mDate.getFullYear() + '-' + month + '-' + day;
      },
      changeShowRegionSelect: function () {
        this.showRegionSelect = !this.showRegionSelect;
      },
      changRegion: function (obj) {
        this.userRegionText = obj.State + (obj.Province ? ' ' + obj.Province : '') + (obj.City ? ' ' + obj.City : '');
        this.userCityId = obj.city ? obj.city : null;
        this.userProvinceId = obj.province ? obj.province : null;
        this.userCountryId = obj.state ? obj.state : null;
      },
      selectDate: function () {
        this.$refs.birthday.open();
      },
      changeBirthday: function () {
        this.userBirthday = this.formatDate(this.userBirthdayPickerValue);
      },
      //上传图片
      onload(e){
        var maxsize = 100 * 1024;
        typeof e.target === 'undefined' ? this.file = e : this.file = e.target.files;
        if (!this.file.length) {
          return
        }
        let files = Array.prototype.slice.call(this.file);
        files = files.reverse();
        if (files.length > 1) {
          this.Toast({message: '头像只能上传一张图片', position: 'bottom'});
          return
        }
        files.forEach((file, i) => {
          if (!/\/(?:jpeg|jpg|png|gif)/i.test(file.type) && file.type != '') {
            this.Toast({message: '不支持您上传的图片格式', position: 'bottom'});
            return;
          }
          var reader = new FileReader();
          var _thit = this;
          reader.onload = function () {
            var result = this.result;
            var img = new Image();
            img.src = result;
            //如果图片大小小于100kb，则直接上传
            if (result.length <= maxsize) {
              img = null;
              _thit.upload(result, file.type, file.name);
              return;
            }
            //图片加载完毕之后进行压缩，然后上传
            if (img.complete) {
              callback();
            } else {
              img.onload = callback;
            }
            function callback() {
              var data = _thit.compress(img);
              _thit.upload(data, file.type, file.name);
              img = null;
            }
          }
          reader.readAsDataURL(file);
        });
      },
      //使用canvas对大图片进行压缩
      compress(img) {
        //    用于压缩图片的canvas
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext('2d');
        //    瓦片canvas
        var tCanvas = document.createElement("canvas");
        var tctx = tCanvas.getContext("2d");

        var initSize = img.src.length;
        var width = img.width;
        var height = img.height;
        //如果图片大于2百万像素，计算压缩比并将大小压至200万以下
        var ratio;
        if ((ratio = width * height / 2000000) > 1) {
          ratio = Math.sqrt(ratio);
          width /= ratio;
          height /= ratio;
        } else {
          ratio = 1;
        }
        canvas.width = width;
        canvas.height = height;
        //        铺底色
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        //如果图片像素大于100万则使用瓦片绘制
        /*var count;
         if ((count = width * height / 1000000) > 1) {
         count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
         //            计算每块瓦片的宽和高
         var nw = ~~(width / count);
         var nh = ~~(height / count);
         tCanvas.width = nw;
         tCanvas.height = nh;
         for (var i = 0; i < count; i++) {
         for (var j = 0; j < count; j++) {
         tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
         ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
         }
         }
         } else {*/
        ctx.drawImage(img, 0, 0, width, height);
        //}
        //进行最小压缩
        var ndata = canvas.toDataURL('image/jpeg', 0.6);
        tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
        return ndata;
      },
      //开始上传
      async upload(basestr, type, name) {

        var text = window.atob(basestr.split(",")[1]);
        var buffer = new Uint8Array(text.length);
        for (var i = 0; i < text.length; i++) {
          buffer[i] = text.charCodeAt(i);
        }
        var blob = this.getBlob([buffer], type);
        var formdata = this.getFormData();
        formdata.append('upload', blob, name);

        /*let response = await fetch(baseUrl+'/common/saveUploadFile',{
         method: 'POST',
         body: formdata
         });*/

        let res = await axios({
          method: 'POST',
          url: baseUrl + '/common/saveUploadFile',
          data: formdata,
          headers: {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        }).then((response) => {
          return response.data;
        }, (response) => {
          console.log(response);
        }).catch((error) => {
          console.log(error);
        });

        if (res.status === 200) {
          this.Toast({message: '上传成功', iconClass: 'ui-toast-icon iconfont icon-appreciate'});
          this.displayimg(res);
        }

      },
      //获取formdata
      getFormData() {
        var isNeedShim = ~navigator.userAgent.indexOf('Android')
          && ~navigator.vendor.indexOf('Google')
          && !~navigator.userAgent.indexOf('Chrome')
          && navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534;
        return isNeedShim ? new FormDataShim() : new FormData()
      },
      getBlob(buffer, format) {
        try {
          return new Blob(buffer, {type: format});
        } catch (e) {
          var bb = new (window.BlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder);
          buffer.forEach(function (buf) {
            bb.append(buf);
          });
          return bb.getBlob(format);
        }
      },
      //显示图片
      displayimg(res){
        this.userImg = res.obj.busiPictureAttachvo.urlAttach;
      },
    },
    watch: {
      'userInfo': function () {
        this.init();
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .next-icon:after {
    @include bis('../../../../images/icon/enter-icon.png');
  }

  .basis1 {
    margin-bottom: p2r(20);
    .edit-head {
      padding-top: p2r(12);
      padding-bottom: p2r(12);
      height: auto;
      position: relative;
      label {
        width: p2r(90);
        height: p2r(90);
        display: block;
        margin-right: p2r(40);
        @include ct;
        right: 0;
      }
      i {
        width: p2r(90);
        height: p2r(90);
        @include bis('../../../../images/elmlogo.jpeg');
        border-radius: 50%;
        margin-right: p2r(40);
      }
      img {
        @include wh(p2r(90), p2r(90));
        float: right;
        margin-right: p2r(40);
        border-radius: 50%;
      }
      input {
        display: none;
      }
    }
    .edit-password {
      a {
        display: block;
      }
    }
  }

  .edit-input {
    /*@include fj(space-between);*/
    position: relative;
    overflow: hidden;
    input {
      width: (400/500)*100%;
      text-align: right;
      padding-right: p2r(40);
      float: right;
      height: p2r(90);
    }
    .ipn-pretend {
      width: (400/500)*100%;
      text-align: right;
      padding-right: p2r(40);
    }
    .ipn-hide {
      position: absolute;
      left: 100%;
      top: 0;
    }
  }

  .edit-sex {
    > div {
      height: p2r(90);
      float: right;
      @include fj(flex-end);
      align-items: center;
      line-height: p2r(80);
      margin-right: p2r(20);
      > div {
        border-bottom: p2r(4) solid #fff;
        span {
          @include sc(p2r(26));
          padding: 0 p2r(32);
        }
      }
      .man > span {
        border-right: 1px solid $bc;
        height: p2r(35);
      }
      .active {
        span {
          color: $blue;
        }
        border-bottom-color: $blue;
      }
    }
  }

  .basis2 {
    border-top: 1px solid $bc;
  }

  /*完成按钮*/
  .submit-btn {
    @include submit;
    margin: p2r(50) auto;
  }
</style>
