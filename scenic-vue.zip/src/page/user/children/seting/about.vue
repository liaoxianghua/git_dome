<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top headTitle="关于">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <div class="text-box">
        <p>
          上海春秋国际旅行社（集团）有限公司（简称“春秋”）的前身是成立于1981年的上海春秋旅行社，1987年8月成立上海春秋国际旅行社有限公司，2012年1月更名为“上海春秋国际旅行社（集团）有限公司”。30余年来，公司由小到大，从单一经营发展到集团化综合经营，是中国最大的民营旅行社之一。2004年5月春秋投资创建了国内最具规模的低成本航空公司——春秋航空股份有限公司（以下简称“春秋航空”）。目前春秋拥有近万名员工，业务涉及旅游、航空、酒店、机票、会议、展览、票务、车队、体育赛事、城市旅游观光巴士、第三方支付、融资租赁、目的地营销策划等，拥有境内54家全资分、子公司和境外7家全资子公司，全国4000多家代理商，上海47家全资营业网点，是国内连锁经营最具规模的旅游批发商和包机批发商之一.
        </p>
        <p>
          春秋是全国文明单位、全国旅游标准化示范企业、全国旅游服务质量标杆单位、全国文明旅游先进单位、上海首批AAAAA级旅行社、世界旅游业理事会成员、国际航空运输协会成员，也是国际会议协会（ICCA）在中国旅行社中最早的会员。
        </p>
        <p>
          2015年，公司荣获上海企业100强（第50名）、上海民营企业100强（第11名）、上海服务业企业50强（第28名）、上海民营服务业企业50强（第9名）、上海市守合同重信用企业、上海市先进企业、上海市“五星级诚信创建企业”称号。
        </p>
      </div>
    </div>
  </div>

</template>

<script>
  import headTop from 'src/components/header/head'
  export default {
    components: {
      headTop
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .text-box {
    width: 100%;
    padding: p2r(12) p2r(23);
    background: $bgc2;
    p {
      font-size: p2r(26);
      margin: p2r(24) 0;
      text-indent: p2r(48);
    }
  }
</style>
