<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="意见反馈">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <p class="state-text">您的反馈意见与建议对我们的工作非常有用,非常感谢!</p>
      <div class="text-editor-box">
      <textarea maxlength="1000" draggable="false" placeholder="请输入您的意见或建议（字数1000字内）" v-model="text">

      </textarea>
      </div>
      <div class="img-uploading">
        <div class="imgs-list">
          <img :src="url" v-for="url in imgUrls">
          <div class="up">
            <label for="img" class="add-img-btn"></label>
            <p>上传照片</p>
          </div>
        </div>
        <input id="img" type="file" class="upload-input" accept="image/*"
               @change="onload($event)" ref="isfiles" multiple>
      </div>
      <div class="phone-edit">
        <p>手机号码</p>
        <input type="tel" maxlength="11" v-model="tel">
      </div>
      <span class="submit-btn" @click="feedbackSub">提交</span>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import {mapMutations, mapState, mapActions} from 'vuex'
  import {uploadPic, addfeedback} from 'src/service/getData'
  import {checkLogin, rightPhoneNumber} from 'src/config/mUtils'
  import headTop from 'src/components/header/head'
  import {baseUrl} from 'src/config/env'

  export default {
    data(){
      return {
        isLogin: false,//是否登录
        tel: null,//电话
        text: null,//内容
        imgUrls: [],//图片
        maxImgUrl: 9,//最多可上传图片数
      }
    },
    components: {
      headTop
    },
    mounted(){
      this.init();
    },
    computed: {
      ...mapState([
        'userInfo', 'login'
      ]),
    },
    methods: {
      init: function () {
        if (this.login) {
          if (this.userInfo.memberDetail.phoneCh) this.tel = this.userInfo.memberDetail.phoneCh;
        }
      },
      feedbackSub: async function () {
        if (!this.text) {
          this.Toast({message: '请输入您的意见或建议', position: 'bottom'});
          return;
        }
        if (!this.tel) {
          this.Toast({message: '请输入您的手机号码', position: 'bottom'});
          return;
        }
        if (this.tel && !rightPhoneNumber(this.tel)) {
          this.Toast({message: '请输入正确的手机号码', position: 'bottom'});
          return;
        }
        let res = await addfeedback(this.text, this.tel, this.imgUrls.join(','));
        if (res.status === 200) {
          await this.messageBox.alert(res.message);
          this.routerBack();
        }
      },
      //上传图片
      onload(e){
        var maxsize = 100 * 1024;
        typeof e.target === 'undefined' ? this.file = e : this.file = e.target.files;
        if (!this.file.length) {
          return
        }
        let files = Array.prototype.slice.call(this.file);
        files = files.reverse();
        if (files.length > this.maxImgUrl) {
          this.Toast({message: '最多上传' + this.maxImgUrl + '张', position: 'bottom'});
          return
        }

        if (files.length + this.imgUrls.length > this.maxImgUrl) {
          this.Toast({
            message: '您已经上传了' + this.imgUrls.length + '张，还能上传' + (this.maxImgUrl - this.imgUrls.length) + '张，请重新选择图片',
            position: 'bottom'
          });
          return;
        }
        files.forEach((file, i) => {
          if (!/\/(?:jpeg|jpg|png|gif)/i.test(file.type) && file.type != '') {
            this.Toast({message: '不支持您上传的图片格式', position: 'bottom'});
            return;
          }
          var reader = new FileReader();
          var _thit = this;
          reader.onload = function () {
            var result = this.result;
            var img = new Image();
            img.src = result;
            //如果图片大小小于100kb，则直接上传
            if (result.length <= maxsize) {
              img = null;
              _thit.upload(result, file.type, file.name);
              return;
            }
            //图片加载完毕之后进行压缩，然后上传
            if (img.complete) {
              callback();
            } else {
              img.onload = callback;
            }
            function callback() {
              var data = _thit.compress(img);
              _thit.upload(data, file.type, file.name);
              img = null;
            }
          }
          reader.readAsDataURL(file);
        });
      },
      //使用canvas对大图片进行压缩
      compress(img) {
        //    用于压缩图片的canvas
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext('2d');
        //    瓦片canvas
        var tCanvas = document.createElement("canvas");
        var tctx = tCanvas.getContext("2d");

        var initSize = img.src.length;
        var width = img.width;
        var height = img.height;
        //如果图片大于2百万像素，计算压缩比并将大小压至200万以下
        var ratio;
        if ((ratio = width * height / 2000000) > 1) {
          ratio = Math.sqrt(ratio);
          width /= ratio;
          height /= ratio;
        } else {
          ratio = 1;
        }
        canvas.width = width;
        canvas.height = height;
        //        铺底色
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        //如果图片像素大于100万则使用瓦片绘制
        /*var count;
         if ((count = width * height / 1000000) > 1) {
         count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
         //            计算每块瓦片的宽和高
         var nw = ~~(width / count);
         var nh = ~~(height / count);
         alert(ratio);
         tCanvas.width = nw;
         tCanvas.height = nh;
         for (var i = 0; i < count; i++) {
         for (var j = 0; j < count; j++) {
         tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 30, 30, nw, nh);
         ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
         }
         }
         } else {*/
        ctx.drawImage(img, 0, 0, width, height);
        //}
        //进行最小压缩
        var ndata = canvas.toDataURL('image/jpeg', 0.6);
        tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
        return ndata;
      },
      //开始上传
      async upload(basestr, type, name) {

        var text = window.atob(basestr.split(",")[1]);
        var buffer = new Uint8Array(text.length);
        for (var i = 0; i < text.length; i++) {
          buffer[i] = text.charCodeAt(i);
        }
        var blob = this.getBlob([buffer], type);
        var formdata = this.getFormData();
        formdata.append('upload', blob, name);

        /*let response = await fetch(baseUrl+'/common/saveUploadFile',{
         method: 'POST',
         body: formdata
         });*/

        let res = await axios({
          method: 'POST',
          url: baseUrl + '/common/saveUploadFile',
          data: formdata,
          headers: {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        }).then((response) => {
          return response.data;
        }, (response) => {
          console.log(response);
        }).catch((error) => {
          console.log(error);
        });

        if (res.status === 200) {
          this.Toast({message: '上传成功', iconClass: 'ui-toast-icon iconfont icon-appreciate'});
          this.displayimg(res);
        }
      },
      //获取formdata
      getFormData() {
        var isNeedShim = ~navigator.userAgent.indexOf('Android')
          && ~navigator.vendor.indexOf('Google')
          && !~navigator.userAgent.indexOf('Chrome')
          && navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534;
        return isNeedShim ? new FormDataShim() : new FormData()
      },
      getBlob(buffer, format) {
        try {
          return new Blob(buffer, {type: format});
        } catch (e) {
          var bb = new (window.BlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder);
          buffer.forEach(function (buf) {
            bb.append(buf);
          });
          return bb.getBlob(format);
        }
      },
      //显示图片
      displayimg(res){
        this.imgUrls.unshift(res.obj.busiPictureAttachvo.urlAttach);
      },
      routerBack: function () {
        this.$router.go(-1);
      },
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .state-text {
    @include sc(p2r(26), $blue);
    line-height: p2r(40);
    text-align: center;
    padding: p2r(30) 0;
  }

  .text-editor-box {
    @include bmb;
    padding: p2r(20) p2r(15);
    textarea {
      resize: none;
      width: 100%;
      height: p2r(260);
    }
  }

  .imgs-list {
    overflow: hidden;
    img {
      height: p2r(148);
      display: block;
      float: left;
      margin: 0 p2r(8) p2r(8) 0;
    }
    .up {
      height: p2r(150);
      overflow: hidden;
      float: left;
      @include fj(flex-start);
      align-items: center;
      & > p {
        @include sc(p2r(28), $fc);
        margin-left: p2r(20);
      }
    }
  }

  .img-uploading {
    @include bmb;
    padding: p2r(20) p2r(30);
    @include fj(flex-start);
    align-items: center;
    .add-img-btn {
      width: p2r(145);
      height: p2r(145);
      border: 1px dashed $bc;
      display: block;
      text-align: center;
    }
    .add-img-btn:after {
      content: '';
      width: p2r(70);
      height: p2r(70);
      display: inline-block;
      @include bis('../../../../images/icon/add-icon.png');
      margin-top: p2r(37);
    }
    .upload-input {
      display: none;
    }
  }

  .phone-edit {
    @include bmb;
    display: flex;
    @include fj(space-between);
    padding: 0 p2r(30);
    height: p2r(92);
    align-items: center;
    p {
      font-size: p2r(28);
      padding-left: p2r(10);
      white-space: nowrap;
    }
    input {
      width: (450/(640-60))*100%;
      text-align: right;
      color: $fc;
    }
  }

  .submit-btn {
    @include submit;
    margin: p2r(100) auto;
  }
</style>
