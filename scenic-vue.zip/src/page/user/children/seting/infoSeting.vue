<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="消息设置">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <ul class="nav-box info-set-nav">
        <li>
          <div class="border-box">
            <p>接收评论通知</p>
            <comp-switch :isOff="receiveComment" @changer="setComment()"></comp-switch>
          </div>
        </li>
        <li>
          <div class="border-box">
            <p>接收点赞通知</p>
            <comp-switch :isOff="receivePraise" @changer="setPraise()"></comp-switch>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import {mapMutations, mapState, mapActions} from 'vuex'
  import headTop from 'src/components/header/head'
  import compSwitch from 'src/components/common/switch'
  import {changeSetting, checkLogin} from 'src/service/getData'

  export default {
    data(){
      return {
        receiveComment: 0,
        receivePraise: 0,
      }
    },
    components: {
      headTop,
      compSwitch
    },
    mounted(){
      this.init();
    },
    computed: {
      ...mapState([
        'userInfo', 'login'
      ]),
    },
    methods: {
      ...mapActions([
        'getUserInfo'
      ]),
      init: function () {
        if (this.login) {
          this.receiveComment = this.userInfo.receiveComment;
          this.receivePraise = this.userInfo.receivePrasie;
        }
      },
      setComment: function () {
        this.receiveComment = this.receiveComment ? 0 : 1;
        this.changeSetting();
      },
      setPraise: function () {
        this.receivePraise = this.receivePraise ? 0 : 1;
        this.changeSetting();
      },
      changeSetting: async function () {
        let res = await changeSetting(this.receivePraise, this.receiveComment);
        if (res.status === 200) {
          this.getUserInfo();
        }
      }
    },
    watch: {
      'userInfo': function () {
        this.init();
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .info-set-nav {
    .border-box {
      display: flex;
      @include fj(space-between);
      align-items: center;
    }
    .off {
      background: $fc3;
    }
    .no {
      background: $fc2;
    }
  }
</style>
