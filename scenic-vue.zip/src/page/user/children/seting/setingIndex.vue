<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="设置">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <ul class="set-nav nav-box">
        <li class="next-icon" v-if="login">
          <router-link to="/user/setingIndex/infoSeting" class="border-box">消息设置</router-link>
        </li>
        <li class="next-icon">
          <router-link to="/user/setingIndex/opinionEditor" class="border-box">意见反馈</router-link>
        </li>
        <li class="next-icon">
          <router-link to="/user/setingIndex/about" class="border-box">关于</router-link>
        </li>
        <li class="versions-info">
          <p class="border-box">
            <span>版本信息</span>
            <span class="span-value">v1.0</span>
          </p>
        </li>
        <li class="language-info">
          <p class="border-box">
            <span>语言</span>
            <span class="span-value">简体中文</span>
          </p>
        </li>
      </ul>
      <span class="out-btn" @click.prevent="logout" v-if="login">退出</span>
      <router-link class="out-btn" to="/login" tag="span" v-else>登录</router-link>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {mapState, mapActions} from 'vuex'
  import {logout, checkLogin} from 'src/service/getData'
  import headTop from 'src/components/header/head'
  import {getSessionStorage, removeSessionStorage} from 'src/config/mUtils'
  export default {
    data(){
      return {}
    },
    mounted(){
    },
    components: {
      headTop
    },
    computed: {
      ...mapState([
        'login'
      ]),
    },
    methods: {
      ...mapActions([
        'getUserInfo'
      ]),
      async logout(){
        if (this.login) {
          let res = await logout();
          if (res.status === 200) {
            removeSessionStorage('token');
            this.getUserInfo();
            this.$router.go('-1');
          }
        }
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .next-icon:after {
    @include bis('../../../../images/icon/enter-icon.png');
  }

  .set-nav {
    margin-bottom: p2r(30);
    a {
      display: block;
    }
  }

  .out-btn {
    display: block;
    text-align: center;
    font-size: p2r(30);
    line-height: (92/30);
    background: $bgc2;
    border-top: 1px solid $bc;
    border-bottom: 1px solid $bc;
  }

  .language-info, .versions-info {
    .border-box {
      display: block;
      overflow: hidden;
      .span-value {
        float: right;
        @include sc(p2r(26), $fc);
      }
    }
  }
</style>
