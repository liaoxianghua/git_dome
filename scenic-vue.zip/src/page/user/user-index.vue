<template>
  <div class="ui-body ui-padding-footer">
    <div class="ui-container">
      <header class="head-container">
        <a href="javascript:void(0)" class="tel-service" @click.prevent="isServer=true"><i></i></a>
        <router-link to="/user/setingIndex" class="setting-btn"><i></i></router-link>
        <div class="user-header" v-if="login">
          <router-link to="/user/infoEditorIndex">
            <img :src="userImg" alt="" v-if="userImg">
            <img src="../../images/unuser-head.png" alt="" v-else>
            <span class="ellipsis">{{userName}}</span>
          </router-link>
        </div>
        <div class="user-header" v-else>
          <router-link :to="{path:'/login',query:{redirect:'/user'}}" replace>
            <img src="../../images/unuser-head.png" alt="">
            <span class="icon-go">您还没有登录,点击登录/注册</span>
          </router-link>
        </div>
        <ul class="state">
          <li class="all-order-btn">
            <router-link :to="{path:'/order'}"><i></i>
              <p>全部订单</p></router-link>
          </li>
          <li class="wait-pay-btn">
            <router-link :to="{path:'/order',query:{status:2}}"><i :class="{'red-dot':isNewState}"></i>
              <p>待付款</p></router-link>
          </li>
          <li class="wait-trip-btn">
            <router-link :to="{path:'/order',query:{status:3}}"><i></i>
              <p>待完成</p></router-link>
          </li>
          <li class="wait-comment-btn">
            <router-link :to="{path:'/order',query:{status:4}}"><i></i>
              <p>待点评</p></router-link>
          </li>
        </ul>
      </header>
      <nav class="nav-wrapper">
        <ul>
          <li>
            <router-link to="/user/collectIndex">我的收藏</router-link>
          </li>
          <li>
            <router-link to="/myTravelIndex">我的游记</router-link>
          </li>
          <li>
            <router-link to="/user/commentInfoIndex">常用信息</router-link>
          </li>
          <li>
            <router-link to="/user/browsingHistory">浏览历史</router-link>
          </li>
        </ul>
      </nav>
      <div class="editor-btn">
        <a href="#" @click.prevent="gonewTravel">新建一篇游记</a>
      </div>
      <template v-if="travelList.id">
        <div class="user-travel">
          <list-title titleText="游记">
            <router-link to="/myTravelIndex" slot="more" class="more">更多</router-link>
          </list-title>
          <div class="item">
            <router-link
              :to="{path: travelList.status === 2?'/homeTravelDetails':'/myTravelIndex/noTrueTravelDetails',query:{travelId:travelList.id}}">
              <div class="user-info"><img v-lazy="travelList.imageUrl" class="img-head">
                <span class="span-name">{{travelList.name || "猴爸爸平台"}}</span>
              </div>
              <div class="notes-title ellipsis"><span class="span-title ">{{travelList.title}}</span></div>
              <div class="notes-text ellipsis"><span class="span-text" v-if="">{{travelList.subTitle}}</span></div>
              <div class="notes-thum"><img v-lazy="travelList.coversImageUrl" class="img-thum"></div>
            </router-link>
            <like-group
              :item="travelList"
              v-show="travelList.status === 2"
            ></like-group>
            <p v-show='travelList.status !== 2' class="updata-time">
              最近更新时间 <span>{{travelList.createTime | formatTime}}</span>
              <span class="status"
                    v-show='travelList.status !== 0 && travelList.status !== 2'>{{travelList.status === 3 && "已退回" || travelList.status === 1 && "未审核"}}</span>
            </p>
          </div>
        </div>
      </template>
      <div v-else class="no-hint">
        <span>亲,快来写游记吧</span>
      </div>
    </div>
    <foot-guide></foot-guide>
    <div class="ui-body server-container" v-show="isServer">
      <div class="server-wrapper">
        <div class="close-icon" @click="isServer=false"></div>
        <div class=" server-info ">
          <img src="../../images/hz.png" alt="">
          <p>实时为您提供咨询服务</p>
        </div>
        <div class="btn-cont">
          <a href="tel:021-52317747">客服电话：021-52317747</a>
          <router-link to="user/setingIndex/opinionEditor">在线反馈</router-link>
        </div>
      </div>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import footGuide from 'src/components/footer/footGuide'
  import likeGroup from 'src/components/common/like'

  import {getmytravel, Praise, collectionEdit, userPageMyTravel} from 'src/service/getData'
  import travelBlock from '../../components/common/travelblock/travelContent.vue'

  import listTitle from '../../components/common/travelblock/traveTitle'
  import {mapMutations, mapState, mapActions} from 'vuex'
  import {getSessionStorage} from 'src/config/mUtils'

  export default {
    data(){
      return {
        isNewState: false,//是否有新的动态（订单状态栏）
        userImg: null,
        userName: '请修改',
        travelList: {},
        travelText: [],
        isServer: false,
        preventRepeatRequest: false,
      }
    },
    components: {
      travelBlock,
      footGuide,
      likeGroup,
      listTitle
    },
    computed: {
      ...mapState([
        'userInfo', 'login'
      ]),
    },
    filters: {
      formatTime: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        let hours = mData.getHours();
        if (hours < 10) {
          hours = '0' + hours;
        }
        let minutes = mData.getMinutes();
        if (minutes < 10) {
          minutes = '0' + minutes;
        }
        let seconds = mData.getSeconds();
        if (seconds < 10) {
          seconds = '0' + seconds;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
      },
    },
    mounted(){
      this.init();
      if (this.login) {
        this.getUserInfo();
        this.getInitDate();
      }
    },

    methods: {
      ...mapActions([
        'getUserInfo'
      ]),
      init: function () {
        if (this.login) {
          this.userImg = this.userInfo.imageUrl;
          this.userName = this.userInfo.memberDetail.nameCh ? this.userInfo.memberDetail.nameCh : '请修改';
        }
      },

      getInitDate: async function () {
        await userPageMyTravel().then(res => {
          if (res.status === 200 && res.obj.travelNote) {
            this.travelList = res.obj.travelNote;
          }
        });
      },

      gonewTravel(){
        this.$router.push({path: '/myTravelIndex/travelEditor', query: {isnew: 'true'}});
      },
    },
    watch: {
      userInfo: function () {
        this.init();
        if (this.login) {
          this.getInitDate();
        }
      },
      login: function () {
        if (this.login) {
          this.getInitDate();
        }
        else {
          this.travelList = {};
        }
      }
    }
  }
</script>

<style lang="scss">
  @import 'src/style/mixin';
  //顶部header块

  .head-container {
    background: linear-gradient(#5eaaf8, #4692f6);
    position: relative;
  }

  //客服电话
  .server-container {
    background: rgba(0, 0, 0, .6);
    .server-wrapper {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: $fc2;
      width: (580/640)*100%;
      .close-icon {
        font-family: "iconfont" !important;
        font-style: normal;
        font-size: p2r(50);
        color: $blue;
        position: absolute;
        top: p2r(20);
        right: p2r(20);
      }
      .close-icon:after {
        content: '\E659';
      }
      .server-info {
        text-align: center;
        margin-top: p2r(30);
        img {
          width: p2r(200);
        }
        p {
          font-size: p2r(26);
        }
      }
      .btn-cont {
        padding: p2r(20) p2r(50);
        a {
          display: block;
          text-align: center;
          color: $fc2;
          background: $blue;
          margin: p2r(30) 0;
          font-size: p2r(30);
          line-height: 2.5;
          border-radius: p2r(8);
        }
      }
    }
  }

  //设置按钮
  .setting-btn {
    display: block;
    position: absolute;
    top: p2r(40);
    right: p2r(20);
    padding: p2r(10);
    i {
      @include wh(p2r(40), p2r(38));
      display: block;
      @include bis('../../images/icon/seting-icon.png');
    }
  }

  //客服
  .tel-service {
    display: block;
    position: absolute;
    top: p2r(40);
    left: p2r(20);
    padding: p2r(10);
    i {
      @include wh(p2r(40), p2r(38));
      display: block;
      @include bis('../../images/icon/seaver-tel.png');
    }
  }

  //头像
  .user-header {
    display: block;
    padding-top: p2r(70);
    padding-bottom: p2r(24);
    text-align: center;
    a {
      display: block;
      margin: 0 auto;
      width: 70%;
    }
    img {
      @include wh(p2r(120), p2r(120));
      @include borderRadius(50%);
      background-color: $bgc2;
      display: inline-block;
    }
    span {
      @include sc(p2r(24), $fc2);
      line-height: 1.2;
      width: 100%;
      text-align: center;
      display: block;
      overflow: hidden;
      margin: p2r(16) 0;
    }
  }

  //订单状态选择栏
  .state {
    display: flex;
    @include fj;
    @include bis('../../images/user-head-bg.png');
    padding: p2r(16) 0;
    li {
      text-align: center;
      @include wh((130/40)+rem, auto);
      a {
        i {
          display: block;
          margin: 0 auto;
          position: relative;
        }
        p {
          @include sc();
          color: $fc2;
          line-height: 1;
          margin-top: p2r(16);
        }
      }
    }
    .all-order-btn {
      i {
        @include wh(p2r(36), p2r(40));
        @include bis('../../images/icon/record-icon.png');
      }
    }
    .wait-pay-btn {
      i {
        @include wh(p2r(42), p2r(42));
        @include bis('../../images/icon/zhong-icon.png');
      }
    }
    .wait-trip-btn {
      i {
        @include wh(p2r(32), p2r(42));
        @include bis('../../images/icon/chuxing-icon.png');
      }
    }
    .wait-comment-btn {
      i {
        @include wh(p2r(40), p2r(40));
        @include bis('../../images/icon/shuxie-icon.png');
      }
    }
  }

  //提示红点
  .red-dot:after {
    content: '';
    display: block;
    position: absolute;
    top: p2r(-5);
    right: p2r(-13);
    @include wh(p2r(10), p2r(10));
    background: #ff0000;
    @include borderRadius(50%);
  }

  //导航栏
  .nav-wrapper {
    @include bmb;
    border-top: none;
    ul {
      width: 100%;
    }
    li {
      width: 50%;
      float: left;
      text-align: center;
      a {
        @include sc(p2r(24), $fc);
        display: block;
        padding: p2r(20) 0;
      }
      a:before {
        content: '';
        display: inline-block;
        margin-right: p2r(50);
        vertical-align: middle;
      }
    }
    li:first-child > a {
      border-bottom: 1px solid $bc;
      border-right: 1px solid $bc;
    }
    li:first-child > a:before {
      @include wh(p2r(40), p2r(40));
      @include bis('../../images/icon/lick-icon.png');
    }

    li:nth-child(2) > a {
      border-bottom: 1px solid $bc;
    }
    li:nth-child(2) > a:before {
      @include wh(p2r(40), p2r(40));
      @include bis('../../images/icon/pic-icon.png');
    }
    li:nth-child(3) > a {
      border-right: 1px solid $bc;
    }
    li:nth-child(3) > a:before {
      @include wh(p2r(40), p2r(40));
      @include bis('../../images/icon/info-icon.png');
    }
    li:nth-child(4) > a:before {
      @include wh(p2r(50), p2r(40));
      @include bis('../../images/icon/eay-icon.png');
    }
  }

  //编辑按钮
  .editor-btn {
    padding: p2r(15) 0;
    text-align: center;
    line-height: 1;
    @include bmb;
    a {
      @include sc(p2r(28), $mc);
    }
  }

  .editor-btn:before {
    content: '';
    display: inline-block;
    vertical-align: middle;
    margin-right: p2r(25);
    @include wh(p2r(38), p2r(42));
    @include bis('../../images/icon/compile-icon.png');
  }

  .editor-btn:after {
    content: '';
    display: inline-block;
    vertical-align: middle;
    margin-left: p2r(30);
    @include wh(p2r(15), p2r(28));
    @include bis('../../images/icon/enter-icon.png');
  }

  .user-travel {
    border-top: 1px solid $bc;

    .item:last-child {
      .updata-time {
        border-bottom: none;
        .status {
          margin-left: p2r(20);
        }
      }
    }

    .item {
      position: relative;
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      overflow: hidden;
      padding: 0 p2r(20);
      margin-bottom: p2r(10);
      &:first-child {
        margin-top: 0;
      }

      .updata-time {
        @include sc(p2r(20), $fc);
        line-height: 1;
        padding: p2r(10) 0 p2r(30);
        span {
          @include sc(p2r(20), $fc);
        }
      }

      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
          @include borderRadius(p2r(35));
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
      }
      .notes-info {
        overflow: hidden;
        li {
          width: 50%;
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(20);
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(20);
          }
          span {
            @include sc(p2r(24), $mc);
          }
        }
        .icon-time {
          @include bis('../../images/icon/icon_time.png')
        }
        .icon-money {
          @include bis('../../images/icon/icon_money.png')
        }
        .icon-like {
          @include bis('../../images/icon/icon_like.png')
        }
        .icon-day {
          @include bis('../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        margin-top: p2r(12);
        .img-thum {
          width: 100%;
        }
      }
    }
  }

</style>
