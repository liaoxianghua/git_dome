<template>
  <div class="ui-body ui-gray-bg"
       :class="[(showTabs && step == 3) || (isTypeSearch && step ==1) || (searchType == 1 && step ==3) ? 'ui-padding-h' : 'ui-padding-header']">
    <head-top>
      <div slot="btn" class="btn-all btn-left btn-back" @click="goBack()"></div>
    </head-top>
    <section class="search-form">
      <i class="i-search"></i>
      <input type="text" autocomplete="off" placeholder="目的地/景点/酒店/攻略/游记" class="ipn-value"
             @input="inputSearch()" @keyup.enter="enterSearch()" @focus="backStep2()" v-model="searchValue"
             ref="ipt">
    </section>
    <!-- 类别Tab -->
    <div class="search-tabs" v-if="(searchType == 1 && step == 3)">
      <div>
        <a v-for="item in productTypes"
           :class="[(item.productType == productType && item.productSubType == productSubType)  ? 'active':'']"
           @click.prevent="changeTab(item.productType,item.productSubType)">{{item.productSubTypeName}}</a>
      </div>
    </div>
    <!-- 分类搜索Tab -->
    <ul class="tab-btn-blcok tab-pattern2 tab-bg" v-if="(showTabs && step == 3) || (isTypeSearch && step ==1)">
      <li v-for="(item,i) in tabText"
          @click.prevent="changeType(item.type)"
          :class="{'active':searchType == item.type}">
        <span>{{item.title}}</span>
      </li>
    </ul>
    <div class="ui-container" ref="container">
      <!--搜索着陆板块-->
      <template v-if="step == 1">
        <section class="search-wrap search-history" v-if="searchHistory.length">
          <div class="title">历史搜索</div>
          <ul class="list">
            <li v-for="item in searchHistory">
              <a class="a-his" @click.prevent="keySearch(item)">{{item}}</a>
            </li>
          </ul>
          <div class="btn"><a class="a-clean" @click.prevent="cleanHistory">清除历史记录</a></div>
        </section>
        <section class="search-wrap search-hot" v-if="searchHot.length">
          <div class="title">最近热搜</div>
          <ul class="list">
            <li v-for="item in searchHot"><a class="a-his"
                                             v-on:click.prevent="keySearch(item)">{{item}}</a></li>
          </ul>
        </section>
      </template>

      <!-- 预搜索结果 -->
      <template v-else-if="step == 2">
        <section class="search-fast" v-if="searchValue">
          <ul class="search-list" v-if="prepareList.length">
            <li v-for="item in prepareList" @click="typeSearch(item.type,item.name)">
              <i class="i-all"></i>
              <span class="span-title" v-html="item.title"></span>
              <span class="span-append">{{item.name}}</span>
            </li>
          </ul>
          <!--<div class="search-empty" v-else>
            <div class="tips"><span class="span-tips">抱歉，没有搜到相关内容</span></div>
            <div class="title">您还可以在这里查找：</div>
            <ul class="search-list">
              <li v-for="item in allSearchList" @click="allSearch(item.type)"><i class="i-all"></i>{{item.title}}</li>
            </ul>
          </div>-->
        </section>
      </template>

      <!--主搜索结果页-->
      <section class="search-result" v-else-if="step == 3">
        <div v-if="searchType == 1">
          <div class="search-page-product" v-infinite-scroll="searchMore" infinite-scroll-distance="10"
               :infinite-scroll-disable="preventLoading">
            <template v-for="(content,i) in searchList">
              <router-link :to="{path:'search/'+reControllerName(content.productType),query:{id:content.id}}"
                           class="item">
                <div class="thum"><img v-lazy="content.mainPic" class="img-thum">
                  <span
                    class="span-tips ellipsis">{{content.productSubTypeName}}</span><span
                    class="span-location ellipsis"><i
                    class="icon iconfont icon-locationfill"></i>{{content.cityName}}</span>
                </div>
                <div class="font">
                  <span class="span-title">{{content.productName}}</span><br>
                  <i class="i-tips" v-if="content.listKeyword" v-for="names in content.listKeyword">{{names.name}}</i>
                  <span class="span-price"
                        :class="[content.productType === 2 && 'span-price-commodity']">{{content.price}}</span>
                  <span class="span-num">{{content.saledNum}}人购买</span>
                </div>
              </router-link>
            </template>
            <div class="noData-hint" v-show="!searchList.length">暂无相关产品....</div>
            <footer class="loading-more" v-show="loadingMoreText && searchList.length">
              <span>{{loadingMoreText}}</span>
            </footer>
          </div>
        </div>

        <div v-else-if="searchType == 2">
          <div class="search-page-notes" v-infinite-scroll="searchMore" infinite-scroll-distance="10"
               :infinite-scroll-disable="preventLoading">
            <div class="item" v-for="(content,i) in searchList">
              <router-link :to="{path:'search/homeTravelDetails',query:{travelId:content.id}}">
                <div class="user-info"><img v-lazy="content.imageUrl" class="img-head"><span
                  class="span-name">{{content.authorName}}</span>
                </div>
                <div class="notes-title ellipsis"><span class="span-title">{{content.title}}</span></div>
                <div class="notes-text"><span class="span-text">{{content.subTitle}}</span></div>
                <div class="notes-thum"><img v-lazy="content.coversImageUrl" class="img-thum"></div>
              </router-link>
              <like-group :item="content"></like-group>
            </div>
          </div>
          <div class="noData-hint" v-show="!searchList.length">暂无相关游记攻略....</div>
          <footer class="loading-more" v-show="loadingMoreText && searchList.length">
            <span>{{loadingMoreText}}</span>
          </footer>
        </div>
      </section>
      <section class="search-fast" v-else>
        <div class="search-empty">
          <div class="tips"><span class="span-tips">抱歉，没有搜到相关内容</span></div>
          <div class="title">您还可以在这里查找：</div>
          <ul class="search-list">
            <li @click="allSearch(1)"><i class="i-all"></i>产品</li>
            <li @click="allSearch(2)"><i class="i-all"></i>游记攻略</li>
          </ul>
        </div>
      </section>
    </div>
    <transition name="router-slid" mode="in-out">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import likeGroup from 'src/components/common/like'
  import {
    initSearch,
    prepareSearch,
    emptyHistory,
    search,
    Praise,
    collectionEdit
  } from '../../service/getData'
  import {getStore, setStore, debounce, trim} from 'src/config/mUtils'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        step: 1,
        currentCity: '上海',
        searchValue: null, // 搜索内容
        showList: false,//显示搜索结果
        searchList: [], // 搜索结果
        hasProduct: false,//结果有无产品
        hasStrategy: false,//结果有无游记攻略
        prepareList: [],// 预搜索结果
        allSearchList: [],
        searchType: null,//搜索类型，null全局搜索，1游记搜索，2产品搜索
        type: 0,//1游记搜索，2产品搜索
        isTypeSearch: false,//是否为栏目搜索
        showTabs: false,//是否显示tab
        pageNum: 1,//分页页数
        pageSize: 10,//分页单页数量
        pageTotal: 0,//分页总页数
        productType: null,//产品分类
        productSubType: null,//产品子分类

        searchHot: [],//热门搜索
        searchHistory: [], // 搜索历史记录

        tabText: [
          {title: "产品", view: 'view1', type: 1},
          {title: "游记攻略", view: 'view2', type: 2},
        ],

        controllerName: 'linesDetails',

        loadingMoreText: null,
        preventRepeatRequest: false, //阻止请求
        preventLoading: true,//阻止loadMore重复加载
      }
    },
    created(){
      if (this.$route.query.type) {
        this.type = this.searchType = this.$route.query.type;
        this.isTypeSearch = true;
        if (this.$route.query.type === 2) {
          this.tabText = [
            {title: "游记攻略", view: 'view2', type: 2},
            {title: "产品", view: 'view1', type: 1}
          ];
        }

      }
      this.debounce = debounce(this.prepareSearch, 300);
    },
    mounted(){
      this.$refs.ipt.focus();
      //初始化最热搜索、历史搜索
      this.initData();
      this.getCity();
    },
    components: {
      headTop,
      likeGroup
    },
    computed: {
      ...mapState([
        'login'
      ]),
    },
    methods: {
      initData: function () {
        this.step = 1;
        if (this.type) {
          this.showTabs = true;
        }

        initSearch().then(res => {
          if (res.status === 200) {
            res.obj.search_hot.forEach(v => this.searchHot.push(v['name']));
            if (this.login && !this.searchHistory) {
              res.obj.search_history.forEach(v => this.searchHistory.push(v['keyword']));
            }
            else {
              this.initHistory();
            }
          }
        });
      },
      initHistory: function () {
        if (getStore('searchHistory')) {
          this.searchHistory = JSON.parse(getStore('searchHistory'));
        }
      },
      backStep2: function () {
        if (this.step === 4) {
          this.step = 2;
        }
      },
      changeType: async function (i) {
        this.type = i;
        if (this.step === 3) {
          this.$refs.container.scrollTop = 0;
          this.pageNum = 1;
          let res = await this.search(this.searchValue, this.type);
          if (this.type == 2) {
            this.pageTotal = res.obj.travelnotes.pages;
            this.searchList = res.obj.travelnotes.list;
          }
          else {
            this.pageTotal = res.obj.products.pages;
            this.productTypes = res.obj.productTypes;
            this.searchList = res.obj.products.list;
          }
        }
        this.searchType = i;
      },
      changeTab: async function (productType, productSubType) {
        if (this.step === 3) {
          this.$refs.container.scrollTop = 0;
        }
        this.productType = productType;
        this.productSubType = productSubType;
        this.pageNum = 1;
        let res = await this.search(this.searchValue, this.searchType, this.productType, this.productSubType);
        this.pageTotal = res.obj.products.pages;
        this.productTypes = res.obj.productTypes;
        this.searchList = res.obj.products.list;
      },
      //预搜索关键字高亮
      highLightText: function () {
        if (this.prepareList.length) {
          this.prepareList.forEach((item, i) => {
            item.title = item.title.replace(this.searchValue, `<span data-v-cab61182 class='span-key'>${this.searchValue}</span>`);
          });
        }
      },
      //预搜索
      prepareSearch: async function () {
        this.prepareList = [];
        this.allSearchList = [];
        if (!this.searchValue) {
          return;
        }
        await this.getPrepareSearchResult();
        if (this.prepareList.length) {
          this.step = 2;
          this.highLightText();
        }
        else {
          this.step = 1;
        }
      },
      getPrepareSearchResult: async function () {
        let res = await prepareSearch(this.searchValue);
        if (res.status === 200) {
          if (res.obj.prepareSearch) this.prepareList = res.obj.prepareSearch;
          if (res.obj.allSearch) this.allSearchList = res.obj.allSearch;
        }
      },
      keyUpSearch: function (e) {
        if (this.searchValue) {
          if (e.keyCode === 13) {
            alert(this.searchValue);
          }
          //节流阀
          if (e.keyCode !== 13 && e.keyCode !== 27) {
            this.debounce();
          }
        }
        else {
          this.step = 1;
        }
      },
      inputSearch: function () {
        if (this.searchValue) {
          this.debounce();
        }
        else {
          this.step = 1;
        }
      },
      keySearch: function (val) {
        this.searchValue = val;
        this.$refs.ipt.focus();
        this.prepareSearch();
      },
      typeSearch: async function (type, keyword) {
        this.productType = null;
        this.productSubType = null;
        this.searchType = type;
        this.searchValue = keyword;

        let res = await this.search(keyword, type);
        this.showTabs = false;

        if (type == 2) {
          this.pageTotal = res.obj.travelnotes.pages;
          this.searchList = res.obj.travelnotes.list;
        }
        else {
          this.pageTotal = res.obj.products.pages;
          this.productTypes = res.obj.productTypes;
          this.searchList = res.obj.products.list;
        }
        if (this.searchList.length) {
          this.step = 3;
        }
        else {
          this.step = 5;
        }
      },
      allSearch: function (type) {
        this.typeSearch(type, null);
      },
      enterSearch: async function () {
        this.productType = null;
        this.productSubType = null;
        this.searchValue = trim(this.searchValue);
        if (!this.searchValue) this.searchValue = null;

        let res = await this.search(this.searchValue);
        this.step = 3;

        if (res.obj.products.list.length && res.obj.travelnotes.list.length) {
          this.showTabs = true;
          if (this.type == 2) {
            this.searchType = 2;
            this.pageTotal = res.obj.travelnotes.pages;
            this.searchList = res.obj.travelnotes.list;
          }
          else {
            this.searchType = 1;
            this.pageTotal = res.obj.products.pages;
            this.productTypes = res.obj.productTypes;
            this.searchList = res.obj.products.list;
          }
        }
        else if (res.obj.travelnotes.list.length) {
          this.searchType = 2;
          this.showTabs = false;
          this.pageTotal = res.obj.travelnotes.pages;
          this.searchList = res.obj.travelnotes.list;
        }
        else if (res.obj.products.list.length) {
          this.searchType = 1;
          this.showTabs = false;
          this.pageTotal = res.obj.products.pages;
          this.productTypes = res.obj.productTypes;
          this.searchList = res.obj.products.list;
        }
        else {
          this.step = 5;
        }
      },
      //搜索
      search: async function (searchValue = null, searchType = null, productType = null, productSubType = null) {
        //重置提示信息
        this.loadingMoreText = null;
        //搜索重置pageNum
        this.pageNum = 1;
        let res = await search(searchValue, searchType, this.pageNum, this.pageSize, this.currentCity, productType, productSubType);
        this.preventLoading = false;
        if (res.status === 200) {
          this.addHistory();
          return res;
        }

      },
      searchMore: async function () {
        if (this.preventLoading) {
          return;
        }
        //阻止重复提交
        this.preventLoading = true;
        if (this.pageTotal > this.pageNum) {
          this.pageNum++;
          let res = await search(this.searchValue, this.searchType, this.pageNum, this.pageSize, this.currentCity, this.productType, this.productSubType);
          if (res.status === 200) {
            let listArr;
            if (this.searchType === 2) {
              listArr = res.obj.travelnotes.list;
            }
            else {
              listArr = res.obj.products.list;
            }

            this.searchList = [...this.searchList, ...listArr];

            if (!listArr.length) {
              this.loadingMoreText = '没有了';
            }
          }
        }
        else {
          this.loadingMoreText = '没有了';
        }
        this.preventLoading = false;
      },
      //添加搜索历史
      addHistory: function () {
        if (!this.searchValue && this.searchValue != 0) {
          return;
        }
        for (let i = 0; i < this.searchHistory.length; i++) {
          let item = this.searchHistory[i];
          if (item == this.searchValue) {
            this.searchHistory.splice(i, 1);
          }
        }
        //只保存9条搜索记录
        if (this.searchHistory.length > 8) {
          this.searchHistory.pop();
        }
        this.searchHistory.unshift(this.searchValue);
        setStore('searchHistory', this.searchHistory);
      },
      //清空搜索历史
      cleanHistory: async function () {
        if (this.login) {
          await emptyHistory().then((res) => {
            if (res.status === 200) {
              this.searchHistory = [];
            }
          });
        }
        this.searchHistory = [];
        setStore('searchHistory', this.searchHistory);
      },
      reSearch: function () {
        this.step = 1;
      },
      //收藏
      collectionEdit: async function (collectionId, index) {
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await collectionEdit(2, collectionId, this.travelnotesList[index].isCollection ? 0 : 1).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {
            this.travelnotesList[index].isCollection = this.travelnotesList[index].isCollection ? 0 : 1;
          }
        });
      },
      //点赞
      async travelPraise(collectionId, index){
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await Praise({
          id: collectionId,
          praiseType: 1
        }).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {
            this.travelnotesList[index].addend = parseInt(res.obj.directSeed);
          }
        });
      },

      //获取城市
      getCity(){
        if (getStore('cityName')) {
          this.currentCity = getStore('cityName')
        } else {
          this.currentCity = '上海';
        }
      },

      //获取产品链接类型
      reControllerName(productType){
        if (productType === 1) {
          return 'spotsDetails'
        } else if (productType === 2) {
          return 'goodsDetails'
        } else if (productType === 3) {
          return 'linesDetails'
        }
      },
      goBack: function () {
        if (this.step > 1) {
          this.initHistory();
          this.searchValue = null;
          this.step = 1;
        }
        else {
          this.$router.go(-1)
        }
      },
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  //enter搜索
  .enter-search-wrapper {
    .history-travel {
      .item {
        width: 100%;
        background-color: $bgc2;
        border-bottom: 1px solid $bc;
        overflow: hidden;
        padding: 0 p2r(20);
        &:first-child {
          margin-top: 0;
        }
        .user-info {
          overflow: hidden;
          padding: p2r(20) p2r(12) 0 0;
          .img-head {
            float: left;
            @include wh(p2r(70), p2r(70));
            margin-right: p2r(20);

          }
          .span-name {
            @include sc(p2r(32), $mc);
            line-height: p2r(40);
          }
        }
        .notes-info {
          overflow: hidden;
          li {
            width: 50%;
            float: left;
            display: flex;
            align-items: center;
            padding: p2r(3) 0;
            p {
              @include sc(p2r(24), $fc);
              margin-right: p2r(20);
            }
            i {
              height: p2r(24);
              width: p2r(24);
              display: block;
              margin-right: p2r(20);
            }
            span {
              @include sc(p2r(24), $mc);
            }
          }
          .icon-times {
            @include bis('../../images/icon/icon_time.png')
          }
          .icon-moneys {
            @include bis('../../images/icon/icon_money.png')
          }
          .icon-likes {
            @include bis('../../images/icon/icon_like.png')
          }
          .icon-days {
            @include bis('../../images/icon/icon_day.png')
          }
        }
        .notes-title {
          .span-title {
            @include sc(p2r(26), $mc);
            @include ellipsisrows(4);
            word-break: break-all;
          }
        }
        .notes-text {
          .span-text {
            @include sc(p2r(24), $mc);
          }
        }
        .notes-thum {
          @include wh(100%, p2r(240));
          overflow: hidden;
          .img-thum {
            width: 100%;
          }
        }
      }
    }

    .time-node-block {
      h3 {
        @include sc(p2r(24), $fc);
        line-height: (70/24);
        padding: 0 p2r(20);
        font-weight: 100;
        background: $bc;
      }
      > ul {
        li {
          padding: p2r(20);
          background: $fc2;
          border-bottom: 1px solid $bc;
          & > div {
            width: 100%;
            display: flex;
          }
        }
        /*图片盒子*/
        .img-box {
          width: (180/600)*100%;
          position: relative;
          i {
            position: absolute;
            left: 0;
            top: 0;
            @include sc(p2r(24), $fc2);
            background: rgba(0, 0, 0, .5);
            padding: p2r(2) p2r(15) p2r(2) p2r(5);
          }
          i:before {
            content: '';
            display: inline-block;
            width: p2r(15);
            height: p2r(20);
            @include bis('../../images/icon/location-icon.png');
            vertical-align: middle;
            margin-right: p2r(10);
          }
          img {
            @include wh(p2r(180), p2r(150));
          }
          p {
            @include sc(p2r(24));
            background: $bgc;
            line-height: (40/24);
            text-align: center;
          }
        }
        /*简介盒子*/
        .describe-box {
          width: (400/600)*100%;
          padding-left: p2r(20);
          /*简介文字*/
          .text-describe {
            @include sc(p2r(28));
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
          }
          /*标签*/
          .label {
            display: flex;
            padding: p2r(15) 0;
            span {
              @include sc(p2r(24), $blue);
              padding: 0 p2r(15);
              border: 1px solid $blue;
              border-radius: p2r(3);
              margin-right: p2r(10);
            }
            span:last-child {
              margin-right: 0;
            }
          }
          /*价格*/
          .price {
            display: flex;
            @include fj(space-between);
            p {
              @include sc(p2r(22), $fc);
            }
            span:first-child {
              @include sc(p2r(30), $fc3);
              font-weight: bold;
              i {
                @include sc(p2r(22), $fc3);
              }
            }
          }
        }
      }
    }
  }

  .search-form {
    position: absolute;
    top: p2r(16);
    right: p2r(16);
    @include wh(82%, p2r(56));
    @include borderRadius(p2r(12));
    background-color: $bgc2;
    overflow: hidden;
    .i-search {
      display: inline-block;
      @include wh(p2r(25), p2r(25));
      @include ct;
      left: p2r(20);
      @include bis("../../images/icon/icon_ipn_search.png");
    }
    input {
      display: inline-block;
      float: right;
      width: 84%;
      padding: 0;
      margin: 0;
      line-height: p2r(56);
      margin-right: p2r(20);
      @include sc(p2r(26), $mc);
    }
  }

  .search-wrap {
    margin: 0 p2r(14);
    .title {
      @include sc(p2r(28), $fc);
      line-height: p2r(68);
      padding: 0 p2r(14);
    }
    .list {
      @include fj(flex-start);
      flex-wrap: wrap;
      li {
        margin-bottom: p2r(20);
        .a-his {
          display: inline-block;
          padding: p2r(10) p2r(32);
          margin: 0 p2r(14);
          line-height: p2r(40);
          @include sc(p2r(28), $mc);
          border: 1px solid $bc;
          background-color: $bgc2;
        }
      }
    }
    .btn {
      text-align: center;
      margin-bottom: p2r(32);
      .a-clean {
        @include sc(p2r(24), $blue);
        line-height: p2r(56);
      }
    }
  }

  .search-history {
    border-bottom: 1px solid $bc;
    margin-bottom: p2r(24);
  }

  .search-fast {
    position: fixed;
    left: 0;
    top: p2r(88);
    width: 100%;
    .search-list {
      background-color: $bgc2;
      li {
        position: relative;
        border-bottom: 1px solid $bc;
        padding: p2r(25) p2r(12) p2r(25) p2r(74);
        @include sc(p2r(30), $mc);
        line-height: p2r(40);
        background-color: $bgc2;
        .i-all {
          display: inline-block;
          @include wh(p2r(33), p2r(33));
          @include ct;
          left: p2r(26);
        }
        /*.i-product {
          @include bis("../../images/icon/icon_search_product.png");
        }
        .i-notes {
          @include bis("../../images/icon/icon_search_notes.png");
        }*/

        .span-title {
          margin-right: p2r(16);
        }

        .span-append {
          color: $fc;
          display: inline-block;
        }
      }
      li:nth-child(2n) {
        i {
          @include bis("../../images/icon/icon_search_notes.png");
        }
      }
      li:nth-child(2n-1) {
        i {
          @include bis("../../images/icon/icon_search_product.png");
        }
      }
    }

    .search-empty {
      .tips {
        @include wh(100%, p2r(280));
        position: relative;
        background-color: $bgc2;
        .span-tips {
          @include center;
          @include sc(p2r(28), $mc);
        }
      }
      .title {
        @include sc(p2r(28), $fc);
        line-height: p2r(68);
        padding: 0 p2r(30);
      }
    }
  }

  .span-key {
    color: $blue;
  }

  .noData-hint {
    text-align: center;
    color: $fc;
    font-size: p2r(28);
    padding: p2r(90) 0;
  }

  .search-tabs {
    background-color: $bgc2;
    border-bottom: 1px solid $bc;
    position: absolute;
    left: 0;
    top: p2r(88);
    right: 0;
    > div {
      overflow: auto;
      white-space: nowrap;
    }
    a {
      text-align: center;
      @include sc(p2r(32), $mc);
      line-height: p2r(60);
      border-bottom: p2r(4) solid $bgc2;
      padding: p2r(10) p2r(24);
      display: inline-block;
    }
    .active {
      border-bottom-color: $blue;
      color: $blue;
    }
  }

  .search-result {
    background-color: $bgc;
    .search-tabs-stance {
      height: p2r(98);
      overflow: hidden;
    }
    .search-page {
      display: none;
    }
    .search-page-product {
      .item {
        border-bottom: 1px solid $bc;
        padding: p2r(18);
        @include fj(flex-start);
        align-items: flex-start;
        background-color: $bgc2;
        .thum {
          position: relative;
          width: p2r(180);
          margin-right: p2r(20);
          .img-thum {
            @include wh(p2r(180), p2r(150));
          }
          .span-tips {
            display: block;
            @include wh(100%, p2r(40));
            @include sc(p2r(24), $mc);
            line-height: p2r(40);
            background-color: $bgc;
            text-align: center;
          }
          .span-location {
            max-width: 100%;
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            @include sc(p2r(24), $fc2);
            line-height: p2r(30);
            padding: 0 p2r(12) 0 0;
            background-color: rgba(0, 0, 0, 0.4);
          }
          .icon {
            display: inline-block;
            @include borderRadius(p2r(28));
            @include sc(p2r(24), $fc2);
            margin: 0 p2r(4);
          }
        }
        .font {
          position: relative;
          padding-bottom: p2r(54);
          min-height: p2r(190);
          flex: 1;
          .span-title {
            display: inline-block;
            @include sc(p2r(28), $mc);
            line-height: p2r(32);
            min-height: p2r(64);
            margin-bottom: p2r(12);
            width: 100%;
            word-break: break-all;
          }
          .i-tips {
            display: block;
            @include sc(p2r(24), $blue);
            line-height: p2r(34);
            border: 1px solid $blue;
            padding: 0 p2r(12);
            margin: p2r(5) p2r(10) p2r(5) 0;
            @include borderRadius(p2r(4));
            float: left;
          }
          .span-price {
            position: absolute;
            left: 0;
            bottom: 0;
            line-height: p2r(40);
            @include sc(p2r(40), $fc3);
            &:before {
              content: '￥';
              font-size: p2r(24);
            }
            &:after {
              content: '起';
              @include sc(p2r(24), $fc);
            }
          }

          .span-price-commodity {
            &:after {
              content: '';
            }
          }

          .span-num {
            position: absolute;
            right: 0;
            bottom: 0;
            @include sc(p2r(24), $fc);
          }
        }
      }
    }
    .search-page-notes {
      .item {
        width: 100%;
        background-color: $bgc2;
        border-bottom: 1px solid $bc;
        border-top: 1px solid $bc;
        overflow: hidden;
        margin-top: p2r(12);
        padding: 0 p2r(20);
        &:first-child {
          margin-top: 0;
          border-top: none;
        }
        .user-info {
          overflow: hidden;
          padding: p2r(20) p2r(12) 0 p2r(12);
          .img-head {
            float: left;
            @include wh(p2r(70), p2r(70));
            margin-right: p2r(20);
            @include borderRadius(p2r(35));
          }
          .span-name {
            @include sc(p2r(26), $mc);
            line-height: p2r(70);
          }
        }
        .notes-title {
          .span-title {
            @include sc(p2r(30), $mc);
          }
        }
        .notes-text {
          .span-text {
            @include sc(p2r(24), $mc);
            @include ellipsisrows(4);
          }
        }
        .notes-thum {
          @include wh(100%, p2r(240));
          overflow: hidden;
          margin-top: p2r(12);
          .img-thum {
            width: 100%;
          }
        }
      }
    }
    .search-page-active {
      display: block;
    }
  }

  .loading-more {
    width: 100%;
    text-align: center;
    @include sc(p2r(28), $fc);
    line-height: 2;
  }

</style>
