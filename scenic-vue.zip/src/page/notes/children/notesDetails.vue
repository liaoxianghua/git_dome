<template>
  <div class="ui-container ui-padding ui-gray-bg">
    <head-top headTitle="游记详情">
      <div slot="register" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <div slot="fav" class="btn-all btn-right btn-right-1">
        <router-link to="" class="btn-fav"></router-link>
      </div>
      <div slot="share" class="btn-all btn-right">
        <router-link to="" class="btn-share"></router-link>
      </div>
    </head-top>
    <section class="details-wrap">
      <div class="user-info"><img src="../../../images/head_img.jpg" class="img-head"><span class="span-name">GJH</span><i
        class="i-time">2017-01-01</i></div>
      <div class="details-title"><span class="span-title">荡口美景,赞一个!!! </span></div>
      <div class="details-content"><img src="../../../images/notes_img.jpg">
        <p>
          秀丽的鹅湖孕育了历史名镇。镇内居民以华氏居多，其祖先华贞固熟读诸子百家，著有《虑得集》行世，族内子孙代代相传。因此，这里孝义之风盛行，物华天宝、钟灵毓秀、名人辈出，经济社会发展快速，成为江南粮赋第一乡。这里河道纵横、湖荡密布，小桥流水、环境幽雅。历经数年保护开发，荡口古镇历史文化街区按照国家5A级旅游景区精心打造成了一个集旅游、休闲、观光、度假为一体的江南水乡古镇。</p>
        <p>
          荡口历史遗存众多，有四个（13处）省级文保单位，一个市级文保单位，一个控保单位，50处历史建筑。2004年被公布为江苏省历史文化名镇，2008年被确定为无锡市五个重点保护的历史文化街区（名镇）之一，2010年被评为中国历史文化名镇。</p>
      </div>
    </section>
    <section class="product-wrap">
      <div class="product-title"><i class="i-bg"></i><span class="span-title">相关产品</span>
        <router-link to="" class="a-more">更多 &gt;</router-link>
      </div>
      <div class="item">
        <div class="thum"><img src="../../../images/product_img.jpg" class="img-thum"></div>
        <div class="title">宜兴陶都大饭店直通车2日1晚自由行(含往返大巴+住宿+宜兴善卷洞+中国陶都陶瓷城）</div>
        <div class="flex">
          <div class="price">1400</div>
          <div class="num">5400人出游</div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
  import headTop from '../../../components/header/head'

  export default {
    data(){
      return {}
    },
    created(){
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {}
  }

</script>
<style lang="scss" scoped>
  @import '../../../style/mixin';

  .details-wrap {
    padding: 0 p2r(20);
    @include bmb;
    .user-info {
      overflow: hidden;
      padding: p2r(20) p2r(12) 0 p2r(12);
      position: relative;
      .img-head {
        float: left;
        @include wh(p2r(70), p2r(70));
        margin-right: p2r(20);
      }
      .span-name {
        @include sc(p2r(26), $mc);
        line-height: p2r(70);
      }
      .i-time {
        @include sc(p2r(20), $fc);
        float: right;
        line-height: p2r(70);
      }
    }
    .details-title {
      .span-title {
        @include sc(p2r(26), $mc);
        line-height: p2r(48);
      }
    }
    .details-content {
      @include sc(p2r(26), $mc);
      img {
        width: 100%;
      }
      p {
        text-indent: p2r(52);
        margin: p2r(12) 0;
      }
    }
  }

  .product-wrap {
    @include bmb;
    margin-bottom: 0;
    .product-title {
      padding: 0 p2r(20);
      border-bottom: 1px solid $bc;
      position: relative;
      line-height: p2r(68);
      overflow: hidden;
      .i-bg {
        @include wh(p2r(4), p2r(26));
        background-color: #cda367;
        display: inline-block;
        margin-right: p2r(12);
      }
      .span-title {
        @include sc(p2r(30), $mc);
      }
      .a-more {
        @include sc(p2r(24), $fc);
        float: right;
      }
    }
    .item {
      padding: p2r(20);
      .thum {
        .img-thum {
          width: 100%;
        }
      }
      .title {
        @include sc(p2r(30), $mc);
        margin: p2r(4) 0;
      }
      .flex{
        @include fj();
        align-items: baseline;
      }
      .price {
        float: left;
        @include sc(p2r(36), $fc3);
        &:before {
          content: '￥';
          @include sc(p2r(24), $fc3);
        }
        &:after {
          content: '起/份';
          @include sc(p2r(24), $fc);
        }
      }
      .num {
        float: right;
        @include sc(p2r(24), $fc);
      }
    }
  }

</style>
