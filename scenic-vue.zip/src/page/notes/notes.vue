<template>
  <div class="ui-padding">
    <head-top headTitle="游记">
      <div slot="register" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <div slot="edit" class="btn-all btn-right btn-right-1">
        <router-link to="" class="btn-edit"></router-link>
      </div>
      <div slot="search" class="btn-all btn-right">
        <router-link to="" class="btn-search"></router-link>
      </div>
    </head-top>
    <section class="banner"><img src="../../images/banner_notes.jpg"></section>
    <section class="notes-list">
      <div class="item">
        <router-link to="notes/notesDetails">
          <div class="user-info"><img src="../../images/head_img.jpg" class="img-head"><span class="span-name">GJH</span>
          </div>
          <div class="notes-title ellipsis"><span class="span-title">荡口美景,赞一个!!! </span></div>
          <div class="notes-thum"><img src="../../images/notes_img.jpg" class="img-thum"></div>
          <ul class="notes-fav">
            <li><span class="span-fav">4310</span></li>
            <li><span class="span-msg">1230</span></li>
            <li><span class="span-view">4310</span></li>
          </ul>
        </router-link>
      </div>
    </section>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'

  export default {
    data(){
      return {}
    },
    created(){
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {}
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .notes-container {
    padding-top: p2r(88);
  }

  .banner {
    width: 100%;
    img {
      width: 100%;
    }
  }

  .notes-list {
    .item {
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      border-top: 1px solid $bc;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(26), $mc);
          line-height: p2r(48);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        .img-thum {
          width: 100%;
        }
      }
      .notes-fav {
        @include fj(left);
        li {
          padding-bottom: p2r(16);
          span {
            @include sc(p2r(24), $fc);
            height: p2r(35);
            line-height: p2r(35);
            padding: 0 p2r(30) 0 p2r(55);
            background-size: auto 100%;
            background-repeat: no-repeat;
          }
          .span-fav {
            background-image: url(../../images/icon/icon_list_fav.png);
          }
          .span-msg {
            background-image: url(../../images/icon/icon_list_msg.png);
          }
          .span-collect{
            background-image: url(../../images/icon/icon_list_collect.png);
          }
          .span-view {
            background-image: url(../../images/icon/icon_list_view.png);
          }
        }
      }
    }
  }
</style>
