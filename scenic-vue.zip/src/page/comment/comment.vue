<template>
  <div class="ui-body ui-padding-header ui-gray-bg page-body">
    <head-top :headTitle="headTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container" v-infinite-scroll="loadingMore" infinite-scroll-distance="10"
         :infinite-scroll-disable="preventLoading">
      <section class="comment-label">
        <ul class="list">
          <li><a class="a-label" @click.prevent="changeTabs(null)" :class="{'a-label-active':tabIndex == null}">全部</a>
          </li>
          <li><a class="a-label" @click.prevent="changeTabs(45)" :class="{'a-label-active':tabIndex == 45}">好评({{commentGNum}})</a>
          </li>
          <li><a class="a-label" @click.prevent="changeTabs(23)" :class="{'a-label-active':tabIndex == 23}">中评({{commentMNum}})</a>
          </li>
          <li><a class="a-label" @click.prevent="changeTabs(1)" :class="{'a-label-active':tabIndex == 1}">差评({{commentBNum}})</a>
          </li>
          <li><a class="a-label" @click.prevent="changeTabs(6)" :class="{'a-label-active':tabIndex == 6}">图片({{commentTNum}})</a>
          </li>
        </ul>
      </section>
      <template v-show="showPage">
        <section class="comment-list" v-if="listArr.length">
          <div class="item" v-for="item in listArr">
            <div class="user-head"><img v-lazy="item.memberBasic.imageUrl" class="img-head"></div>
            <div class="user-name"><span class="span-name">{{item.memberBasic.memberAccount | elsName}}</span>
            </div>
            <div class="comment-star">
              <i class="icon iconfont" :class="[item.gread>0?'icon-favorfill':'icon-favor']"></i><i
              class="icon iconfont"
              :class="[item.gread>1?'icon-favorfill':'icon-favor']"></i><i
              class="icon iconfont" :class="[item.gread>2?'icon-favorfill':'icon-favor']"></i><i class="icon iconfont"
                                                                                                 :class="[item.gread>3?'icon-favorfill':'icon-favor']"></i><i
              class="icon iconfont" :class="[item.gread>4?'icon-favorfill':'icon-favor']"></i>
              <span class="span-score">{{item.gread}}</span></div>
            <div class="push-time">{{item.createTime | formatDate}}</div>
            <div class="comment-cont"><p>{{item.content}}</p></div>
            <div class="img-list" v-if="item.productcommentfile.length">
              <img v-for="v in item.productcommentfile" v-lazy="v.fileUrl" @click="changeSlideImg(v.fileUrl)">
            </div>
            <favour :item="item"></favour>
            <div class="replay" v-if="item.sellerComtent">
              <i class="i-say"></i>
              <p>商家回复：{{item.sellerComtent}}</p>
            </div>
          </div>
        </section>
        <section class="goods-empty" v-else>暂无评价</section>
      </template>
      <footer class="loading-more" v-show="loadingMoreText && listArr.length">{{loadingMoreText}}</footer>
    </div>
    <album :picUrl="slideImg" @closeAlbum="changeSlideImg('')"></album>
  </div>
</template>

<script>
  import album from 'src/components/common/album'
  import favour from 'src/components/common/goods/favour'
  import {goodsComment, Praise} from 'src/service/getData'
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {
        productId: 0,//产品ID
        commentNum: 0, //评论数
        commentGNum: 0, //好评数
        commentMNum: 0, //中评数
        commentBNum: 0, //差评数
        commentTNum: 0,//带图片的评论数
        headTitle: '点评',
        listArr: [],
        typeArr: [],//产品分类列表
        pageNum: 1,
        pageSize: 10,
        totalPage: 1,
        tabIndex: null,
        showPage: false, //显示页面内容
        preventLoading: false, //阻止加载更多
        loadingMoreText: '',
        slideImg: null,
      }
    },
    filters: {
      elsName: function (name) {
        let length = name.length;
        if (length != 11) {
          return '***' + name.substr(3, length);
        }
        else {
          return name.substr(0, 3) + '****' + name.substr(7, length);
        }
      },
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
    },
    created(){
      if (this.$route.query.id) this.productId = parseInt(this.$route.query.id);
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
      album,
      favour
    },
    computed: {},
    methods: {
      initData: async function () {
        this.pageNum = 1;
        this.showPage = false;
        let res = await goodsComment(this.productId, this.tabIndex, this.pageSize, this.pageNum);
        if (res.status !== 200) {
          return;
        }
        this.showPage = true;
        let total = parseInt(res.obj.commentStatistic.A) + parseInt(res.obj.commentStatistic.B) + parseInt(res.obj.commentStatistic.C);
        this.headTitle = '点评(' + total + ')';
        this.listArr = res.obj.proudctComments.list;
        this.totalPage = res.obj.proudctComments.pages;
        this.commentGNum = res.obj.commentStatistic.A;
        this.commentMNum = res.obj.commentStatistic.B;
        this.commentBNum = res.obj.commentStatistic.C;
        this.commentTNum = res.obj.commentStatistic.D;
      },

      loadingMore: async function () {
        if (this.totalPage > this.pageNum) {
          this.preventLoading = true;
          this.pageNum++;

          let res = await goodsComment(this.productId, this.tabIndex, this.pageSize, this.pageNum);
          this.preventLoading = false;

          if (res.status !== 200) {
            return;
          }

          let listArr = res.obj.proudctComments.list;
          if (!listArr.length) {
            //没有更多阻止以后触发加载更多
            this.loadingMoreText = '没有更多了';
            return;
          }
          this.listArr = [...this.listArr, ...listArr];
        }
        else {
          this.loadingMoreText = '没有更多了';
        }
      },
      changeTabs: function (i) {
        this.tabIndex = i;
        this.initData();
      },
      changeSlideImg: function (val) {
        this.slideImg = val;
      },
      setFavour: async function (id) {
        let param = {id: id, praiseType: 2};
        let res = await Praise(param);
        if (res.status === 200) {
          for (let i in this.listArr) {
            let item = this.listArr[i];
            if (item.id == id) {
              this.Toast({message: res.message, position: 'bottom'});
              if (res.obj.praiseed) {
                item.praised = res.obj.praiseed;
                item.praiseCount++
              }
              else {
                item.praised = res.obj.praiseed;
                item.praiseCount--
              }
            }
          }
        }
      }
    },
  }

</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .page-body {
    z-index: 2;
  }

  .goods-empty {
    @include sc(p2r(26), $mc);
    text-align: center;
    width: 100%;
    margin: p2r(100) 0;
  }

  .loading-more {
    width: 100%;
    text-align: center;
    @include sc(p2r(28), $fc);
    line-height: 2;
    margin-bottom: p2r(20);
  }

  .comment-label {
    .list {
      text-align: center;
      margin: p2r(16) p2r(36);
      overflow: hidden;
      li {
        float: left;
        margin: p2r(6) 0;
        .a-label {
          display: block;
          padding: 0 p2r(16);
          margin: 0 p2r(6);
          line-height: p2r(58);
          @include sc(p2r(28), $mc);
          border: 1px solid $bc;
          background-color: $bgc2;
          @include borderRadius(p2r(8));
        }
        .a-label-active {
          background-color: $blue;
          color: $fc2;
          border-color: $blue;
        }
      }
    }
  }

  .comment-list {
    .item {
      @include bmb;
      padding: p2r(22) p2r(30);
      .user-head {
        float: left;
        @include wh(p2r(72), p2r(72));
        @include borderRadius(p2r(36));
        margin-right: p2r(24);
        overflow: hidden;
        .img-head {
          @include wh(p2r(72), p2r(72));
        }
      }
      .user-name {
        @include sc(p2r(24), $mc);
        width: p2r(320);
        float: left;
      }
      .comment-star {
        @include wh(p2r(320), p2r(24));
        line-height: 1;
        float: left;
        .icon {
          @include sc(p2r(24), $fc3);
          margin-right: p2r(4);
        }
        .span-score {
          @include sc(p2r(24), $fc3);
          &:after {
            content: '分';
          }
        }
      }
      .push-time {
        float: right;
        @include sc(p2r(24), $fc);
      }
      .comment-cont {
        width: 100%;
        overflow: hidden;
        padding-top: p2r(12);
        @include sc(p2r(26), $mc);
        line-height: 1.6;
      }
      .img-list {
        white-space: nowrap;
        overflow: auto;
        margin: p2r(12) 0;
        min-width: 100%;
        & > img {
          height: p2r(120);
          margin-right: p2r(8);
        }
      }
      .favour {
        overflow: hidden;
        span {
          float: right;
          @include sc(p2r(26), $fc);
          border: p2r(2) solid $bc;
          padding: p2r(6) p2r(12);
          @include borderRadius(p2r(6));
        }
        .span-active {
          color: $fc3;
        }
        .favour-active {
          color: red;
        }
      }
      .replay {
        position: relative;
        background-color: #edf4ff;
        @include borderRadius(p2r(12));
        @include sc(p2r(24), $mc);
        width: 100%;
        padding: p2r(16);
        margin-top: p2r(16);
        .i-say {
          position: absolute;
          left: p2r(24);
          top: p2r(-8);
          width: 0;
          height: 0;
          border-left: p2r(6) solid transparent;
          border-right: p2r(6) solid transparent;
          border-bottom: p2r(8) solid #edf4ff;
        }
        p {
          margin: 0;
          line-height: p2r(30);
        }
      }
    }
  }
</style>
