<template>
  <div class="ui-body ui-padding">
    <head-top headTitle="城市定位" ref="top">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="search-form">
      <i class="i-search"></i>
      <input type="text" name="city" autocomplete="off" placeholder="请输入城市，如上海/shanghai/sh" class="ipn-value"
             v-model="inputValue">
    </div>
    <div class="ui-container" ref="container">
      <section class="city-now">定位城市：<span class="span-city">{{cityname}}</span></section>
      <section class="city-hot" v-if="searchresults.length">
        <div class="title" v-if="inputValue">搜索结果：</div>
        <!--<div class="title" v-else>搜索历史：</div>-->
        <ul class="list">
          <template v-if="searchresults[1] === true">
            <li><a class="a-city">{{searchresults[0]}}</a></li>
          </template>
          <template v-else>
            <li v-for="city in searchresults"><a class="a-city" @click.prevent="nextPage(city)">{{city}}</a></li>
          </template>
        </ul>
      </section>
      <section class="city-hot">
        <div class="title" ref="hotCity">热门</div>
        <ul class="list">
          <li v-for="hotcity in heatCity"><a class="a-city" @click="nextPage(hotcity.name)">{{hotcity.name}}</a></li>
        </ul>
      </section>
      <section class="city-list">
        <div v-for="item in cityList">
          <div class="title" ref="i">{{item.char}}</div>
          <ul class="list">
            <li v-for="city in item.list" @click="nextPage(city.name)">{{city.name}}</li>
          </ul>
        </div>
      </section>
      <section class="city-bar">
        <a @click="location($event,'h')">热门</a>
        <a v-for="(citys,i) in cityList" @click="location($event,i)">{{citys.char}}</a>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import {cityInit, selectCity} from '../../service/getData'
  import {getStore, setStore,} from '../../config/mUtils'

  export default {
    data(){
      return {
        inputValue: '', // 搜索地址
        cityid: 'SHA', // 当前城市id
        cityname: '上海', // 当前城市名字
        placelist: [], // 搜索城市列表
        placeHistory: [], // 历史搜索记录
        historytitle: true, // 默认显示搜索历史头部，点击搜索后隐藏
        placeNone: false, // 搜索无结果，显示提示信息
        heatCity: [],  //热门城市

        cityList: [], //城市列表

        searchresults: [],

        activeLetter: false,
      }
    },

    mounted(){
      this.getCityInit();//获取热门城市
    },
    components: {
      headTop
    },

    computed: {},

    methods: {
      location(e, i){
        if (typeof i === "string") {
          this.activeLetter = true;
          //document.body.scrollTop = this.$refs.hotCity.offsetTop - this.$refs.top.$el.offsetHeight;
          this.$refs.container.scrollTop = this.$refs.hotCity.offsetTop - this.$refs.top.$el.offsetHeight;
          this.$refs.hotCity.style.fontWeight = 'bold';
        } else {
          this.activeLetter = true;
          //document.body.scrollTop = this.$refs.i[i].offsetTop - this.$refs.top.$el.offsetHeight;
          this.$refs.container.scrollTop = this.$refs.i[i].offsetTop - this.$refs.top.$el.offsetHeight;
          this.$refs.i[i].style.fontWeight = 'bold';
        }
        //选中字母
        let zMels = e.target.parentNode.children;
        for (let i = 0; i < zMels.length; i++) {
          if (zMels[i] === e.target) {
            e.target.parentNode.children[i].style.color = "#6ba4f5";
          } else {
            e.target.parentNode.children[i].style.color = "#cda467";
          }
        }
        //选中
        this.$refs.i.forEach((el, inx) => {
          if (inx !== i) {
            el.style.fontWeight = '100';
          }
        });
      },

      async getCityInit(){
        this.cityname = getStore('cityName') ? getStore('cityName') : '上海';
        await cityInit().then(res => {
          if (res.status === 200) {
            this.heatCity = res.obj.hotCity;
            for (let k in res.obj.groupCity) {
              let item = res.obj.groupCity[k];
              this.cityList.push({char: k, list: item});
            }
          }
          this.cityList = this.cityList.sort(function (a, b) {
            return a.char.charCodeAt(0) - b.char.charCodeAt(0);
          });
        });
      },

      async nextPage(cityName){
        await selectCity(cityName).then(res => {
          if (res.status === 200) {
            setStore('cityName', cityName);
            this.$router.push({path: '/home', query: {cityName}});
          } else {
            this.messageBox.alert(res.message);
          }
        })
      },
    },

    watch: {
      inputValue(val){
        if (val !== '') {
          this.$refs.container.scrollTop = 0;
        }
        let results = [];
        this.searchresults = results;
        if (!val) {
          return;
        }
        val = val.toUpperCase();
        for (let i in this.cityList) {
          this.cityList[i].list.forEach(v => {
            if (v.name) {
              if (v.pinyin && v.pinyin.indexOf(val) !== -1) {
                results.push(v.name);
              } else if (v.jianpin && v.jianpin.indexOf(val) !== -1) {
                results.push(v.name);
              } else if (v.name && v.name.indexOf(val) !== -1) {
                results.push(v.name);
              } else if (v.initialLetter && v.initialLetter.indexOf(val) !== -1) {
                results.push(v.name);
              } else {
                return;
              }
            }
          });
        }
        if (results.length) {
          this.searchresults = results;
        } else {
          this.searchresults = [];
          this.searchresults[0] = "没有搜索结果，请重新输入.."
          this.searchresults[1] = true
        }
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .search-form {
    position: absolute;
    top: p2r(16);
    right: p2r(16);
    @include wh(p2r(520), p2r(56));
    @include borderRadius(p2r(12));
    background-color: $bgc2;
    overflow: hidden;
    .i-search {
      display: inline-block;
      @include wh(p2r(25), p2r(25));
      @include ct;
      left: p2r(20);
      @include bis("../../images/icon/icon_ipn_search.png");
    }
    input {
      float: right;
      width: p2r(440);
      padding: 0;
      margin: 0;
      line-height: p2r(56);
      margin-right: p2r(20);
      @include sc(p2r(26), $mc);
    }
  }

  .city-now {
    @include sc(p2r(28), $fc);
    line-height: p2r(80);
    @include bmb;
    margin: p2r(12) 0;
    padding: 0 p2r(20);
    .span-name {
      color: $mc;
    }
  }

  .city-hot {
    .title {
      @include sc(p2r(28), $fc);
      line-height: p2r(66);
      padding: 0 p2r(20);
    }
    .list {
      overflow: hidden;
      padding: 0 p2r(66) 0 p2r(12);
      li {
        float: left;
        margin-bottom: p2r(20);
        .a-city {
          display: inline-block;
          padding: 0 p2r(55);
          margin: 0 p2r(8);
          line-height: p2r(60);
          @include sc(p2r(28), $mc);
          border: 1px solid $bc;
          background-color: $bgc2;
        }
      }
    }
  }

  .city-list {
    .title {
      @include sc(p2r(24), $mc);
      padding: 0 p2r(30);
      line-height: p2r(36);
    }
    .list {
      @include bmb;
      padding-left: p2r(30);
      margin-bottom: 0;
      li {
        border-bottom: 1px solid $bc;
        line-height: p2r(80);
        @include sc(p2r(30), $mc);
        &:last-child {
          border-bottom: none;
        }
      }
    }
  }

  .city-bar {
    @include ct;
    position: fixed;
    right: p2r(10);
    text-align: center;
    line-height: 1.2;
    a, span {
      display: block;
      @include sc(p2r(24), $fc3);
    }
    a {
      font-weight: bolder;
    }
  }
</style>
