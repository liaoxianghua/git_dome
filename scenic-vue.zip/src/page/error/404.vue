<template>
  <div class="ui-container ui-gray-bg">
    <div class="error-wrap">
      <img src="../../images/hz.png"><br>
      <span class="span-404">抱歉，页面不见了！</span>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'

  export default {
    components: {
      headTop,
    },
    data(){
      return {}
    },
    mounted(){
    },
    methods: {},
  }
</script>

<style lang="scss">
  @import 'src/style/mixin';

  .error-wrap {
    text-align: center;
    @include center;
    white-space: nowrap;
    @include sc(p2r(32), $mc);
  }
</style>
