<template>
  <div class="ui-padding">
    <head-top v-bind:headTitle="title">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'

  export default {
    data(){
      return {
        title: '服务规则', //登录方式，默认普通登录
      }
    },
    components: {
      headTop,
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

</style>
