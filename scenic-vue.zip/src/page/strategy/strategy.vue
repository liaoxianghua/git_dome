<template>
  <div>
    <div class="ui-body ui-padding-header ui-padding-footer">
      <head-top headTitle="游记攻略">
        <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
        <router-link :to="{path:'/search',query:{type:2}}" slot="btn" class="btn-all btn-right btn-search"
                     tag="div"></router-link>
      </head-top>
      <div class="ui-container" v-infinite-scroll="loadingMore" infinite-scroll-distance="10"
           :infinite-scroll-disable="preventLoading" v-if="showPage">
        <section class="notes-list">
          <div class="item" v-for="(item,i) in travelListdata">
            <router-link :to="{path:'/homeTravelDetails',query:{travelId:item.id,isFlag:item.isFlag}}">
              <div class="notes-title ellipsis"><span class="span-title ">{{item.title}}</span></div>
              <div class="notes-text"><span class="span-text">{{item.subTitle}}</span></div>
              <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
            </router-link>
            <like-group
              :item="item"
            ></like-group>
          </div>
          <div class="no-hint" v-show="!travelListdata.length">
            <span>暂时没有数据哦!</span>
          </div>
          <footer class="loading-more" v-show="loadingMoreText && travelListdata.length">{{loadingMoreText}}</footer>
        </section>
      </div>
      <foot-guide></foot-guide>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import footGuide from 'src/components/footer/footGuide'
  import likeGroup from 'src/components/common/like'

  import {travelList, Praise, collectionEdit} from '../../service/getData'
  import {getStore} from 'src/config/mUtils'

  export default {
    data(){
      return {
        pagNam: 1,
        pagSize: 10,
        totalPage: null,
        currentCity: '上海', //当前城市

        isCollection: null,  //是否收藏
        travelListdata: [],  //列表数据
        ispraise: 0, //是否点赞
        addend: 0, //点赞数量

        showPage: false,//显示页面
        preventRepeatRequest: false,//接口开关
        preventLoading: true, //阻止加载更多
        loadingMoreText: '',
      }
    },
    created(){
    },
    mounted(){
      this.getTravelData();
    },
    components: {
      headTop,
      footGuide,
      likeGroup
    },
    methods: {
      //初始数据
      async getTravelData(){
        if (getStore('cityName')) {
          this.currentCity = getStore('cityName');
        }
        await travelList({
          city: this.currentCity,
          pageNum: this.pagNam,
          pageSize: this.pagSize
        }).then(res => {
          this.preventLoading = false;
          if (res.status === 200) {
            let travelListdata = res.obj.travelnotesvo.list;
            this.totalPage = res.obj.travelnotesvo.total;

            travelListdata.forEach(item => {
              item.isCollection = 0;
              item.addend = 0;
            });
            this.travelListdata = travelListdata;
            this.showPage = true;
            if(this.travelListdata.length < this.pageSize){
              this.loadingMoreText = '没有了';
            }
          }
        })
      },

      //加载更多
      async loadingMore(){
        if (this.preventLoading) {
          return;
        }
        this.preventLoading = true;
        if (Math.ceil(this.totalPage / this.pagSize) > this.pagNam) {
          this.pagNam++;
          await travelList({
            city: this.currentCity,
            pageNum: this.pagNam,
            pageSize: this.pagSize
          }).then(res => {
            if (res.status !== 200) {
              return
            }
            let travelList = res.obj.travelnotesvo.list;
            this.travelListdata = [...this.travelListdata, ...travelList];
          });
        } else {
          this.loadingMoreText = '没有了';
        }
        this.preventLoading = false;
      },
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .notes-container {
    padding-top: p2r(88);
  }

  .banner {
    width: 100%;
    img {
      width: 100%;
    }
  }

  .notes-list {
    .item {
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      border-top: 1px solid $bc;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      &:first-child {
        margin-top: 0;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        line-height: 2;
        .span-text {
          @include sc(p2r(24), $mc);
          @include ellipsisrows(4);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        .img-thum {
          margin-top: p2r(12);
          width: 100%;
          min-height: p2r(240);
        }
      }
      .notes-fav {
        @include fj(left);
        position: relative;
        li {
          padding-bottom: p2r(16);
          span {
            @include sc(p2r(24), $fc);
            height: p2r(35);
            line-height: p2r(35);
            padding: 0 p2r(30) 0 p2r(55);
            background-size: auto 100%;
            background-repeat: no-repeat;
          }
          .span-fav {
            background-image: url(../../images/icon/icon_list_fav.png);
          }
          .span-msg {
            background-image: url(../../images/icon/icon_list_msg.png);
          }
          .span-collect {
            background-image: url(../../images/icon/icon_list_collect.png);
          }
          .span-view {
            background-image: url(../../images/icon/icon_list_view.png);
          }
          .i-text {
            display: inline-block;
            border: 1px solid $bc;
            @include borderRadius(p2r(13));
            @include sc(p2r(20), $fc);
            line-height: p2r(30);
            font-style: normal;
            padding: 0 p2r(12);
          }
        }
        .time {
          @include ct;
          right: 0;
        }
      }
    }
  }
</style>
