<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="游记详情">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <!--游记详情-->
      <section class="details-wrap">
        <list-title titleText="游记"></list-title>
        <div class="item">
          <!--user-->
          <div class="user-info"><img v-lazy="detailContent.imageUrl" class="img-head">
            <span class="span-name">{{detailContent.name || "猴爸爸平台"}}</span>
          </div>
          <!--出行详情-->
          <ul class="notes-info">
            <li v-show="detailContent.departureDate">
              <i class="icon-time1"></i>
              <p>出行时间</p>
              <span>{{detailContent.departureDate | formatDate}}</span>
            </li>
            <li v-show="detailContent.fee">
              <i class="icon-money"></i>
              <p>人均消费</p>
              <span>{{detailContent.fee}}</span>
            </li>
            <li v-show="detailContent.persons">
              <i class="icon-like1"></i>
              <p>出行形式</p>
              <span>{{detailContent.persons}}</span>
            </li>
            <li v-show="detailContent.days">
              <i class="icon-day"></i>
              <p>出行天数</p>
              <span>{{detailContent.days}}</span>
            </li>
          </ul>
          <!--标题-->
          <h3 class="h3-travel-title">{{detailContent.title}}</h3>
          <!--游记内容-->
          <div class="details-content" v-for="(item,i) in detailContent.travelnotesdetailsList">
            <img v-if="item.url" v-lazy="item.url">
            <p v-else-if="item.words">
              {{item.words}}
          </p>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import listTitle from 'src/components/common/travelblock/traveTitle'
  import alertTip from 'src/components/common/alertTip'
  import likeGroup from 'src/components/common/like'

  import {setStore,getStore,saveHistory,checkLogin} from 'src/config/mUtils'
  import {mapState, mapMutations} from 'vuex'

  import {
    homeTravelDetails,
    homeDetailsComment,
    homeDetailsCommentUP,
    Praise,
    collectionEdit,
    travelHistory,
    travelDetails,
  } from 'src/service/getData'

  export default {
    data(){
      return {
        travelId:null,  //游记Id
        isFlag:null,  //用户身份标识
        detailContent:{}, //详情内容
        travelTitle:'', //游记标题
        preventRepeatRequest:false, //节流标识
      }
    },
    mounted(){
      this.$nextTick(() =>{
        this.travelId = this.$route.query.travelId;
        this.getTravelDetails();
      });
    },
    components: {
      headTop,
      listTitle,
    },

    methods:{
      /*详情数据*/
      async getTravelDetails(){
        await travelDetails(this.travelId).then(res => {
          if (res.status === 200) {
            //详情内容
            this.detailContent = res.obj.travelNote;
            //await travelHistory(this.travelId).then(res => {
          }
        })
      }
    },
    filters:{
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
    }
  }

</script>
<style lang="scss" scoped>
  @import 'src/style/mixin.scss';
  .details-wrap {
    @include bmb;
    .item {
      width: 100%;
      background-color: $bgc2;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      margin-bottom: p2r(10);
      &:first-child {
        margin-top: 0;
      }
      .h3-travel-title{
        font-size:p2r(28);
        font-weight:100;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
          border-radius: 50%;
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
        .span-time{
          @include sc(p2r(26), $fc);
          float:right;
          line-height: p2r(70);
        }
      }
      .notes-info{
        overflow: hidden;
        li{
          width:50%;
          float:left;
          display:flex;
          align-items: center;
          padding:p2r(3) 0;
          p{
            @include sc(p2r(24),$fc);
            margin-right:p2r(20);
          }
          i{
            height:p2r(24);
            width:p2r(24);
            display:block;
            margin-right:p2r(20);
          }
          span{
            @include sc(p2r(24),$mc);
          }
        }
        .icon-time1{@include bis('../../../images/icon/icon_time.png')}
        .icon-money{@include bis('../../../images/icon/icon_money.png')}
        .icon-like1{@include bis('../../../images/icon/icon_like.png')}
        .icon-day{@include bis('../../../images/icon/icon_day.png')}
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        .img-thum {
          width: 100%;
        }
      }
      .details-content {
        @include sc(p2r(24), $mc);
        padding-top: p2r(15);
        img {
          width: 100%;
        }
        p {
          text-indent: p2r(52);
          line-height: 2;
        }
      }
    }
  }
</style>
