<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top>
      <div slot="btn" class="btn-all btn-left btn-char" @click="$router.go(-1)">关闭</div>
      <ul slot="btn" class="controlBlock  btn-all btn-right">
        <li class="slot">
          <a href="#" class="iconfont  icon-order" @click.prevent="goSortPage"><span>照片排序</span></a>
        </li>
        <li class="draft"><a href="#" class="iconfont icon-check" @click.prevent="travelDraft"> <span>保存草稿</span></a>
        </li>
        <li class="publish"><a href="#" @click.prevent="getEditContentNum"><span>发表游记</span></a></li>
      </ul>
    </head-top>
    <!--内容编辑-->
    <div class="ui-container">
      <div class="editor-wrapper">
        <div class="editor-title">
          <div class="title-content">
            <!--<img v-if="titleBg" :src="titleBg">-->
            <textarea class="travel-title-text" :class="{'title-text2':!titleBg}" v-model="titleText"
                      maxlength="48"></textarea>
          </div>
          <div class="travel-editor-btn">
            <a class="add-text" @click.prevent="addtext({type:1,sortIndex:0})" href="">添加文字</a>
            <div class="img-add-wrap">
              <label for="addimg" class="add-img">插入图片</label>
              <input id="addimg" type="file" class="upload-input" accept="image/*"
                     @change="onload($event,{type:2,sortIndex:0})" ref="isfiles" multiple>
            </div>
          </div>
        </div>
        <div class="travel-content" v-for="(item,i) in editContent">
          <div class="editor-content">
            <div class="travel-text" v-if="item.type===1">
              <textarea class="content-text" placeholder="想要写点啥呢？" v-model="editContent[i]['words']" ref="contens"></textarea>
              <i class="icon-close iconfont icon-close" @click="deleteContent(i)">删除</i>
            </div>
            <div class="travel-img" v-if="item.type===2">
              <img ref="contens" :src="editContent[i]['url']" alt=""/>
              <input type="text" v-model="editContent[i]['url']">
              <i class="icon-close iconfont" @click="deleteContent(i)">删除</i>
            </div>
          </div>
          <div class="travel-editor-btn">
            <a class="add-text" @click.prevent="addtext({type:1,sortIndex:i+1,})" href="">添加文字</a>
            <div class="img-add-wrap">
              <label :for="'addimg'+i" class="add-img">插入图片</label>
              <input :id="'addimg'+i" type="file" class="upload-input" accept="image/*"
                     @change="onload($event,{type:2,sortIndex:i+1})" ref="isfiles" multiple>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--标题填写-->
    <div class="ui-body ui-padding-header ui-white-bg" v-if="isnewTreval&&!isnext">
      <head-top>
        <div slot="btn" class="btn-all btn-left btn-char" @click="$router.go(-1)">取消</div>
        <div slot="btn" class="btn-all btn-right btn-char" @click="isnext=true">下一步</div>
      </head-top>
      <div :class="{'ui-container':!isnext}">
        <div class="title-text-wrap">
          <textarea placeholder="请输入游记标题" v-model="titleText" maxlength="48"></textarea>
          <p>可输入<span>{{settitlenum}}</span>字</p>
        </div>
        <div class="hint-text">
          <p>提示:</p>
          <p>1.一个好的游记标题会给你带来更多的阅读哦;</p>
          <p>2.标题可以在写游记过程中编辑</p>
          <p>3.设置好标题后可以通过点击“下一步”来添加照片或文字</p>
        </div>
      </div>
    </div>
    <!--排序-->
    <div class="ui-body ui-padding-header ui-white-bg" v-show="isSort">
      <head-top headTitle="照片排序">
        <div slot="btn" class="btn-all btn-left btn-back" @click='isSort = false'></div>
        <div slot="btn" class="btn-all btn-right btn-char" @click='isSort = false'>完成</div>
      </head-top>
      <div class="ui-container">
        <div class="sort-wrapper">
          <draggable :list="editContent" :options="{animation:300,handle:'.cell'}">
            <div class="li-cell" v-for="(item,i) in editContent" :key="i">
              <div v-if="item.words" class="cell">{{item.words}}</div>
              <div v-if="item.url" class="cell"><img v-lazy="item.url" alt=""></div>
            </div>
          </draggable>
        </div>
      </div>
    </div>
    <!--弹框-->
    <div class="ui-body alert-body" v-show="isaAlert">
      <div class="alert-hint">
        <div class="hint-wrap">
          <div class="hint-cont">
            <p>你要完成游记，请选择</p>
            <p>经过您的辛勤耕耘，你的游记已经拥有了
        {{ Statisticsimages.length || 0}}张图片，
        {{ StatisticsTexts || 0}}个文字</p>
          </div>
          <div class="travel-btn-group">
            <a @click.prevent="travelDraft"> 暂不发表 </a>
            <a @click.prevent="travelPublish"> 发表游记 </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {uploadPic, newmytravel, amendmytravel, getmytravel} from 'src/service/getData'
  import {mapState, mapMutations} from 'vuex'
  import draggable from 'vuedraggable'
  import {baseUrl} from 'src/config/env'
  import axios from 'axios'
  import {trim} from 'src/config/mUtils'

  export default {
    data(){
      return {
        isnext: false, //是否是编辑新的游记
        isnewTreval: null,//判断是否是新建游记
        editorID: null,//编辑游记的id
        editStatus: null,//编辑游记的当前状态

        editTravel: null, //当前编辑游记
        titleBg: "", //编辑的title背景

        preventRequests: false, //防止多次请求

        editContent: [],//编辑器容器
        file: null,//上传的源文件
        StatisticsTexts: 0, //文字统计
        Statisticsimages: [],  //图片统计
        maxImgUrl: 5,

        //新建游记
        userId: null,
        titleText: '',//文章标题
        titleNum: 48,//限制标题文字
        travelNotesId: null, //文章id
        travelstatus: 0, //游记状态

        //排序
        isSort: false,
        isaAlert: false,
      }
    },

    mounted(){
      this.initData();
    },

    computed: {
      settitlenum(){//字符数字限制
        this.titleText = this.titleText.split('');
        if (this.titleText.length > this.titleNum) {
          this.titleText.length = this.titleNum;
        }
        this.titleText = this.titleText.join('');
        return this.titleNum - this.titleText.length;
      },
      ...mapState([
        'mytravel',
        'mytravelStatus'
      ]),
    },

    methods: {
      ...mapMutations([
        'INIT_MYTRAVEL',
        'SAVE_STATISTRAVEL',
        'SET_STARELSTATUS'
      ]),

      //初始化数据
      initData(){
        this.analysisRouter();
        this.getAgoDate();
      },

      //解析路由
      analysisRouter(){
        if (this.$route.query) {
          this.isnewTreval = this.$route.query.isnew; //判断是否是新建游记
          this.editorID = this.$route.query.editorid; //编辑游记的id
          this.editStatus = this.$route.query.editstatus; //编辑游记的当前状态
          this.editTravel = this.$route.query.edittravel;//当前编辑的游记
        }
      },

      //编辑旧游记时获取源数据
      getAgoDate(){
        if (this.isnewTreval) {
          return
        }
        this.titleText = this.editTravel.title;
        this.editContent = this.editTravel.travelnotesdetailsList;
        this.titleBg = this.editTravel.coversImageUrl;
        //this.settitleBg();
      },

      //保存为草稿
      async travelDraft(){
        this.titleText = trim(this.titleText);
        //是否有标题
        if (!this.titleText) {
          //let msg = !this.titleText && "没有编辑标题" || !this.titleBg && "还没有添加图片"
          this.messageBox.alert("请填写文章标题");
          return
        }
        if (this.preventRequests) {
          return
        }
        this.preventRequests = true;

        this.travelstatus = 0;

        this.filterNullText();

        this.isaAlert = false;//统计提示开关
        let parameter = this.parameter();
        if (this.isnewTreval) {
          //新建一片游记
          await newmytravel(parameter).then(res => {
            this.preventRequests = false;
            if (res.status === 200) {
              this.SET_STARELSTATUS({activeIndex: 2, travelstatus: 0});
              this.$router.replace('/myTravelIndex');

            }
          });
        }
        else {
          //修改游记
          await amendmytravel(parameter).then(res => {
            this.preventRequests = false;
            if (res.status === 200) {
              this.SET_STARELSTATUS({activeIndex: 2, travelstatus: 0});
              this.$router.replace('/myTravelIndex');
            }
          });
        }

        this.initMyTravel(0);
      },

      //发布游记
      async travelPublish(){
        this.titleText = trim(this.titleText);
        //是否有标题
        if (!this.titleText) {
          //let msg = !this.titleText && "没有编辑标题" || !this.titleBg && "还没有添加图片"
          this.messageBox.alert("请填写游记标题");
          return
        }
        if (this.preventRequests) {
          return
        }
        this.preventRequests = true;

        this.travelstatus = 1;

        //过滤空字符段落
        this.filterNullText();

        let parameter = this.parameter();
        this.isaAlert = false;
        if (this.isnewTreval) {
          //发布新游记
          await newmytravel(parameter).then(res => {
            this.preventRequests = false;
            if (res.status === 200) {
              this.SET_STARELSTATUS({activeIndex: 1, travelstatus: 1})
              this.$router.replace('/myTravelIndex');
            }
          });
        } else {
          //发布修改游记
          await amendmytravel(parameter).then(res => {
            this.preventRequests = false;
            if (res.status === 200) {
              this.SET_STARELSTATUS({activeIndex: 1, travelstatus: 1})
              this.$router.replace('/myTravelIndex');
            }
          });
        }
        this.initMyTravel(1);
      },

      //统计文字图片数量
      getEditContentNum(){
        this.titleText = trim(this.titleText);

        if (!this.titleText) {
          //let msg = !this.titleText && "没有编辑标题" || !this.titleBg && "还没有添加图片"
          this.messageBox.alert("请填写游记标题");
          return
        }

        this.editContent.forEach(item => {
          if (item.url) {
            this.Statisticsimages.push(item.url);
          } else if (item.words) {
            this.StatisticsTexts += item.words.length;
          }
        });
        this.isaAlert = true;
      },

      //初始化我的游记列表数据
      async initMyTravel(stat){
        await getmytravel({status: stat, pageSize: 10, pageNum: 1}).then(res => {
          if (res.status === 200) {
            this.INIT_MYTRAVEL(res.obj.travelnotesvo.list);
            this.SAVE_STATISTRAVEL(res.obj.travelNotesCountVo);
          }
        });
      },

      //设置title bg图片
      settitleBg(){
        if (this.editContent) {
          this.editContent.forEach(item => {
            let flag = false;
            if (item.url && !flag) {
              this.titleBg = item.url;
              flag = true;
              return false
            }
          });
        }
      },

      //排序
      goSortPage(){
        this.isSort = true;
      },

      //参数处理
      parameter(){
        let jsons = null;
        if (this.isnewTreval) {
          jsons = {
            "id": null,
            "mememberId": this.userId,
            "status": this.travelstatus,
            "type": 1,
            "title": this.titleText,
            "createTime": null,
            "travelnotesdetailsList": this.editContent
          }
        } else {
          jsons = {
            "id": this.editorID,
            "mememberId": this.userId,
            "status": this.travelstatus,
            "type": 1,
            "title": this.titleText,
            "createTime": null,
            "travelnotesdetailsList": this.editContent
          }
        }
        return JSON.stringify(jsons);
      },

      //删除当前文字/图片
      deleteContent(i){
        this.editContent.splice(i, 1);
      },

      //显示图片
      displayimg(basestr, obj, res){
        let url = "",
          fileName = "";
        if (res) {
          url = res.obj.busiPictureAttachvo.urlAttach;
          fileName = res.obj.busiPictureAttachvo.name;
        } else {
          url = basestr;
        }

        this.editContent.splice(obj.sortIndex, 0, {
          type: obj.type, url: url, fileName: fileName, sortIndex: obj.sortIndex,
          words: null, travelNotesId: this.travelNotesId, title: null, id: null,
        });
      },

      //添加文章文字
      addtext(obj){
        this.editContent.splice(obj.sortIndex, 0, {
          type: obj.type, url: null, fileName: null, sortIndex: obj.sortIndex,
          words: null, travelNotesId: this.travelNotesId, title: null, id: null,
        });
        this.$nextTick(() =>{
            console.log(this.$refs.contens);
            console.log(obj.sortIndex);
            console.log(this.$refs.contens[obj.sortIndex]);
            if(obj.type === 1){
              this.$refs.contens[obj.sortIndex].focus();
            }
        });
      },

      //过滤空字符段
      filterNullText(){
        this.editContent.forEach((item, i) => {
          if (item.type !== 1) {
            return
          }
          if (item.words === null || item.words.replace(/\s+/g, '').length === 0) {
            this.deleteContent(i);
          }
        })
      },

      //上传图片
      onload(e, obj){
        var maxsize = 100 * 1024;
        typeof e.target === 'undefined' ? this.file = e : this.file = e.target.files;
        if (!this.file.length) {
          return
        }
        let files = Array.prototype.slice.call(this.file);
        files = files.reverse();

        if (files.length > this.maxImgUrl) {
          this.Toast({message: '最多上传' + this.maxImgUrl + '张', position: 'bottom'});
          return
        }

        files.forEach((file, i) => {
          if (!/\/(?:jpeg|jpg|png|gif)/i.test(file.type) && file.type != '') {
            this.Toast({message: '不支持您上传的图片格式', position: 'bottom'});
            return
          }
          ;
          var reader = new FileReader();
          var _thit = this;
          reader.onload = function () {
            var result = this.result;
            var img = new Image();
            img.src = result;
            //如果图片大小小于100kb，则直接上传
            if (result.length <= maxsize) {
              img = null;
              _thit.upload(result, file.type, obj, file.name);
              return;
            }
            //图片加载完毕之后进行压缩，然后上传
            if (img.complete) {
              callback();
            } else {
              img.onload = callback;
            }
            function callback() {
              var data = _thit.compress(img);
              _thit.upload(data, file.type, obj, file.name);
              img = null;
            }
          }
          reader.readAsDataURL(file);
        });
      },
      //使用canvas对大图片进行压缩
      compress(img) {
        //    用于压缩图片的canvas
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext('2d');
        //    瓦片canvas
        var tCanvas = document.createElement("canvas");
        var tctx = tCanvas.getContext("2d");

        var initSize = img.src.length;
        var width = img.width;
        var height = img.height;

        //如果图片大于2百万像素，计算压缩比并将大小压至200万以下
        var ratio;
        if ((ratio = width * height / 2000000) > 1) {
          ratio = Math.sqrt(ratio);
          width /= ratio;
          height /= ratio;
        } else {
          ratio = 1;
        }
        canvas.width = width;
        canvas.height = height;
        //铺底色
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        //如果图片像素大于100万则使用瓦片绘制
        /*var count;
         if ((count = width * height / 1000000) > 1) {
         count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
         //            计算每块瓦片的宽和高
         var nw = ~~(width / count);
         var nh = ~~(height / count);
         tCanvas.width = nw;
         tCanvas.height = nh;
         for (var i = 0; i < count; i++) {
         for (var j = 0; j < count; j++) {
         tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
         ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
         }
         }
         } else {*/
        ctx.drawImage(img, 0, 0, width, height);
        //}

        //进行最小压缩
        var ndata = canvas.toDataURL('image/jpeg', 0.6);
        tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
        return ndata;
      },
      //开始上传
      async upload(basestr, type, obj, name) {
        var text = window.atob(basestr.split(",")[1]);
        var buffer = new Uint8Array(text.length);
        for (var i = 0; i < text.length; i++) {
          buffer[i] = text.charCodeAt(i);
        }
        var blob = this.getBlob([buffer], type);
        var formdata = this.getFormData();
        formdata.append('upload', blob, name);
        let res = await axios({
          method: 'POST',
          url: baseUrl + '/common/saveUploadFile',
          data: formdata,
          headers: {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        }).then((response) => {
          if (response.data.status === 200) {
            this.Toast({message: '上传成功', position: 'bottom'});
          }
          return response.data;
        }).catch((error) => {
          console.log(error);
        });
        this.displayimg(basestr, obj, res);
      },
      //获取formdata
      getFormData() {
        var isNeedShim = ~navigator.userAgent.indexOf('Android')
          && ~navigator.vendor.indexOf('Google')
          && !~navigator.userAgent.indexOf('Chrome')
          && navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534;
        return isNeedShim ? new FormDataShim() : new FormData()
      },
      getBlob(buffer, format) {
        try {
          return new Blob(buffer, {type: format});
        } catch (e) {
          var bb = new (window.BlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder);
          buffer.forEach(function (buf) {
            bb.append(buf);
          });
          return bb.getBlob(format);
        }
      },
    },

    components: {
      headTop,
      draggable
    },
    watch: {
      editContent(val){
        val.forEach((item, i) => {
          item.sortIndex = i;
        });
        if(this.isnewTreval){
          //this.settitleBg();
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';
  @import '../../../assets/iconfont/iconfont.css';

  .alert-body {
    background: none;
  }

  .content-wrapper {
    height: 100%;
    overflow: auto;
    background: $bgc2;
  }

  .alert-hint {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    height: 100%;
    background: rgba(0, 0, 0, .5);
    .hint-wrap {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 70%;
      background: $fc2;
      font-size: p2r(26);
      text-align: center;
    }
    .hint-cont {
      padding: p2r(20);
      p:last-child {
        margin: p2r(30) 0;
      }
    }
    .travel-btn-group {
      border-top: 1px solid $bc;
      display: flex;
      a {
        flex: 1;
        display: block;
        padding: p2r(15) 0;
        text-align: center;
      }
      a:first-child {
        border-right: 1px solid $bc;
      }
    }
  }

  //排序界面
  .sort-wrapper {
    padding: p2r(10);
    height: 100%;
    .sort-list {
      overflow: hidden;
    }
    .li-cell {
      width: p2r(620/3);
      height: p2r(620/3);
      padding: p2r(5);
      float: left;
    }
    .cell {
      width: 100%;
      height: 100%;
      padding: p2r(5);
      border: 1px solid $bc;
      font-size: p2r(26);
      color: $fc;
      overflow: hidden;
      img {
        width: 100%;
      }
    }
  }

  //头部控制按钮
  .controlBlock {
    display: flex !important;
    line-height: 1 !important;
    li {
      width: p2r(110);
      display: flex;
      align-items: center;
      @include fj(space-between);
      padding-left: p2r(10);
      a {
        @include sc(p2r(28), $fc2);
        span {
          width: p2r(58);
          display: inline-block;
          @include sc(p2r(28), $fc2);
          line-height: 1;
        }
      }
      a:before {
        vertical-align: top;
      }
    }
    .publish {
      a:before {
        content: '';
        display: inline-block;
        width: p2r(20);
        height: p2r(24);
        @include bis('../../../images/icon/leaf-icon.png');
        vertical-align: top;
      }
    }
    .draft {
      display: flex;
      align-items: center;
      @include fj(space-between);
    }
    .slot:after, .draft:after {
      content: '|';
      display: block;
      font-size: p2r(30);
      color: #5186d2;
    }
  }

  .editor-wrapper {
    min-height: 110%;
    img {
      max-width: 100%;
    }
    .editor-title {
      .travel-editor-btn {
        padding: p2r(30) p2r(60);
      }
    }

    .title-content {
      position: relative;
      text-align: center;
      background: $blue;
      min-height: p2r(240);
      > p {
        display: none;
      }
    }
    .upload-input {
      display: none;
    }
    .travel-title-text {
      position: absolute;
      bottom: p2r(20);
      height: p2r(60);
      left: 0;
      resize: none;
      width: (600/640)*100%;
      background: transparent;
      color: $fc2;
      font-size: p2r(30);
      border: 1px dashed $fc2;
      margin: 0 p2r(20);
      padding: p2r(10) p2r(20);
      font-weight: bold;
    }

    .title-text2 {
      color: $mc;
      border: 1px dashed $bc;
    }

    .travel-content {
      padding: 0 p2r(20);
    }

    .editor-content {
      position: relative;
    }
    .travel-text, .travel-img {
      .icon-close {
        position: absolute;
        right: p2r(10);
      }
    }
    .travel-img {
      text-align: center;
      img {
        max-width: 100%;
      }
      input {
        display: none;
      }
      .icon-close {
        background: rgba(0, 0, 0, .5);
        border-radius: p2r(20);
        color: $fc2;
        font-size: p2r(24);
        padding: p2r(4) p2r(20);
        bottom: p2r(14);
      }
    }

    .travel-text {
      border: 1px solid $bc;
      padding: p2r(20);
      padding-bottom: p2r(40);
      .icon-close {
        color: $fc;
        height: p2r(30);
        line-height: p2r(29);
        font-size: p2r(24);
        padding: p2r(3) p2r(20);
      }
    }
    .content-text {
      resize: none;
      width: 100%;
      height: p2r(110);
      overflow-y: auto;
      font-size: p2r(24);
    }
    .travel-editor-btn {
      padding: p2r(55) p2r(40) p2r(30) p2r(40);
      overflow: hidden;
      .img-add-wrap {
        float: right;
      }
      .add-text {
        float: left;
      }
      a, label {
        font-size: p2r(28);
        color: $blue;
        display: flex;
        align-items: center;
      }
      a:before, label:before {
        content: '';
        display: inline-block;
        width: p2r(50);
        height: p2r(50);
        vertical-align: middle;
        margin-right: p2r(20);
      }
    }
  }

  .add-text:before {
    @include bis('../../../images/icon/icon-t.png');
  }

  .add-img:before {
    @include bis('../../../images/icon/icon-pic.png');
  }

  .icon-close {
    @include sc(p2r(20), $fc);

  }

  //标题编辑
  .title-text-wrap {
    padding: p2r(20);
    textarea {
      resize: none;
      width: 100%;
      font-size: p2r(30);
      height: p2r(155);
    }
    p {
      @include sc(p2r(24), $fc);
      padding-bottom: p2r(10);
      border-bottom: 1px solid $bc;
      line-height: 1;
      text-align: right;
    }
  }

  .hint-text {
    padding: p2r(20);
    p {
      @include sc(p2r(24), $blue);
    }
  }
</style>
