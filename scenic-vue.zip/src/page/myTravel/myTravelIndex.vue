<template>
  <div class="ui-body page-padding ui-white-bg">
    <head-top headTitle="我的游记">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <ul class="tab-btn-blcok tab-pattern2">
      <li v-for="(item,index) in tabText"
          @click.prevent="initData(index,item.status)"
          :class="{active:activeIndex === index}">
        {{item.title}} {{item.totalPage}}



      </li>
    </ul>
    <div class="ui-container" v-infinite-scroll="loadingMore" infinite-scroll-distance="10"
         :infinite-scroll-disable="preventRepeatRequest" ref="container">
      <div class="tab-content-blcok my-travel-show"
           ref="travelC">
        <div class="item" v-if="listArr.length" v-for="(item,i) in listArr">
          <router-link
            :to="{path:'/myTravelIndex/travelDetails',query:{travelId:item.id}}"
            v-show='activeStatus === 2'>
            <div class="notes-title ellipsis"><span class="span-title ">{{item.title}}</span></div>
            <div class="notes-text "><span class="span-text" v-if="">{{item.subTitle}}</span></div>
            <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
          </router-link>
          <router-link
            :to="{path:'/myTravelIndex/noTrueTravelDetails',query:{travelId:item.id}}"
            v-show='activeStatus !== 2'>
            <div class="notes-title ellipsis"><span class="span-title ">{{item.title}}</span></div>
            <div class="notes-text "><span class="span-text" v-if="">{{item.subTitle}}</span></div>
            <div class="notes-thum"><img v-lazy="item.coversImageUrl" class="img-thum"></div>
          </router-link>
          <vice-menu :currentStatu="activeStatus"
                     :TravelId='item.id'
                     @deletetravel="deletetravel"
                     v-show=" activeStatus!==1 || item.type!==1"
                     :isShow="activeStatus"
                     :currentTravel='item'>
          </vice-menu>
          <like-group
            :item="item"
            v-show='activeStatus === 2'
          ></like-group>
          <p v-show='activeStatus !== 2' class="updata-time">最近更新时间 <span>{{item.createTime | formatTime}}</span>
            <span class="status"
                  v-show='activeStatus === 1'>{{item.type === 3 && "已退回" || item.type === 1 && "未审核"}}</span>
          </p>
        </div>
        <div v-show="!listArr.length" class="no-hint">
          <span>亲,快来写游记吧</span>
        </div>
        <footer class="loading-more" v-show="loadingMoreText && listArr.length">{{loadingMoreText}}</footer>
        <router-link
          :class="{isposition:isposition}"
          :to="{path: '/myTravelIndex/travelEditor', query:{ isnew: 'true' }}"
          class="travel-nwe ui-btn">新建一篇游记



        </router-link>
      </div>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>

</template>

<script>
  import headTop from 'src/components/header/head.vue'
  import viceMenu from 'src/components/common/viceMenu'
  import likeGroup from 'src/components/common/like'

  import {getmytravel, Praise, collectionEdit} from 'src/service/getData'
  import {mapMutations, mapState} from 'vuex'

  export default {
    components: {
      headTop,
      viceMenu,
      likeGroup,
    },

    computed: {
      ...mapState([
        'mytravel', 'mytravelStatis', 'mytravelStatus', 'login', 'listTravel'
      ]),
    },

    data(){
      return {
        isdisplay: true,
        activeStatus: 2,

        userId: null,
        tabText: [
          {title: "已发表", view: 'view1', status: 2},
          {title: "待审核", view: 'view1', status: 1},
          {title: "草稿", view: 'view1', status: 0},
        ],
        activeIndex: 0,

        preventRepeatRequest: false, //阻止请求
        loadingMoreText: null,

        pageSize: 10,
        pageNum: 1,
        travelnotesvos: [],
        travelText: [],
        isposition: null,
        IsShow: true,

        listArr: [],

        totalPage: null,
      }
    },

    filters: {
      formatTime: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        let hours = mData.getHours();
        if (hours < 10) {
          hours = '0' + hours;
        }
        let minutes = mData.getMinutes();
        if (minutes < 10) {
          minutes = '0' + minutes;
        }
        let seconds = mData.getSeconds();
        if (seconds < 10) {
          seconds = '0' + seconds;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
      },
    },

    mounted(){
      this.initData();
    },

    methods: {
      ...mapMutations([
        'INIT_MYTRAVEL',
        'SAVE_STATISTRAVEL',
        'SET_STARELSTATUS',
        'INIT_LISTTRAVEL',
      ]),
      //tab切换
      initData(index = 0, sta = 2){
        this.$refs.container.scrollTop = 0;
        this.IsShow = false;
        this.activeIndex = index;
        this.activeStatus = sta;
        this.pageNum = 1;
        this.getTravelList();
      },

      //获取初始数据
      async getTravelList(){

        await getmytravel({status: this.activeStatus, pageSize: this.pageSize, pageNum: this.pageNum}).then(res => {
          if (res.status === 200) {
            this.travelText.length = 0;

            //统计数量
            this.SAVE_STATISTRAVEL(res.obj.travelNotesCountVo);
            this.tabText.forEach(item => {
              if (item.status === 0) {
                item.totalPage = this.mytravelStatis.cgtype;
              } else if (item.status === 1) {
                item.totalPage = this.mytravelStatis.dshtype + this.mytravelStatis.wtgtype;
              } else if (item.status === 2) {
                item.totalPage = this.mytravelStatis.shtgtype;
              }
            });

            //已发表
            if (res.obj.passMytravelsList) {
              this.listArr = res.obj.passMytravelsList.list;
              //this.INIT_MYTRAVEL(res.obj.passMytravelsList.list);
              this.totalPage = res.obj.passMytravelsList.total;
              //待审核，草稿
            } else if (res.obj.travelnotesvo) {
              this.listArr = res.obj.travelnotesvo.list;
              //this.INIT_MYTRAVEL(res.obj.travelnotesvo.list);
              this.totalPage = res.obj.travelnotesvo.total;

              //取出第一段字符
              res.obj.travelnotesvo.list.forEach(item => {
                let isfand = false;
                if (!item.travelnotesdetailsList.length || !item.travelnotesdetailsList.url && !item.travelnotesdetailsList.words) {
                  this.travelText.push('');
                }
                item.travelnotesdetailsList.forEach(travels => {
                  if (travels.words && !isfand) {
                    isfand = !isfand;
                    this.travelText.push(travels.words);
                  }
                });
              });
            }
          }
        });
      },

      //判断页面高度
      getpageHeight(){
        let pH = document.body.offsetHeight;
        let cH = this.$refs.travelC.offsetHeight;

        if (cH > pH) {
          this.isposition = false;
        } else {
          this.isposition = true;
        }
      },

      //加载更多
      async loadingMore (){
        this.preventRepeatRequest = true;
        if (Math.ceil(this.totalPage / this.pageSize) > this.pageNum) {
          this.pageNum++;
          await getmytravel({status: this.activeStatus, pageSize: this.pageSize, pageNum: this.pageNum}).then(res => {
            if (res.status === 200) {
              if (res.obj.passMytravelsList) {
                let passTravel = res.obj.passMytravelsList.list;
                this.listArr = [...this.listArr, ...passTravel];
                //passTravel = [...this.mytravel, ...passTravel];
                //this.INIT_MYTRAVEL(passTravel);
              } else if (res.obj.travelnotesvo) {
                let noTravel = res.obj.travelnotesvo.list;
                this.listArr = [...this.listArr, ...noTravel];
                //noTravel = [...this.mytravel, ...noTravel];
                //this.INIT_MYTRAVEL(noTravel);
              }
            }
          });
        } else {
          this.loadingMoreText = "没有更多新数据";
        }
        this.preventRepeatRequest = false;
      },

      //删除
      deletetravel(id){
        this.mytravel.forEach((item, i) => {
          if (item.id === id) {
            this.mytravel.splice(i, 1);
            this.travelText.splice(i, 1);
            this.tabText[this.activeIndex].totalPage--;
          }
        });
      },
    },

    watch: {
      mytravelStatus(val){
        this.loadingMoreText = null;
        this.initData(val.activeIndex, val.travelstatus);
      },
      mytrave: function () {
        this.listArr = this.mytravel;
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .page-padding {
    padding-top: p2r(180);
  }

  .no-hint {
    color: $fc;
    font-size: p2r(24);
    padding: p2r(90) 0;
    text-align: center;
  }

  .loading-more {
    width: 100%;
    text-align: center;
    @include sc(p2r(28), $fc);
    line-height: 2;
  }

  //已发表
  /*列表*/
  .my-travel-show {
    .item:first-child {
      border-top: none;
    }
    .item {
      position: relative;
      width: 100%;
      background-color: $bgc2;
      border-bottom: 1px solid $bc;
      border-top: 1px solid $bc;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      margin-bottom: p2r(10);
      &:first-child {
        margin-top: 0;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
      }
      .notes-info {
        overflow: hidden;
        li {
          width: 50%;
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(20);
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(20);
          }
          span {
            @include sc(p2r(24), $mc);
          }
        }
        .icon-time {
          @include bis('../../images/icon/icon_time.png')
        }
        .icon-money {
          @include bis('../../images/icon/icon_money.png')
        }
        .icon-like {
          @include bis('../../images/icon/icon_like.png')
        }
        .icon-day {
          @include bis('../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        line-height: 2;
        .span-text {
          @include sc(p2r(24), $mc);
          @include ellipsisrows(3);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        margin-top: p2r(12);
        .img-thum {
          width: 100%;
        }
      }
    }
  }

  .travel-nwe {
    @include submit;
    margin-top: p2r(30);
    margin-bottom: p2r(30);
  }

  .isposition {
    position: fixed;
    bottom: p2r(65);
    z-index: 110;
    left: 50%;
    transform: translateX(-50%);
  }

  .travel-nwe:before {
    content: '';
    display: inline-block;
    width: p2r(40);
    height: p2r(42);
    @include bis('../../images/icon/icon_edit.png');
    vertical-align: middle;
    margin-right: p2r(28);
  }

  //草稿
  .draft-wrapper {
    .item {
      border-bottom: none;
      margin-bottom: 0;
      margin-top: 0;
    }
    .item:last-child {
      .updata-time {
        border-bottom: none;
      }
    }
  }

  .updata-time {
    @include sc(p2r(20), $fc);
    line-height: 1;
    padding: p2r(10) 0 p2r(30);
    span {
      @include sc(p2r(20), $fc);
    }
    .status {
      margin-left: p2r(50);
    }
  }


</style>
