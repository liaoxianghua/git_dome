<template>
  <div class="ui-body ui-padding-header ui-padding-footer">
    <head-top :headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container" v-show="!showLoading">
      <section class="order-wrap order-info">
        <div class="goods-title">
          <div>{{productTitle}}</div>
          <div><span class="span-price" v-if="productType === 2">{{price}}</span></div>
        </div>
        <div class="goods-number" v-if="productType === 2">
          <div class="tit">购买数量</div>
          <span class="span-btn span-minus" v-on:click="changeTotalNum(-1)"><i
            class="i-icon i-minus"></i></span><span
          class="span-value" @click="inputTotalNum()">{{totalNum}}</span><span class="span-btn span-add"
                                                                               v-on:click="changeTotalNum(1)"><i
          class="i-icon i-add"></i></span>
        </div>
        <div class="goods-info" v-else>
          <span>套餐名称：{{mealsName}}<br>出行日期：{{productTimeStamp | formatDate}}<br></span>
          <template v-if="productType === 3">出行人：{{totalNum}}（{{adultNum}}大 {{childNum}}小）</template>
          <template v-else>份数：{{totalNum}}</template>
          <br>
        </div>
      </section>
      <section class="order-wrap order-person" v-if="productType === 3">
        <div class="title">
          <span><i class="i-cx"></i>出行人信息</span>
          <router-link :to="{path:'confirmOrder/choosePerson',query:{totalNum:totalNum,productId:productId}}"
                       class="btn-add">
            <template v-if="selectedPerson.length"><i class="icon iconfont icon-add"></i>修改出行人</template>
            <template v-else><i class="icon iconfont icon-add"></i>添加出行人</template>
          </router-link>
        </div>
        <ul class="list" v-for="(item,i) in listPerson">
          <li>出行人{{i + 1}}<br>
            <span>姓名：{{item.nameCh}}</span>
            <span v-if="item.documents"><br>{{item.documents[0].documentName}}：{{item.documents[0].documentNo}}</span>
          </li>
        </ul>
      </section>
      <section class="order-wrap order-user">
        <div class="title">
          <span v-if="productType === 3"><i class="i-cx"></i>预定人信息</span>
          <span v-else><i class="i-cx"></i>购买人信息</span>
        </div>
        <div class="form-list">
          <div class="item" v-if="productType === 2">
            <div class="label">购买人</div>
            <div class="ipn"><input type="text" maxlength="50" placeholder="请输入购买人姓名" v-model="orderName"></div>
          </div>
          <div class="item" v-else>
            <div class="label">联系人</div>
            <div class="ipn"><input type="text" maxlength="50" placeholder="请输入联系人姓名" v-model="orderName"></div>
          </div>
          <div class="item">
            <div class="label">手机号码</div>
            <div class="ipn"><input type="tel" maxlength="11" placeholder="11位手机号码"
                                    v-model="orderTel"></div>
          </div>
          <div class="item" v-if="productType !== 3 && !login">
            <div class="label">验证码</div>
            <div class="ipn">
              <label><input type="tel" maxlength="4" v-model="orderCaptcha"></label>
              <span class="a-btn" @click="getVerifyCode" v-show="!mobileCodeNum && !computedTime">获取验证码</span>
              <span class="a-btn" @click="getVerifyCode" v-show="mobileCodeNum && !computedTime">重新获取</span>
              <span class="a-btn btn-char-gray" v-show="computedTime">{{computedTime}}秒可重发</span>
            </div>
          </div>
          <div class="item">
            <div class="label">邮箱</div>
            <div class="ipn"><label><input type="mail" maxlength="50" v-model="orderEmail"></label></div>
          </div>
          <div class="item">
            <div class="label">微信</div>
            <div class="ipn"><label><input type="text" maxlength="30" placeholder="仅作为备用联系方式"
                                           v-model="orderWechat"></label></div>
          </div>
          <div class="item">
            <div class="label">备注</div>
            <div class="ipn"><label><input type="text" maxlength="128" v-model="orderText"></label></div>
          </div>
        </div>
      </section>
      <section class="order-wrap order-invoice">
        <div class="title" @click="changeShowSelect">
          <span><i class="i-cx"></i>发票信息</span>
          <span class="span-v" v-show="needInvoice">需要发票</span>
          <i class="icon icon-r iconfont" :class="[needInvoice?'icon-unfold':'icon-right']"></i>
        </div>
        <div class="form-list" v-show="needInvoice">
          <div class="item">
            <div class="label">发票类型</div>
            <div class="ipn">
              <label @click="changeInvoiceType(2)"><i class="rule-radio"
                                                      v-bind:class="{'rule-radio-on':invoiceType===2}"></i>
                <span class="radio-text">个人</span></label>
              <label @click="changeInvoiceType(1)"><i class="rule-radio"
                                                      v-bind:class="{'rule-radio-on':invoiceType===1}"></i>
                <span class="radio-text">单位</span></label>
            </div>
          </div>
          <div class="item">
            <div class="label">发票抬头</div>
            <div class="ipn" v-if="invoiceType === 1"><input type="text" maxlength="30" placeholder="请输入公司名称"
                                                             v-model="invoiceTitle"></div>
            <div class="ipn" v-else><input type="text" maxlength="30" placeholder="请输入个人姓名" v-model="invoiceTitle">
            </div>
          </div>
          <!--<div class="item">
            <div class="label">手机</div>
            <div class="ipn"><input type="tel" maxlength="11" placeholder="11位手机号码" v-model="invoicePhone"></div>
          </div>
          <div class="item">
            <div class="label">邮箱</div>
            <div class="ipn"><input type="text" maxlength="50" placeholder="如 abc@def.com" v-model="invoiceEmail"></div>
          </div>-->
          <div class="item">
            <div class="label">领取方式</div>
            <div class="ipn">
              <label @click="changeInvoiceGetType(0)"><i class="rule-radio"
                                                         v-bind:class="{'rule-radio-on':invoiceGetType===0}"></i>
                <span class="radio-text">当面领取</span></label>
              <label @click="changeInvoiceGetType(1)"><i class="rule-radio"
                                                         v-bind:class="{'rule-radio-on':invoiceGetType===1}"></i>
                <span class="radio-text">邮寄到付</span></label>
            </div>
          </div>
          <div class="item" v-show="invoiceGetType">
            <div class="label">邮寄地址</div>
            <div class="ipn"><input type="text" maxlength="50" placeholder="如需邮寄时请填写邮寄地址" v-model="invoiceAddress">
            </div>
          </div>
          <div class="item">
            <div class="tips">提示：发票为纸质发票，您可选择邮寄到付或当面领取，如需邮寄请填写邮寄地址，如当面领取可联系客服。</div>
          </div>
        </div>
      </section>
      <!--<section class="order-wrap">
        <div class="title">
          <span><i class="i-cx"></i>订单备注</span>
          <input type="text" maxlength="128" placeholder="请输入" class="ipn">
        </div>
      </section>-->
      <section class="order-rule">
        <div><i class="rule-radio" v-bind:class="{'rule-radio-on':agreeRule}"
                v-on:click="changeRuleRadio"></i></div>
        <div>　我已阅读并接受<span class="span-tips" v-on:click="changeRuleView">预定须知</span>等条款</div>
      </section>
    </div>
    <section class="order-footer">
      <div class="total" v-on:click="changeTotalView">
        总额：<span class="span-total">{{totalMoney}}</span>
        <span class="span-v">详细 <i class="icon iconfont icon-unfold"></i></span>
      </div>
      <div class="btn">
        <span class="a-sub" @click="subOrder">立即购买</span>
      </div>
    </section>
    <section class="fixed-wrap" v-show="isShowRule">
      <div class="cont">
        <h5>预定须知</h5>
        <div v-html="productRule" class="text"></div>
        <div v-html="returnRule" class="text"></div>
      </div>
      <div class="btn-close" v-on:click="changeRuleView"><i class="icon iconfont icon-close"></i></div>
    </section>
    <section class="fixed-wrap" v-show="isShowTotal">
      <div class="cont">
        <h5>价格详细</h5>
        <ul class="list" v-if="productType === 1">
          <li><span class="span-label">商品费用</span><span class="span-value">￥{{totalPrice}}</span></li>
          <li class="details"><span class="span-label">{{productTitle}}</span><span class="span-value">￥{{price}}/份 x{{totalNum}}</span>
          </li>
        </ul>
        <ul class="list" v-else-if="productType === 2">
          <li><span class="span-label">套餐费用</span><span class="span-value">￥{{totalPrice}}</span></li>
          <li class="details"><span class="span-label">{{productTitle}}</span><span class="span-value">￥{{price}}/份 x{{totalNum}}</span>
          </li>
        </ul>
        <ul class="list" v-else-if="productType === 3">
          <li><span class="span-label">套餐费用</span><span class="span-value">￥{{totalPrice}}</span></li>
          <li class="details"><span class="span-label">成人</span><span
            class="span-value">￥{{adultPrice}}/人 x{{adultNum}}</span>
          </li>
          <li class="details"><span class="span-label">小孩</span><span
            class="span-value">￥{{childPrice}}/人 x{{childNum}}</span>
          </li>
          <li v-if="isSingleRoom"><span class="span-label">单房差</span><span
            class="span-value">￥{{singleRoomPrice}}</span></li>
        </ul>
        <div class="total">合计：<span class="span-total">{{totalMoney}}</span></div>
      </div>
      <div class="btn-close" @click="changeTotalView"><i class="icon iconfont icon-close"></i></div>
    </section>
    <transition name="router-slidT" mode="out-in">
      <select-small v-if="showSelect"
                    :optionArr="[{text:'需要发票',value:1},{text:'不需要发票',value:0}]"
                    :selectedValue="needInvoice"
                    @closeSelect="changeShowSelect"
                    @changeSelect="changeInvoice"></select-small>
    </transition>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {goodsDetails, goodsCombo, saveOrder, mobileCode} from 'src/service/getData'
  import {checkLogin, rightPhoneNumber, rightEmailAddress} from 'src/config/mUtils'
  import headTop from 'src/components/header/head'
  import selectSmall from 'src/components/common/selectSmall'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        pageTitle: '订单填写',
        productId: 0,//产品ID
        mealsId: 0,//套餐ID
        mealsName: null,//套餐名称
        stockId: 0,//库存id
        totalNum: 0,//数量
        adultNum: 0,//大人
        childNum: 0,//小孩
        roomNum: 0,//房间数
        totalMoney: 0,//订单总价
        totalPrice: 0,//套餐总价
        price: 0,//单价
        adultPrice: 0,//大人价格
        childPrice: 0,//小孩价格
        singleRoomPrice: 0,//单房差
        productTitle: null,//产品信息
        productType: 1,//产品分类
        productDate: 0,//出行日期
        productTimeStamp: 0,//出行时间戳
        ProductTotalNum: 0,//产品库存
        maxCount: -1,//最多购买数量
        minCount: 1,//最少购买数量
        needInvoice: 0,//是否需要发票
        invoiceType: 2,//发票类型
        invoicePhone: null,//发票电话
        invoiceTitle: null,//发票抬头
        invoiceEmail: null,//发票邮件地址、
        invoiceGetType: 0,//发票领取方式
        invoiceAddress: null,//发票邮寄地址
        agreeRule: false,//同意订单规则
        isSingleRoom: false,//是否有单房差
        orderName: null,//订单联系人姓名
        orderTel: null,//订单联系人电话
        orderEmail: null,//订单联系人邮件地址
        orderWechat: null,//订单联系人微信
        orderText: null,//订单备注
        orderCaptcha: null,//验证码
        orderBusinessType: null,//验证码类型
        orderToken: null,//验证码TOKEN
        productRule: null,//产品预订须知
        returnRule: null,//产品退订须知
        isShowRule: false,//是否显示订单规则
        isShowTotal: false,//是否显示总金额详情
        showLoading: false, //显示加载动画
        computedTime: 0, //倒数记时
        mobileCodeNum: 0,//验证码发送次数
        validate_token: null, //获取短信时返回的验证值
        showSelect: false,//是否显示select
        listPerson: []
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
    },
    created(){
      this.productId = this.$route.query.productId;
      if (this.$route.query.totalNum) this.totalNum = this.$route.query.totalNum;
      if (this.$route.query.mealsId) this.mealsId = this.$route.query.mealsId;
      if (this.$route.query.stockId) this.stockId = this.$route.query.stockId;
      if (this.$route.query.adultNum) this.adultNum = this.$route.query.adultNum;
      if (this.$route.query.childNum) this.childNum = this.$route.query.childNum;
      if (this.$route.query.date) {
        this.productTimeStamp = parseInt(this.$route.query.date);
      }
      if (checkLogin()) {
        this.login = true;
      }
    },
    mounted(){
      this.initData();
      //清空选中出行人
      this.INIT_SELECTED_PERSON([]);
    },
    components: {
      headTop,
      selectSmall
    },
    computed: {
      ...mapState([
        'userInfo', 'myPerson', 'selectedPerson', 'login'
      ]),
    },
    methods: {
      ...mapMutations([
        'RECORD_USERINFO', 'INIT_SELECTED_PERSON'
      ]),
      initData: async function () {
        this.showLoading = true;
        if (!this.productId) {
          return;
        }

        let res = await goodsDetails(this.productId);
        if (res.status !== 200) {
          return;
        }
        this.showLoading = false;
        let productInfo = res.obj.product;

        this.productTitle = productInfo.productName;
        this.productType = productInfo.productType;
        this.productRule = productInfo.orderRule;
        this.returnRule = productInfo.returnRule;

        for (let i in productInfo.productMeals) {
          if (productInfo.productMeals[i].id == this.mealsId) {
            this.mealsName = productInfo.productMeals[i].mealsName;
          }
        }

        //线路订单，景区订单查询套餐数据并初始化价格等信息
        if (this.productType === 1 || this.productType === 3) {
          res = await goodsCombo(this.mealsId, this.reFormatDate());
          if (res.status !== 200) {
            return;
          }

          let combo = res.obj.listStock;
          let day = new Date(this.productTimeStamp).getDate();
          let nowCombo = combo[day - 1];
          if (nowCombo.price) this.price = nowCombo.price.toFixed(2);
          if (nowCombo.adultPrice) this.adultPrice = nowCombo.adultPrice.toFixed(2);
          if (nowCombo.childPrice) this.childPrice = nowCombo.childPrice.toFixed(2);
          if (nowCombo.singleRoomPrice) this.singleRoomPrice = nowCombo.singleRoomPrice.toFixed(2);
        }
        //产品订单直接根据产品数据初始化价格等信息
        else {
          if (productInfo.price) this.price = productInfo.price.toFixed(2);
          this.ProductTotalNum = productInfo.totalNum;
          this.maxCount = productInfo.maxCount;
          this.minCount = productInfo.minCount;
          if (this.minCount > 0) {
            this.totalNum = this.minCount;
          }
        }

        if (this.productType === 3) {
          this.totalPrice = parseFloat(this.adultPrice) * parseInt(this.adultNum) + parseFloat(this.childPrice) * parseInt(this.childNum);
          if (this.adultNum % 2) {
            this.isSingleRoom = true;
            this.totalMoney = this.totalPrice + parseFloat(this.singleRoomPrice);
          }
          else {
            this.totalMoney = this.totalPrice
          }
        }
        else {
          this.totalMoney = this.totalPrice = parseFloat(this.price) * parseInt(this.totalNum);
        }

        this.totalPrice = this.totalPrice.toFixed(2);
        this.totalMoney = this.totalMoney.toFixed(2);

        //线路需登录才能下单
        if (this.productType === 3 && !this.login) {
          this.$router.replace({path: '/login', query: {redirect: this.$route.fullPath}});
        }

        if (this.login) {
          this.orderName = this.userInfo.memberDetail.nameCh;
          this.orderTel = this.userInfo.memberDetail.phoneCh;
        }
      },
      changeShowSelect: function () {
        this.showSelect = !this.showSelect;
      },
      changeInvoice: function (val, text) {
        this.needInvoice = val;
        this.needInvoiceText = text;
      },
      changeRuleView: function () {
        this.isShowRule = !this.isShowRule;
      },
      changeTotalView: function () {
        this.isShowTotal = !this.isShowTotal;
      },
      changeInvoiceType: function (val) {
        this.invoiceType = val;
      },
      changeInvoiceGetType: function (val) {
        this.invoiceGetType = val;
      },
      reFormatDate: function () {
        let date = new Date(this.productTimeStamp);
        return date.getFullYear() + (date.getMonth() < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1)
      },
      changeRuleRadio: function () {
        this.agreeRule = !this.agreeRule;
      },
      changeTotalNum: function (n) {
        this.totalNum += parseInt(n);
        if (this.totalNum < 0) this.totalNum = 0;
      },
      inputTotalNum: async function () {
        let res = await this.messageBox.prompt('请输入大于0的数字', '购买数量');
        if (isNaN(res.value) || res.value <= 0) {
          this.Toast({message: '请输入大于0的数字', position: 'bottom'});
          return;
        }
        this.totalNum = 0;
        this.changeTotalNum(res.value);
      },
      subOrder: async function () {
        if (this.selectedPerson.length === 0 && this.productType === 3) {
          this.Toast({message: '请添加出行人', position: 'bottom'});
          return;
        }
        if (this.selectedPerson.length != this.totalNum && this.productType === 3) {
          this.Toast({message: '出行人数和购买数量不符，请修改出行人', position: 'bottom'});
          return;
        }
        if (!this.totalNum) {
          this.Toast({message: '请选择购买数量', position: 'bottom'});
          return;
        }
        //小商品判断购买数量
        if (this.totalNum && this.productType === 2) {
          if (this.totalNum > this.ProductTotalNum) {
            this.Toast({message: '购买数量不能大于库存,请修改您的购买数量', position: 'bottom'});
            return;
          }
          if (this.totalNum > this.maxCount && this.maxCount !== -1) {
            this.Toast({message: '购买数量最多为' + this.maxCount + ',请修改您的购买数量', position: 'bottom'});
            return;
          }
          if (this.totalNum < this.minCount && this.minCount !== -1) {
            this.Toast({message: '购买数量最少为' + this.minCount + ',请修改您的购买数量', position: 'bottom'});
            return;
          }
        }
        if (!this.orderName) {
          if (this.productType === 2) {
            this.Toast({message: '请输入购买人姓名', position: 'bottom'});
          }
          else {
            this.Toast({message: '请输入联系人姓名', position: 'bottom'});
          }
          return;
        }
        if (!this.orderTel) {
          this.Toast({message: '请输入联系人手机号码', position: 'bottom'});
          return;
        }
        if (!rightPhoneNumber(this.orderTel)) {
          this.Toast({message: '联系人手机号码格式有误', position: 'bottom'});
          return;
        }
        if (this.orderEmail && !rightEmailAddress(this.orderEmail)) {
          this.Toast({message: '邮箱地址格式有误', position: 'bottom'});
          return;
        }
        if (this.needInvoice) {
          if (!this.invoiceTitle) {
            this.Toast({message: '请填写发票抬头', position: 'bottom'});
            return;
          }
          if (this.invoiceGetType && !this.invoiceAddress) {
            this.Toast({message: '请填写发票邮寄地址', position: 'bottom'});
            return;
          }
          /*if (!this.invoiceEmail && !this.invoicePhone) {
           this.Toast({message: '发票中手机邮箱至少填写一项', position: 'bottom'});
           return;
           }
           if (this.invoicePhone && !rightPhoneNumber(this.invoicePhone)) {
           this.Toast({message: '发票手机号码格式有误', position: 'bottom'});
           return;
           }
           if (this.invoiceEmail && !rightEmailAddress(this.invoiceEmail)) {
           this.Toast({message: '发票邮箱格式有误', position: 'bottom'});
           return;
           }*/
        }
        if (!this.agreeRule) {
          this.Toast({message: '请阅读并接受预定须知', position: 'bottom'});
          return;
        }


        //线路订单
        let person = null;
        if (this.productType === 3) {
          person = '';
          for (let i = 0; i < this.selectedPerson.length; i++) {
            person += (i === 0 ? '' : ',') + this.selectedPerson[i].join('|');
          }
          //person = this.selectedPerson.join(',')
        }

        let res = await saveOrder(this.productId, this.totalNum, this.mealsId, this.stockId, this.adultNum, this.childNum, person, this.orderName, this.orderTel, this.orderEmail, this.orderWechat, this.orderCaptcha, this.orderBusinessType, this.orderText, this.needInvoice, this.invoiceType, this.invoicePhone, this.invoiceTitle, this.invoiceEmail, this.invoiceGetType, this.invoiceAddress);
        if (res.status === 200) {
          //未登录下单设置登录状态
          if (this.productType !== 3 && !this.login) {
            this.RECORD_USERINFO(res.obj.member);
          }

          //清空选中出行人
          this.INIT_SELECTED_PERSON([]);

          this.$router.replace({path: 'confirmOrder/payment', query: {orderId: res.obj.order.encode}});
        }
      },
      //获取短信验证码
      getVerifyCode: async function () {
        if (!this.orderTel) {
          this.Toast({message: '请输入手机号码', position: 'bottom'});
          return;
        }
        if (!rightPhoneNumber(this.orderTel)) {
          this.Toast({message: '手机号码格式有误', position: 'bottom'});
          return;
        }

        //发送短信验证码
        let sms = await mobileCode(this.orderTel, 6);
        if (sms.status !== 200) {
          return;
        }

        this.orderBusinessType = this.validate_token = sms.obj.token;


        this.computedTime = 60;
        this.timer = setInterval(() => {
          this.computedTime--;
          if (this.computedTime === 0) {
            clearInterval(this.timer)
          }
        }, 1000);
      },
      initSelectedPerson: function () {
        if (this.selectedPerson.length > this.totalNum) {
          this.selectedPerson.splice(0, this.selectedPerson.length - this.totalNum);
          this.INIT_SELECTED_PERSON(this.selectedPerson);
        }
      },
      inSelectedPerson: function (search) {
        for (let i = 0; i < this.selectedPerson.length; i++) {
          if (search === this.selectedPerson[i][0]) {
            return i;
          }
        }
        return -1;
      },
    },
    watch: {
      totalNum: function () {
        this.totalMoney = this.totalPrice = parseFloat(this.price) * parseInt(this.totalNum);
        this.totalPrice = this.totalPrice.toFixed(2);
        this.totalMoney = this.totalMoney.toFixed(2);
      },
      selectedPerson: function () {
        this.listPerson = [];
        for (let i = 0; i < this.myPerson.length; i++) {
          let item = this.myPerson[i];
          if (this.inSelectedPerson(item.id) > -1) {

            this.listPerson.push(item);
          }
        }
      },
      myPerson: function () {
        this.listPerson = [];
        for (let i = 0; i < this.myPerson.length; i++) {
          let item = this.myPerson[i];
          if (this.inSelectedPerson(item.id) > -1) {
            this.listPerson.push(item);
          }
        }
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .padding-w {
    padding: 0 p2r(28);
  }

  .padding-b {
    padding-bottom: p2r(98);
  }

  .order-wrap {
    @include bmb;
    .title {
      @include sc(p2r(28), $mc);
      position: relative;
      line-height: p2r(70);
      padding-left: p2r(44);
      .i-cx {
        display: inline-block;
        @include wh(p2r(4), p2r(26));
        background-color: $fc3;
        @include ct;
        left: p2r(28);
      }
      .span-v {
        color: $blue;
        margin-left: p2r(42);
      }
      .btn-add {
        @include ct;
        right: p2r(28);
        @include sc(p2r(28), $blue);
        .icon {
          @include sc(p2r(28), $blue);
        }
      }
      .icon-r {
        @include ct;
        right: p2r(28);
      }
      .btn-invoice {
        @include ct;
        right: p2r(28);
        @include sc(p2r(28), $mc);
        line-height: p2r(80);
        .icon {
          @include sc(p2r(28), $blue);
          @include ct;
        }
      }
      .ipn {
        @include ct;
        @include sc(p2r(28), $mc);
        right: 0;
        width: p2r(436);
      }
    }
    .form-list {
      padding-left: p2r(38);
      .item {
        @include fj(flex-star);
        border-top: 1px solid $bc;
        height: p2r(80);
        overflow: hidden;
        align-items: center;
        .label {
          width: p2r(168);
          @include sc(p2r(28), $mc);
          line-height: p2r(80);
        }
        .ipn {
          flex: 1;
          position: relative;
          line-height: p2r(34);
          @include sc(p2r(26), $mc);
          input {
            @include sc(p2r(26), $mc);
            padding: 0;
            @include wh(100%, p2r(80));
            line-height: p2r(80);
          }
          .a-btn {
            @include ct;
            right: p2r(24);
            @include sc(p2r(26), $blue);
          }
        }
        .tips {
          @include sc(p2r(24), $fc);
        }
      }
    }
  }

  .goods-number {
    border-top: 1px solid $bc;
    padding: p2r(28) p2r(24);
    text-align: right;
    position: relative;
    height: p2r(60);
    overflow: hidden;
    box-sizing: content-box;
    .tit {
      @include ct;
      left: p2r(24);
      @include sc(p2r(28), $mc);
      line-height: 1;
      letter-spacing: 0;
      .span-pri {
        @include sc(p2r(20), $fc);
        &:before {
          content: '￥';
        }
        &:after {
          content: '/人';
        }
      }
    }
    span {
      display: inline-block;
      overflow: hidden;
    }
    .span-value {
      border: 1px solid #aaa;
      @include wh(auto, p2r(60));
      line-height: p2r(60);
      @include sc(p2r(26), $mc);
      text-align: center;
      min-width: p2r(80);
      max-width: p2r(240);
      padding: 0 p2r(10);
    }
    .span-value-active {
      background-color: $blue;
      color: $fc2;
    }
    .span-btn {
      border: 1px solid $bc;
      line-height: p2r(52);
      @include wh(p2r(60), p2r(60));
      text-align: center;
      box-sizing: border-box;
    }
    .span-add {
      border-left: none;
    }
    .span-minus {
      border-right: none;
    }
    .i-icon {
      font-family: "iconfont" !important;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      @include sc(p2r(32), $fc);
      display: inline-block;
    }
    .i-add {
      &:before {
        content: "\E767";
      }
    }
    .i-minus {
      &:before {
        content: "\E768";
      }
    }
  }

  .order-person {
    .list {
      padding-left: p2r(38);
      li {
        @include sc(p2r(26), $mc);
        line-height: p2r(40);
        border-top: 1px solid $bc;
        padding: p2r(20) 0;
        span {
          @include sc(p2r(24), $fc);
        }
      }
    }
  }

  .order-invoice {
  }

  .order-info {
    .goods-title {
      @include sc(p2r(28), $mc);
      line-height: 1.4;
      padding: p2r(12) p2r(28);
      overflow: hidden;
      div {
        width: 100%;
        overflow: hidden;
      }
      .span-price {
        @include sc(p2r(36), $fc3);
        display: inline-block;
        float: right;
        &:before {
          font-size: p2r(26);
          content: '￥';
        }
      }
    }
    .goods-info {
      @include sc(p2r(26), $mc);
      padding: p2r(12) p2r(28);
      border-top: 1px solid $bc;
    }
  }

  .order-rule {
    @include fj(flex-star);
    padding: 0 p2r(28);
    @include sc(p2r(26), $mc);
    align-items: center;
    height: p2r(64);
    padding-bottom: p2r(12);
    div {
      height: p2r(36);
      line-height: p2r(34);
    }
    .span-tips {
      color: $blue;
    }
  }

  .order-footer {
    @include wh(100%, p2r(98));
    @include fj();
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: $bgc2;
    border-top: 1px solid $bc;
    line-height: p2r(98);
    .total {
      flex: 1;
      @include sc(p2r(26), $mc);
      text-indent: p2r(28);
      position: relative;
      .span-total {
        @include sc(p2r(34), $fc3);
        &:before {
          content: '￥';
          font-size: p2r(24);
        }
      }
      .span-v {
        @include ct;
        right: p2r(28);
      }
    }
    .btn {
      text-align: center;
      @include wh(p2r(200), auto);
      background-color: #6ba4f5;
      height: p2r(98);
      @include sc(p2r(32), $fc2);
      .icon {
        @include sc(p2r(28), $fc2);
      }
      .a-sub {
        @include sc(p2r(32), $fc2);
      }
    }
  }

  .fixed-wrap {
    @include wh(100%, 100%);
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    background-color: rgba(0, 0, 0, 0.9);
    .cont {
      position: absolute;
      left: 0;
      top: p2r(146);
      padding: 0 p2r(36);
      width: 100%;
      height: 70%;
      overflow: auto;
      box-sizing: border-box;
      h5, p {
        @include sc(p2r(28), $fc2);
      }
      h5 {
        line-height: 2;
      }
      p {
        line-height: 1.6;
      }
      .list {
        margin-bottom: p2r(44);
        li {
          @include fj();
          margin-top: p2r(44);
          span {
            display: block;
            @include sc(p2r(28), $fc2);
          }
          .span-label {
            width: 60%;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
        .details {
          margin-top: 0;
          span {
            @include sc(p2r(26), $fc);
          }
        }
      }
      .total {
        @include sc(p2r(28), $fc2);
        text-align: right;
        border-top: 1px dashed $fc2;
        line-height: p2r(110);
        .span-total {
          @include sc(p2r(42), $fc3);
          &:before {
            content: '￥';
            @include sc(p2r(24), $fc3);
          }
        }
      }
      .text {
        @include sc(p2r(26), $fc2);
      }
    }
    .btn-close {
      @include cl;
      bottom: p2r(64);
      @include wh(p2r(52), p2r(52));
      border: p2r(4) solid $fc2;
      @include borderRadius(p2r(26));
      .icon {
        @include sc(p2r(28), $fc2);
        @include center;
        line-height: 1;
      }
    }
  }

  .rule-radio {
    display: inline-block;
    @include wh(p2r(34), p2r(34));
    border: p2r(4) solid $blue;
    @include borderRadius(p2r(18));
    background-color: #fff;
    float: left;
  }

  .radio-text {
    float: left;
    padding: 0 p2r(8);
  }

  .rule-radio-on {
    @include bis("../../images/icon/icon_register_ok.png");
    background-color: $blue;
  }
</style>
