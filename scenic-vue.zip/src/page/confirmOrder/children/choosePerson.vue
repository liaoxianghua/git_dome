<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top :headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <div slot="btn" class="btn-all btn-right btn-char" @click="personSub">完成</div>
    </head-top>
    <div class="ui-container" v-show="!showLoading">
      <section class="btn-wrap">
        <router-link to="choosePerSon/editPerson">
          <span class="span-add"><i class="i-icon icon-add"></i>新增常用旅客</span>
        </router-link>
      </section>
      <section class="person-list" v-if="myPerson.length">
        <div class="item" v-for="item in myPerson">
          <template v-if="item.documents.length && item.phoneCh">
            <div class="checkbox"><i class="i-icon"
                                     :class="[inSelectedPerson(item.id) === -1?'icon-square':'icon-squarecheckfill']"
                                     @click="changeSelected(item.id,item.documents[0].id)"></i>
            </div>
            <div class="info">
              <span class="span-name">{{item.nameCh}} {{item.nameEnF}}<template
                v-if="item.nameEnF && item.nameEnS">/</template>{{item.nameEnS}}</span><span class="span-self"
                                                                                             v-if="item.isSelf">本人</span><br>
              <span>{{documentType[item.documents[0].documentType]}}：{{item.documents[0].documentNo}}</span><br>
              <span>手机号码：{{item.phoneCh}}</span>
            </div>
            <div class="edit">
              <router-link :to="{path:'choosePerson/editPerson',query:{id:item.id}}"><i class="i-icon icon-edit"></i>
              </router-link>
            </div>
          </template>
          <template v-else>
            <div class="checkbox"><i class="i-icon"
                                     :class="[inSelectedPerson(item.id) === -1?'icon-square':'icon-squarecheckfill']"
                                     @click="changeSelected(0,0)"></i>
            </div>
            <div class="info">
              <span class="span-name">{{item.nameCh}} {{item.nameEnF}}<template
                v-if="item.nameEnF && item.nameEnS">/</template>{{item.nameEnS}}</span><span class="span-self"
                                                                                             v-if="item.isSelf">本人</span><br>
              <router-link :to="{path:'choosePerson/editPerson',query:{id:item.id}}" class="a-router">信息不全，点击补全


              </router-link>
            </div>
            <div class="edit">
              <router-link :to="{path:'choosePerson/editPerson',query:{id:item.id}}"><i class="i-icon icon-edit"></i>
              </router-link>
            </div>
          </template>
        </div>
      </section>
      <section class="empty" v-else>您还没有常用旅客，赶快添加吧</section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {getPersonList, getCredential, checkLogin} from 'src/service/getData'
  import headTop from 'src/components/header/head'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        pageTitle: '选择出行人',
        deliverable: [], //有效地址列表
        showAlert: false,
        alertText: null,
        alertBtn: [{title: '确认', 'click': this.closeTip}],//提示按钮
        showLoading: false, //显示加载动画
        documentType: {},
        selected: [],
        totalNum: 0,
      }
    },
    created(){
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
    },
    computed: {
      ...mapState([
        'myPerson', 'selectedPerson'
      ]),
    },
    methods: {
      ...mapMutations([
        'INIT_PERSON', 'INIT_SELECTED_PERSON'
      ]),
      initData: async function () {
        this.showLoading = true;
        let res = await getPersonList();
        if (res.status !== 200) {
          return;
        }

        this.INIT_PERSON(res.obj.commonTripManList);

        res = await getCredential();
        if (res.status !== 200) {
          return;
        }

        res.obj.credentialTypes.forEach((val) => {
          this.documentType[val.value] = val.name;
        });

        this.showLoading = false;
      },
      changeSelected: function (id, documentId) {
        if (!id) {
          this.Toast({message: '出行人信息不全，请先补全再选择', position: 'bottom'});
          return;
        }
        let i = this.inSelectedPerson(id);
        if (i > -1) {
          this.selectedPerson.splice(i, 1);
        }
        else {
          this.selectedPerson.push([id, documentId]);
        }
        this.INIT_SELECTED_PERSON(this.selectedPerson);
      },
      inSelectedPerson: function (search) {
        for (let i = 0; i < this.selectedPerson.length; i++) {
          if (search === this.selectedPerson[i][0]) {
            return i;
          }
        }
        return -1;
      },
      personSub: function () {
        let totalNum = this.$route.query.totalNum;
        let errand = totalNum - this.selectedPerson.length;
        if (errand !== 0) {
          let msg = '订单有' + totalNum + '位旅客，' + (errand > 0 ? '请再选择' + Math.abs(errand) + '位出行人' : '请取消' + Math.abs(errand) + '位出行人');
          this.Toast({message: msg, position: 'bottom'});
          return;
        }
        this.$router.go(-1);
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .empty {
    @include sc(p2r(28), $fc);
    text-align: center;
    margin: p2r(64) 0;
  }

  .i-icon {
    font-family: "iconfont" !important;
    font-style: normal;
    -webkit-font-smoothing: antialiased;
    @include sc(p2r(30), $fc2);
    display: inline-block;
  }

  .btn-wrap {
    margin: p2r(28) 0;
    text-align: center;
    .span-add {
      display: inline-block;
      @include wh(p2r(460), p2r(80));
      background-color: $blue;
      @include borderRadius(p2r(8));
      @include sc(p2r(30), $fc2);
      line-height: p2r(80);
    }
  }

  .person-list {
    .item {
      @include fj();
      align-items: center;
      border-top: 1px solid $bc;
      border-bottom: 1px solid $bc;
      background-color: $bgc2;
      padding: p2r(14);
      line-height: 1.6;
      margin-bottom: p2r(12);
      .checkbox {
        width: p2r(80);
        text-align: center;
      }
      .info {
        flex: 1;
        @include sc(p2r(24), $fc);
        span {
          word-break: break-all;
        }
        .span-name {
          @include sc(p2r(26), $mc);
        }
        .span-edit {
          color: $blue;
        }
        .span-self {
          display: inline-block;
          border: 1px solid $fc3;
          @include borderRadius(p2r(4));
          line-height: p2r(30);
          @include sc(p2r(24), $fc3);
          padding: 0 p2r(6);
          margin-left: p2r(12);
        }
        .a-router {
          color: $blue;
        }
      }
      .edit {
        width: p2r(80);
        text-align: center;
        .i-icon {
          @include sc(p2r(48), $mc);
        }
      }
      .i-icon {
        @include sc(p2r(48), $blue);
      }
    }
  }
</style>
