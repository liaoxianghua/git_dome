<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top :headTitle="pageTitle">
      <div class="btn-left btn-char btn-all" @click="$router.go(-1)" slot="btn">取消</div>
      <div class="btn-right btn-char btn-all" @click="editSub" slot="btn">保存</div>
    </head-top>
    <div class="ui-container">
      <div class="info-entering">
        <h3>旅客姓名</h3>
        <ul>
          <li><p>中文姓名</p><input type="text" placeholder="姓名" v-model="nameCh" maxlength="30"></li>
          <li><p>英文姓</p><input type="text" placeholder="英文姓" v-model="nameEnS" maxlength="30"></li>
          <li><p>英文名</p><input type="text" placeholder="英文名" v-model="nameEnF" maxlength="30"></li>
        </ul>
        <h3>证件</h3>
        <ul>
          <li class="next-icon">
            <p>证件类型</p>
            <input type="text" readonly placeholder="证件类型" @click="initCertificateSelect" class="next-icon"
                   v-model="selects.certificate.text" maxlength="30">
          </li>
          <li>
            <p>证件号</p>
            <input type="text" :placeholder="'请输入证件号'" v-model="documentNo" maxlength="30">
          </li>
        </ul>
        <h3>其他信息</h3>
        <ul>
          <li class="next-icon">
            <p>生日</p>
            <input type="text" placeholder="出生日期" v-model="birthday" readonly @click="selectDate">
          </li>
          <li class="set-sex">
            <p>性别</p>
            <div>
              <div @click="changeSex" class="man" :class="{active:sex}">
                <span>男</span>
              </div>
              <div @click="changeSex" :class="{active:!sex}">
                <span>女</span>
              </div>
            </div>
          </li>
          <li class="next-icon nationality">
            <p>国籍</p>
            <input type="text" readonly placeholder="国籍" @click="initNationalitySelect"
                   v-model="selects.nationality.text" maxlength="32">
          </li>
          <li><p>手机号</p><input type="tel" placeholder="手机号码" v-model="tel" maxlength="11"></li>
        </ul>
        <div class="set-self">
          <p>设为本人</p>
          <comp-switch :isOff="isSelf" @changer="changSelf"></comp-switch>
        </div>
      </div>
      <div class="delete-btn" v-if="id"><span @click="deleteSub"><i class="icon iconfont icon-delete"></i><br>删除</span>
      </div>
    </div>
    <mt-datetime-picker v-model="birthdayPickerValue" ref="birthday" type="date" :endDate="new Date()"
                        :startDate="new Date('1900-01-01')" @confirm="changeBirthday()"></mt-datetime-picker>
    <transition name="router-slid" mode="out-in">
      <selects v-if="showSelect"
               :selectTitle="selectTitle"
               :optionArr="optionArr"
               :selectedValue="selectedValue"
               @closeSelect="changeShowSelect"
               @changeSelect="changeSelectValue"></selects>
    </transition>
  </div>
</template>

<script>
  import {
    checkLogin,
    getNationality,
    getCredential,
    getPersonInfo,
    updatePersonInfo,
    addPersonInfo,
    deletePersonInfo,
    getPersonList
  } from 'src/service/getData'
  import {rightPhoneNumber, rightEmailAddress} from 'src/config/mUtils'
  import headTop from 'src/components/header/head'
  import compSwitch from 'src/components/common/switch'
  import selects from 'src/components/common/selects'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        pageTitle: '出行人',
        id: 0,//出行人ID
        nameCh: null,//出行人姓名
        nameEnF: null,//出行人英文名
        nameEnS: null,//出行人英文姓
        sex: 1,//性别
        birthday: null,//出生日期
        birthdayPickerValue: null,
        documentId: null,//证件ID
        documentNo: null,//证件号码
        tel: null,//电话号码
        isSelf: 0,//是否为本人
        documents: [],//出行人证件集合
        selects: {
          nationality: {
            title: '选择国籍',
            text: null,
            value: null,
            option: []
          },
          certificate: {
            title: '选择证件类型',
            text: null,
            value: null,
            option: []
          }
        },
        showSelect: false,
        selectName: null,
        selectTitle: null,
        selectedValue: 0,
        optionArr: [],
        showLoding: false,
        preventRepeatRequest: false, //阻止请求
      }
    },
    created(){
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
      compSwitch,
      selects,
    },
    computed: {
      ...mapState([
        'myPerson', 'selectedPerson'
      ]),
    },
    methods: {
      ...mapMutations([
        'INIT_PERSON', 'INIT_SELECTED_PERSON'
      ]),
      initData: async function () {
        if (this.$route.query.id) {
          this.id = this.$route.query.id;
          let res = await getPersonInfo(this.id);
          if (res.status !== 200) {
            return;
          }
          let info = res.obj.commonTripManInfo;
          this.nameCh = info.nameCh;
          this.nameEnF = info.nameEnF;
          this.nameEnS = info.nameEnS;
          this.selects.nationality.value = info.nationality;
          this.selects.nationality.text = info.nationalityName;
          this.documents = info.documents;
          if (this.documents) {
            this.selects.certificate.value = info.documents[0].documentType;
            this.selects.certificate.text = info.documents[0].documentName;
            this.documentNo = info.documents[0].documentNo;
            this.documentId = info.documents[0].id;
          }
          if (info.birthday) this.birthdayPickerValue = new Date(info.birthday).toLocaleString();
          if (info.birthday) this.birthday = this.dateFormat(info.birthday);

          this.sex = info.sex;
          this.tel = info.phoneCh;
          this.isSelf = info.isSelf;
        }

        //Datetime Picker 默认日期
        if (!this.brithdayPickerValue) this.birthdayPickerValue = new Date('2000-01-01').toLocaleString();
      },
      changeSex: function () {
        this.sex = this.sex ? 0 : 1;
      },
      initCertificateSelect: async function () {
        if (!this.selects.certificate.option.length) {
          let res = await getCredential();
          let option = [];
          res.obj.credentialTypes.forEach((val) => {
            option.push({text: val.name, value: val.value});
          });
          this.selects.certificate.option = option;
        }
        this.initSelect('certificate');
      },
      initNationalitySelect: async function () {
        if (!this.selects.nationality.option.length) {
          let res = await getNationality();
          let option = [];
          res.obj.countryList.forEach((val) => {
            option.push({text: val.name, value: val.id, disable: val.valid ? 0 : 1});
          });
          this.selects.nationality.option = option;
        }
        this.initSelect('nationality');
      },
      initSelect: function (name) {
        this.optionArr = this.selects[name].option;
        this.selectTitle = this.selects[name].title;
        this.selectedValue = this.selects[name].value;
        this.selectName = name;
        this.changeShowSelect();
      },
      changeShowSelect: function () {
        this.showSelect = !this.showSelect;
      },
      changeSelectValue: function (val, text) {
        this.selects[this.selectName].text = text;
        this.selects[this.selectName].value = val;
        if (this.selectName === 'certificate' && this.documents) {
          this.changeCertificateCallback();
        }
      },
      changeCertificateCallback: function () {
        for (let i = 0; i < this.documents.length; i++) {
          let val = this.documents[i];
          if (val.documentType == this.selects.certificate.value) {
            this.documentNo = val.documentNo;
            this.documentId = val.id;
            break;
          }
          else {
            this.documentNo = null;
            this.documentId = null;
          }
        }
      },
      changSelf: function () {
        this.isSelf = this.isSelf ? 0 : 1;
      },
      dateFormat: function (value) {
        let date = new Date(value);
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let day = date.getDate();
        if (month < 10) {
          month = '0' + month;
        }
        if (day < 10) {
          day = '0' + day;
        }
        return year + '-' + month + '-' + day;
      },
      selectDate: function () {
        this.$refs.birthday.open();
      },
      changeBirthday: function () {
        this.birthday = this.dateFormat(this.birthdayPickerValue);
      },
      routerBack: function () {
        this.$router.go(-1);
      },
      editSub: async function () {
        if (this.preventRepeatRequest) {
          return;
        }
        if (!this.nameCh) {
          this.Toast({message: '请输入出行人姓名', position: 'bottom'});
          return;
        }
        if (!this.tel) {
          this.Toast({message: '请输入出行人手机号', position: 'bottom'});
          return;
        }
        if (this.tel && !rightPhoneNumber(this.tel)) {
          this.Toast({message: '请输入正确的手机号', position: 'bottom'});
          return;
        }
        if ((!this.documentNo && this.selects.certificate.value) || (this.documentNo && !this.selects.certificate.value)) {
          this.Toast({message: '证件信息不完整', position: 'bottom'});
          return;
        }

        let message;
        if (this.selects.certificate.text && this.documentNo) {
          message = this.selects.certificate.text + '：' + this.documentNo;
        }
        let affirm = await this.messageBox({
          title: '请核对信息',
          message: '姓名：' + this.nameCh + (message ? '<br>' + message : ''),
          showCancelButton: true,
          cancelButtonText: '修改'
        });
        if (affirm === 'cancel') {
          return;
        }

        this.preventRepeatRequest = true;
        let res;
        if (this.id) {
          res = await updatePersonInfo(this.id, this.documentId, this.nameCh, this.nameEnF, this.nameEnS, this.sex, this.tel, this.selects.nationality.value, this.selects.certificate.value, this.documentNo, this.isSelf, this.birthday);
        }
        else {
          res = await addPersonInfo(this.nameCh, this.nameEnF, this.nameEnS, this.sex, this.tel, this.selects.nationality.value, this.selects.certificate.value, this.documentNo, this.isSelf, this.birthday);
          //新增默认选中
          if (res.status === 200 && res.obj) {
            this.selectedPerson.push([res.obj.id, res.obj.memberDocument.id]);
            this.INIT_SELECTED_PERSON(this.selectedPerson);
          }
        }
        this.preventRepeatRequest = false;
        if (res.status !== 200) {
          return;
        }

        this.initPerson();
        await this.messageBox.alert(res.message);
        this.routerBack();
      },
      deleteSub: async function () {
        await this.messageBox.confirm('确认要删除出行人？');

        let res = await deletePersonInfo(this.id);
        if (res.status !== 200) {
          return;
        }

        //删除出行人同步删除选择
        let i = this.inSelectedPerson(this.id);
        if (i > -1) {
          this.selectedPerson.splice(i, 1);
          this.INIT_SELECTED_PERSON(this.selectedPerson);
        }


        //同步出行人数据
        this.initPerson();

        await this.messageBox.alert(res.message);
        this.routerBack();
      },
      inSelectedPerson: function (search) {
        for (let i = 0; i < this.selectedPerson.length; i++) {
          if (search === this.selectedPerson[i][0]) {
            return i;
          }
        }
        return -1;
      },
      initPerson: async function () {
        let res = await getPersonList();
        if (res.status !== 200) {
          return;
        }
        this.INIT_PERSON(res.obj.commonTripManList);
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .info-entering {
    h3 {
      @include sc(p2r(22), $fc);
      font-weight: 400;
      line-height: (50/22);
      border-bottom: 1px solid $bc;
      padding: 0 p2r(30);

    }
    > div, ul > li {
      display: flex;
      border-bottom: 1px solid $bc;
      padding: 0 p2r(30);
      background: $bgc2;
      p {
        height: p2r(80);
        line-height: p2r(80);
      }
      input {
        height: p2r(80);
        font-size: p2r(26);
      }
    }
    .next-icon {
      position: relative;
    }
    .next-icon:after {
      content: '';
      display: inline-block;
      width: p2r(16);
      height: p2r(27);
      @include bis('../../../../images/icon/enter-icon.png');
      @include ct();
      right: p2r(30);
    }
    .set-sex {
      > div {
        height: p2r(80);
        width: p2r(160);
        display: flex;
        border-bottom: p2r(4) solid transparent;
        input {
          display: none;
        }
        > div {
          display: flex;
          align-items: center;
          span {
            @include sc(p2r(26));
            padding: 0 p2r(25);
            line-height: (35/26);
          }
        }
        .man > span {
          border-right: 1px solid $bc;
          height: p2r(35);
        }
        .active {
          span {
            color: $blue;
          }
          border-bottom-color: $blue;
        }
      }
    }
    .set-self {
      margin-top: p2r(50);
      @include fj(space-between);
      align-items: center;
      border-top: 1px solid $bc;
    }
    .nationality {
      font-size: p2r(26);
    }
    .identity {
      > a {
        display: inline-block;
        width: 160/(640-60)*100%;
        border-right: 1px solid $bc;
        @include sc(p2r(26));
      }
    }
    p {
      width: 160/(640-60)*100%;
      @include sc(p2r(26));
    }
    input {
      flex: 1;
      padding-left: p2r(15);
    }
  }

  .delete-btn {
    margin: p2r(24) 0;
    text-align: center;
    @include sc(p2r(24), $mc);
    line-height: 1.2;
    .icon {
      @include sc(p2r(56), $blue);
      display: inline-block;
    }
  }
</style>
