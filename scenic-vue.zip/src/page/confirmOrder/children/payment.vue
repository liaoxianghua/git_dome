<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="确认支付">
      <div slot="btn" class="btn-all btn-left btn-back" @click="goBack()"></div>
    </head-top>
    <div class="ui-container" v-if="!showLoading">
        <section class="order-title">
          <div>{{orderInfo.product.productName}}</div>
        </section>
        <section class="pay-wrap">
          <div class="title">
            <span><i class="i-cx"></i>订单详情</span>
          </div>
          <ul class="info-list">
            <li>
              <span class="span-label">订单号：</span>
              <span class="span-value">{{orderInfo.orderNo}}</span>
            </li>
            <li v-if="orderInfo.orderType === 1 || orderInfo.orderType === 3 ">
              <span class="span-label">套餐名称：</span>
              <span class="span-value">{{orderInfo.mealsName}}</span>
            </li>
            <li v-if="orderInfo.orderType === 3">
              <span class="span-label">出发日期：</span>
              <span class="span-value">{{orderInfo.travelTime | formatDate}} {{orderInfo.travelTime | formatWeek}}</span>
            </li>
            <li v-else-if="orderInfo.orderType === 1">
              <span class="span-label">游玩日期：</span>
              <span class="span-value">{{orderInfo.travelTime | formatDate}} {{orderInfo.travelTime | formatWeek}}</span>
            </li>
            <li v-if="orderInfo.orderType === 3">
              <span class="span-label">出行人数：</span>
              <span
                class="span-value">{{orderInfo.adultCount + orderInfo.childCount}} (大人*{{orderInfo.adultCount}} 小孩*{{orderInfo.childCount}})</span>
            </li>
            <li v-else>
              <span class="span-label">购买数量：</span>
              <span class="span-value">{{orderInfo.orderCount}}</span>
            </li>
            <!--<li v-if="orderInfo.orderType === 3"><span class="span-label">出行人：</span><span class="span-value">
              <template v-for="item in orderInfo.memberDetailInfos">
                {{item.nameCh}}
              </template>
            </span></li>-->
          </ul>
        </section>
        <section class="pay-wrap order-person" v-if="orderInfo.orderType === 3">
          <div class="title"><span><i class="i-cx"></i>出行人信息</span></div>
          <ul class="list" v-for="(item,i) in orderInfo.memberDetailInfos">
            <li>出行人{{i + 1}}
            <span><br>姓名：{{item.nameCh}}</span>
              <span
                v-if="item.orderLinkmanDoc"><br>{{item.orderLinkmanDoc.documentName}}：{{item.orderLinkmanDoc.documentNo}}</span>
            </li>
          </ul>
        </section>
        <section class="pay-wrap">
          <div class="title"><span><i class="i-cx"></i>商户信息</span></div>
          <ul class="info-list">
            <li><span class="span-label">名称：</span><span class="span-value">{{orderInfo.seller.sellerName}}</span></li>
            <li><span class="span-label">联系电话：</span><span
              class="span-value">{{orderInfo.sellerUser.phone}} {{orderInfo.sellerUser.tel}}</span></li>
          </ul>
        </section>
        <section class="pay-wrap no-margin-bottom">
          <div class="title"><span><i class="i-cx"></i>支付方式</span></div>
          <ul class="pay-list">
            <li @click="changePayType(1)"><i class="i-icon i-alipay"></i>支付宝支付<i class="icon iconfont icon-roundcheckfill"
                                                                                 :class="{'icon-checked':payType===1}"></i>
            </li>
            <li @click="changePayType(2)"><i class="i-icon i-wxpay"></i>微信支付<i class="icon iconfont icon-roundcheckfill"
                                                                               :class="{'icon-checked':payType===2}"></i>
            </li>
            <li @click="changePayType(3)"><i class="i-icon i-unpay"></i>银行卡支付(储蓄卡和信用卡)<i
              class="icon iconfont icon-roundcheckfill" :class="{'icon-checked':payType===3}"></i>
            </li>
          </ul>
        </section>
        <section class="pay-sub">
          <div class="total-info"><span class="span-label">总额：</span><span class="span-value">{{payMoney}}</span></div>
          <div class="pay-btn"><span class="span-btn" @click="orderPayment">去支付</span></div>
        </section>
    </div>
  </div>
</template>

<script>
  import {checkLogin, orderDetail, payment} from 'src/service/getData'
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {
        orderId: 0,//订单ID
        orderInfo: null,//订单信息
        payType: 1,//支付方式
        payMoney: 0,//支付金额
        showLoading: true, //显示加载动画
        preventRepeatRequest: false, //阻止请求
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
      formatTime: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        let hours = mData.getHours();
        if (hours < 10) {
          hours = '0' + hours;
        }
        let minutes = mData.getMinutes();
        if (minutes < 10) {
          minutes = '0' + minutes;
        }
        let seconds = mData.getSeconds();
        if (seconds < 10) {
          seconds = '0' + seconds;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
      },
      formatWeek: function (timestamp) {
        let weekDayText = ['星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
        return weekDayText[new Date(timestamp).getDay()];
      },
    },
    created(){
      if (this.$route.query.orderId) this.orderId = this.$route.query.orderId;
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {
      initData: async function () {
        if (!this.orderId) {
          return;
        }
        let res = await orderDetail(this.orderId);
        if (res.status !== 200) {
          return;
        }

        this.orderInfo = res.obj.order;
        this.payMoney = this.orderInfo.payPrice;
        //this.payMoney.toFixed(2);
        /*if (this.payMoney <= 0) {
         await this.messageBox.alert('当前订单已支付');
         this.$router.replace('/order');
         }*/
        this.showLoading = false;
      },
      changePayType: function (val) {
        this.payType = val;
      },
      orderPayment: async function () {
        if (this.preventRepeatRequest) {
          return;
        }
        this.preventRepeatRequest = true;
        let res = await payment(this.orderId, this.payMoney, this.payType);
        this.preventRepeatRequest = false;
        if (res.status === 201) {
          this.routerTo();
        }
        if (res.status === 200) {
          await this.messageBox.alert(res.message);
          this.routerTo();
        }
      },
      routerTo(){
        this.$router.replace({path: '/order'});
      },
      goBack: async function () {
        let affirm = await this.messageBox({
          title: '提示',
          message: '确认取消支付？',
          showCancelButton: true,
          confirmButtonText: '取消支付',
          cancelButtonText: '继续支付'
        });
        if (affirm === 'cancel') {
          return;
        }

        this.$router.replace('/order');
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  .order-title {
    @include bmb;
    padding: p2r(16) p2r(26);
    @include sc(p2r(28), $mc);
  }

  .pay-wrap {
    @include bmb;
    .title {
      @include sc(p2r(28), $mc);
      position: relative;
      line-height: p2r(70);
      padding-left: p2r(44);
      .i-cx {
        display: inline-block;
        @include wh(p2r(4), p2r(26));
        background-color: $fc3;
        @include ct;
        left: p2r(28);
      }
    }
    .info-list {
      padding: p2r(16) p2r(22);
      border-top: 1px solid $bc;
      li {
        width: 100%;
        @include fj(flex-start);
        line-height: p2r(42);
        span {
          display: block;
          @include sc(p2r(26), $mc);
        }
        .span-label {
          width: p2r(140);
          text-align: right;
          color: $fc;
        }
        .span-value {
          flex: 1;
        }
      }
    }
    .pay-list {
      padding-left: p2r(20);
      border-top: 1px solid $bc;
      li {
        position: relative;
        line-height: p2r(88);
        padding-left: p2r(96);
        border-bottom: 1px solid $bc;
        @include sc(p2r(28), #666);
        .i-icon {
          display: inline-block;
          @include wh(p2r(72), p2r(72));
          @include ct;
          left: p2r(10);
        }
        .i-alipay {
          @include bis("../../../images/payment_alipay.png");
        }
        .i-wxpay {
          @include bis("../../../images/payment_wxpay.png");
        }
        .i-unpay {
          @include bis("../../../images/payment_unpay.png");
        }
        &:last-child {
          border-bottom: none;
        }
        .icon {
          @include sc(p2r(46), #ddd);
          @include ct;
          right: p2r(24);
        }
        .icon-checked {
          color: $blue;
        }
      }
    }
  }

  .no-margin-bottom {
    margin-bottom: 0;
  }

  .pay-sub {
    padding: 0 p2r(20);
    background-color: $bgc2;
    .total-info {
      @include fj();
      align-items: baseline;
      padding: p2r(30) 0;
      span {
        display: block;
      }
      .span-label {
        @include sc(p2r(26), $fc);
      }
      .span-value {
        @include sc(p2r(42), $fc3);
        &:before {
          content: '￥';
          font-size: p2r(26);
        }
      }
    }
    .pay-btn {
      padding-bottom: p2r(70);
      .span-btn {
        @include wh(100%, p2r(80));
        background-color: $blue;
        @include sc(p2r(32), $fc2);
        display: inline-block;
        text-align: center;
        line-height: p2r(80);
        @include borderRadius(p2r(12));
      }
    }
  }

  .order-person {
    .list {
      li {
        @include sc(p2r(26), $mc);
        line-height: p2r(40);
        border-top: 1px solid $bc;
        padding: p2r(20) 0 p2r(20) p2r(38);
        span {
          @include sc(p2r(24), $fc);
        }
      }
    }
  }
</style>
