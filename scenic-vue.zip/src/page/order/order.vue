<template>
  <div class="ui-body page-padding">
    <head-top :headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <ul class="tab-btn-blcok">
      <li v-for="(item,i) in tabText" @click.prevent="initOrderData(item.status)"
          :class="{active:item.status===status}">
        <span>{{item.title}}</span>
      </li>
    </ul>
    <div class="ui-container" v-infinite-scroll="loadingMore" infinite-scroll-distance="10"
         :infinite-scroll-disable="preventLoading" ref="container">
      <template v-show="showLoading">
        <section class="tab-content-blcok" v-if="listArr.length">
          <div class="order-block" v-for="item in listArr">
            <router-link :to="{path:'order/detail',query:{'id':item.encode}}">
              <div class="order-title">
                <div>
                  <i :class="reIconClassName(item.product.productType,item.product.productSubType)"></i>
                  <p>{{item.product.productType | typeText(item.product.productSubType, typeArr)}}</p>
                  <p>订单编号:{{item.orderNo}}</p>
                </div>
              </div>
              <div class="order-brief">
                <p class="order-text">{{item.productName}}</p>
                <div class="order-time">
                  <p>下单时间：{{item.createTime | formatTime}}</p>
                  <p class="price">合计：<i>￥</i><span>{{item.payPrice}}</span></p>
                </div>
              </div>
            </router-link>
            <div class="btn-group">
              <span class="span-status" v-if="item.orderStatus === 1">待确认</span>
              <span class="span-status red-text"
                    v-else-if="item.orderStatus === 3 && (item.payStatus === 1 || item.payStatus === 2)">待支付</span>
              <span class="span-status blue-text"
                    v-else-if="item.orderStatus === 3 && (item.payStatus === 3 || item.payStatus === 4)">已付款</span>
              <span class="span-status" v-if="item.orderStatus === 4">待取消</span>
              <span class="span-status grey-text"
                    v-else-if="item.orderStatus === 2 || item.orderStatus === 5">已取消</span>
              <span class="span-status grey-text" v-else-if="item.orderStatus === 6 && !item.commented">已完成</span>
              <span class="span-status grey-text" v-else-if="item.orderStatus === 6 && item.commented">已点评</span>
              <template v-if="item.orderStatus === 1">
                <a class="btn-cancel" @click.prevent="setOrderStatus(item.encode,2)">取消订单</a>
              </template>
              <template v-else-if="item.orderStatus === 3 && (item.payStatus === 1 || item.payStatus === 2)">
                <a class="btn-cancel" @click.prevent="setOrderStatus(item.encode,4)">取消订单</a>
                <router-link class="btn-affirm" :to="{path:'/confirmOrder/payment',query:{orderId:item.encode}}">
                  <span>付款</span>
                </router-link>
              </template>
              <template v-else-if="item.orderStatus === 3 && (item.payStatus === 3 || item.payStatus === 4)">
                <a class="btn-cancel" @click.prevent="setOrderStatus(item.encode,4)">取消订单</a>
              </template>
              <template v-else-if="item.orderStatus === 2 || item.orderStatus === 5">
                <router-link
                  :to="{path:'/goods/'+reControllerName(item.orderType),query:{id:item.productId}}"
                  class="btn-affirm">
                  <span>继续预定</span>
                </router-link>
              </template>
              <template v-else-if="item.orderStatus === 6">
                <router-link :to="{path:'order/comment',query:{orderId:item.encode}}" class="btn-affirm">点评







                </router-link>
              </template>
            </div>
          </div>
        </section>
        <section class="order-empty" v-else>暂无订单</section>
      </template>
      <footer class="loading-more" v-show="loadingMoreText && listArr.length">{{loadingMoreText}}</footer>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {mapState, mapMutations} from 'vuex'
  import {orderList, goodsTypes, cancelOrder, setOrderStatus} from 'src/service/getData'
  import headTop from 'src/components/header/head'

  export default {
    components: {
      headTop,
    },
    data(){
      return {
        pageTitle: '全部订单',
        activeIndex: 0,
        currentView: 'view1',
        tabText: [
          {title: "全部", status: 1},
          {title: "待审核", status: 5},
          {title: "待支付", status: 2},
          {title: "待完成", status: 3},
          {title: "待点评", status: 4}
        ],
        listArr: [],//订单列表
        typeArr: [],//产品分类列表
        status: 1,//订单状态
        pageNum: 1,
        pageSize: 10,
        showPage: false, //显示页面内容
        preventLoading: true, //阻止加载更多
        loadingMoreText: '',
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
      formatTime: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        let hours = mData.getHours();
        if (hours < 10) {
          hours = '0' + hours;
        }
        let minutes = mData.getMinutes();
        if (minutes < 10) {
          minutes = '0' + minutes;
        }
        let seconds = mData.getSeconds();
        if (seconds < 10) {
          seconds = '0' + seconds;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
      },
      typeText: function (type, subType, typeArr) {
        let res;
        typeArr.forEach((val) => {
          if (val.productType === type && val.productSubType === subType) {
            return res = val.productSubTypeName;
          }
        });
        return res;
      }
    },
    mounted(){
      this.initData();
    },
    computed: {
      ...mapState([
        'orderStatus',
      ]),
    },
    methods: {
      initData: async function () {
        if (this.$route.query.status) this.status = this.$route.query.status;

        let res = await goodsTypes();
        if (res.status !== 200) {
          return;
        }

        this.typeArr = res.obj.productCategorys;
        this.initOrderData(this.status);
      },
      initOrderData: async function (status) {
        this.loadingMoreText = '';
        this.$refs.container.scrollTop = 0;
        this.showPage = false;
        this.status = status;
        this.pageNum = 1;
        let res = await orderList(this.status, this.pageSize, this.pageNum);
        this.showPage = true;
        this.preventLoading = false;
        if (res.status !== 200) {
          return;
        }
        this.listArr = res.obj.orders.list;
        this.totalPage = res.obj.orders.pages;

        if(this.listArr.length < this.pageSize){
          this.loadingMoreText = '没有了';
        }
      },
      loadingMore: async function () {
        if (this.preventLoading) {
          return;
        }
        this.preventLoading = true;
        if (this.totalPage > this.pageNum) {
          this.pageNum++;
          let res = await orderList(this.status, this.pageSize, this.pageNum);
          this.preventLoading = false;
          if (res.status !== 200) {
            return;
          }

          let listArr = res.obj.orders.list;
          if (!listArr.length) {
            //没有更多阻止以后触发加载更多
            this.loadingMoreText = '没有了';
            return;
          }
          this.listArr = [...this.listArr, ...listArr];
        }
        else {
          //没有更多阻止以后触发加载更多
          this.loadingMoreText = '没有了';
        }
      },
      setOrderStatus: async function (orderId, orderStatus) {
        await this.messageBox.confirm('确定取消订单?');

        let res = await setOrderStatus(orderId, orderStatus);
        if (res.status === 200) {
          this.Toast({message: '取消成功', position: 'bottom'});
          this.initOrderData(this.status);
        }
      },
      reControllerName: function (productType) {
        if (productType === 1) {
          return 'spotsDetails';
        }
        else if (productType === 2) {
          return 'goodsDetails';
        }
        else if (productType === 3) {
          return 'linesDetails';
        }
      },
      reIconClassName: function (productType, productSubType) {
        return 'icon-' + productType + '-' + productSubType;
      }
    },
    watch: {
      orderStatus: function () {
        this.initOrderData(this.status);
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .page-padding {
    padding-top: p2r(186);
  }

  .content-wrapper {
    height: 100%;
    overflow: auto;
  }

  .order-empty {
    @include sc(p2r(26), $fc);
    text-align: center;
    width: 100%;
    margin: p2r(100) 0;
  }

  //切换
  .red-text {
    color: #ff1c31;
  }

  .blue-text {
    color: $blue;
  }

  .grey-text {
    color: $fc;
  }

  .icon-1-1:after {
    background: url('../../images/order/0101.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-1-2:after {
    background: url('../../images/order/0102.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-1-3:after {
    background: url('../../images/order/0103.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-1-4:after {
    background: url('../../images/order/0104.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-2-1:after {
    background: url('../../images/order/0201.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-3-1:after {
    background: url('../../images/order/0301.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-3-2:after {
    background: url('../../images/order/0302.png') no-repeat center;
    background-size: auto 100%;
  }

  .icon-3-3:after {
    background: url('../../images/order/0303.png') no-repeat center;
    background-size: auto 100%;
  }

  .order-block {
    @include bmb;
    margin-bottom: 0;
    display: block;
    border-top: none;
    .order-title, .order-brief, .btn-group {
      padding: 0 p2r(30);
      border-bottom: 1px solid $bc;
    }
    //订单标题
    .order-title {
      @include fj(space-between);
      align-items: center;
      font-size: p2r(24);
      height: p2r(72);
      > div {
        display: flex;
        align-items: center;
        i {
          display: inline-block;
          @include wh(p2r(56), p2r(56));
          border-radius: p2r(2);
          margin-right: p2r(15);
        }
        i:after {
          content: '';
          width: 100%;
          height: 100%;
          display: inline-block;
        }
        p {
          margin-right: p2r(18);
        }
      }
    }
    //订单简介
    .order-brief {
      padding: p2r(22) p2r(20);
    }
    .order-text {
      font-size: p2r(28);
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      line-height: (42/28);
      margin-bottom: p2r(10);
    }
    .order-time {
      display: flex;
      @include fj(space-between);
      p {
        font-size: p2r(22);
        color: $fc;
        line-height: (44/22);
      }
      .price {
        line-height: (44/30);
        i, span {
          color: $fc3;
        }
        span {
          font-size: p2r(30);
        }
        i {
          font-size: p2r(20);
        }
      }
    }
    /*按钮组*/
    .btn-group {
      border-bottom: none;
      padding-top: p2r(13);
      padding-bottom: p2r(13);
      text-align: right;
      position: relative;
      height: p2r(85);
      a {
        width: p2r(150);
        line-height: (55/28);
        display: inline-block;
        font-size: p2r(28);
        text-align: center;
        border-radius: p2r(6);
        margin-left: p2r(20);
      }
      .span-status {
        @include ct;
        left: p2r(20);
        font-size: p2r(24);
      }
    }
  }

  .btn-affirm {
    border: 1px solid $blue;
    color: $blue;
  }

  .btn-cancel {
    border: 1px solid $fc;
    color: $fc;
  }

  .loading-more {
    width: 100%;
    text-align: center;
    @include sc(p2r(28), $fc);
    line-height: 2;
  }

</style>
