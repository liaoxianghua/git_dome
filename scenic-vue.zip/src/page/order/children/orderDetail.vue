<template>
  <div class="ui-body ui-padding-header">
    <head-top :headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container" v-if="!showLoading">
      <p class="state-hint no-pay" v-if="orderInfo.payStatus < 3">您的订单还未支付</p>
      <div class="order-introduce">
        <p class="order-text ellipsis-rows">
          <router-link :to="{path:'/goods/'+reControllerName(orderInfo.orderType),query:{id:orderInfo.productId}}">
            <span>{{orderInfo.productName}}</span>
          </router-link>
        </p>
        <ul class="col-interval">
          <li><p>订单编号</p>{{orderInfo.orderNo}}</li>
          <li><p>下单时间</p>{{orderInfo.createTime | formatTime}}</li>
          <li v-if="orderInfo.orderType === 3"><p>出发日期</p>
            <span>{{orderInfo.travelTime | formatDate}} {{orderInfo.travelTime | formatWeek}}</span>
          </li>
          <li v-else-if="orderInfo.orderType === 1"><p>游玩日期</p>
            <span>{{orderInfo.travelTime | formatDate}} {{orderInfo.travelTime | formatWeek}}</span>
          </li>
          <li v-if="orderInfo.orderType === 3"><p>出行人数</p>
            <span>{{orderInfo.adultCount + orderInfo.childCount}} (大人*{{orderInfo.adultCount}} 小孩*{{orderInfo.childCount}})</span>
          </li>
          <li v-else><p>购买数量</p>{{orderInfo.orderCount}}</li>
          <li><p>订单金额</p>
            <div class="price"><i>￥</i><span>{{orderInfo.orderPrice}}</span></div>
          </li>
        </ul>
        <ul class="col-interval col-interval-border">
          <li><p>商户</p>{{orderInfo.seller.sellerName}}</li>
          <li><p>联系电话</p>{{orderInfo.sellerUser.phone}} {{orderInfo.sellerUser.tel}}</li>
        </ul>
      </div>
      <div class="order-traveller" v-if="orderInfo.orderType === 3 && orderInfo.memberDetailInfos.length">
        <child-title titleText="旅客信息"></child-title>
        <ul>
          <li v-for="(item,i) in orderInfo.memberDetailInfos">
            <p>旅客{{i + 1}}</p>
            <div>
              <span>{{item.nameCh}}</span>
              <p>{{item.orderLinkmanDoc.documentName}}：{{item.orderLinkmanDoc.documentNo}}</p>
            </div>
          </li>
        </ul>
      </div>
      <div class="order-linkman">
        <child-title titleText="联系人信息"></child-title>
        <ul class="col-interval">
          <li><p>姓名</p>{{orderInfo.linkMan}}</li>
          <li><p>手机</p>{{orderInfo.phone}}</li>
          <li><p>邮箱</p>{{orderInfo.email}}</li>
        </ul>
      </div>
      <div class="order-linkman order-invoice">
        <child-title titleText="发票信息"></child-title>
        <ul class="col-interval" v-if="orderInfo.needInvoice">
          <li><p>抬头</p>{{orderInfo.invoice.title}}</li>
          <li><p>发票类型</p>{{orderInfo.invoice.type === 1?'单位':'个人'}}</li>
          <li><p>领取方式</p>{{orderInfo.invoice.gainType?'邮寄到付':'当面领取'}}</li>
          <li v-if="orderInfo.invoice.gainType"><p>邮寄地址</p>{{orderInfo.invoice.takeAddress}}</li>
        </ul>
        <ul class="col-interval" v-else>
          <li>不需要发票</li>
        </ul>
      </div>
      <div class="order-btn">
        <template v-if="orderInfo.orderStatus === 1">
          <a class="btn-cancel" @click.prevent="setOrderStatus(orderInfo.encode,2)">取消订单</a>
        </template>
        <template
          v-else-if="orderInfo.orderStatus === 3 && (orderInfo.payStatus === 1 || orderInfo.payStatus === 2)">
          <a class="btn-cancel" @click.prevent="setOrderStatus(orderInfo.encode,4)">取消订单</a>
          <router-link class="btn-affirm" :to="{path:'/confirmOrder/payment',query:{orderId:orderInfo.encode}}">
            <span>付款</span>
          </router-link>
        </template>
        <template
          v-else-if="orderInfo.orderStatus === 3 && (orderInfo.payStatus === 3 || orderInfo.payStatus === 4)">
          <a class="btn-cancel" @click.prevent="setOrderStatus(orderInfo.encode,4)">取消订单</a>
        </template>
        <template v-else-if="orderInfo.orderStatus === 2 || orderInfo.orderStatus === 5">
          <router-link
            :to="{path:'/goods/'+reControllerName(orderInfo.orderType),query:{id:orderInfo.productId}}"
            class="btn-affirm">
            <span>继续预定</span>
          </router-link>
        </template>
        <template v-else-if="orderInfo.orderStatus === 6">
          <router-link :to="{path:'detail/comment',query:{orderId:orderInfo.encode}}" class="btn-affirm">点评</router-link>
        </template>
      </div>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>
<script>
  import {checkLogin, orderDetail, setOrderStatus} from 'src/service/getData'
  import headTop from 'src/components/header/head'
  import childTitle from 'src/components/common/travelblock/traveTitle'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        pageTitle: '订单详情',
        id: 0,//订单ID
        orderInfo: 0,//订单信息
        showLoading: true, //显示加载动画
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
      formatTime: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        let hours = mData.getHours();
        if (hours < 10) {
          hours = '0' + hours;
        }
        let minutes = mData.getMinutes();
        if (minutes < 10) {
          minutes = '0' + minutes;
        }
        let seconds = mData.getSeconds();
        if (seconds < 10) {
          seconds = '0' + seconds;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
      },
      formatWeek: function (timestamp) {
        let weekDayText = ['星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
        return weekDayText[new Date(timestamp).getDay()];
      },
    },
    components: {
      headTop,
      childTitle
    },
    created(){
      if (this.$route.query.id) this.id = this.$route.query.id;
    },
    mounted(){
      this.initData();
    },
    computed: {
      ...mapState([
        'orderStatus',
      ]),
    },
    methods: {
      ...mapMutations([
        'SAVE_ORDER_STATUS'
      ]),
      initData: async function () {
        if (!this.id) {
          this.$router.go(-1);
        }
        this.showLoading = true;
        let res = await orderDetail(this.id);
        this.showLoading = false;
        if (res.status !== 200) {
          return;
        }
        this.orderInfo = res.obj.order;
      },
      loadTop: function () {
        this.$refs.loadmore.onTopLoaded();
      },
      setOrderStatus: async function (orderId, orderStatus) {
        await this.messageBox.confirm('确定取消订单?');
        let res = await setOrderStatus(orderId, orderStatus);
        if (res.status === 200) {
          this.SAVE_ORDER_STATUS({id: orderId});
          this.initData();
        }
      },
      reControllerName: function (productType) {
        if (productType === 1) {
          return 'spotsDetails';
        }
        else if (productType === 2) {
          return 'goodsDetails';
        }
        else if (productType === 3) {
          return 'linesDetails';
        }
      },
    }
  }
</script>
<style lang="scss">
  @import '../../../style/mixin';

  .content-wrapper {
    height: 100%;
    overflow: auto;
  }

  .state-hint {
    background: $blue;
    color: $fc2;
    font-size: p2r(30);
    padding: p2r(15) 0 p2r(30);
    text-align: center;
  }

  .state-hint:before {
    content: '';
    display: inline-block;
    width: p2r(46);
    height: p2r(46);
    margin-right: p2r(18);
    vertical-align: middle;
  }

  //两列间隔文字
  .col-interval {
    padding: p2r(20) p2r(30);
    li {
      font-size: p2r(24);
      line-height: 1;
      margin: p2r(12) 0;
      display: flex;
      align-items: center;
      p {
        color: $fc;
        width: p2r(150);
        display: inline-block;
        padding-right: p2r(38);
        text-align: right;
      }
    }
  }

  .col-interval-border {
    border-top: 1px solid $bc;
  }

  //文字介绍
  .order-introduce {
    @include bmb;
    .price {
      line-height: (44/30);
      i, span {
        color: $fc3;
      }
      span {
        font-size: p2r(30);
      }
      i {
        font-size: p2r(20);
      }
    }
    .order-text {
      font-size: p2r(28);
      font-weight: bold;
      padding: p2r(16) p2r(30);
      line-height: (42/28);
      border-bottom: 1px solid $bc;
    }
  }

  //机票
  .order-ticket {
    @include bmb;
    ul {
      li {
        padding: p2r(16) p2r(30);
        border-bottom: 1px dashed $bc;
      }
      li:last-child {
        border-bottom: none;
      }
    }
    .ticket-title {
      display: flex;
      align-items: center;
      font-size: p2r(26);
      i {
        display: inline-block;
        width: p2r(35);
        height: p2r(35);
        border-radius: p2r(4);
        padding: p2r(2);
        margin-right: p2r(15);
        text-align: center;
        line-height: p2r(33);
        color: $fc2;
      }
      p {
        margin-right: p2r(26);
      }
      p:last-child {
        span {
          border-left: 1px solid $bc;
          margin: 0 p2r(10);
        }
      }
    }
    .ticket-time {
      @include fj(space-between);
      margin-top: p2r(36);
      > i {
        margin-top: p2r(14);
      }
      > div {
        > span {
          font-size: p2r(36);
          line-height: 1;
        }
        > p {
          font-size: p2r(24);
          color: $fc;
          line-height: (52/24);
        }
      }
    }
  }

  .icon-aircraft {
    display: inline-block;
    width: p2r(104);
    height: p2r(30);
    @include bis('../../../images/icon/aircraft-icon.png');
  }

  //酒店
  .order-grogshop {
    @include bmb;
  }

  //旅客信息
  .order-traveller {
    @include bmb;
    ul {
      li {
        border-bottom: 1px dashed $bc;
        padding: p2r(20);
        font-size: p2r(24);
        display: flex;
        > p {
          color: $fc;
          width: p2r(108);
          padding-right: p2r(38);
          text-align: right;
        }
        > div {
          > p {
            color: $fc;
          }
        }
      }
      li:last-child {
        border-bottom: none;
      }
    }
  }

  //联系人
  .order-linkman {
    @include bmb;
    .col-interval {
      > li > p {
        width: p2r(108);
        padding-right: p2r(45);
        text-align: right;
      }
    }
  }

  //发票信息
  .order-invoice{
    .col-interval {
      > li > p {
        width: p2r(156);
      }
    }
  }

  //保险信息
  .order-insurance {
    @include bmb;
    h4 {
      font-size: p2r(28);
      padding: 0 p2r(35);
      padding-top: p2r(40);
    }
    ul > li > p {
      padding-right: p2r(65);
    }
  }

  //按钮组
  .order-btn {
    background: $bgc2;
    border-bottom: none;
    display: flex;
    @include fj(flex-end);
    padding: p2r(20);
    a {
      width: p2r(150);
      line-height: (55/28);
      display: block;
      font-size: p2r(28);
      text-align: center;
      border-radius: p2r(6);
      margin-left: p2r(20);
    }
  }

  //图标
  .go {
    background: $blue;
  }

  .go:before {
    content: '去';
  }

  .answer {
    background: $fc3;
  }

  .answer:before {
    content: '回';
  }

  .no-pay:before {
    @include bis('../../../images/icon/money-yuan-icon.png');
  }

  //按钮
  .btn-affirm {
    border: 1px solid $blue;
    color: $blue;

  }

  .btn-cancel {
    border: 1px solid $fc;
    color: $mc;
  }


</style>
