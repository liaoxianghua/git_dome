<template>
  <div class="ui-body ui-padding-header">
    <head-top headTitle="填写点评">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container" v-if="!showLoading">
      <div class="comment-obj">
        <div><img v-lazy="orderInfo.fileUrl" :alt="orderInfo.productName"></div>
        <p class="ellipsis-rows">{{orderInfo.productName}}</p>
      </div>
      <div class="comment-content">
        <div class="comment-score">
          <p>总评分</p>
          <ul class="grade">
            <li @click="changeGrade(1)"><span><i class="icon"
                                                 :class="[grade > 0 ?'icon-favorfill':'icon-favor']"></i></span>
            </li>
            <li @click="changeGrade(2)"><span><i class="icon"
                                                 :class="[grade > 1 ?'icon-favorfill':'icon-favor']"></i></span>
            </li>
            <li @click="changeGrade(3)"><span><i class="icon"
                                                 :class="[grade > 2 ?'icon-favorfill':'icon-favor']"></i></span>
            </li>
            <li @click="changeGrade(4)"><span><i class="icon"
                                                 :class="[grade > 3 ?'icon-favorfill':'icon-favor']"></i></span>
            </li>
            <li @click="changeGrade(5)"><span><i class="icon"
                                                 :class="[grade > 4 ?'icon-favorfill':'icon-favor']"></i></span>
            </li>
          </ul>
        </div>
        <div class="comment-from">
            <textarea name="" id="" cols="30" rows="10" placeholder="写点什么吧" v-model="content"
                      maxlength="600"></textarea>
        </div>
        <div class="comment-add-pic">
          <div class="img-list">
            <img :src="url" v-for="url in imgUrls">
            <div class="add-pic">
              <label for="img" class="btn-add-img">添加照片</label>
              <input id="img" class="upload-input" type="file" accept="image/*"
                     @change="onload($event)" ref="isfiles" multiple>
            </div>
          </div>
        </div>
      </div>
      <span class="submit-btn" @click="commentSub()">提交</span>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import {mapState, mapMutations} from 'vuex'
  import {checkLogin, orderDetail, uploadPic, addComment} from 'src/service/getData'
  import headTop from 'src/components/header/head'
  import childTitle from 'src/components/common/travelblock/traveTitle'
  import {baseUrl} from 'src/config/env'

  export default {
    data(){
      return {
        orderId: 0,//订单ID
        orderInfo: {},//订单信息
        grade: 5,//
        content: null,//评价内容
        imgUrls: [],//图片地址
        maxImgUrl: 10,//最多可上传图片数
        showLoading: true, //显示加载动画
        preventRepeatRequest: false, //阻止请求\
      }
    },
    components: {
      headTop,
    },
    created(){
      if (this.$route.query.orderId) this.orderId = this.$route.query.orderId;
    },
    mounted(){
      this.initData();
    },
    computed: {
      ...mapState([
        'orderStatus',
      ]),
    },
    methods: {
      ...mapMutations([
        'SAVE_ORDER_STATUS'
      ]),
      initData: async function () {
        if (!this.orderId) {
          return;
        }
        let res = await orderDetail(this.orderId);
        if (res.status !== 200) {
          this.showAlert = true;
          this.alertText = res.message;
          return;
        }

        this.orderInfo = res.obj.order;

        this.showLoading = false;
      },
      changeGrade: function (i) {
        this.grade = i;
      },
      commentSub: async function () {
        if (!this.content) {
          this.Toast({message: '请写下您的点评', position: 'middle'});
          return;
        }
        let res = await addComment(this.orderInfo.productId, this.orderInfo.productName, this.orderId, this.orderInfo.sellerId, this.content, this.grade, this.imgUrls.join(','));
        if (res.status !== 200) {
          return;
        }

        await this.messageBox.alert(res.message);
        this.SAVE_ORDER_STATUS({id: this.orderId, status: this.orderInfo.orderStatus + 1});
        this.$router.go(-1);
      },
      //上传图片
      onload(e){
        var maxsize = 100 * 1024;
        typeof e.target === 'undefined' ? this.file = e : this.file = e.target.files;
        if (!this.file.length) {
          return
        }
        let files = Array.prototype.slice.call(this.file);
        files = files.reverse();
        if (files.length > this.maxImgUrl) {
          this.Toast({message: '最多上传' + this.maxImgUrl + '张', position: 'bottom'});
          return
        }

        if (files.length + this.imgUrls.length > this.maxImgUrl) {
          this.Toast({
            message: '您已经上传了' + this.imgUrls.length + '张，还能上传' + (this.maxImgUrl - this.imgUrls.length) + '张，请重新选择图片',
            position: 'bottom'
          });
          return;
        }
        files.forEach((file, i) => {
          if (!/\/(?:jpeg|jpg|png|gif)/i.test(file.type) && file.type != '') {
            this.Toast({message: '不支持您上传的图片格式', position: 'bottom'});
            return;
          }
          var reader = new FileReader();
          var _thit = this;
          reader.onload = function () {
            var result = this.result;
            var img = new Image();
            img.src = result;
            //如果图片大小小于100kb，则直接上传
            if (result.length <= maxsize) {
              img = null;
              _thit.upload(result, file.type, file.name);
              return;
            }
            //图片加载完毕之后进行压缩，然后上传
            if (img.complete) {
              callback();
            } else {
              img.onload = callback;
            }
            function callback() {
              var data = _thit.compress(img);
              _thit.upload(data, file.type, file.name);
              img = null;
            }
          }
          reader.readAsDataURL(file);
        });
      },
      //使用canvas对大图片进行压缩
      compress(img) {
        //    用于压缩图片的canvas
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext('2d');
        //    瓦片canvas
        var tCanvas = document.createElement("canvas");
        var tctx = tCanvas.getContext("2d");

        var initSize = img.src.length;
        var width = img.width;
        var height = img.height;
        //如果图片大于2百万像素，计算压缩比并将大小压至200万以下
        var ratio;
        if ((ratio = width * height / 2000000) > 1) {
          ratio = Math.sqrt(ratio);
          width /= ratio;
          height /= ratio;
        } else {
          ratio = 1;
        }
        canvas.width = width;
        canvas.height = height;
        //        铺底色
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        //如果图片像素大于100万则使用瓦片绘制
        /*var count;
         if ((count = width * height / 1000000) > 1) {
         count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
         //            计算每块瓦片的宽和高
         var nw = ~~(width / count);
         var nh = ~~(height / count);
         tCanvas.width = nw;
         tCanvas.height = nh;
         for (var i = 0; i < count; i++) {
         for (var j = 0; j < count; j++) {
         tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
         ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
         }
         }
         } else {*/
        ctx.drawImage(img, 0, 0, width, height);
        //}
        //进行最小压缩
        var ndata = canvas.toDataURL('image/jpeg', 0.6);
        tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
        return ndata;
      },
      //开始上传
      async upload(basestr, type, name) {

        var text = window.atob(basestr.split(",")[1]);
        var buffer = new Uint8Array(text.length);
        for (var i = 0; i < text.length; i++) {
          buffer[i] = text.charCodeAt(i);
        }
        var blob = this.getBlob([buffer], type);
        var formdata = this.getFormData();
        formdata.append('upload', blob, name);

        /*let response = await fetch(baseUrl+'/common/saveUploadFile',{
         method: 'POST',
         body: formdata
         });*/

        let res = await axios({
          method: 'POST',
          url: baseUrl + '/common/saveUploadFile',
          data: formdata,
          headers: {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        }).then((response) => {
          return response.data;
        }, (response) => {
          console.log(response);
        }).catch((error) => {
          console.log(error);
        });

        if (res.status === 200) {
          this.Toast({message: '上传成功', iconClass: 'ui-toast-icon iconfont icon-appreciate'});
          this.displayimg(res);
        }

      },
      //获取formdata
      getFormData() {
        var isNeedShim = ~navigator.userAgent.indexOf('Android')
          && ~navigator.vendor.indexOf('Google')
          && !~navigator.userAgent.indexOf('Chrome')
          && navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534;
        return isNeedShim ? new FormDataShim() : new FormData()
      },
      getBlob(buffer, format) {
        try {
          return new Blob(buffer, {type: format});
        } catch (e) {
          var bb = new (window.BlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder);
          buffer.forEach(function (buf) {
            bb.append(buf);
          });
          return bb.getBlob(format);
        }
      },
      //显示图片
      displayimg(res){
        this.imgUrls.unshift(res.obj.busiPictureAttachvo.urlAttach);
      },
    }
  }
</script>

<style lang="scss">
  @import '../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .comment-obj {
    @include fj(space-between);
    background: $bgc2;
    padding: p2r(20);
    border-bottom: 1px solid $bc;
    > div {
      width: p2r(182);
      img {
        @include wh(p2r(180), p2r(150))
      }
    }
    > p {
      width: p2r(400);
      font-size: p2r(30);
      @include ellipsisrows(3);
    }
  }

  .comment-content {
    background: $bgc2;
    padding: p2r(20);
    border-bottom: 1px solid $bc;
  }

  .comment-score {
    display: flex;
    align-items: center;
    padding: p2r(10) 0;
    > p {
      font-size: p2r(30);
      margin-right: p2r(32);
    }
  }

  .comment-from {
    padding: p2r(12) 0;
    textarea {
      resize: none;
      width: 100%;
      background: $bgc;
      height: p2r(120);
      padding: p2r(20);
      border: 1px solid $bc;
      border-radius: p2r(6);
    }
  }

  .comment-add-pic {
    overflow: hidden;
    .img-list {
      width: 100%;
      overflow: hidden;
      .upload-input {
        display: none;
      }
      img {
        height: p2r(122);
        float: left;
        margin: 0 p2r(6) p2r(6) 0;
      }
      .add-pic {
        float: left;
        .btn-add-img {
          width: p2r(120);
          height: p2r(50);
          border: 1px solid $blue;
          text-align: center;
          border-radius: p2r(6);
          display: block;
          background: url(../../../images/icon/camera-icon.png) no-repeat center 30%;
          background-size: 40% auto;
          @include sc(p2r(24), $blue);
          padding-top: p2r(70);
        }
      }
    }
  }

  .icon-camera {
    width: p2r(40);
    height: p2r(33);
    display: inline-block;
    @include bis('../../../images/icon/camera-icon.png');
  }

  .submit-btn {
    @include submit;
    margin-top: p2r(42);
  }

  .grade {
    display: flex;
    li {
      padding: 0 p2r(15);
      span {
        display: inline-block;
      }
      .icon {
        font-family: "iconfont" !important;
        font-style: normal;
        -webkit-font-smoothing: antialiased;
        @include sc(p2r(40), $fc3);
        line-height: p2r(88);
        display: inline-block;
      }
    }
  }
</style>
