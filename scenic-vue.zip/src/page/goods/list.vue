<template>
  <div class="ui-body page-padding ui-gray-bg">
    <head-top headTitle="产品">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <form class="search-form">
      <i class="i-search"></i>
      <input type="search" name="search" autocomplete="off" placeholder="目的地/景点/酒店/攻略/游记" class="ipn-value"
             readonly
             @click="routerToSearch">
    </form>
    <nav class="goods-nav" ref="nav">
      <template v-for="(item,i) in typeArr">
          <span class="span-item"
                :class="{'span-item-active':item.productSubType === productSubType && item.productType === productType}"
                @click="initGoodsData(item.productType,item.productSubType)"><i>{{item.productSubTypeName}}</i></span>
      </template>
    </nav>
    <div class="ui-container" v-infinite-scroll="loadingMore" infinite-scroll-distance="10"
         :infinite-scroll-disable="preventLoading" ref="container" v-show="showPage" rel="container">
      <section class="goods-list" v-if="listArr.length">
        <div class="item" v-for="item in listArr">
          <router-link :to="{path:'goods/'+reControllerName(item.productType),query:{id:item.id}}">
            <div class="thum">
              <img v-lazy="item.mainPic" class="img-thum" :alt="item.productName">
              <span class="span-tips ellipsis">{{item.productType | typeText(item.productSubType, typeArr)}}</span>
              <span class="span-location ellipsis"><i
                class="icon iconfont icon-locationfill"></i>{{item.cityName}}</span>
            </div>
            <div class="font">
              <span class="span-title">{{item.productName}}</span>
              <template v-for="v in item.listKeyword">
                <i class="i-tips">{{v.name}}</i>
              </template>
              <span class="span-price"
                    :class="[item.productType===2 && 'span-price-commodity']">{{item.price}}</span>
              <span class="span-num">{{item.saledNum}}人购买</span>
            </div>
          </router-link>
        </div>
      </section>
      <section class="goods-empty" v-else>暂无商品</section>
      <footer class="loading-text" v-show="loadingMoreText && listArr.length">{{loadingMoreText}}</footer>
    </div>
    <!--<router-view></router-view>-->
    <transition name="router-slid" mode="in-out">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {goodsList, goodsTypes} from 'src/service/getData'
  import headTop from 'src/components/header/head'
  import {setStore, getStore} from 'src/config/mUtils'

  export default {
    data(){
      return {
        cityName: null,
        productType: null,//一级分类
        productSubType: null,//二级分类
        typeArr: [],//产品分类列表
        listArr: [],//产品列表
        showPage: false, //显示页面内容
        pageNum: 1,
        pageSize: 10,
        totalPage: 1,//总页数
        preventLoading: true, //阻止加载更多
        loadingMoreText: '',
      }
    },
    created(){
      if (this.$route.query.productType) this.productType = parseInt(this.$route.query.productType);
      if (this.$route.query.productSubType) this.productSubType = parseInt(this.$route.query.productSubType);
      this.cityName = getStore('cityName');
      if (!this.cityName) this.cityName = '上海';
      if (this.$route.query.city) this.cityName = this.$route.query.city;
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
    },
    filters: {
      typeText: function (type, subType, typeArr) {
        let res;
        typeArr.forEach((val) => {
          if (val.productType === type && val.productSubType === subType) {
            return res = val.productSubTypeName;
          }
        });
        return res;
      }
    },
    methods: {
      initData: async function () {
        await this.initGoodsData(this.productType, this.productSubType);
        //let res = await goodsTypes();
        //this.typeArr = res.obj.productCategorys;
        //nav定位
        setTimeout(() => {
          let els = this.$refs.nav.children, scrollX = 0;
          for (let i = 0; i < els.length; i++) {
            let el = els[i];
            if (el.className.indexOf('span-item-active') !== -1) {
              break;
            }
            else {
              scrollX += el.offsetWidth;
            }
          }
          this.$refs.nav.scrollLeft = scrollX;
        }, 100);
      },

      initGoodsData: async function (productType, productSubType) {
        this.loadingMoreText = '';
        this.$refs.container.scrollTop = 0;
        this.preventLoading = true;
        this.loadingMoreText = '';
        this.productType = productType;
        this.productSubType = productSubType;
        this.showPage = false;
        this.pageNum = 1;

        let res = await goodsList(this.cityName, this.productType, this.productSubType, this.pageSize, this.pageNum);

        this.showPage = true;
        this.listArr = res.obj.proudcts.list;
        this.totalPage = res.obj.proudcts.pages;
        this.typeArr = res.obj.productCategorys;

        this.preventLoading = false;

        if(this.listArr.length < this.pageSize){
          this.loadingMoreText = '没有了';
        }
      },
      reControllerName: function (productType) {
        if (productType === 1) {
          return 'spotsDetails';
        }
        else if (productType === 2) {
          return 'goodsDetails';
        }
        else if (productType === 3) {
          return 'linesDetails';
        }
      },
      loadingMore: async function () {
        if (this.preventLoading) {
          return;
        }
        this.preventLoading = true;

        if (this.totalPage > this.pageNum) {
          this.pageNum++;
          let res = await goodsList(this.cityName, this.productType, this.productSubType, this.pageSize, this.pageNum);

          this.preventLoading = false;
          if (res.status !== 200) {
            return;
          }

          let listArr = res.obj.proudcts.list;
          if (!listArr.length) {
            this.loadingMoreText = '没有了';
            return;
          }
          this.listArr = [...this.listArr, ...listArr];
        }
        else {
          this.loadingMoreText = '没有了';
        }
      },
      routerToSearch: function () {
        this.$router.push('search');
      },
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .page-padding {
    padding-top: p2r(170);
  }

  .goods-empty {
    @include sc(p2r(26), $fc);
    text-align: center;
    width: 100%;
    margin: p2r(100) 0;
  }

  .search-form {
    position: absolute;
    top: p2r(16);
    right: p2r(16);
    @include wh(82%, p2r(56));
    @include borderRadius(p2r(12));
    background-color: $bgc2;
    overflow: hidden;
    .i-search {
      display: inline-block;
      @include wh(p2r(25), p2r(25));
      @include ct;
      left: p2r(20);
      @include bis("../../images/icon/icon_ipn_search.png");
    }
    input {
      display: inline-block;
      float: right;
      width: 84%;
      padding: 0;
      margin: 0;
      line-height: p2r(56);
      margin-right: p2r(20);
      @include sc(p2r(26), $mc);
    }
  }

  .goods-nav {
    line-height: p2r(70);
    overflow: auto;
    white-space: nowrap;
    background-color: $bgc2;
    border-bottom: 1px solid $bc;
    position: absolute;
    left: 0;
    top: p2r(88);
    width: 100%;
    .span-item {
      display: inline-block;
      & > i {
        display: inline-block;
        padding: 0 p2r(30);
        @include sc(p2r(28), $mc);
        margin-right: p2r(32);
        font-style: normal;
        border-bottom: p2r(4) solid $bgc2;
      }
      &:last-child {
        & > i {
          margin-right: 0;
        }
      }
    }
    .span-item-active {
      & > i {
        border-color: $blue;
      }
    }
  }

  .goods-list {
    background-color: $bgc2;
    .item {
      border-bottom: 1px solid $bc;
      a {
        display: block;
        width: 100%;
        overflow: hidden;
        @include fj(flex-start);
        align-items: flex-start;
        padding: p2r(18);
      }
      .thum {
        position: relative;
        width: p2r(180);
        margin-right: p2r(20);
        .img-thum {
          @include wh(p2r(180), p2r(150));
        }
        .span-tips {
          display: block;
          @include wh(100%, p2r(40));
          @include sc(p2r(24), $mc);
          line-height: p2r(40);
          background-color: $bgc;
          text-align: center;
        }
        .span-location {
          max-width: 100%;
          display: block;
          position: absolute;
          top: 0;
          left: 0;
          @include sc(p2r(24), $fc2);
          line-height: p2r(30);
          padding: 0 p2r(12) 0 0;
          background-color: rgba(0, 0, 0, 0.4);
        }
        .icon {
          display: inline-block;
          @include borderRadius(p2r(28));
          @include sc(p2r(24), $fc2);
          margin: 0 p2r(4);
        }
      }
      .font {
        position: relative;
        padding-bottom: p2r(54);
        min-height: p2r(190);
        flex: 1;
        .span-title {
          display: inline-block;
          @include sc(p2r(28), $mc);
          line-height: p2r(32);
          min-height: p2r(64);
          margin-bottom: p2r(12);
          width: 100%;
          word-break: break-all;
        }
        .i-tips {
          display: block;
          @include sc(p2r(24), $blue);
          line-height: p2r(34);
          border: 1px solid $blue;
          padding: 0 p2r(12);
          margin: p2r(5) p2r(10) p2r(5) 0;
          @include borderRadius(p2r(4));
          float: left;
        }
        .span-price {
          position: absolute;
          left: 0;
          bottom: 0;
          line-height: p2r(40);
          &:before {
            content: '￥';
            font-size: p2r(24);
          }
          &:after {
            content: '起';
            @include sc(p2r(24), $fc);
          }
          @include sc(p2r(40), $fc3);
        }

        .span-price-commodity {
          &:after {
            content: '';
          }
        }

        .span-num {
          position: absolute;
          right: 0;
          bottom: 0;
          @include sc(p2r(24), $fc);
        }
      }
    }
  }

  .loading-text {
    width: 100%;
    text-align: center;
    @include sc(p2r(28), $fc);
    line-height: 2;
  }
</style>
