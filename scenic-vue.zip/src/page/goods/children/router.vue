<template>
  <div class="ui-body ui-white-bg"></div>
</template>

<script>
  export default {
    created(){
      let action = this.$route.query.action;
      let id = this.$route.query.id;
      if (action && id) {
        this.$router.replace({path: action, query: {id: id}});
      }
    },
  }
</script>
