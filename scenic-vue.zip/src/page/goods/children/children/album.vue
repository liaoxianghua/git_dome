<template>
  <div class="ui-body ui-padding-header ui-gray-bg album-body">
    <head-top :headTitle="headTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <nav class="nav-tab"><span class="nav-a" :class="{'nav-active':tabIndex===0}" @click="changeTabIndex(0)">官方图片</span><span
      class="nav-a" :class="{'nav-active':tabIndex===1}" @click="changeTabIndex(1)">网友晒图</span></nav>
    <div class="ui-container" v-show="showPage">
      <ul class="album-list" v-for="(arr,i) in listArr" v-show="tabIndex === i">
        <template v-if="arr.length">
          <li v-for="item in arr" @click="changeSlideImg(i === 0?item.officialImg:item.onlineImg)"><img
            v-lazy="i === 0?item.officialImg:item.onlineImg"></li>
        </template>
        <template v-else>
          <li class="empty">暂无图片</li>
        </template>
      </ul>
    </div>
    <album :picUrl="slideImg" @closeAlbum="changeSlideImg('')"></album>
  </div>
</template>

<script>
  import album from 'src/components/common/album'
  import {goodsAlbum} from 'src/service/getData'
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {
        productId: 0,//产品ID
        tabIndex: 0, //tab序号
        headTitle: '产品相册',
        listArr: [],
        showPage: false, //显示页面内容
        slideImg: null,
      }
    },
    filters: {
      elsName: function (name) {
        return name;
      },
    },
    created(){
      if (this.$route.query.id) this.productId = parseInt(this.$route.query.id);
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
      album
    },
    computed: {},
    methods: {
      initData: async function () {
        this.showPage = false;
        let res = await goodsAlbum(this.productId);
        if (res.status !== 200) {
          return;
        }
        this.listArr.push(res.obj.officialImgList);
        this.listArr.push(res.obj.onlineImgList);

        this.showPage = true;
      },
      changeTabIndex: function (val) {
        this.tabIndex = val;
      },
      changeSlideImg: function (val) {
        this.slideImg = val;
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .album-body {
    z-index: 2;
  }

  .nav-tab {
    @include cl;
    position: absolute;
    top: p2r(14);
    @include wh(p2r(360), p2r(54));
    overflow: hidden;
    box-sizing: content-box;
    background-color: $blue;
    border: p2r(2) solid $bgc2;
    @include borderRadius(p2r(8));
    .nav-a {
      display: block;
      @include sc(p2r(30), $fc2);
      @include wh(p2r(180), p2r(54));
      line-height: p2r(54);
      text-align: center;
      float: left;
    }
    .nav-active {
      color: $blue;
      background-color: $bgc2;
    }
  }

  .album-list {
    padding: p2r(12);
    overflow: hidden;
    li {
      float: left;
      @include wh(p2r(296), p2r(226));
      position: relative;
      overflow: hidden;
      margin: p2r(6);
      background-color: $bgc2;
      border: p2r(6) solid $bgc2;
      img {
        @include center;
        width: 100%;
      }
    }
    .empty {
      margin: p2r(64) 0;
      width: 100%;
      text-align: center;
      @include sc(p2r(32), $fc);
      background: none;
      border: none;
    }
  }
</style>
