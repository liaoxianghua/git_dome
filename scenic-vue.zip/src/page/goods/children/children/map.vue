<template>
  <div class="ui-body page-body">
    <template v-if="takeAddress">
      <iframe :src="'http://map.baidu.com/mobile/webapp/place/list/qt=s&vt=map&showall=1&wd='+takeAddress"
              frameborder="0" class="map-frame"></iframe>
    </template>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        takeAddress: null,
      }
    },
    created(){
      let takeAddress = this.$route.query.takeAddress;
      if (takeAddress) {
        this.takeAddress = takeAddress;
      }
    },
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .page-body{
    z-index: 2;
  }

  .map-frame {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
  }
</style>
