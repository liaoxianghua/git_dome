<template>
  <div class="ui-body page-padding option-body">
    <div class="ui-container page-container">
      <section class="goods-option-wrap">
        <div class="goods-info">
          <div class="btn-back" @click="$router.go(-1)"><i class="icon iconfont icon-close"></i></div>
          <div class="goods-thum"><img v-lazy="productCover" class="img-thum"></div>
          <div class="goods-title"><span>{{productTitle}}</span></div>
        </div>
        <div class="select-wrap">
          <div class="goods-combo">
            <div class="title">产品类型</div>
            <ul class="list">
              <li v-for="item in combo">
                <a @click.prevent="selectCombo(item.id)" class="a-combo"
                   :class="[selectedComboId == item.id ? 'a-active' : '']">{{item.mealsName}}</a>
              </li>
            </ul>
          </div>
          <div class="goods-date" v-if="selectedComboId">
            <div class="title">
              <span>选择日期</span>
              <div class="calendar-btn"><i class="i-icon i-back" @click="changeMonth(-1)"></i><span
                class="span-value">{{year}}年{{month}}月</span><i
                class="i-icon i-next" v-on:click="changeMonth(1)"></i></div>
            </div>
            <div class="select">
              <div class="calendar-wrap">
                <ul class="calendar-week">
                  <li>日</li>
                  <li>一</li>
                  <li>二</li>
                  <li>三</li>
                  <li>四</li>
                  <li>五</li>
                  <li>六</li>
                </ul>
                <ul class="calendar-list">
                  <li v-for="day in days">
                    <div v-if="day.rep" v-bind:class="[day.num == selectedDay?'active':'']"
                         v-on:click="changeSelectedDay(day.num)">
                      <span class="span-rep">{{day.rep}}件</span>
                      <span class="span-num span-mc">{{day.num}}</span>
                      <span class="span-pri">{{day.pri}}</span>
                    </div>
                    <div v-else>
                      <span class="span-num">{{day.num}}</span>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="number-wrap">
            <div class="number-select">
              <div class="title">购买数量</div>
              <span class="span-btn span-minus" v-on:click="changeTotalNum(-1)"><i
                class="i-icon i-minus"></i></span><span
              class="span-value" @click="inputTotalNum()">{{totalNum}}</span><span class="span-btn span-add"
                                                                                   v-on:click="changeTotalNum(1)"><i
              class="i-icon i-add"></i></span>
            </div>
          </div>
        </div>
        <div content="goods-path"></div>
      </section>
    </div>
    <div class="option-footer" ref="footer">
      <div class="total"><span class="span-title">总额：</span><span class="span-num">{{total}}</span></div>
      <div class="btn" @click="confirmOrder">
        <span class="a-sub">立即购买</span>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapState, mapMutations} from 'vuex'
  import {goodsDetails, goodsCombo} from 'src/service/getData'

  export default {
    data(){
      return {
        id: null,//产品ID
        productTitle: '',//产品名称
        productCover: '',//产品封面
        combo: [],//套餐
        isSale: true,//是否售卖
        selectedComboId: 0,//套餐
        selectedStockId: 0,//库存ID
        selectedDay: 0,//出行日期
        year: null,
        month: null,
        day: null,
        week: null,
        days: [],
        repertory: [],//当前套餐月份库存
        total: 0,
        totalNum: 0,//出行人数
        price: 0,//单价
        minCount: 1,//最小购买数量
        maxCount: -1,//最大购买数量
        lastOrderDay: 0,//预定截止天数
        lastOrderTime: 1,//预定截止时间
      }
    },
    filters: {
      numberFormat: function (number) {
        if (number >= 10000) {
          if (number % 10000 === 0) {
            return (number / 10000) + '万';
          }
          else {
            return (number / 10000).toFixed(1) + '万';
          }
        }
        else {
          return number;
        }
      }
    },
    created(){
      if (this.$route.query.id) this.id = this.$route.query.id;
      /*this.$refs.footer.addEventListener('touchmove', function (e) {
       e.preventDefault();
       });*/
    },
    mounted(){
      this.init();
      this.initData();
    },
    components: {},
    computed: {
      ...mapState([
        'userMeal'
      ]),
    },
    methods: {
      ...mapMutations([
        'SAVE_MEAL',
      ]),
      init: function () {
        let mDate = new Date();
        this.year = mDate.getFullYear();
        this.month = mDate.getMonth() + 1;
        this.day = mDate.getDate();
      },
      initData: async function () {
        if (!this.id) {
          return;
        }

        let res = await goodsDetails(this.id);
        if (res.status !== 200) {
          return;
        }

        this.isSale = res.obj.product.isSale;
        this.minCount = res.obj.product.minCount;
        this.maxCount = res.obj.product.maxCount;
        this.lastOrderDay = res.obj.product.lastOrderDay;
        this.lastOrderTime = res.obj.product.lastOrderTime;
        this.combo = res.obj.product.productMeals;
        this.productTitle = res.obj.product.productName;
        this.productCover = res.obj.product.mainPic;

        //默认购买数量为最小购买数量
        if (this.minCount > 0) {
          this.changeTotalNum(this.minCount);
        }

        //恢复套餐选择状态
        if (this.userMeal.productId === this.id) {
          this.selectedComboId = this.userMeal.mealsId;
          this.selectedStockId = this.userMeal.stockId;
          this.selectedDay = this.userMeal.selectedDay;
          this.year = this.userMeal.year;
          this.month = this.userMeal.month;
          this.total = this.userMeal.total;
          this.totalNum = this.userMeal.totalNum;
          this.price = this.userMeal.price;
        }
        //默认选择第一个套餐
        if (this.combo.length && this.selectedComboId === 0) {
          this.selectCombo(this.combo[0].id);
        }
        else {
          this.initCalendar();
        }
      },
      initCalendar: async function () {
        //获取库存数据
        let res = await goodsCombo(this.selectedComboId, this.reFormatDate());
        let repertory = [];
        if (res.status === 200) {
          if (res.obj.listStock.length) {
            res.obj.listStock.forEach(function (value, i) {
              let day = new Date(value.playDay).getDate();
              repertory[i + 1] = {
                num: day,
                rep: value.totalNum,
                pri: value.price,
                id: value.id
              };
            });
          }
        }
        this.repertory = repertory;
        this.createCalendar();
      },
      createCalendar: function () {
        let days = [];
        let firstDayWeek = this.getMonthFirstWeek(this.year, this.month);
        for (let i = 0; i < firstDayWeek; i++) {
          days.push({num: '', rep: 0, pri: 0, id: 0});
        }
        this.repertory.forEach(function (val) {
          days.push(val);
        });
        this.days = days;
      },
      changeMonth: function (n) {
        n = parseInt(n);
        let mData = new Date();
        //阻止当月以前的日历展示
        if (this.month + n < mData.getMonth() + 1 && this.year <= mData.getFullYear()) {
          this.Toast({'message': '不能选择当月以前的月份', 'position': 'bottom'});
          this.month = mData.getMonth() + 1;
          this.year = mData.getFullYear();
          return;
        }
        if (this.month + n <= 12 && this.month + n > 0) {
          this.month += n;
        }
        else {
          this.year += (n > 0 ? 1 : -1);
          this.month += n;
          this.month -= (n > 0 ? 12 : -12);
        }

        //选择月份初始化数据
        this.total = 0;
        this.selectedDay = 0;
        this.selectedStockId = 0;
        this.price = 0;

        this.initCalendar();
      },
      changeSelectedDay: function (i) {
        this.selectedDay = i;
        this.price = this.repertory[i].pri;
        this.selectedStockId = this.repertory[i].id;

        //选择日期初始化数据
        this.total = 0;

        this.calculateTotal();
        this.saveMeal();
      },
      getMonthLastDay: function (y, m) {
        return new Date(new Date(y, m, 1).getTime() - 1000 * 60 * 60 * 24).getDate();
      },
      getMonthFirstWeek: function (y, m) {
        return new Date(y, m, 1).getDay();
      },
      reFormatDate: function () {
        let month = this.month;
        return this.year.toString() + (month < 10 ? '0' + month.toString() : month.toString())
      },
      selectCombo: function (i) {
        this.selectedComboId = i;
        this.initCalendar();

        //选择月份初始化数据
        this.total = 0;
        this.selectedDay = 0;
        this.selectedStockId = 0;
        this.price = 0;

        this.saveMeal();
      },
      changeTotalNum: function (n) {
        this.totalNum += parseInt(n);
        if (this.totalNum < 0) this.totalNum = 0;
        this.calculateTotal();
      },
      calculateTotal: function () {
        this.total = parseFloat(this.price) * parseInt(this.totalNum);
        if (this.total) this.total = this.total.toFixed(2);
        this.saveMeal();
      },
      inputTotalNum: async function () {
        let res = await this.messageBox.prompt('请输入大于0的数字', '购买数量');
        if (isNaN(res.value) || res.value <= 0) {
          this.Toast({message: '请输入大于0的数字', position: 'bottom'});
          return;
        }
        this.totalNum = 0;
        this.changeTotalNum(res.value);
      },
      calculateLastDay: function (day) {
        let date = new Date();
        let monthLastDay = this.getMonthLastDay();
        let nowHours = date.getHours();
        if (nowHours < this.lastOrderTime) {
          day -= 1;
        }

        if (day + this.lastOrderDay > monthLastDay) {
          day = monthLastDay;
          //过月重置lastOrderDay
          this.lastOrderDay -= (monthLastDay - day);
        }
        else {
          day += this.lastOrderDay;
        }
        return day;
      },
      saveMeal: function () {
        //套餐数据保存进VUEX
        this.SAVE_MEAL({
          productId: this.id,
          mealsId: this.selectedComboId,
          stockId: this.selectedStockId,
          totalNum: this.totalNum,
          adultNum: 0,
          childNum: 0,
          total: this.total,
          price: this.price,
          selectedDay: this.selectedDay,
          year: this.year,
          month: this.month,
        });
      },
      confirmOrder: function () {
        if (!this.selectedComboId) {
          this.Toast({message: '请选择套餐', position: 'bottom'});
          return;
        }
        if (!this.selectedDay) {
          this.Toast({message: '请选择日期', position: 'bottom'});
          return;
        }
        if (!this.totalNum) {
          this.Toast({message: '请选择购买数量', position: 'bottom'});
          return;
        }
        if (this.totalNum < this.minCount && this.minCount !== -1) {
          this.Toast({message: '购买数量不足' + this.minCount + ',请修改您的购买数量', position: 'bottom'});
          return;
        }
        if (this.totalNum > this.maxCount && this.maxCount !== -1) {
          this.Toast({message: '购买数量最多为' + this.maxCount + ',请修改您的购买数量', position: 'bottom'});
          return;
        }
        if (this.totalNum > this.repertory[this.selectedDay].rep) {
          this.Toast({message: '库存不足了，请修改您的购买数量', position: 'bottom'});
          return;
        }

        let date = new Date(this.year, this.month - 1, this.selectedDay).getTime();
        this.$router.replace({
          path: '/confirmOrder', query: {
            productId: this.id,
            mealsId: this.selectedComboId,
            stockId: this.selectedStockId,
            date: date,
            totalNum: this.totalNum
          }
        })
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .option-body {
    z-index: 2;
    background-color: rgba(0, 0, 0, 0.7);
    padding-bottom: p2r(98);
  }

  .page-container {
    position: relative;
  }

  .btn-back {
    position: absolute;
    right: p2r(10);
    top: 0;
    .icon {
      @include sc(p2r(24), $mc);
      border: 1px solid $mc;
      display: inline-block;
      @include borderRadius(p2r(20));
      @include wh(p2r(40), p2r(40));
      line-height: p2r(40);
      text-align: center;
    }
  }

  .goods-option-wrap {
    @include wh(100%, 100%);
    position: absolute;
    left: 0;
    bottom: 0;
  }

  .goods-info {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 70%;
    background-color: $bgc2;
  }

  .select-wrap {
    height: 70%;
    overflow: scroll;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: $bgc2;
  }

  .goods-path {
    @include wh(100%, p2r(98));
    overflow: hidden;
  }

  .goods-thum {
    border: p2r(4) solid #fff;
    @include borderRadius(p2r(12));
    position: absolute;
    left: p2r(20);
    top: p2r(-72);
    float: left;
    overflow: hidden;
    .img-thum {
      @include wh(p2r(200), p2r(200));
    }
  }

  .goods-title {
    padding: p2r(8) p2r(60) p2r(32) p2r(240);
    @include sc(p2r(26), $mc);
    line-height: 1.4;
    min-height: p2r(160);
    border-bottom: 1px solid $bc;
    span {
      word-break: break-all;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }

  .goods-combo {
    width: 100%;
    background-color: $bgc2;
    overflow: hidden;
    box-sizing: border-box;
    padding: 0 p2r(20);
    .title {
      line-height: p2r(64);
      @include sc(p2r(28), $mc);
    }
    .list {
      text-align: center;
      /*@include fj(flex-start);
      flex-wrap: wrap;*/
      padding-bottom: p2r(8);
      li {
        float: left;
        margin-bottom: p2r(10);
        margin-right: p2r(10);
        .a-combo {
          display: inline-block;
          padding: 0 p2r(22);
          margin-right: p2r(22);
          line-height: p2r(50);
          @include sc(p2r(24), $mc);
          background-color: $bgc;
          @include borderRadius(p2r(18))
        }
        .a-active {
          background-color: $blue;
          color: $fc2;
        }
      }
    }
  }

  .goods-date {
    overflow: hidden;
    border-top: 1px solid $bc;
    .title {
      line-height: p2r(70);
      @include sc(p2r(28), $mc);
      padding: 0 p2r(20);
    }
    .select {
      img {
        width: 100%;
      }
    }
  }

  .option-footer {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    @include wh(100%, p2r(98));
    background-color: $bgc2;
    border-top: 1px solid $bc;
    @include fj();
    text-align: center;
    line-height: p2r(98);
    .total {
      flex: 1;
      @include sc(p2r(26), $mc);
      .span-num {
        @include sc(p2r(34), $fc3);
        &:before {
          content: '￥';
          font-size: p2r(24);
        }
      }
    }
    .btn {
      @include wh(p2r(200), auto);
      background-color: #6ba4f5;
      height: p2r(98);
      @include sc(p2r(32), $fc2);
      .icon {
        @include sc(p2r(28), $fc2);
      }
      .a-sub {
        @include sc(p2r(32), $fc2);
      }
    }
  }

  .calendar-btn {
    float: right;
    @include sc(p2r(26), $mc);
    line-height: p2r(70);
    .span-value {
      margin: 0 p2r(24);
    }
    .i-icon {
      font-family: "iconfont" !important;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      @include sc(p2r(26), $blue);
      display: inline-block;
    }
    .i-back {
      &:before {
        content: "\E679";
      }
    }
    .i-next {
      &:before {
        content: "\E6A3";
      }
    }
  }

  .calendar-wrap {
    width: 100%;
    overflow: hidden;
    .calendar-week {
      border-top: 1px solid $bc;
      border-bottom: 1px solid $bc;
      background-color: #fdfdfd;
      line-height: p2r(50);
      padding: 0 p2r(12);
      @include fj();
      @include sc(p2r(24), $mc);
      li {
        flex: 1;
        text-align: center;
      }
    }
    .calendar-list {
      align-items: center;
      overflow: hidden;
      li {
        width: 14.285%;
        height: p2r(108);
        float: left;
        text-align: center;
        line-height: 1.2;
        padding: p2r(2) 0;
        overflow: hidden;
        span {
          display: block;
          width: 100%;
        }
        .span-num {
          @include sc(p2r(30), $fc);
          line-height: p2r(106);
        }
        .span-mc {
          @include sc(p2r(26), $mc);
          line-height: p2r(40);
        }
        .span-rep {
          padding-top: p2r(6);
          @include sc(p2r(24), $fc);
        }
        .span-pri {
          @include sc(p2r(24), $fc3);
          letter-spacing: -1px;
          padding-bottom: p2r(6);
          &:before {
            content: '￥';
          }
        }
      }
      .active {
        background-color: $blue;
        color: $fc2;
        .span-num {
          color: $fc2;
        }
        .span-rep {
          color: $fc2;
        }
        .span-pri {
          color: $fc2;
        }
      }
    }
  }

  .number-wrap {
    .number-select {
      border-top: 1px solid $bc;
      padding: p2r(28) p2r(24);
      text-align: right;
      position: relative;
      height: p2r(60);
      overflow: hidden;
      box-sizing: content-box;
      .title {
        @include ct;
        left: p2r(24);
        @include sc(p2r(28), $mc);
        line-height: 1;
        letter-spacing: 0;
        .span-pri {
          @include sc(p2r(20), $fc);
          &:before {
            content: '￥';
          }
          &:after {
            content: '/人';
          }
        }
      }
      span {
        display: inline-block;
        overflow: hidden;
      }
      .span-value {
        border: 1px solid #aaa;
        @include wh(p2r(80), p2r(60));
        line-height: p2r(60);
        @include sc(p2r(26), $mc);
        text-align: center;
      }
      .span-value-active {
        background-color: $blue;
        color: $fc2;
      }
      .span-btn {
        border: 1px solid $bc;
        line-height: p2r(52);
        @include wh(p2r(60), p2r(60));
        text-align: center;
        box-sizing: border-box;
      }
      .span-add {
        border-left: none;
      }
      .span-minus {
        border-right: none;
      }
      .i-icon {
        font-family: "iconfont" !important;
        font-style: normal;
        -webkit-font-smoothing: antialiased;
        @include sc(p2r(32), $fc);
        display: inline-block;
      }
      .i-add {
        &:before {
          content: "\E767";
        }
      }
      .i-minus {
        &:before {
          content: "\E768";
        }
      }
    }
  }
</style>
