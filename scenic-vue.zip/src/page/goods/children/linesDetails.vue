<template>
  <div class="ui-body ui-padding-footer ui-gray-bg">
    <header class="goods-header">
      <div class="icon-l"><i class="icon iconfont icon-back" v-on:click=$router.go(-1)></i></div>
      <!--<div class="icon-r"><i class="icon iconfont icon-share"></i></div>-->
      <div class="icon-r"><i class="icon iconfont" :class="[isCollection?'icon-likefill':'icon-like']"
                             @click="collectionEdit"></i></div>
    </header>
    <div class="ui-container">
      <div class="container-wrap">
        <div class="goods-thums" v-if="pics.length">
          <swiper :options="swiperOptions" ref="swiper" class="list">
            <template v-for="(item,key) in pics" v-if="item.fileUrl">
              <swiper-slide>
                <router-link :to="{path:'linesDetails/album',query:{id:id}}"><img v-lazy="item.fileUrl"
                                                                                  :alt="item.picName"></router-link>
              </swiper-slide>
            </template>
          </swiper>
          <div class="info">产品编号：{{code}}<span class="span-num" ref="idx">{{slideIndex}}/{{pics.length}}</span></div>
        </div>
        <section class="goods-info">
          <div class="title">{{title}}</div>
          <ul class="keys" v-if="keywords">
            <li v-for="item in keywords"><span class="span-key" v-if="item.name">{{item.name}}</span></li>
          </ul>
          <ul class="price">
            <li><span class="span-price">{{price}}</span></li>
            <li><i class="icon iconfont icon-attention"></i><span class="span-num">{{viewNum}}</span></li>
          </ul>
          <div class="rec"><span class="span-gray">经理推荐：</span><span v-html="recommendText"></span></div>
        </section>
        <section class="goods-combo" v-if="allowBuy">
          <router-link :to="{path:'linesDetails/option',query:{id:id}}">
            <span class="span-v ellipsis">选择：套餐类型/日期/人数</span>
            <i class="icon iconfont icon-right"></i>
          </router-link>
        </section>
        <section class="goods-plate goods-details">
          <div class="title"><i class="icon"></i>产品特色</div>
          <div class="view" v-html="remarkText"></div>
        </section>
        <section class="goods-plate goods-traffic">
          <div class="title"><i class="icon"></i>交通信息</div>
          <div class="view" v-html="trafficText"></div>
        </section>
        <section class="goods-plate goods-comment">
          <div class="title"><i class="icon"></i>用户评价</div>
          <ul class="list" v-if="comment.length">
            <li v-for="item in comment">
              <span class="span-name">{{item.memberBasic.memberAccount | elsName}}</span>
              <span class="span-time ellipsis">{{item.createTime | formatDate}}</span>
              <p class="p-star">
                <i class="icon iconfont" :class="[item.gread>0?'icon-favorfill':'icon-favor']"></i><i
                class="icon iconfont"
                :class="[item.gread>1?'icon-favorfill':'icon-favor']"></i><i
                class="icon iconfont" :class="[item.gread>2?'icon-favorfill':'icon-favor']"></i><i class="icon iconfont"
                                                                                                   :class="[item.gread>3?'icon-favorfill':'icon-favor']"></i><i
                class="icon iconfont" :class="[item.gread>4?'icon-favorfill':'icon-favor']"></i>
                <span class="span-score">{{item.gread}}</span>
              </p>
              <p class="p-cont">{{item.content}}</p>
              <div class="img-list" v-if="item.productcommentfile.length">
                <img v-for="v in item.productcommentfile" v-lazy="v.fileUrl" :alt="v.fileName"
                     @click="slideImg = v.fileUrl">
              </div>
              <div class="replay" v-if="item.sellerComtent">
                <i class="i-say"></i>
                <p>商家回复：{{item.sellerComtent}}</p>
              </div>
              <div class="favour">
                <favour :item="item"></favour>
              </div>
            </li>
          </ul>
          <ul class="list" v-else>
            <li><span class="span-empty">暂无评价</span></li>
          </ul>
          <div class="btn" v-if="comment.length">
            <router-link :to="{path:'linesDetails/comment',query:{id:id}}"><span class="span-btn">查看全部评价</span>
            </router-link>
          </div>
        </section>
        <template v-if="productRecommend.length">
          <div class="correlation-title"><i class="i-cx"></i><span class="span-title">大家还在看</span></div>
          <section class="goods-list">
            <div class="item" v-for="item in productRecommend">
              <router-link :to="{path:'router',query:{action:'linesDetails',id:item.id}}" replace tag="div">
                <div class="thum">
                  <img v-lazy="item.mainPic" class="img-thum" :alt="item.productName">
                  <span
                    class="span-tips ellipsis">{{item.productType | typeText(item.productSubType, typeArr)}}</span>
                  <span class="span-location ellipsis"><i
                    class="icon iconfont icon-locationfill"></i>{{item.cityName}}</span>
                </div>
                <div class="font">
                  <span class="span-title">{{item.productName}}</span>
                  <template v-for="v in item.listKeyword">
                    <i class="i-tips">{{v.name}}</i>
                  </template>
                  <span class="span-price-commodity">{{item.price}}</span>
                  <span class="span-num">{{item.saledNum}}人购买</span>
                </div>
              </router-link>
            </div>
          </section>
        </template>
      </div>
    </div>
    <footer class="goods-footer">
      <router-link :to="{path:'linesDetails/option',query:{id:id}}" class="buy" tag="div" v-if="allowBuy">立即预定 <i
        class="icon iconfont icon-right"></i></router-link>
      <div class="buy disable" v-else>立即预定 <i class="icon iconfont icon-right"></i></div>
    </footer>
    <album :picUrl="slideImg" @closeAlbum="slideImg = null"></album>
    <transition name="router-slidT" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import album from 'src/components/common/album'
  import favour from 'src/components/common/goods/favour'
  import {goodsDetails, goodsTypes, collectionEdit} from 'src/service/getData'
  import {setStore, getStore, checkLogin, saveHistory} from 'src/config/mUtils'
  import {swiper, swiperSlide} from 'vue-awesome-swiper'
  import Swiper from "../../../../node_modules/vue-awesome-swiper/swiper";
  import SwiperSlide from "../../../../node_modules/vue-awesome-swiper/slide";

  export default {
    data(){
      let _this = this;
      return {
        cityName: null,
        id: null, //产品ID
        code: 0, //产品编号
        title: null, //产品名称
        keywords: null, //产品关键字
        price: 0, //价格
        viewNum: 0, //点击数
        recommendText: null, //经理推荐
        remarkText: null, //产品特色
        trafficText: null, //交通信息
        comment: {}, //用户评价
        commentNum: 0, //用户评论显示
        pics: [], //图集
        isCollection: 0,//是否收藏
        isSale: true, //是否售卖
        allowBuy: false,//允许购买
        typeArr: [],//分类数据
        productRecommend: [],//推荐产品
        showLoading: false, //显示加载动画
        preventRepeatRequest: false, //阻止重复请求
        slideImg: null,
        slideIndex: 1,
        swiperOptions: {
          autoplay: 3000,
          onSlideChangeStart: function (swiper) {
            _this.slideIndex = swiper.activeIndex + 1;
          }
        }
      }
    },
    created(){
      if (getStore('cityName')) {
        this.cityName = getStore('cityName');
      }
    },
    mounted(){
      this.init();
    },
    filters: {
      elsName: function (name) {
        let length = name.length;
        if (length != 11) {
          return '***' + name.substr(3, length);
        }
        else {
          return name.substr(0, 3) + '****' + name.substr(7, length);
        }
      },
      typeText: function (type, subType, typeArr) {
        let res;
        typeArr.forEach((val) => {
          if (val.productType === type && val.productSubType === subType) {
            return res = val.productSubTypeName;
          }
        });
        return res;
      },
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },
    },
    components: {SwiperSlide, Swiper, album, favour},
    computed: {},
    methods: {
      init: async function () {
        let res = await goodsTypes();
        this.typeArr = res.obj.productCategorys;
        this.initData();
      },
      initData: async function () {
        if (this.$route.query.id) this.id = this.$route.query.id;
        this.showLoading = true;

        let res = await goodsDetails(this.id, this.cityName);

        //页面错误返回上一页
        if (res.status === 601 || res.status === 602 || res.status === 603) {
          await this.messageBox.alert(res.message);
          this.$router.go(-1);
        }
        if (res.status !== 200) {
          return;
        }

        let info = res.obj.product;

        this.code = info.id;
        this.title = info.productName;
        this.keywords = info.listKeyword;
        this.price = info.price;
        this.viewNum = info.readCount;
        this.recommendText = info.recommend;
        this.remarkText = info.remark;
        this.trafficText = info.traffic;
        this.comment = info.listProductComment;
        this.commentNum = info.listProductComment.length ? 1 : 0;
        this.isSale = info.isSale;
        this.pics = info.productPics;
        this.productRecommend = info.recommendProducts;
        this.isCollection = info.collected;
        //没有套餐购买按钮变灰if (info.totalNum - info.saleNum < 1 ) {
        if (info.productMeals.length == 0 || info.isSale == 0) {
          this.allowBuy = false;
        }
        else {
          this.allowBuy = true;
        }
        this.showLoading = false;

        //保存浏览历史
        if (this.id) saveHistory(this.id);
      },
      collectionEdit: async function () {
        if (!checkLogin()) {
          this.$router.replace({path: '/login', query: {redirect: this.$route.fullPath}});
          return;
        }
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        let res = await collectionEdit(1, this.id, this.isCollection ? 0 : 1);
        if (res.status === 200) {
          this.Toast({message: res.message, position: 'bottom'});
          this.isCollection = this.isCollection ? 0 : 1;
        }
        this.preventRepeatRequest = false;
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  .goods-header {
    position: absolute;
    overflow: hidden;
    padding: p2r(15) p2r(30);
    left: 0;
    right: 0;
    top: 0;
    z-index: 2;
    .icon-l {
      float: left;
    }
    .icon-r {
      float: right;
      margin-left: p2r(20);
    }
    .icon {
      @include wh(p2r(50), p2r(50));
      @include borderRadius(p2r(25));
      background-color: rgba(0, 0, 0, 0.4);
      @include sc(p2r(30), $fc2);
      line-height: p2r(50);
      text-align: center;
      display: inline-block;
    }

  }

  .goods-thums {
    position: relative;
    .list {
      @include wh(100%, p2r(348));
      img {
        width: 100%;
        height: 100%;
      }
    }
    .info {
      position: absolute;
      left: 0;
      bottom: 0;
      @include wh(100%, p2r(46));
      line-height: p2r(46);
      background-color: rgba(0, 0, 0, 0.4);
      @include sc(p2r(24), $fc2);
      padding: 0 p2r(20);
      z-index: 1;
      .span-num {
        @include ct;
        right: p2r(12);
        @include sc(p2r(24), $fc2);
      }
    }
  }

  .goods-info {
    @include bmb;
    padding: p2r(12) p2r(24);
    .title {
      @include sc(p2r(30), $mc);
      line-height: 1.4;
    }
    .keys {
      /*@include fj(flex-start);
      flex-wrap: wrap;*/
      padding-top: p2r(12);
      overflow: hidden;
      li {
        float: left;
      }
      .span-key {
        display: block;
        border: 1px solid $blue;
        @include sc(p2r(24), $blue);
        padding: 0 p2r(15);
        @include borderRadius(p2r(4));
        margin: p2r(5) p2r(10) p2r(5) 0;
      }
    }
    .price {
      margin: p2r(20) 0;
      margin-top: p2r(10);
      @include fj();
      align-items: baseline;
      .span-price {
        @include sc(p2r(38), $fc3);
        display: inline-block;
        &:before {
          content: '￥';
          font-size: p2r(24);
        }
        &:after {
          content: '起';
          font-size: p2r(24);
        }
      }
      .icon {
        @include sc(p2r(30), $fc);
      }
      .span-num {
        @include sc(p2r(24), $fc);
        margin-left: p2r(6);
      }
    }
    .rec {
      @include sc(p2r(24), $mc);
      .span-gray {
        color: $mc;
      }
    }
  }

  .goods-combo {
    @include bmb;
    padding: 0 p2r(24);
    @include sc(p2r(28), $mc);
    line-height: p2r(68);
    .span-v {
      display: block;
      width: p2r(560);
      float: left;
    }
    .icon {
      float: right;
      @include sc(p2r(24), $fc);
    }
  }

  .goods-plate {
    padding: 0 p2r(24) p2r(24) p2r(24);
    @include bmb;
    .title {
      @include sc(p2r(30), $mc);
      line-height: p2r(68);
      padding-left: p2r(18);
      position: relative;
      .icon {
        display: inline-block;
        @include wh(p2r(4), p2r(28));
        background-color: $fc3;
        @include ct;
        left: 0;
      }
    }
    .view {
      width: 100%;
      overflow: hidden;
      @include sc(p2r(24), $mc);
      img {
        width: 100%;
      }
    }
  }

  .goods-details {

  }

  .goods-comment {
    .list {
      overflow: hidden;
      li {
        position: relative;
        @include sc(p2r(24), $mc);
        .span-name {
          display: block;
          width: p2r(400);
        }
        .span-time {
          position: absolute;
          right: 0;
          top: 0;
        }
        .p-star {
          @include wh(100%, p2r(44));
          margin-top: p2r(12);
          overflow: hidden;
          line-height: p2r(44);
          .icon {
            @include sc(p2r(24), $fc3);
            margin-right: p2r(4);
          }
          .span-score {
            @include sc(p2r(24), $fc3);
            &:after {
              content: '分';
            }
          }
        }
        .span-empty {
          text-align: center;
          display: inline-block;
          width: 100%;
        }
        .p-cont {
          margin: p2r(12) 0;
        }
        .img-list {
          //overflow: auto;
          overflow: hidden;
          //white-space: nowrap;
          margin-bottom: p2r(12);
          height: p2r(120);
          & > img {
            height: p2r(120);
            margin-right: p2r(12);
          }
        }
        .replay {
          position: relative;
          background-color: #edf4ff;
          @include borderRadius(p2r(12));
          @include sc(p2r(24), $mc);
          width: 100%;
          padding: p2r(16);
          margin: p2r(16) 0;
          .i-say {
            position: absolute;
            left: p2r(24);
            top: p2r(-8);
            width: 0;
            height: 0;
            border-left: p2r(6) solid transparent;
            border-right: p2r(6) solid transparent;
            border-bottom: p2r(8) solid #edf4ff;
          }
          p {
            margin: 0;
            line-height: p2r(30);
          }
        }
        .favour {
          position: absolute;
          right: 0;
          top: p2r(20);
          width: p2r(100);
        }
      }
    }
    .btn {
      text-align: center;
      margin: p2r(20);
      .span-btn {
        display: inline-block;
        @include wh(p2r(250), p2r(70));
        @include sc(p2r(30), $blue);
        line-height: p2r(70);
        border: 1px solid $blue;
        @include borderRadius(p2r(4))
      }
    }

  }

  .correlation-title {
    line-height: p2r(38);
    text-align: center;
    @include sc(p2r(26), $mc);
    margin-bottom: p2r(12);
    position: relative;
    .span-title {
      display: inline-block;
      background-color: $bgc;
      padding: 0 p2r(24);
    }
    .i-cx {
      display: inline-block;
      width: 90%;
      border-bottom: 1px solid $bc;
      @include center;
      z-index: -1;
    }
  }

  .goods-list {
    background-color: $bgc2;
    .item {
      border-bottom: 1px solid $bc;
      padding: p2r(18);
      & > div {
        @include fj(flex-start);
        align-items: flex-start;
      }
      .thum {
        position: relative;
        width: p2r(180);
        margin-right: p2r(20);
        .img-thum {
          @include wh(p2r(180), p2r(150));
        }
        .span-tips {
          display: block;
          @include wh(100%, p2r(40));
          @include sc(p2r(24), $mc);
          line-height: p2r(40);
          background-color: $bgc;
          text-align: center;
        }
        .span-location {
          max-width: 100%;
          display: block;
          position: absolute;
          top: 0;
          left: 0;
          @include sc(p2r(24), $fc2);
          line-height: p2r(30);
          padding: 0 p2r(12) 0 0;
          background-color: rgba(0, 0, 0, 0.4);
        }
        .icon {
          display: inline-block;
          @include borderRadius(p2r(28));
          @include sc(p2r(24), $fc2);
          margin: 0 p2r(4);
        }
      }
      .font {
        flex: 1;
        position: relative;
        padding-bottom: p2r(54);
        min-height: p2r(190);
        .span-title {
          display: inline-block;
          @include sc(p2r(28), $mc);
          line-height: p2r(32);
          min-height: p2r(64);
          margin-bottom: p2r(12);
          width: 100%;
        }
        .i-tips {
          display: block;
          @include sc(p2r(24), $blue);
          line-height: p2r(34);
          border: 1px solid $blue;
          padding: 0 p2r(12);
          margin: p2r(5) p2r(10) p2r(5) 0;
          @include borderRadius(p2r(4));
          float: left;
        }
        .span-price-commodity {
          position: absolute;
          left: 0;
          bottom: 0;
          line-height: p2r(40);
          @include sc(p2r(40), $fc3);
          &:before {
            content: '￥';
            font-size: p2r(24);
          }
          &:after {
            content: '起';
            @include sc(p2r(24), $fc);
          }
        }
        .span-num {
          position: absolute;
          right: 0;
          bottom: 0;
          @include sc(p2r(24), $fc);
        }
      }
    }
  }

  .goods-footer {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    @include wh(100%, p2r(98));
    background-color: $bgc2;
    border-top: 1px solid $bc;
    @include fj();
    text-align: center;
    line-height: p2r(98);
    .fav {
      @include wh(p2r(240), auto);
      @include sc(p2r(32), $mc);
      .icon {
        @include sc(p2r(40), $mc);
        margin-right: p2r(20);
      }
    }
    .fav-active {
      color: $fc3;
      .icon {
        color: $fc3;
      }
    }
    .buy {
      flex: 1;
      background-color: #6ba4f5;
      height: p2r(98);
      @include sc(p2r(32), $fc2);
      .icon {
        @include sc(p2r(28), $fc2);
      }
      a {
        @include sc(p2r(32), $fc2);
      }
    }
    .disable {
      background-color: $fc;
    }
  }
</style>
