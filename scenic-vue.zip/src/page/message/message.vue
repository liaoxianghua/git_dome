<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="消息">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <section class="message-menu">
        <ul class="menu-list-msg">
          <li>
            <router-link to="message/favour">
              <i class="icon-l iconfont icon-appreciate"></i>
              <i class="icon-r iconfont icon-right"></i>
              <div class="cont"><span class="span-title">赞</span></div>
            </router-link>
          </li>
          <li>
            <router-link to="message/comment">
              <i class="icon-l iconfont icon-mark"></i>
              <i class="icon-r iconfont icon-right"></i>
              <div class="cont"><span class="span-title">评论</span></div>
            </router-link>
          </li>
          <li>
            <router-link to="message/notice">
              <i class="icon-l iconfont icon-notice"></i>
              <i class="icon-r iconfont icon-right"></i>
              <div class="cont"><span class="span-title">系统通知</span></div>
            </router-link>
          </li>
        </ul>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'

  export default {
    data(){
      return {}
    },
    created(){
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {}
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .message-menu {

  }

  .menu-list-msg {
    @include bmb;
    width: 100%;
    overflow: hidden;
    li {
      padding-left: p2r(106);
      position: relative;
      box-sizing: border-box;
      width: 100%;
      .icon-l {
        display: inline-block;
        @include wh(p2r(56), p2r(56));
        @include borderRadius(p2r(28));
        @include ct;
        left: p2r(30);
        @include sc(p2r(32), $fc2);
        text-align: center;
        line-height: p2r(56);
      }
      .icon-r {
        display: inline-block;
        @include wh(p2r(56), p2r(56));
        @include ct;
        right: p2r(30);
        @include sc(p2r(32), $fc4);
        text-align: center;
        line-height: p2r(56);
      }
      .cont {
        width: 100%;
        border-bottom: 1px solid $bc;
        .span-title {
          line-height: p2r(120);
          @include sc(p2r(28), $mc);
        }
      }
      &:nth-child(n+1) {
        .icon-l {
          background-color: #ef9a9a;
        }
      }
      &:nth-child(n+2) {
        .icon-l {
          background-color: #ffcc80;
        }
      }
      &:nth-child(n+3) {
        .icon-l {
          background-color: #aed581;
        }
      }
      &:last-child {
        .cont {
          border-bottom: none;
        }
      }
    }
  }
</style>
