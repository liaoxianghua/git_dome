<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top v-bind:headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <div class="content-container">{{pageContent}}</div>
    </div>
  </div>
</template>

<script>
  import headTop from '../../../../components/header/head'
  import {messageNoticeDetails} from 'src/service/getData'

  export default {
    data(){
      return {
        pageTitle: null,
        pageContent: null,
        id: 0,
      }
    },
    created(){
      if (this.$route.query.id) this.id = this.$route.query.id;
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
    },
    methods: {
      initData: async function () {
        if (!this.id) {
          return;
        }

        let res = await messageNoticeDetails(this.id);
        if (res.status !== 200) {
          return;
        }

        this.pageTitle = res.obj.systemNoticeDetail.msgTitle;
        this.pageContent = res.obj.systemNoticeDetail.msgContent;
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .content-container {
    padding: p2r(24);
    @include sc(p2r(26), $mc);
    text-indent: p2r(52);
  }
</style>
