<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top headTitle="赞">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)" v-if="!showSelectItem"></div>
      <div slot="btn" class="btn-all btn-left btn-char" @click="changeShowSelectItem" v-if="showSelectItem">取消</div>
      <div slot="btn" class="btn-all btn-right btn-char" @click="changeShowSelectItem" v-show="!showSelectItem && listArr.length">多选</div>
      <div slot="btn" class="btn-all btn-right-1 btn-char" @click="changeAllSelectItem" v-show="showSelectItem">{{allSelectItemText}}</div>
      <div slot="btn" class="btn-all btn-right btn-char" @click="deleteAllMsgItem" v-show="showSelectItem">删除</div>
    </head-top>
    <div class="ui-container">
      <section class="message-menu">
        <ul class="menu-list-favour" v-if="listArr.length">
          <li v-for="item in listArr" @touchstart="touchStart($event,item.id)"
              @touchmove="setPreventRepeatRequest($event)"
              @touchend="touchEnd()">
            <img v-lazy="item.imageUrl" class="img-head"/>
            <div class="cont">
              <span class="span-zan"><span class="font-fc3 ellipsis">{{item.nameCh}}</span> 赞了你</span>
              <span class="span-time font-fc">{{item.nowTime}}</span>
              <span class="span-title font-fc ellipsis">{{item.title}}</span>
            </div>
            <div class="btn-delete" @click="selectItem(item.id)" v-show="showSelectItem"><span
              class="icon iconfont" :class="[item.selected?'icon-roundcheckfill':'icon-round']"></span></div>
          </li>
        </ul>
        <div class="empty-text" v-else>您还未收到点赞</div>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {messagePraiseList, messageDelete} from 'src/service/getData'
  import headTop from '../../../components/header/head'

  export default {
    data(){
      return {
        listArr: [],
        showSelectItem: false,
        allSelectItem: false,
        allSelectItemText: '全选',
        preventRepeatRequest: false, //阻止请求
        touchXY: {X: 0, Y: 0},
      }
    },
    created(){
    },
    mounted(){
      this.initData();
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {
      initData: async function () {
        let res = await messagePraiseList();
        if (res.status !== 200) {
          return;
        }
        let list = res.obj.memberPraiseList;
        list.forEach(item => {
          item.selected = 0;
          this.listArr.push(item);
        });
      },
      deleteMsgItem: async function (id) {
        if (!id) {
          return;
        }

        let res = await messageDelete(id.join(','), 1);
        if (res.status !== 200) {
          return;
        }

        for (let i = 0; i < id.length; i++) {
          for (let j = 0; j < this.listArr.length; j++) {
            if (this.listArr[j].id === id[i]) {
              this.listArr.splice(j, 1);
            }
          }
        }
      },
      deleteAllMsgItem: async function () {
        let msgIds = [];
        for (let i = 0; i < this.listArr.length; i++) {
          let item = this.listArr[i];
          if (item.selected) {
            msgIds.push(item.id);
          }
        }
        if(msgIds.length === 0){
          this.Toast({message: '至少选择一条消息', position: 'bottom'});
          return;
        }

        await this.messageBox.confirm('确认要删除选中消息？');
        this.showSelectItem = false;

        this.deleteMsgItem(msgIds);
      },
      setPreventRepeatRequest: function (e) {
        let el = e.touches[0];
        if (Math.abs(el.screenX - this.touchXY.X) > 20 || Math.abs(el.screenY - this.touchXY.Y) > 20) {
          this.preventRepeatReuqest = true;
        }
      },
      touchStart: function (e, id) {
        this.touchXY = {X: e.touches[0].screenX, Y: e.touches[0].screenY};
        this.preventRepeatReuqest = false;
        var msgId = id;
        setTimeout(async () => {
          if (!this.preventRepeatReuqest) {
            await this.messageBox.confirm('确认要删除这条消息？');
            this.deleteMsgItem([msgId]);
          }
        }, 1500);
      },
      touchEnd: function () {
        this.preventRepeatReuqest = true;
      },
      changeShowSelectItem: function () {
        this.showSelectItem = !this.showSelectItem;
      },
      selectItem: function (id) {
        for (let i = 0; i < this.listArr.length; i++) {
          if (this.listArr[i].id === id) {
            this.listArr[i].selected = this.listArr[i].selected ? 0 : 1;
          }
        }
      },
      changeAllSelectItem: function () {
        this.allSelectItem = !this.allSelectItem;
        this.allSelectItemText = this.allSelectItem ? '全不选' : '全选';
        for (let i = 0; i < this.listArr.length; i++) {
          this.listArr[i].selected = this.allSelectItem ? 1 : 0;
        }
      },
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  .empty-text {
    text-align: center;
    @include sc(p2r(28), $fc);
    margin: p2r(64) 0;
  }

  .message-menu {

  }

  .menu-list-favour {
    @include bmb;
    li {
      padding-left: p2r(120);
      position: relative;
      .cont {
        width: 100%;
        border-bottom: 1px solid $bc;
        line-height: 1.5;
        padding: p2r(24) 0;
        .span-zan {
          display: block;
          @include sc(p2r(26), $mc);
        }
        .span-time {
          display: block;
        }
        .span-title {
          display: block;
          @include ct;
          right: p2r(30);
          width: p2r(186);
        }
        .font-fc {
          @include sc(p2r(24), $fc);
        }
        .font-fc3 {
          color: $fc3;
          display: block;
          overflow: hidden;
          width: 36%;
          float: left;
        }
      }
      .img-head {
        @include wh(p2r(72), p2r(72));
        @include ct;
        left: p2r(30);
        @include borderRadius(p2r(36));
        background-color: #efefef;
      }
      .btn-delete {
        width: p2r(126);
        height: 99%;
        @include sc(p2r(26), $fc2);
        @include ct;
        right: 0;
        background-color: $bgc2;
        span {
          @include center;
          @include sc(p2r(46), $blue);
        }
      }
      &:last-child {
        .cont {
          border-bottom: none;
        }
      }
    }
  }
</style>
