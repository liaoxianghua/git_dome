<template>
  <div class="ui-body ui-padding-header ui-gray-bg" :class="{'ui-padding-b-comment':activeComment}">
    <head-top :headTitle='detailContent.type === 1 ? "游记详情" : "攻略详情"'>
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
      <div slot="btn" @click="collectionEdit" class="btn-all btn-right "
           :class="[detailContent.collected?'btn-fav-1':'btn-fav']"></div>
    </head-top>
    <div class="ui-container">
      <!--游记详情-->
      <section class="details-wrap">
        <list-title :titleText='detailContent.type === 1 ? "游记" : "攻略"'></list-title>
        <div class="item">
          <!--user-->
          <div class="user-info"><img v-lazy="detailContent.imageUrl" class="img-head">
            <span class="span-name">{{detailContent.name || "猴爸爸平台"}}</span>
          </div>
          <!--出行详情-->
          <ul class="notes-info">
            <li v-if="detailContent.departureDate">
              <i class="icon-time1"></i>
              <p>出行时间</p>
              <span class="ellipsis">{{detailContent.departureDate | formatDate}}</span>
            </li>
            <li v-if="detailContent.fee && detailContent.fee.replace(/\s+/g).length !==0">
              <i class="icon-money"></i>
              <p>人均消费</p>
              <span class="ellipsis">{{detailContent.fee | blankRemove }}</span>
            </li>
            <li v-if="detailContent.persons && detailContent.persons.replace(/\s+/g).length !==0">
              <i class="icon-like1"></i>
              <p>出行人群</p>
              <span class="ellipsis">{{detailContent.persons | blankRemove}}</span>
            </li>
            <li v-if="detailContent.days && detailContent.days.replace(/\s+/g).length !==0 ">
              <i class="icon-day"></i>
              <p>出行天数</p>
              <span class="ellipsis">{{detailContent.days | blankRemove}}</span>
            </li>
          </ul>
          <!--标题-->
          <h3 class="h3-travel-title">{{detailContent.title}}</h3>
          <!--游记内容-->
          <div class="details-content" v-for="(item,i) in detailContent.travelnotesdetailsList">
            <img v-if="item.url" v-lazy="item.url">
            <p v-else-if="item.words">
              {{item.words}}
          </p>
          </div>

          <!--控制组-->
          <ul class="notes-fav">
            <!--点赞-->
            <li class="ui-li">
            <span class="icon-all "
                  :class="[detailContent.praised?'span-fav-a':'span-fav']"
                  @click="travelPraise">
              {{detailContent.praiseCount || 0}}
            </span>
            </li>

            <!--评论-->
            <li class="ui-li">
            <span @click.self="Inputfocus" class="icon-all span-msg" v-if="login">
              {{detailContent.commentCount + commentNum || 0}}
            </span>
              <router-link :to="{path:'login',query:{redirect:$route.fullPath}}" tag="span" class="icon-all span-msg"
                           v-else>{{detailContent.commentCount + commentNum || 0}}



              </router-link>
            </li>

            <!--收藏-->
            <li class="ui-li">
            <span class="icon-all" :class="[detailContent.collected?'span-collect-a':'span-collect']"
                  @click="collectionEdit">
              {{detailContent.collectionCount}}
            </span>
            </li>

            <!--览量-->
            <li class="ui-li">
            <span class="icon-all span-view">
              {{detailContent.readCount || 0}}
            </span>
            </li>

            <!--时间-->
            <li class="time ui-li"><i class="i-text">{{detailContent.nowTime || 0 }}</i></li>

          </ul>
          <!--<like-group
            :item="detailContent"
            @click.self="Inputfocus"
          ></like-group>-->

        </div>
      </section>

      <!--评论-->
      <div class="comment-div">
        <p class="comment-title"><span>评论</span></p>
        <ul class="comment-list" v-show="commentdata.length">
          <li v-for="(comment,i) in commentdata.slice(0,pageSize)">
            <div class="img-box"><img v-lazy="comment.imageUrl" alt=""></div>
            <div class="comment-content">
              <p class="user-name"><span>{{comment.name ? comment.name : "猴爸爸旅行"}}</span><span
                class="time">{{comment.nowTime}}</span></p>
              <p class="comment-text">{{comment.comments}}</p>
            </div>
          </li>
        </ul>
        <a class="ui-more-comment" @click="moreComment($event)" v-show="commentdata.length>pageSize">查看更多...</a>
        <div class="no-hint" v-show="!commentdata.length">
          暂时没有评论....




        </div>
      </div>

      <!--相关推荐-->
      <section class="product-wrap " v-if="travelrecommend.length">
        <list-title titleText="相关推荐">
          <router-link :to="{path:'/goods'}" slot="more" class="more">更多</router-link>
        </list-title>
        <div class="item" v-for="(item,i) in travelrecommend">
          <router-link :to="{path:'/goods/'+reControllerName(item.productType),query:{id:item.id}}">
            <div class="thum"><img v-lazy="item.fileUrl" class="img-thum"></div>
            <div class="title">{{item.productName}}</div>
            <a class="a-city" href="#"> <i class="iconfont icon-shoucang"></i> {{item.name}} </a>
          </router-link>
          <div class="flex">
            <div :class="[item.productType===2?'price-1':'price']">{{item.minPrice}}</div>
            <div class="num">{{item.saleNum}}人<template v-if="item.productType===2">购买</template><template v-else>出游</template></div>
          </div>
        </div>
      </section>

      <!--输入框
      <div :class="[activeComment?'display-input-div':'undisplay-input-div']" class="input-div">
        <input ref="commentInput" type="text" placeholder="添加评论..." v-model="commentText">
        <a @click.prevent="getcommentData" >发送</a>
      </div>-->
    </div>
    <!--输入框-->
    <transition name="router-slid" mode="out-in">
      <div class="ui-body ui-padding ui-gray-bg comment-page" v-show="isOpenComment">
        <head-top headTitle="评论">
          <div slot="btn" class="btn-all btn-left btn-back" @click="isOpenComment = false"></div>
        </head-top>
        <div class="ui-container">
          <div class="input-wrap">
            <textarea ref="commentInput" type="text" placeholder="请写下您的评论" v-model="commentText"></textarea>
            <a @click.prevent="getcommentData">发送</a>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import listTitle from '../../components/common/travelblock/traveTitle'
  import alertTip from 'src/components/common/alertTip'
  import likeGroup from 'src/components/common/like'

  import {setStore, getStore, saveHistory, checkLogin} from 'src/config/mUtils'
  import {mapState, mapMutations} from 'vuex'

  import {
    homeTravelDetails,
    homeDetailsComment,
    homeDetailsCommentUP,
    Praise,
    collectionEdit,
    travelHistory,
    travelDetails,
  } from '../../service/getData'

  export default {
    data(){
      return {
        travelId: null,  //游记Id
        isFlag: null,  //用户身份标识
        detailContent: {}, //详情内容

        mutuallyGroup: {}, //交互组

        travelrecommend: [], //相关推荐
        travelTitle: '', //游记标题
        pointcount: 0, //点赞

        commentdata: [], //评论数据
        pageNum: 1,  //页数
        pageSize: 3,  //页条
        commentText: null, //评论内容
        commentNum: 0,
        activeComment: false,

        ispraise: null, //是否点赞
        isCollection: null,  //是否收藏

        showAlert: false, //显示提示组件
        alertText: null, //提示的内容
        alertBtn: [{title: '确认', 'click': this.closeTip}],//提示按钮

        isOpenComment: false,


        preventRepeatRequest: false, //节流标识
      }
    },
    mounted(){
      this.$nextTick(() => {
        this.travelId = this.$route.query.travelId;
        this.isFlag = this.$route.query.isFlag;
        //this.getHomeTravelDetails();
        this.getTravelDetails();
      });
    },
    components: {
      headTop,
      listTitle,
      alertTip,
      likeGroup
    },
    computed: {
      ...mapState([
        'handleGroup', 'login'
      ])
    },
    methods: {
      ...mapMutations([
        'MUTUALLY_HANDLE'
      ]),
      moreComment(e){
        if (this.commentdata.length - this.pageSize < 0) {
          return
        }
        this.pageSize += 5;
        this.commentdata.slice(0, this.pageSize);
      },

      //获取产品链接类型
      reControllerName(productType){
        if (productType === 1) {
          return 'spotsDetails'
        } else if (productType === 2) {
          return 'goodsDetails'
        } else if (productType === 3) {
          return 'linesDetails'
        }
      },

      /*详情数据*/
      async getTravelDetails(){
        await travelDetails(this.travelId).then(res => {
          if (res.status === 200) {
            //详情内容
            this.detailContent = res.obj.travelNote;
            //评论
            this.commentdata = res.obj.travelNoteComments;

            //相关推荐
            this.travelrecommend = res.obj.recommendProducts;
            //点赞标识
            //this.ispraise = this.detailContent.praised > 0 ? true : false;
            //收藏标识
            this.isCollection = this.detailContent.collected > 0 ? 1 : 0;

            this.MUTUALLY_HANDLE({
              like: this.detailContent.praiseCount,
              likestatus: this.detailContent.praised ? true : false,

              collect: this.detailContent.collectionCount,
              collectstatus: this.detailContent.collected,

              read: this.detailContent.readCount,
              comment: this.detailContent.commentCount,
              id: this.detailContent.id
            });

            //保存浏览历史
            if (this.travelId) saveHistory(this.travelId, 'strategy');
          }
        });
        await travelHistory(this.travelId).then(res => {
          if (res.status === 200) {
            this.detailContent.readCount++;
            this.MUTUALLY_HANDLE({
              like: this.handleGroup[this.detailContent.id].like,
              likestatus: this.handleGroup[this.detailContent.id].likestatus,

              collect: this.handleGroup[this.detailContent.id].collect,
              collectstatus: this.handleGroup[this.detailContent.id].collectstatus,

              read: this.detailContent.readCount,
              comment: this.handleGroup[this.detailContent.id].comment,
              id: this.detailContent.id
            });
          }
        });
      },

      //评论
      async getcommentData(){
        if (!this.commentText) {
          return
        }
        await homeDetailsComment({id: this.travelId, commenttext: this.commentText}).then(res => {
          if (res.status === 200) {

            this.MUTUALLY_HANDLE({
              like: this.handleGroup[this.detailContent.id].like,
              likestatus: this.handleGroup[this.detailContent.id].likestatus,

              collect: this.handleGroup[this.detailContent.id].collect,
              collectstatus: this.handleGroup[this.detailContent.id].collectstatus,

              read: this.handleGroup[this.detailContent.id].read,
              comment: ++this.handleGroup[this.detailContent.id].comment,
              id: this.detailContent.id
            });

            this.commentNum++;
            this.commentText = '';
          }
        });
        await homeDetailsCommentUP(this.travelId).then(res => {
          if (res.status === 200) {
            this.commentdata = res.obj.indexTravelNotesUserCommentslVo;
          }
        });
        this.isOpenComment = false;
      },

      //点赞
      async travelPraise(){
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await Praise({
          id: this.travelId,
          praiseType: 1
        }).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {
            //this.ispraise = res.obj.praiseed;

            this.detailContent.praiseCount += res.obj.praiseed ? 1 : -1;
            this.detailContent.praised = res.obj.praiseed ? true : false;

            this.MUTUALLY_HANDLE({
              like: this.detailContent.praiseCount,
              likestatus: this.detailContent.praised,

              collect: this.handleGroup[this.detailContent.id].collect,
              collectstatus: this.handleGroup[this.detailContent.id].collectstatus,

              read: this.handleGroup[this.detailContent.id].read,
              comment: this.handleGroup[this.detailContent.id].comment,
              id: this.detailContent.id
            });

            this.Toast({
              message: res.message,
              position: 'bottom',
              duration: 500
            });
          }
        });
      },

      //收藏
      collectionEdit: async function () {
        if (!this.login) {
          this.$router.push({path: '/login', query: {redirect: this.$route.fullPath}});
          return;
        }
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await collectionEdit(2, this.travelId, this.isCollection ? 0 : 1).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {
            this.detailContent.collected = this.handleGroup[this.detailContent.id].collectstatus ? 0 : 1;

            this.detailContent.collectionCount += this.detailContent.collected ? 1 : -1;

            this.MUTUALLY_HANDLE({
              like: this.handleGroup[this.detailContent.id].like,
              likestatus: this.handleGroup[this.detailContent.id].likestatus,

              collect: this.detailContent.collectionCount,
              collectstatus: this.detailContent.collected,

              read: this.handleGroup[this.detailContent.id].read,
              comment: this.handleGroup[this.detailContent.id].comment,
              id: this.detailContent.id
            });

            this.Toast({
              message: res.message,
              position: 'bottom',
              duration: 500
            });
          }
        });
      },

      //获取焦点
      Inputfocus(){
        this.isOpenComment = true;
        //this.activeComment = true;
        //this.$refs.commentInput.focus();
      }
    },
    filters: {
      formatDate: function (timestamp) {
        let mData = new Date(timestamp);
        let mouth = mData.getMonth() + 1;
        if (mouth < 10) {
          mouth = '0' + mouth;
        }
        let day = mData.getDate();
        if (day < 10) {
          day = '0' + day;
        }
        return mData.getFullYear() + '-' + mouth + '-' + day;
      },

      blankRemove(value = ''){
        return value.replace(/\s+/g, "");
      },
    }
  }

</script>
<style lang="scss" scoped>
  @import 'src/style/mixin.scss';

  .ui-padding-b-comment {
    padding-bottom: p2r(90);
  }

  .comment-page {
    //background:rgba(0,0,0,.5);
    //background:$fc2;
    .input-wrap {
      margin: p2r(50) p2r(20);
      textarea {
        width: 100%;
        height: p2r(200);
        border: 1px solid $bc;
        border-radius: p2r(8);
        resize: none;
        padding: p2r(20) p2r(30);
        font-size: p2r(24)
      }
      a {
        background: $blue;
        padding: p2r(20);
        text-align: center;
        display: block;
        color: $fc2;
        font-size: p2r(30);
        margin-top: p2r(40);

      }
    }
  }

  .details-wrap {
    @include bmb;
    border-top: none;
    .item {
      width: 100%;
      background-color: $bgc2;
      overflow: hidden;
      margin-top: p2r(12);
      padding: 0 p2r(20);
      margin-bottom: p2r(10);
      &:first-child {
        margin-top: 0;
      }
      .h3-travel-title {
        margin-top: p2r(12);
        font-size: p2r(30);
        font-weight: 100;
        word-break: break-all;
      }
      .user-info {
        overflow: hidden;
        padding: p2r(20) p2r(12) 0 p2r(12);
        .img-head {
          float: left;
          @include wh(p2r(70), p2r(70));
          margin-right: p2r(20);
          border-radius: 50%;
        }
        .span-name {
          @include sc(p2r(26), $mc);
          line-height: p2r(70);
        }
        .span-time {
          @include sc(p2r(26), $fc);
          float: right;
          line-height: p2r(70);
        }
      }
      .notes-info {
        overflow: hidden;
        li:nth-child(1), li:nth-child(3) {
          width: 55%;
          span {
            width: p2r(160);
          }
        }
        li:nth-child(2), li:nth-child(4) {
          width: 45%;
          span {
            width: p2r(110);
          }
        }
        li {
          float: left;
          display: flex;
          align-items: center;
          padding: p2r(3) 0;
          p {
            @include sc(p2r(24), $fc);
            margin-right: p2r(15);
            white-space: nowrap;
          }
          i {
            height: p2r(24);
            width: p2r(24);
            display: block;
            margin-right: p2r(15);
          }
          span {
            @include sc(p2r(24), $mc);
            width: p2r(140);
          }
        }
        .icon-time1 {
          @include bis('../../images/icon/icon_time.png')
        }
        .icon-money {
          @include bis('../../images/icon/icon_money.png')
        }
        .icon-like1 {
          @include bis('../../images/icon/icon_like.png')
        }
        .icon-day {
          @include bis('../../images/icon/icon_day.png')
        }
      }
      .notes-title {
        .span-title {
          @include sc(p2r(30), $mc);
        }
      }
      .notes-text {
        .span-text {
          @include sc(p2r(24), $mc);
        }
      }
      .notes-thum {
        @include wh(100%, p2r(240));
        overflow: hidden;
        .img-thum {
          width: 100%;
        }
      }
      .details-content {
        @include sc(p2r(24), $mc);
        padding-top: p2r(15);
        img {
          width: 100%;
        }
        p {
          text-indent: p2r(52);
          line-height: 2;
        }
      }
      .notes-fav {
        @include fj(left);
        position: relative;
        li {
          padding-bottom: p2r(16);
          width: 19%;
          &:last-child {
            width: 23%;
          }
          span {
            &:before {
              padding: p2r(15);
            }
            @include sc(p2r(24), $fc);
            height: p2r(35);
            line-height: p2r(35);
            padding: 0 p2r(30) 0 0;
          }

          .icon-all {
            @include ct();
            font-family: "iconfont" !important;
            font-style: normal;
            -webkit-font-smoothing: antialiased;
            display: inline-block;
          }

          .span-fav:before {
            content: '\E644';
          }

          .span-fav-a:before {
            content: '\E644';
            color: red;
          }

          .span-msg:before {
            content: '\e667';
          }

          .span-msg-a:before {
            content: '\e666';
          }

          .span-collect:before {
            content: '\e669';
          }

          .span-collect-a:before {
            content: '\e668';
            color: red;
          }

          .span-view-a:before {
            content: '\e73c';
          }

          .span-view:before {
            content: '\e73d';
          }

          .span-view-a:before {
            content: '\e73c';
          }

          .i-text {
            display: inline-block;
            border: 1px solid $bc;
            @include borderRadius(p2r(13));
            @include sc(p2r(20), $fc);
            line-height: p2r(30);
            font-style: normal;
            padding: 0 p2r(12);
          }
        }
      }
    }
  }

  .comment-div {
    border-top: 1px solid $bc;
    background: $fc2;
    border-bottom: 1px solid $bc;
    .comment-title {
      border-bottom: 1px solid $bc;
      padding: 0 p2r(20);
      overflow: hidden;
      span {
        color: $blue;
        display: block;
        border-bottom: 1px solid $blue;
        height: p2r(80);
        padding: 0 p2r(30);
        float: left;
        line-height: p2r(80);
        font-size: p2r(28);
      }
    }
    .comment-list {
      li {
        @include fj(flex-start);
        padding: 0 p2r(20);
        padding-right: 0;
        .img-box {
          width: p2r(100);
          height: p2r(110);
          padding: p2r(15) p2r(12);
          vertical-align: middle;
          img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            vertical-align: middle;
          }
        }
        .comment-content {
          flex: 1;
          border-bottom: 1px solid $bc;
          padding: p2r(15) 0;
          padding-right: p2r(20);
        }
        .user-name {
          overflow: hidden;
          display: flex;
          @include fj(space-between);
          width: 100%;
          font-size: p2r(24);
          span:first-child {
            color: $fc3;
          }
          .time {
            display: inline-block;
            border: 1px solid $bc;
            border-radius: p2r(16);
            font-size: p2r(20);
            color: $fc;
            line-height: p2r(30);
            font-style: normal;
            padding: 0 p2r(12);
          }
        }
        .comment-text {
          padding-top: p2r(12);
          font-size: p2r(24);
          line-height: 1.4;
          word-break: break-all;
        }
      }
      li:last-child {
        .comment-content {
          border-bottom: none;
        }
      }
    }
    .ui-more-comment {
      font-size: p2r(28);
      color: $blue;
      display: block;
      text-align: center;
      padding: p2r(20) 0;
      border-top: 1px solid $bc;
      margin: p2r(20) p2r(20) 0;
    }
  }

  .display-input-div {
    height: p2r(80);
  }

  .undisplay-input-div {
    height: 0;
  }

  .input-div {
    transition: height .5s;
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    input {
      background: $fc2;
      line-height: p2r(80);
      flex: 4;
      padding-left: p2r(20);
      border: none;
      border-top: 1px solid $bc;
      border-bottom: 1px solid $bc;
      font-size: p2r(24);
    }
    a {
      flex: 1;
      background: $blue;
      color: $fc2;
      font-size: p2r(28);
      line-height: p2r(80);
      text-align: center;
    }
  }

  /*相关推荐*/
  .product-wrap {
    @include bmb;
    margin-bottom: 0;
    margin-top: p2r(10);
    .product-title {
      padding: 0 p2r(20);
      border-bottom: 1px solid $bc;
      position: relative;
      line-height: p2r(68);
      overflow: hidden;
      .i-bg {
        @include wh(p2r(4), p2r(26));
        background-color: #cda367;
        display: inline-block;
        margin-right: p2r(12);
      }
      .span-title {
        @include sc(p2r(30), $mc);
      }
      .a-more {
        @include sc(p2r(24), $fc);
        float: right;
      }
    }
    .item:last-child {
      .flex {
        border-bottom: none;
      }
    }
    .item {
      padding: p2r(20);
      padding-bottom: 0;
      position: relative;
      .thum {
        height: p2r(240);
        overflow: hidden;
        .img-thum {
          width: 100%;

        }
      }
      .a-city {
        position: absolute;
        color: $fc2;
        font-size: p2r(24);
        background: rgba(0, 0, 0, .5);
        top: p2r(20);
        vertical-align: middle;
        padding: 0 p2r(15);
        line-height: (30/24);
      }
      .title {
        @include sc(p2r(30), $mc);
        margin: p2r(4) 0;
      }
      .flex {
        @include fj();
        align-items: baseline;
        border-bottom: 1px solid $bc;
        padding-bottom: p2r(20);
      }
      .price {
        float: left;
        @include sc(p2r(36), $fc3);
        &:before {
          content: '￥';
          @include sc(p2r(24), $fc3);
        }
        &:after {
          content: '起';
          @include sc(p2r(24), $fc);
        }
      }
      .price-1 {
        float: left;
        @include sc(p2r(36), $fc3);
        &:before {
          content: '￥';
          @include sc(p2r(24), $fc3);
        }
      }
      .num {
        float: right;
        @include sc(p2r(24), $fc);
      }
    }
  }
</style>
