<template>
  <div class="ui-body ui-padding-header login-container">
    <head-top :noBG="true">
      <div slot="btn" class="btn-all btn-left btn-back" @click="goHome()"></div>
      <div slot="btn" class="btn-all btn-right btn-char">
        <router-link to="login/register" class="btn-char">注册账号</router-link>
      </div>
    </head-top>
    <div class="ui-container">
      <section class="login-wrap">
        <div class="login-logo"><img src="../../images/logo.png"></div>
        <ul class="login-form" v-if="loginWay">
          <li class="li-border">
            <i class="i-icon i-user"></i>
            <input type="text" name="phone" autocomplete="off" class="ipn-all ipn-user" maxlength="11"
                   placeholder="手机号码"
                   v-model="phoneNumber">
          </li>
          <li class="li-border" v-if="showPassword">
            <i class="i-icon i-pass"></i>
            <input type="text" name="password" autocomplete="off" class="ipn-all ipn-pass" maxlength="16"
                   placeholder="密码(8-16个字符)"
                   v-model="passWord" @keyup.enter="mobileLogin">
            <span class="btn-ipn btn-view-on" @click="changePassWordType"></span>
          </li>
          <li class="li-border" v-else>
            <i class="i-icon i-pass"></i>
            <input type="password" name="password" autocomplete="off" class="ipn-all ipn-pass" maxlength="16"
                   placeholder="密码(8-16个字符)"
                   v-model="passWord" @keyup.enter="mobileLogin">
            <span class="btn-ipn btn-view" @click="changePassWordType"></span>
          </li>
          <li class="li-border" v-if="showVerifyCode && verifyCodeSrc">
            <i class="i-icon i-code"></i>
            <input type="text" name="verify" autocomplete="off" class="ipn-all" maxlength="4"
                   placeholder="验证码" v-model="verifyCodeNumber">
            <img class="img-code" :src="verifyCodeSrc" alt="验证码" @click="getVerifyCode()" @keyup.enter="mobileLogin">
          </li>
          <li>
            <router-link to="login/reSetPassword" class="ui-btn btn-all btn-forget">忘记密码？</router-link>
            <button type="button" class="btn-all btn-fast" @click="changeLoginWay">快速登录</button>
          </li>
          <li>
            <button type="button" class="btn-all btn-sub" @click.prevent="mobileLogin">登 录</button>
          </li>
        </ul>
        <ul class="login-form" v-else>
          <li class="li-border">
            <i class="i-icon i-user"></i>
            <input type="text" name="phone" autocomplete="off" class="ipn-all ipn-user" maxlength="11"
                   placeholder="手机号码"
                   v-model="phoneNumber">
            <span class="btn-ipn btn-char" @click="getMobileCode" v-show="!mobileCodeNum && !computedTime">获取验证码</span>
            <span class="btn-ipn btn-char" @click="getMobileCode" v-show="mobileCodeNum && !computedTime">重新获取</span>
            <span class="btn-ipn btn-char btn-char-gray" v-show="computedTime">{{computedTime}}秒可重发</span>
          </li>
          <li class="li-border">
            <i class="i-icon i-pass"></i>
            <input type="text" name="password" autocomplete="off" class="ipn-all ipn-pass" maxlength="4"
                   placeholder="请输入短信验证码" v-model="mobileCode" @keyup.enter="mobileLogin">
          <li>
            <button type="button" class="btn-all btn-normal" @click="changeLoginWay">账号密码登录</button>
          </li>
          <li>
            <button type="button" class="btn-all btn-sub" @click.prevent="mobileLogin">登 录</button>
          </li>
        </ul>
        <!--<div class="others-login">
          <div class="title">第三方账号登录</div>
          <ul class="btn-list">
            <li>
              <router-link to="login/fastRegister"><span class="btn-all btn-weibo"></span></router-link>
            </li>
            <li>
              <router-link to="login/fastRegister"><span class="btn-all btn-qq"></span></router-link>
            </li>
            <li>
              <router-link to="login/fastRegister"><span class="btn-all btn-wechat"></span></router-link>
            </li>
          </ul>
        </div>-->
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {mapState, mapMutations} from 'vuex'
  import {mobileCode, checkExsis, fastLogin, getcaptchas, accountLogin, logout, verifyCode} from 'src/service/getData'
  import {setStore, getStore, rightPhoneNumber, rightMobileCode, rightPassword} from 'src/config/mUtils'
  import md5 from 'blueimp-md5'

  export default {
    data(){
      return {
        loginWay: true, //登录方式，默认普通登录
        showPassword: false, // 是否显示密码
        phoneNumber: null, //电话号码
        mobileCode: null, //短信验证码
        validate_token: null, //获取短信时返回的验证值，登录时需要
        mobileCodeNum: 0,//验证码发送次数
        computedTime: 0, //倒数记时
        passWord: null, //密码
        codeNumber: null, //短信验证码
        userInfo: null,
        verifyCodeSrc: null,
        verifyCodeNumber: null,//验证码
        showVerifyCode: false,
      }
    },
    created(){
      let queryPhoneNumber = this.$route.query.tel;
      if (queryPhoneNumber) this.phoneNumber = queryPhoneNumber;

    },
    components: {
      headTop,
    },
    computed: {},
    methods: {
      ...mapMutations([
        'RECORD_USERINFO',
      ]),
      //改变登录方式
      changeLoginWay: function () {
        this.loginWay = !this.loginWay;
      },
      //是否显示密码
      changePassWordType: function () {
        this.showPassword = !this.showPassword;
      },
      //获取短信验证码
      getMobileCode: async function () {
        if (!this.phoneNumber) {
          this.Toast({message: '请输入手机号码', position: 'middle'});
          return;
        }
        if (!rightPhoneNumber(this.phoneNumber)) {
          this.Toast({message: '手机号码格式有误', position: 'middle'});
          return;
        }

        //发送短信验证码
        let sms = await mobileCode(this.phoneNumber, 3);
        if (sms.status === 105) {
          let affirm = await this.messageBox({
            title: '手机号未注册',
            message: '该号码未注册会员，立刻去注册？',
            showCancelButton: true,
            confirmButtonText: '去注册',
            cancelButtonText: '取消'
          });
          if (affirm === 'cancel') {
            return;
          }
          this.routerTo();
          return;
        }
        if (sms.status === 200) {
          this.validate_token = sms.obj.token;
          this.computedTime = 60;
          this.mobileCodeNum++;
          this.timer = setInterval(() => {
            this.computedTime--;
            if (this.computedTime === 0) {
              clearInterval(this.timer)
            }
          }, 1000);
        }
      },
      //发送登录信息
      mobileLogin: async function () {
        let res;
        if (!this.loginWay) {
          if (!this.phoneNumber) {
            this.Toast({message: '请输入手机号码', position: 'middle'});
            return;
          } else if (!rightPhoneNumber(this.phoneNumber)) {
            this.Toast({message: '手机号码格式有误', position: 'middle'});
            return;
          } else if (!this.validate_token) {
            this.Toast({message: '请先获取短信验证码', position: 'middle'});
            return;
          } else if (!this.mobileCode) {
            this.Toast({message: '请输入短信验证码', position: 'middle'});
            return;
          }

          res = await fastLogin(this.phoneNumber, this.mobileCode, this.validate_token);
        } else {
          if (!this.phoneNumber) {
            this.Toast({message: '请输入手机号码', position: 'middle'});
            return;
          } else if (!rightPhoneNumber(this.phoneNumber)) {
            this.Toast({message: '手机号码格式有误', position: 'middle'});
            return;
          } else if (!this.passWord) {
            this.Toast({message: '请输入密码', position: 'middle'});
            return
          } else if (this.showVerifyCode && !this.verifyCodeNumber) {
            this.Toast({message: '请输入验证码', position: 'middle'});
            return;
          }

          //用户名登录
          let passWord = md5(this.passWord).toUpperCase();
          res = await accountLogin(this.phoneNumber, passWord, this.verifyCodeNumber);

          if (res.obj.count >= 5 && res.status !== 200) {
            await this.getVerifyCode();
            this.showVerifyCode = true;
          }
        }


        if (res.status === 105) {
          this.messageBox.alert(res.message);
          return;
        }
        if (res.status === 200) {
          this.userInfo = res.obj.memberBasic;
          this.RECORD_USERINFO(this.userInfo);
          this.goBack();
        }
      },
      //验证码
      getVerifyCode: async function () {
        let res = await verifyCode();
        if (res.status !== 200) {
          return;
        }
        this.verifyCodeSrc = res.obj;
      },
      routerTo: function () {
        this.$router.replace({path: '/login/register', query: {'tel': this.phoneNumber}});
      },
      goBack: function () {
        if (this.$route.query.redirect) {
          this.$router.replace(this.$route.query.redirect);
        }
        else {
          this.$router.replace('/home');
        }
      },
      goHome: function () {
        if (this.$route.query.back) {
          this.$router.replace(this.$route.query.back);
        }
        else {
          this.$router.go(-1);
        }
        //this.$router.replace('/home');
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .login-container {
    @include bis('../../images/login_bg.jpg');
    @include allcover();
    @include wh(100%, 100%);
  }

  .login-wrap {
    .login-logo {
      width: 100%;
      text-align: center;
      margin: 2% 0;
      img {
        width: p2r(302);
      }
    }

    .login-form {
      margin: p2r(120) 0;
      padding: 0 p2r(40);
      li {
        position: relative;
        overflow: hidden;
        input:-webkit-autofill {
          background-color: rgba(255, 255, 255, 0);
        }
        .i-icon {
          @include wh(p2r(36), p2r(40));
          @include ct();
        }
        .i-user {
          @include bis("../../images/icon/icon_login_user.png");
        }
        .i-pass {
          @include bis("../../images/icon/icon_login_pass.png");
        }
        .i-code {
          @include bis("../../images/icon/icon_register_code.png");
        }
        .btn-ipn {
          @include ct();
          right: 0;
        }
        .btn-char {
          @include sc(p2r(26), $fc2);
          line-height: p2r(40);
          padding: 0 p2r(8);
          @include borderRadius(p2r(8));
          border: 1px solid $fc2;
        }
        .btn-char-gray {
          color: $fc2;
          background-color: #999;
          border: 1px solid #999;
        }
        .btn-view {
          width: p2r(80);
          height: p2r(80);
          @include bis("../../images/icon/icon_login_view.png");
          background-position: center center;
          background-size: 50% 50%;
        }
        .btn-view-on {
          width: p2r(80);
          height: p2r(80);
          @include bis("../../images/icon/icon_login_view_on.png");
          background-position: center center;
          background-size: 50% 50%;
        }
        .ipn-all {
          display: inline;
          @include wh(p2r(360), p2r(40));
          line-height: p2r(40);
          border: none;
          background: none;
          margin: p2r(25) 0 p2r(25) p2r(110);
          @include sc(p2r(30), $fc2);
          &::-webkit-input-placeholder {
            color: $fc2;
            opacity: 0.4;
          }
        }
        .ipn-verify {
          width: p2r(300);
          float: right;
        }
        .img-code {
          @include ct;
          right: 0;
          width: p2r(200);
          @include borderRadius(p2r(12));
        }
        .btn-all {
          background: none;
          border: none;
          @include sc(p2r(28), #0d4ea1);
          line-height: p2r(110);
        }
        .btn-fast {
          float: right;
        }
        .btn-normal {
          float: right;
        }
        .btn-sub {
          display: inline-block;
          @include wh(100%, p2r(80));
          line-height: p2r(80);
          background-color: $blue;
          @include sc(p2r(34), $fc2);
          @include borderRadius(p2r(16));
        }
      }
      .li-border {
        border-bottom: 1px solid #fff;
      }
    }
    .others-login {
      position: absolute;
      top: p2r(860);
      width: 100%;
      padding: 0 p2r(60);
      .title {
        text-align: center;
        line-height: p2r(90);
        @include sc(p2r(24), $fc2);
      }
      .btn-list {
        @include fj();
      }
      .btn-all {
        width: p2r(90);
        height: p2r(90);
        display: inline-block;
        background-color: $blue;
        @include borderRadius(p2r(80));
        box-shadow: 0 0 p2r(4) #2463b5;
      }
      .btn-weibo {
        @include bis("../../images/icon/icon_login_weibo.png");
      }
      .btn-qq {
        @include bis("../../images/icon/icon_login_qq.png");
      }
      .btn-wechat {
        @include bis("../../images/icon/icon_login_wechat.png");
      }
    }
  }
</style>
