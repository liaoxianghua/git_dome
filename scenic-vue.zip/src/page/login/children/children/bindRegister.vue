<template>
  <div class="register-container">
    <head-top headTitle="绑定手机号">
      <div slot="btn" class="btn-all btn-left btn-back" v-on:click="$router.go(-1)"></div>
    </head-top>
    <section class="register-wrap">
      <ul class="register-form">
        <li>
          <i class="i-icon i-user"></i>
          <input type="text" name="phone" autocomplete="off" class="ipn-all ipn-user" maxlength="11" placeholder="手机号码"
                 v-model="phoneNumber">
          <a class="btn-ipn btn-char" @click.prevent="getVerifyCode" v-show="!computedTime">获取验证码</a>
          <a class="btn-ipn btn-char btn-char-gray" @click.prevent=""
             v-show="computedTime">已发送({{computedTime}}s)</a>
        </li>
        <li>
          <i class="i-icon i-pass"></i>
          <input type="text" name="code" autocomplete="off" class="ipn-all ipn-pass" maxlength="16"
                 placeholder="输入验证码"
                 v-model="passWord">
        </li>
        <li>
          <button type="button" class="btn-all btn-sub">登录</button>
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import alertTip from 'src/components/common/alertTip'
  import {mapState, mapMutations} from 'vuex'
  import {mobileCode, checkExsis, validateMobileCode} from 'src/service/getData'

  export default {
    data(){
      return {
        loginWay: true, //登录方式，默认短信登录
        showPassword: false, // 是否显示密码
        phoneNumber: null, //电话号码
        mobileCode: null, //短信验证码
        validate_token: null, //获取短信时返回的验证值，登录时需要
        computedTime: 0, //倒数记时
        agreeRule: true, //同意条款
        userInfo: null, //获取到的用户信息
        userAccount: null, //用户名
        passWord: null, //密码
        captchaCodeImg: null, //验证码地址
        codeNumber: null, //验证码
        showAlert: false, //显示提示组件
        alertText: null, //提示的内容
      }
    },
    created(){
    },
    components: {
      headTop,
      alertTip,
    },
    computed: {
      //判断手机号码
      rightPhoneNumber: function () {
        return /^1\d{10}$/gi.test(this.phoneNumber)
      }
    },
    methods: {
      //获取短信验证码
      async getVerifyCode(){
        if (this.rightPhoneNumber) {
          this.computedTime = 60;
          this.timer = setInterval(() => {
            this.computedTime--;
            if (this.computedTime === 0) {
              clearInterval(this.timer)
            }
          }, 1000);
          //发送短信验证码
          let sms = await mobileCode(this.phoneNumber, 2);
          if (sms.message) {
            this.showAlert = true;
            this.alertText = sms.message;
            return
          }

          this.validate_token = res.validate_token;
        }
      },
      //发送注册信息
      async mobileLogin(){
        if (this.loginWay) {
          if (!this.rightPhoneNumber) {
            this.showAlert = true;
            this.alertText = '手机号码不正确';
            return
          } else if (!(/^\d{6}$/gi.test(this.mobileCode))) {
            this.showAlert = true;
            this.alertText = '短信验证码不正确';
            return
          }
          //手机号登录
          this.userInfo = await sendLogin(this.mobileCode, this.phoneNumber, this.validate_token);
        } else {
          if (!this.userAccount) {
            this.showAlert = true;
            this.alertText = '请输入手机号/邮箱/用户名';
            return
          } else if (!this.passWord) {
            this.showAlert = true;
            this.alertText = '请输入密码';
            return
          } else if (!this.codeNumber) {
            this.showAlert = true;
            this.alertText = '请输入验证码';
            return
          }
          //用户名登录
          this.userInfo = await accountLogin(this.userAccount, this.passWord, this.codeNumber);
        }
        //如果返回的值不正确，则弹出提示框，返回的值正确则返回上一页
        if (!this.userInfo.user_id) {
          this.showAlert = true;
          this.alertText = this.userInfo.message;
          if (!this.loginWay) this.getCaptchaCode();
        } else {
          this.RECORD_USERINFO(this.userInfo);
          this.$router.go(-1);

        }
      },
      closeTip(){
        this.showAlert = false;
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';

  .register-container {
    padding-top: p2r(88);
    background-color: #fff;
    @include allcover();
    @include wh(100%, 100%);
  }

  .register-wrap {
    .register-form {
      margin: p2r(35) 0;
      padding: 0 p2r(38);
      li {
        position: relative;
        overflow: hidden;
        @include sc(p2r(26), $mc);
        &:nth-child(1) {
          border-bottom: 1px solid #eee;
        }
        &:nth-child(2) {
          border-bottom: 1px solid #eee;
        }
        &:nth-child(3) {
          padding: p2r(60) 0;
        }
        .i-icon {
          @include wh(p2r(36), p2r(40));
          @include ct();
        }
        .i-user {
          @include bis("../../../../images/icon/icon_register_user.png");
        }
        .i-pass {
          @include bis("../../../../images/icon/icon_register_code.png");
        }
        .ipn-all {
          display: inline;
          @include wh(p2r(360), p2r(90));
          border: none;
          background: none;
          margin-left: p2r(110);
          @include sc(p2r(30), $mc);
          &::-webkit-input-placeholder {
            color: $fc;
            opacity: 0.4;
          }
        }
        .btn-ipn {
          @include ct();
          right: 0;
        }
        .btn-char {
          @include sc(p2r(26), $tc);
          line-height: p2r(40);
          padding: 0 p2r(8);
          @include borderRadius(p2r(8));
          border: p2r(1) solid $tc;
        }
        .btn-char-gray {
          color: $fc;
          border: p2r(1) solid $fc;
        }
        .btn-all {
          background: none;
          border: none;
          @include sc(p2r(28), #0d4ea1);
          line-height: p2r(110);
        }
        .btn-fast {
          float: right;
        }
        .btn-normal {
          float: right;
        }
        .btn-sub {
          @include wh(100%, p2r(80));
          line-height: p2r(80);
          background-color: $blue;
          @include sc(p2r(34), $fc2);
          @include borderRadius(p2r(16));
        }
        .register-tips {
          color: $tc;
        }
        .register-radio {
          display: inline-block;
          @include wh(p2r(34), p2r(34));
          border: p2r(1) solid $blue;
          @include borderRadius(p2r(18));
          background-color: #fff;
        }
        .register-radio-on {
          @include bis("../../../../images/icon/icon_register_ok.png");
          background-color: $blue;
        }
      }
      .flex {
        @include fj();
      }
    }
  }
</style>
