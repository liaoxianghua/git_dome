<template>
  <div class="ui-body ui-padding-header">
    <head-top v-bind:headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <div class="content-container">服务条款</div>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {
        pageTitle: '隐私与服务条款',
      }
    },
    components: {
      headTop,
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../../../style/mixin';


  .content-container {
    padding: p2r(24);
    @include sc(p2r(26), $mc);
  }
</style>
