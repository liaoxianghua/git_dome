<template>
  <div class="ui-container ui-padding">
    <head-top headTitle="注册成功">
      <div slot="btn" class="btn-all btn-left btn-back" v-on:click="$router.go(-1)"></div>
    </head-top>
    <section class="register-wrap">
      <div class="fast-info">
        <img src="../../../images/head_img.jpg" class="head-img"><br>
        <span class="wellcome-info">你好，GJHHHH<br>欢迎来到猴爸爸旅行</span>
        <router-link to="fastRegister/bindRegister"><span class="btn-sub">绑定手机号</span></router-link>
        <span class="tips">提醒：若已是会员，可输入注册的手机号进行绑定。</span>
      </div>
    </section>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from '../../../components/header/head'

  export default {
    data(){
      return {}
    },
    created(){
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {}
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .register-container {
    padding-top: p2r(88);
    background-color: #fff;
    @include allcover();
    @include wh(100%, 100%);
  }

  .register-wrap {
    .fast-info {
      text-align: center;
      @include sc(p2r(28), $mc);
      padding: 0 p2r(35);
      margin-top: p2r(66);
      line-height: 1.7;
      .head-img {
        @include wh(p2r(102), p2r(102));
        margin-bottom: p2r(8);
        @include borderRadius(60);
      }
      .wellcome-info {
        display: inline-block;
        margin-bottom: p2r(60);
      }
      .btn-sub {
        @include wh(100%, p2r(80));
        line-height: p2r(80);
        background-color: $blue;
        @include sc(p2r(34), $fc2);
        @include borderRadius(p2r(16));
        display: inline-block;
      }
      .tips {
        @include sc(p2r(24), $fc);
        display: inline-block;
        margin: p2r(24) 0;
      }
    }
  }
</style>
