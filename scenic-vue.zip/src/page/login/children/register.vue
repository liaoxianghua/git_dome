<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top :headTitle="pageTitle">
      <div slot="btn" class="btn-all btn-left btn-back" v-on:click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <section class="register-wrap">
        <ul class="register-form" v-if="!regStep">
          <li>
            <i class="i-icon i-user"></i>
            <input type="text" name="phone" autocomplete="off" class="ipn-all ipn-user" maxlength="11" placeholder="手机号码"
                   v-model="phoneNumber">
            <span class="btn-ipn btn-char" @click="getVerifyCode" v-show="!mobileCodeNum && !computedTime">获取验证码</span>
            <span class="btn-ipn btn-char" @click="getVerifyCode" v-show="mobileCodeNum && !computedTime">重新获取</span>
            <span class="btn-ipn btn-char btn-char-gray" v-show="computedTime">{{computedTime}}秒可重发</span>

          </li>
          <li>
            <i class="i-icon i-code"></i>
            <input type="text" name="code" autocomplete="off" class="ipn-all ipn-pass" maxlength="4"
                   placeholder="请输入短信验证码"
                   v-model="mobileCode">
          </li>
          <li class="flex">
            <div><i class="register-radio" v-bind:class="{'register-radio-on':agreeRule}"
                    v-on:click="changeRuleRadio"></i></div>
            <div>我愿意接受</div>
            <div><span class="register-tips" v-on:click="$router.push('register/rule')">《猴爸爸旅行隐私与服务条款》</span></div>
          </li>
          <li v-if="agreeRule">
            <button type="button" class="btn-all btn-sub" v-on:click.prevent="changeStep">下一步</button>
          </li>
          <li v-else>
            <button type="button" class="btn-all btn-sub btn-disable">下一步</button>
          </li>
        </ul>
        <ul class="register-form" v-else>
          <li v-if="!showPassword">
            <i class="i-icon i-code"></i>
            <input type="password" name="password" autocomplete="off" class="ipn-all ipn-user"
                   maxlength="16"
                   placeholder="请设置登录密码（8-16）位字符"
                   v-model="passWord">
            <span class="btn-ipn btn-view" v-on:click.prevent="changeShowPassword"></span>
          </li>
          <li v-else>
            <i class="i-icon i-code"></i>
            <input type="text" name="password" autocomplete="off" class="ipn-all ipn-user"
                   maxlength="16"
                   placeholder="请设置登录密码（8-16）位字符"
                   v-model="passWord">
            <span class="btn-ipn btn-view-on" v-on:click.prevent="changeShowPassword"></span>
          </li>
          <li v-if="!showrPassword">
            <i class="i-icon i-code"></i>
            <input type="password" name="rpassword" autocomplete="off" class="ipn-all ipn-user"
                   maxlength="16"
                   placeholder="请再次输入登录密码"
                   v-model="rPassWord">
            <span class="btn-ipn btn-view" v-on:click.prevent="changeShowrPassword"></span>
          </li>
          <li v-else>
            <i class="i-icon i-code"></i>
            <input type="text" name="rpassword" autocomplete="off" class="ipn-all ipn-user"
                   maxlength="16"
                   placeholder="请再次输入登录密码"
                   v-model="rPassWord">
            <span class="btn-ipn btn-view-on" v-on:click.prevent="changeShowrPassword"></span>
          </li>
          <li>
            <button type="button" class="btn-all btn-sub" v-on:click.prevent="mobileRegister">确认</button>
          </li>
        </ul>
      </section>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import {mapState, mapMutations} from 'vuex'
  import headTop from '../../../components/header/head'
  import {mobileCode, validateMobileCode, checkExsis, accountRegister} from '../../../service/getData'
  import {rightPhoneNumber, rightMobileCode, rightPassword} from 'src/config/mUtils'
  import md5 from 'blueimp-md5'

  export default {
    data(){
      return {
        pageTitle: '注册',//页面标题
        phoneNumber: null, //电话号码
        mobileCode: null, //短信验证码
        validate_token: null, //获取短信时返回的验证值，登录时需要
        passWord: null, //密码
        rPassWord: null, //重复密码
        computedTime: 0, //倒数记时
        mobileCodeNum: 0,//验证码发送次数
        agreeRule: true, //同意条款
        showPassword: false,//显示密码
        showrPassword: false,//显示重复密码
        regStep: 0, //注册步骤
      }
    },
    created(){
      let queryPhoneNumber = this.$route.query.tel;
      if (queryPhoneNumber) this.phoneNumber = queryPhoneNumber;
    },
    components: {
      headTop
    },
    computed: {},
    methods: {
      ...mapMutations([
        'RECORD_USERINFO',
      ]),
      changeShowPassword: function () {
        this.showPassword = !this.showPassword;
      },
      changeShowrPassword: function () {
        this.showrPassword = !this.showrPassword;
      },
      changeRuleRadio(){
        this.agreeRule = !this.agreeRule;
      },
      //获取短信验证码
      async getVerifyCode(){
        if (!this.phoneNumber) {
          this.Toast({message: '请输入手机号码', position: 'middle'});
          return;
        }
        if (!rightPhoneNumber(this.phoneNumber)) {
          this.Toast({message: '手机号码格式有误', position: 'middle'});
          return;
        }

        //发送短信验证码
        let sms = await mobileCode(this.phoneNumber, 1);
        if (sms.status === 104) {
          let affirm = await this.messageBox({
            title: '手机号已注册',
            message: '该号码已经注册会员,是否直接登录？',
            showCancelButton: true,
            confirmButtonText: '去登录',
            cancelButtonText: '取消'
          });
          if (affirm === 'cancel') {
            return;
          }
          this.$router.replace({path: '/login', query: {'tel': this.phoneNumber}});
          return;
        }
        if (sms.status === 200) {
          this.validate_token = sms.obj.token;
          this.computedTime = 60;
          this.mobileCodeNum++;
          this.timer = setInterval(() => {
            this.computedTime--;
            if (this.computedTime === 0) {
              clearInterval(this.timer);
            }
          }, 1000);
        }
      },
      //进入设置密码页面
      async changeStep(){
        if (this.regStep === 0) {
          if (!this.phoneNumber) {
            this.Toast({message: '请输入手机号码', position: 'middle'});
            return;
          } else if (!this.validate_token) {
            this.Toast({message: '请先获取短信验证码', position: 'middle'});
            return;
          } else if (!rightPhoneNumber(this.phoneNumber)) {
            this.Toast({message: '手机号码格式有误', position: 'middle'});
            return;
          } else if (!this.mobileCode) {
            this.Toast({message: '请输入短信验证码', position: 'middle'});
            return;
          } else if (!this.agreeRule) {
            this.Toast({message: '请同意服务条款', position: 'middle'});
            return
          }

          //验证手机验证码
          let res = await validateMobileCode(this.phoneNumber, this.mobileCode, this.validate_token, 1);

          if (res.status === 200) {
            this.pageTitle = '设置密码';
            this.regStep++;
          }
        }

      },
      //发送注册信息
      async mobileRegister(){
        if (!rightPassword(this.passWord)) {
          this.Toast({message: '您的密码安全等级太弱，请设置8-16位数字和字母的组合', position: 'middle'});
          return
        } else if (!this.rPassWord) {
          this.Toast({message: '请再次输入密码', position: 'middle'});
          return
        } else if (this.passWord !== this.rPassWord) {
          this.Toast({message: '两次输入的密码不一致', position: 'middle'});
          return
        }

        let passWord = md5(this.passWord).toUpperCase();
        let res = await accountRegister(this.phoneNumber, passWord, passWord, this.mobileCode, this.validate_token);

        //如果返回的值不正确，则弹出提示框，返回的值正确则自动登录并返首页
        if (res.status === 200) {
          await this.messageBox.alert(res.message);
          this.userInfo = res.obj.memberBasic;
          this.RECORD_USERINFO(this.userInfo);
          this.$router.replace('/home');
        }
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .register-wrap {
    .register-form {
      margin: p2r(35) 0;
      padding: 0 p2r(38);
      li {
        position: relative;
        overflow: hidden;
        @include sc(p2r(26), $mc);
        &:nth-child(1) {
          border-bottom: 1px solid #eee;
        }
        &:nth-child(2) {
          border-bottom: 1px solid #eee;
        }
        &:nth-child(3) {
          padding: p2r(60) 0;
        }
        .i-icon {
          @include wh(p2r(36), p2r(40));
          @include ct();
        }
        .i-user {
          @include bis("../../../images/icon/icon_register_user.png");
        }
        .i-code {
          @include bis("../../../images/icon/icon_register_code.png");
        }
        .i-pass {
          @include bis("../../../images/icon/icon_register_password.png");
        }
        .ipn-all {
          display: inline-block;
          @include wh(p2r(430), p2r(40));
          line-height: p2r(40);
          border: none;
          background: none;
          margin: p2r(25) 0 p2r(25) p2r(60);
          @include sc(p2r(30), $mc);
        }
        .btn-ipn {
          @include ct();
          right: 0;
        }
        .btn-view {
          width: p2r(44);
          height: p2r(44);
          @include bis("../../../images/icon/icon_reg_view.png");
        }
        .btn-view-on {
          width: p2r(44);
          height: p2r(44);
          @include bis("../../../images/icon/icon_reg_view_on.png");
        }
        .btn-char {
          @include sc(p2r(26), $tc);
          line-height: p2r(40);
          padding: 0 p2r(8);
          @include borderRadius(p2r(8));
          border: p2r(1) solid $tc;
        }
        .btn-char-gray {
          color: $fc;
          border: p2r(1) solid $fc;
        }
        .btn-all {
          background: none;
          border: none;
          @include sc(p2r(28), #0d4ea1);
          line-height: p2r(110);
        }
        .btn-fast {
          float: right;
        }
        .btn-normal {
          float: right;
        }
        .btn-sub {
          @include wh(100%, p2r(80));
          line-height: p2r(80);
          background-color: $blue;
          @include sc(p2r(34), $fc2);
          @include borderRadius(p2r(16));
        }
        .btn-disable {
          background-color: $fc;
        }
        .register-tips {
          color: $tc;
        }
        .register-radio {
          display: inline-block;
          @include wh(p2r(34), p2r(34));
          border: p2r(4) solid $blue;
          @include borderRadius(p2r(18));
          background-color: #fff;
        }
        .register-radio-on {
          @include bis("../../../images/icon/icon_register_ok.png");
          background-color: $blue;
        }
      }
      .flex {
        @include fj();
      }
    }
  }
</style>
