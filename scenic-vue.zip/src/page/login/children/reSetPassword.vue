<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top headTitle="重置密码">
      <div slot="btn" class="btn-all btn-left btn-back" v-on:click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <section class="register-wrap" v-if="step == 0">
        <div class="register-tips">请输入注册手机号码<br>以验证账户</div>
        <ul class="register-form">
          <li>
            <i class="i-icon i-user"></i>
            <input type="text" name="phone" autocomplete="off" class="ipn-all ipn-user" maxlength="11" placeholder="手机号码"
                   v-model="phoneNumber">
          </li>
        </ul>
        <div class="register-btn">
          <button type="button" class="btn-all btn-sub" v-on:click="getVerifyCode" v-if="phoneNumber">获取验证码</button>
          <button type="button" class="btn-all btn-sub ui-btn-disable" v-else>获取验证码</button>
        </div>
      </section>
      <section class="register-wrap" v-else-if="step == 1">
        <div class="register-tips">请验证您的手机号码<br>{{phoneNumber}}</div>
        <ul class="register-form">
          <li>
            <i class="i-icon i-code"></i>
            <input type="text" name="code" autocomplete="off" class="ipn-all ipn-user" maxlength="4" placeholder="请输入验证码"
                   v-model="mobileCode">
            <span class="btn-ipn btn-char" @click="getVerifyCode" v-show="!mobileCodeNum && !computedTime">获取验证码</span>
            <span class="btn-ipn btn-char" @click="getVerifyCode" v-show="mobileCodeNum && !computedTime">重新获取</span>
            <span class="btn-ipn btn-char btn-char-gray" v-show="computedTime">{{computedTime}}秒可重发</span>
          </li>
        </ul>
        <div class="register-btn">
          <button type="button" class="btn-all btn-sub" v-on:click="validateVerifyCode" v-if="mobileCode">下一步</button>
          <button type="button" class="btn-all btn-sub ui-btn-disable" v-else>下一步</button>
        </div>
      </section>
      <section class="register-wrap" v-else-if="step == 2">
        <div class="register-tips">请输入密码</div>
        <ul class="register-form">
          <li v-if="showPassword">
            <i class="i-icon i-pass"></i>
            <input type="text" name="password" autocomplete="off" class="ipn-all ipn-pass" maxlength="16"
                   placeholder="密码(8-16个字符)" v-model="passWord">
            <span class="btn-ipn btn-clean" v-on:click="cleanPassword"></span>
            <span class="btn-ipn btn-view-on" v-on:click="changeShowPassword"></span>
          </li>
          <li v-else>
            <i class="i-icon i-pass"></i>
            <input type="password" name="password" autocomplete="off" class="ipn-all ipn-pass" maxlength="16"
                   placeholder="密码(8-16个字符)" v-model="passWord">
            <span class="btn-ipn btn-clean" v-on:click="cleanPassword"></span>
            <span class="btn-ipn btn-view" v-on:click="changeShowPassword"></span>
          </li>
        </ul>
        <div class="register-btn">
          <button type="button" class="btn-all btn-sub" v-on:click="sendReSetPassword" v-if="passWord">确认</button>
          <button type="button" class="btn-all btn-sub ui-btn-disable" v-else>确认</button>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from '../../../components/header/head'
  import {mapState, mapMutations} from 'vuex'
  import {mobileCode, validateMobileCode, reSetPassword} from '../../../service/getData'
  import {rightPhoneNumber, rightMobileCode, rightPassword} from 'src/config/mUtils'
  import md5 from 'blueimp-md5'

  export default {
    data(){
      return {
        step: 0, //步骤
        showPassword: false, // 是否显示密码
        phoneNumber: null, //电话号码
        mobileCode: null, //短信验证码
        validate_token: null, //获取短信时返回的验证值，登录时需要
        computedTime: 0, //倒数记时\
        mobileCodeNum: 0,//验证码发送次数
        agreeRule: true, //同意条款
        passWord: null, //新密码
      }
    },
    created(){
    },
    components: {
      headTop,
    },
    computed: {},
    methods: {
      ...mapMutations([
        'RECORD_USERINFO',
      ]),
      changeShowPassword(){
        this.showPassword = !this.showPassword;
      },
      cleanPassword(){
        this.passWord = null;
      },
      //获取短信验证码
      async getVerifyCode(){
        if (!this.phoneNumber) {
          this.Toast({message: '请输入手机号码', position: 'middle'});
          return;
        }
        if (!rightPhoneNumber(this.phoneNumber)) {
          this.Toast({message: '手机号码格式有误', position: 'middle'});
          return;
        }
        //发送短信验证码
        let sms = await mobileCode(this.phoneNumber, 5);
        if (sms.status === 105) {
          this.messageBox.alert(sms.message);
          return;
        }
        if (sms.status === 200) {
          this.validate_token = sms.obj.token;
          this.computedTime = 60;
          this.mobileCodeNum++;
          this.timer = setInterval(() => {
            this.computedTime--;
            if (this.computedTime == 0) {
              clearInterval(this.timer);
            }
          }, 1000);
          this.step = 1;
        }
      },
      //验证短信验证码
      async validateVerifyCode(){
        if (!this.mobileCode) {
          this.Toast({message: '请输入短信验证码', position: 'middle'});
          return
        }
        //验证手机验证码
        let res = await validateMobileCode(this.phoneNumber, this.mobileCode, this.validate_token, 5);
        if (res.status === 200) {
          this.step = 2;
        }
      },
      //发送密码修改
      async sendReSetPassword(){
        if (!rightPassword(this.passWord)) {
          this.Toast({message: '您的密码安全等级太弱，请设置8-16位数字和字母的组合', position: 'middle'});
          return
        }

        let passWord = md5(this.passWord).toUpperCase();
        let res = await reSetPassword(this.phoneNumber, passWord, this.mobileCode, this.validate_token);
        if (res.status === 200) {
          await this.messageBox.alert(res.message);
          this.$router.replace('/login');
        }
      }
    }
  }

</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

  textarea, input {
    font-size: p2r(24);
  }

  .register-wrap {
    .register-form {
      margin: p2r(35) 0;
      padding: 0 p2r(38);
      li {
        position: relative;
        overflow: hidden;
        @include sc(p2r(26), $mc);
        &:nth-child(1) {
          border-bottom: 1px solid #eee;
        }
        .i-icon {
          @include wh(p2r(36), p2r(40));
          @include ct();
        }
        .i-user {
          @include bis("../../../images/icon/icon_register_tel.png");
        }
        .i-code {
          @include bis("../../../images/icon/icon_register_code.png");
        }
        .i-pass {
          @include bis("../../../images/icon/icon_register_password.png");
        }
        .ipn-all {
          display: inline-block;
          @include wh(p2r(360), p2r(40));
          line-height: p2r(40);
          border: none;
          background: none;
          margin: p2r(25) 0 p2r(25) p2r(60);
          @include sc(p2r(30), $mc);
          &::-webkit-input-placeholder {
            color: $fc;
            opacity: 0.4;
          }
        }
        .btn-ipn {
          @include ct();
          right: 0;
        }
        .btn-char {
          @include sc(p2r(26), $tc);
          line-height: p2r(40);
          padding: 0 p2r(8);
          @include borderRadius(p2r(8));
          border: p2r(1) solid $tc;
        }
        .btn-char-gray {
          color: $fc;
          border: p2r(1) solid $fc;
        }
        .btn-view {
          width: p2r(44);
          height: p2r(44);
          @include bis("../../../images/icon/icon_reg_view.png");
        }
        .btn-view-on {
          width: p2r(44);
          height: p2r(44);
          @include bis("../../../images/icon/icon_reg_view_on.png");
        }
        .btn-clean {
          width: p2r(44);
          height: p2r(44);
          @include bis("../../../images/icon/icon_reg_clean.png");
          right: p2r(76);
        }
      }
      .flex {
        @include fj();
      }
    }
    .register-btn {
      padding: 0 p2r(30);
      .btn-all {
        background: none;
        border: none;
      }
      .btn-sub {
        @include wh(100%, p2r(80));
        line-height: p2r(80);
        background-color: $blue;
        @include sc(p2r(34), $fc2);
        @include borderRadius(p2r(16));
      }
      .btn-disable {
        background-color: $fc;
      }
    }
    .register-tips {
      margin-top: p2r(24);
      @include sc(p2r(28), $mc);
      text-align: center;
      line-height: 1.8;
    }
  }
</style>
