<template>
  <div class="ui-body ui-padding-header ui-white-bg">
    <head-top ref="head" headTitle="直播">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <div class="ui-container">
      <section class="live-list">
        <div class="item" v-for="item in videoList">
          <div class="ui-video-wrap">
            <d-player
              ref="video"
              :video="{url:item.skipUrl,pic:item.pictureUrl}"
              :loop="false"
              preload="none"
            ></d-player>
          </div>
          <div class="user-info">
            <img src="../../images/hz.png" class="img-head">
            <span class="span-title ellipsis">{{item.title}}-{{item.subTitle}}</span>
            <span class="span-name">猴爸爸旅行</span>
            <a class="a-fav" @click="videoPraise(item.id,item.praised)"><i class="iconfont icon-likefill i-fav" :class="{'i-fav-active':item.praised}"></i><br>{{item.praiseCount || 0}}</a>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  //import videoUnit from '../../components/common/video'
  import {moreVideo, Praise} from '../../service/getData'
  import VueDPlayer from 'vue-dplayer'


  export default {
    data(){
      return {
        playId: 0,
        videoList: [],
        preventRepeatRequest: false,//阻止请求
      }
    },
    created(){
      if (this.$route.query.playId) this.playId = parseInt(this.$route.query.playId);
    },
    mounted(){
      this.$nextTick(() => {
        this.initVideoDate();
      })
    },
    computed: {},
    components: {
      headTop,
      'd-player': VueDPlayer
    },

    methods: {
      //播放视屏提前
      aheadData: function () {
        let topItem;
        for (let i = 0; i < this.videoList.length; i++) {
          let item = this.videoList[i];
          if (item.id === this.playId) {
            topItem = item;
            this.videoList.splice(i, 1);
          }
        }
        this.videoList.unshift(topItem);
        //this.videoList = [...this.videoList.splice(i, 1), ...this.videoList];
      },

      //初始化视屏列表数据
      initVideoDate: async function () {
        let res = await moreVideo();

        if (res.status === 200) {
          this.videoList = res.obj.directseedingmore;
        }

        if (this.playId) {
          this.aheadData();
        }
      },
      //初始化视屏列表数据
      async getVideoDate(){
        await moreVideo().then(res => {
          if (res.status === 200) {
            this.videoList = res.obj.directseedingmore;
          }
        });
        console.log(this.videoList);
      },
      //点赞
      async videoPraise(collectionId, praised){
        if (this.preventRepeatRequest) {
          return false;
        }
        this.preventRepeatRequest = true;
        await Praise({
          id: collectionId,
          praiseType: 3
        }).then(res => {
          if (res.status === 200) {
            praised = res.obj.praiseed;

            this.videoList.forEach(item => {
              if (item.id === collectionId) {
                item.praised = praised;
                item.praiseCount += praised ? 1 : -1;
              }
            });

            this.Toast({
              message: res.message,
              position: 'bottom',
              duration: 500
            });

            this.preventRepeatRequest = false;
          }
        });
      },
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .head-top {
    z-index: 100001;
  }

  .live-list {
    overflow: hidden;
    .item {
      position: relative;
      margin-bottom: p2r(10);
      background: $mc;
      padding-bottom: p2r(20);
      &:last-child {
        margin-bottom: none;
      }
      .ui-video-wrap {
        overflow: hidden;
      }
      .user-info {
        position: relative;
        background: rgba(255, 255, 255, 0.9);
        padding: p2r(6) 0;
        @include borderRadius(p2r(12));
        height: p2r(84);
        margin: p2r(20) p2r(30) 0;
        .img-head {
          @include wh(p2r(54), p2r(54));
          @include borderRadius(p2r(30));
          float: left;
          margin: p2r(8) p2r(32);
        }
        span {
          @include sc(p2r(28), $mc);
          width: p2r(380);
          line-height: 1.3;
        }
        .span-title {
          display: block;
          float: left;
        }
        .span-name {
          float: left;
        }
        .a-fav {
          @include ct;
          right: p2r(12);
          @include sc(p2r(24), #fc2871);
          text-align: center;
          line-height: 1;
        }
        .i-fav {
          @include wh(p2r(40), p2r(40));
          line-height: p2r(40);
          display: inline-block;
          @include borderRadius(p2r(20));
          background-color: #fc2871;
          @include sc(p2r(28), $fc2);
        }
        .i-fav-active{
          background: none;
          color: #fc2871;
        }
      }
      .live-control {
        overflow: hidden;
        .lucency {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, .5);
        }

        .img-thum {
          width: 100%;
        }

        a {
          display: inline-block;
          @include wh(p2r(80), p2r(80));
        }
        .a-play {
          @include center;
          @include bis("../../images/icon/icon_live_play.png");
        }
        .a-pause {
          border-radius: 50%;
          background: rgba(0, 0, 0, .7);
          text-align: center;
        }
        .a-pause:after {
          content: '';
          display: inline-block;
          width: p2r(20);
          height: p2r(40);
          border-left: p2r(5) solid rgba(255, 255, 255, .8);
          border-right: p2r(5) solid rgba(255, 255, 255, .8);
          margin-top: p2r(20);
        }
      }
    }
  }
</style>
