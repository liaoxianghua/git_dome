<template>
  <div class="ui-padding">
    <head-top ref="head" headTitle="直播">
      <div slot="btn" class="btn-all btn-left btn-back" @click="$router.go(-1)"></div>
    </head-top>
    <section class="live-list">
      <div class="item" ref='g' v-for="(item,i) in videoList">
        <div class="ui-video-wrap">
          <video
            preload="metadata"
            :src="item.skipUrl"
            controls
            loop="loop"
          >
          </video>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
  import headTop from '../../components/header/head'
  import {moreVideo, Praise} from '../../service/getData'

  export default {
    data(){
      return {
        videoList: [],
        videoEls: [],

        pindex: null,
        palyId: null,
        currentPlay: null,
        issource: false, //加载完成
        ispraise: 0,
        addend: 0,
      }
    },
    created(){

    },
    mounted(){
        this.getVideoDate();
    },
    computed: {},
    components: {
      headTop,
    },

    methods: {
      //初始化视屏列表数据
      async getVideoDate(){
        await moreVideo().then(res => {
          if (res.status === 200) {
            res.obj.directseedingmore.forEach(item => {
              item.isPlay = false;
            });
            this.videoList = res.obj.directseedingmore;
          }
        });
      },
    },
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .live-list {
    .item {
      position: relative;
      margin-bottom: p2r(10);
      &:last-child {
        margin-bottom: none;
      }
      .ui-video-wrap {
        height: p2r(490);
        overflow: hidden;
        video {
          object-fit: fill;
          width: 100%;
          height: p2r(490);
        }
        .video-thum {
          width: 100%;
        }
      }
      .user-info {
        position: absolute;
        left: p2r(20);
        right: p2r(20);
        bottom: p2r(26);
        background: rgba(255, 255, 255, 0.9);
        padding: p2r(6) 0;
        @include borderRadius(p2r(12));
        height: p2r(84);
        .img-head {
          @include wh(p2r(54), p2r(54));
          @include borderRadius(p2r(30));
          float: left;
          margin: p2r(8) p2r(32);
        }
        span {
          @include sc(p2r(28), $mc);
          width: p2r(380);
          line-height: 1.3;
        }
        .span-title {
          display: block;
          float: left;
        }
        .span-name {
          float: left;
        }
        .a-fav {
          @include ct;
          right: p2r(12);
          @include sc(p2r(24), #fc2871);
          text-align: center;
          line-height: 1;
        }
        .i-fav {
          @include wh(p2r(40), p2r(40));
          @include bis("../../images/icon/icon_live_fav.png");
          display: inline-block;
          @include borderRadius(p2r(20));
        }
      }
      .live-control {
        overflow: hidden;
        .lucency {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, .5);
        }

        .img-thum {
          width: 100%;
        }

        a {
          display: inline-block;
          @include wh(p2r(80), p2r(80));
        }
        .a-play {
          @include center;
          @include bis("../../images/icon/icon_live_play.png");
        }
        .a-pause {
          border-radius: 50%;
          background: rgba(0, 0, 0, .7);
          text-align: center;
        }
        .a-pause:after {
          content: '';
          display: inline-block;
          width: p2r(20);
          height: p2r(40);
          border-left: p2r(5) solid rgba(255, 255, 255, .8);
          border-right: p2r(5) solid rgba(255, 255, 255, .8);
          margin-top: p2r(20);
        }
      }
    }
  }
</style>
