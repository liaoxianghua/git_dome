<template>
  <transition name="router-fade" mode="out-in">
    <router-view></router-view>
  </transition>
</template>

<script>
  import {mapMutations, mapState, mapActions} from 'vuex'

  export default {
    mounted(){
      this.getUserInfo();
    },
    methods: {
      ...mapActions([
        'getUserInfo'
      ]),
    },
  }

</script>

<style lang="scss">
  @import './style/common';
  @import './assets/iconfont/iconfont.css';
</style>
