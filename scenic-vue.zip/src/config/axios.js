import {messageBox, Toast, Indicator} from 'mint-ui'
import {baseUrl, delayTime, routerMode} from './env'
import axios from 'axios'
axios.defaults.withCredentials = true;//让ajax携带cookie
axios.defaults.timeout = 20000;                     //响应时间
axios.defaults.baseURL = baseUrl;

export default async (type = 'GET', url = '', data = {}, method = 'fetch') => {
  type = type.toUpperCase();

  if (type === 'GET') {
    let dataStr = ''; //数据拼接字符串
    Object.keys(data).forEach(key => {
      if (data[key] !== null) {
        dataStr += key + '=' + data[key] + '&';
      }
    });

    if (dataStr !== '') {
      dataStr = dataStr.substr(0, dataStr.lastIndexOf('&'));
      url = url + '?' + dataStr;
    }
    data = {};
  }
  else if (type === 'POST') {
    let dataStr = ''; //数据拼接字符串
    Object.keys(data).forEach(key => {
      if (data[key] !== null) {
        dataStr += key + '=' + data[key] + '&';
      }
    });

    if (dataStr !== '') {
      data = dataStr.substr(0, dataStr.lastIndexOf('&'));
    }
  }

  let response = await axios({
    method: type,
    url: url,
    data: data,
    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then((response) => {
    return response;
  });
  return response.data;
}

//http request
axios.interceptors.request.use(
  config => {
    Indicator.open();
    return config;
  },
  err => {
    return Promise.reject(err);
  }
);


// http response
axios.interceptors.response.use(
  response => {
    setTimeout(() => {
      Indicator.close();
    }, delayTime);
    //错误处理
    switch (response.data.status) {
      case 200://正常
        //return false;
        break;
      case 101://未登录
        //未登录销毁本地token
        window.sessionStorage.removeItem('token');
        if (response.config.url.indexOf('member/selectMemberInfo') == -1) {
          messageBox.alert(response.data.message);
         /* console.log(window.location);
          let redirect = window.location.pathname + window.location.search;
          if (routerMode === 'hash') {
            window.location.href = '/#/login?redirect=' + redirect;
          }
          else {
            window.location.href = '/login?redirect=' + redirect;
          }*/
        }
        break;
      case 104://手机号已注册
        break;
      case 105://手机号未注册
        break;

      case 601://商户不存在
        break;
      case 602://商户被禁用
        break;
      case 603://产品不存在
        break;

      default://错误
        messageBox.alert(response.data.message);
        break;
    }
    return response;
  },
  error => {
    Indicator.close();
    if (error.response) {
      switch (error.response.status) {
        case 304:
          Toast({message: '请求超时', position: 'bottom'});
          break;
        case 404:
          Toast({message: '404', position: 'bottom'});
          break;
      }
    }
    else {
      Toast({message: '网络错误', position: 'bottom'});
      //console.log(error.indexOf('404'));
      //Toast({message: error, position: 'bottom'});
    }
    return Promise.reject(error)   // 返回接口返回的错误信息
  }
);
