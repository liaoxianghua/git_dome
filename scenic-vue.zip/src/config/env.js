/**
 * 配置编译环境和线上环境之间的切换
 *
 * baseUrl: 域名地址
 * routerMode: 路由模式
 * imgBaseUrl: 图片所在域名地址
 *
 */
let baseUrl;
let routerMode;
const delayTime = 300;
const imgBaseUrl = 'https://fuss10.elemecdn.com';

if (process.env.NODE_ENV == 'development') {
  //baseUrl = 'http://10.131.8.76:8080/scenic-api';//舒畅
	//baseUrl = 'http://10.131.9.44:8089/scenic-api';//志军
	//baseUrl = 'http://10.131.10.52:8081/scenic-api';//茂平
	//baseUrl = 'http://10.131.10.163:8080/scenic-api';//象兵
  baseUrl = 'http://10.131.10.137:8080/scenic-api'; //廖祥华
  //baseUrl = 'http://10.131.0.163:9090/scenic-api'; //测试
  //baseUrl = 'http://10.131.8.76:8080/scenic-api'; //线上
	routerMode = 'hash'
}else{
  baseUrl = window.config.apiUrl;
  //baseUrl = 'http://10.131.8.76:8080/scenic-api';//舒畅
	routerMode = 'hash'
}

export {
	baseUrl,
	routerMode,
	imgBaseUrl,
  delayTime
}
