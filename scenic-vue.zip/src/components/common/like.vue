<template>
  <ul class="notes-fav" v-if="handleGroup[item.id]">
    <li @click="travelPraise(item.id)">
      <span class="icon-all span-fav" :class="[handleGroup[item.id].likestatus?'span-fav-a':'span-fav']">{{handleGroup[item.id].like}}</span>
    </li>
    <router-link tag="li" :to="{path:'/homeTravelDetails',query:{travelId:item.id}}">
      <span class="icon-all span-msg">{{handleGroup[item.id].comment}}</span>
    </router-link>
    <li @click="collectionEdit(item.id)">
      <span class="icon-all span-collect"
            :class="[handleGroup[item.id].collectstatus?'span-collect-a':'span-collect']">{{handleGroup[item.id].collect}}</span>
    </li>
    <li><span class="icon-all span-view">
      {{handleGroup[item.id].read}}</span></li>
    <li class="time"><i class="i-text">{{item.nowTime}}</i></li>
  </ul>
</template>

<script>
  import {collectionEdit, Praise} from '../../service/getData'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        status: null,
        isCollection: null,
        preventRepeatRequest: false, //接口节流
      }
    },
    props: ['item'],
    mounted(){
      this.MUTUALLY_HANDLE({
        like: this.item.praiseCount,
        likestatus: this.item.praised ? true : false,

        collect: this.item.collectionCount,
        collectstatus: this.item.collected,

        read:this.item.readCount,
        comment: this.item.commentCount,
        id: this.item.id
      });
    },
    computed: {
      ...mapState([
        'login', 'handleGroup'
      ]),
    },
    methods: {
      ...mapMutations([
        'MUTUALLY_HANDLE'
      ]),
      //收藏
      async collectionEdit (collectionId) {
        if (!this.login) {
          this.$router.push({path: '/login', query: {redirect: this.$route.fullPath}});
          return;
        }
        if (this.preventRepeatRequest) {
          return;
        }
        this.preventRepeatRequest = true;
        await collectionEdit(2, collectionId, this.item.collected ? 0 : 1).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {
            this.handleGroup[this.item.id].collectstatus = this.handleGroup[this.item.id].collectstatus ? 0 : 1;
            this.handleGroup[this.item.id].collect += this.handleGroup[this.item.id].collectstatus ? 1 : -1;

            this.MUTUALLY_HANDLE({
              like: this.handleGroup[this.item.id].like,
              likestatus: this.handleGroup[this.item.id].likestatus,

              collect: this.handleGroup[this.item.id].collect,
              collectstatus: this.handleGroup[this.item.id].collectstatus,

              read:this.handleGroup[this.item.id].read,
              comment: this.handleGroup[this.item.id].comment,
              id: this.item.id
            });

            console.log(this.handleGroup);

            this.Toast({
              message: res.message,
              position: 'bottom',
              duration: 500
            });
            this.$emit('updataCollect');
          }
        });
      },

      //点赞
      async travelPraise(collectionId){

        if (this.preventRepeatRequest) {
          return;
        }
        this.preventRepeatRequest = true;
        await Praise({
          id: collectionId,
          praiseType: 1
        }).then(res => {
          this.preventRepeatRequest = false;
          if (res.status === 200) {

            this.handleGroup[this.item.id].like += res.obj.praiseed ? 1 : -1;

            this.MUTUALLY_HANDLE({
              like: this.handleGroup[this.item.id].like,
              likestatus: res.obj.praiseed,

              collect: this.handleGroup[this.item.id].collect,
              collectstatus: this.handleGroup[this.item.id].collectstatus,

              read:this.handleGroup[this.item.id].read,
              comment: this.handleGroup[this.item.id].comment,
              id: this.item.id
            });

            this.Toast({
              message: res.message,
              position: 'bottom',
              duration: 500
            });
          }
        });
      },
    },
  }
</script>

<style lang="scss">
  @import '../../style/mixin';

  .notes-fav {
    display: flex;
    position: relative;
    li {
      padding-bottom: p2r(16);
      width: 19%;
      &:last-child {
        width: 24%;
      }
      span {
        &:before {
          padding-right: p2r(15);
        }
        @include sc(p2r(24), $fc);
        height: p2r(35);
        line-height: p2r(35);
        padding: 0 p2r(30) 0 0;
      }

      .i-text {
        display: inline-block;
        border: 1px solid $bc;
        @include borderRadius(p2r(13));
        @include sc(p2r(20), $fc);
        line-height: p2r(32);
        font-style: normal;
        padding: 0 p2r(8);
        white-space: nowrap;
      }
    }
    .time {
      text-align: right;
    }
  }

  .icon-all {
    @include ct();
    font-family: "iconfont" !important;
    font-style: normal;
    -webkit-font-smoothing: antialiased;
    @include sc(p2r(40), $fc2);
    display: inline-block;
  }

  .span-fav:before {
    content: '\E644';
  }

  .span-fav-a:before {
    content: '\E644';
    color: red;
  }

  .span-msg:before {
    content: '\e667';
  }

  .span-msg-a:before {
    content: '\e666';
  }

  .span-collect:before {
    content: '\e669';
  }

  .span-collect-a:before {
    content: '\e668';
    color: red;
  }

  .span-view-a:before {
    content: '\e73c';
  }

  .span-view:before {
    content: '\e73d';
  }

  .span-view-a:before {
    content: '\e73c';
  }
</style>
