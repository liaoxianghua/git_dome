<template>
  <div class="menu-block">
    <ul class="menu-list-travel" v-show="isdisplay">
      <li
        @click.prevent="goEditPage"
        v-show=" currentStatu!==1 || currentTravel.type!==1"
        class="iconfont icon-edit ">

        <a>编辑</a>
      </li>
      <li class="iconfont icon-delete active" @click="travelDelete">删除</li>
    </ul>
    <p class="iconfont icon-moreandroid" @click="changShow()"></p>
  </div>
</template>

<script>
  import {deletemytravel} from '../../service/getData'
  export default {
    data(){
      return {
        isdisplay: false,
      }
    },
    props: ['currentStatu', 'TravelId', 'currentTravel', 'isShow'],

    methods: {
      async travelDelete(){
        this.isdisplay = false;
        await this.messageBox.confirm('确定删除？');
        await deletemytravel(this.TravelId).then(res => {
          if (res.status === 200) {
            this.$emit('deletetravel', this.TravelId);
          }
        });
      },
      changShow(){
        this.isdisplay = !this.isdisplay;
      },
      goEditPage(){
        this.isdisplay = false;
        this.$router.push({
          path: 'myTravelIndex/travelEditor',
          query: {editstatus: this.currentStatu, editorid: this.TravelId, edittravel: this.currentTravel}
        });
      },
    },
    watch: {
      isShow: function () {
        this.isdisplay = false;
      }
    }
  }

</script>

<style lang="scss">
  @import '../../style/mixin';
  @import '../../assets/iconfont/iconfont.css';
  /*菜单*/
  .menu-block {
    position: absolute;
    top: p2r(20);
    right: p2r(12);
    display: flex;
    > p {
      @include sc(p2r(38), $mc);
    }
  }

  .menu-list-travel:after {
    content: '';
    display: inline-block;
    width: p2r(12);
    height: p2r(12);
    background: $bgc2;
    border-bottom: 1px solid $bc;
    border-right: 1px solid $bc;
    transform: rotate(-45deg);
    position: absolute;
    top: p2r(14);
    right: p2r(-9);
  }

  .menu-list-travel {
    padding: 0 p2r(12);
    border: 1px solid $bc;
    border-radius: p2r(8);
    background: $bgc2;
    position: relative;
    margin-right: p2r(12);
    li {
      border-bottom: 1px solid $bc;
      padding: p2r(30);
      width: p2r(200);
      text-align: center;
      font-size: p2r(32);
    }
    li:before {
      margin-right: p2r(25);
    }
    li:last-child {
      border-bottom: none;
    }
    .active {
      color: #fe5a5a;
      a {
        color: #fe5a5a;
      }
    }
  }

  .menudisplay {
    display: none;
  }
</style>
