<template>
  <div class="tip-wrap">
    <section class="tip-container">
      <p class="tip-text" v-if="alertText">{{alertText}}</p>
      <div class="tip-btn">
        <slot name="btn"></slot>
      </div>
    </section>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        timer: null,
      }
    },
    mounted(){

    },
    props: ['alertText'],
    methods: {
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  @keyframes tipMove {
    0% {
      transform: scale(1)
    }
    35% {
      transform: scale(.8)
    }
    70% {
      transform: scale(1.1)
    }
    100% {
      transform: scale(1)
    }
  }

  .tip-wrap {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 200;
    background-color: rgba(0, 0, 0, 0.4);
  }

  .tip-container {
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: p2r(-222);
    margin-left: p2r(-222);
    width: p2r(444);
    animation: tipMove .4s;
    background-color: rgba(255, 255, 255, 1);
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    @include borderRadius(p2r(12));
    overflow: hidden;
    .tip-text {
      @include sc(p2r(30), $mc);
      line-height: 1.4;
      text-align: center;
      padding: p2r(50) p2r(20);
    }
    .tip-btn {
      @include fj();
      border-top: 1px solid $bc;
      width: 100%;
      .btn-item {
        flex: 1;
        border-right: 1px solid $bc;
        text-align: center;
        line-height: p2r(80);
        font-weight: bold;
        @include sc(p2r(32), $mc);
        &:last-child {
          border: none;
        }
      }
    }
  }

</style>
