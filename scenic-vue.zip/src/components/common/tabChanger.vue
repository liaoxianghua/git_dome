<template>
  <div>
    <ul class="tab-btn-blcok tab-pattern1" >
      <li v-for="(item,index) in items"  @click.prevent="tabChang(index,item.view)" :class="{active:activeIndex===index}" >{{item.title}}</li>
    </ul>
    <section class="tab-content-blcok">
      <div>{{items[activeIndex].content}}</div>
    </section>
  </div>
</template>

<script>
    export default {
      data(){
          return {
              activeIndex:0,
              currentView:'child1',
              items:[
                {title:"一个1",view:'child1'},
                {title:"一个2",view:'child2'}
              ]
          }
      },
      methods:{
          tabChang(index,currentView){
            this.activeIndex = index;
            this.currentView = currentView;
          }
      }
    }
</script>

<style lang="scss">
  @import '../../style/mixin';


  .tab-content-blcok{
   /* div{
      display:none;
    }
    .active{
      display:block;
    }*/
  }
</style>
