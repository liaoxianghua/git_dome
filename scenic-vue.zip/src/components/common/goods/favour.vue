<template>
  <div class="favour" v-if="id">
    <span :class="{'favour-active':commentFavour[id].praised}" @click="setFavour()"><i
      class="icon iconfont icon-appreciate"></i> {{commentFavour[id].praiseCount}}</span>
  </div>
</template>

<script>
  import {Praise} from 'src/service/getData'
  import {mapState, mapMutations} from 'vuex'

  export default {
    data(){
      return {
        id: 0
      }
    },
    props: ['item'],
    created(){
    },
    mounted(){
      this.init();
    },
    computed: {
      ...mapState([
        'login', 'commentFavour'
      ]),
    },
    methods: {
      ...mapMutations([
        'EDIT_COMMENTFAVOUR'
      ]),
      init: function () {
        this.id = this.item.id;
        this.EDIT_COMMENTFAVOUR({praised: this.item.praised, praiseCount: this.item.praiseCount, id: this.id});
      },
      setFavour: async function (id) {
        let param = {id: this.id, praiseType: 2};
        let res = await Praise(param);
        if (res.status === 200) {
          let item = this.commentFavour[this.id];
          if (res.obj.praiseed) {
            item.praised = res.obj.praiseed;
            item.praiseCount++
          }
          else {
            item.praised = res.obj.praiseed;
            item.praiseCount--
          }
          this.EDIT_COMMENTFAVOUR(item);

          this.Toast({message: res.message, position: 'bottom'});
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .favour {
    overflow: hidden;
    span {
      float: right;
      @include sc(p2r(26), $fc);
      border: p2r(2) solid $bc;
      padding: p2r(6) p2r(12);
      @include borderRadius(p2r(6));
    }
    .span-active {
      color: $fc3;
    }
    .favour-active {
      color: red;
    }
  }
</style>
