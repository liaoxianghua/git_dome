<template>
  <div class="loading_container">
    <div class="load_img" :style="{backgroundPositionY: -(positionY%7)*2.5 + 'rem'}">
    </div>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        positionY: 0,
        timer: null,
      }
    },
    mounted(){
      /*this.timer = setInterval(() => {
       this.positionY ++;
       }, 600)*/
    },
    beforeDestroy(){
      //clearInterval(this.timer);
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  @keyframes load {
    0% {
      transform: scale(1);
    }
    50% {
      transform: scale(0.9);
    }
    100% {
      transform: scale(1);
    }
  }

  .loading_container {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    @include wh(4.5rem, 4.5rem);

  }

  .load_img {
    @include wh(100%, 100%);
    background: url(../../images/hz.png) no-repeat;
    background-size: 100% 100%;
    animation: load .6s infinite ease-in-out;
    position: relative;
    z-index: 11;
  }
</style>
