<template>
  <div class="ui-body ui-white-bg page-padding">
    <!--居住地址三级联动选项-->
    <head-top headTitle="地址选择">
      <a class="btn-left btn-char btn-back btn-all" href="#" @click.prevent="closeSiteSelect" slot="btn"></a>
    </head-top>
    <div class="siteTitle">
      <div class="area" @click="statedSelected" :class="State?'':'active'">{{State ? State : '请选择'}}</div>
      <div class="area" @click="provinceSelected" :class="Province?'':'active'" v-show="showProvinceList">
        <span>{{Province ? Province : '请选择'}}</span>
      </div>
      <div class="area" @click="citySelected" :class="City?'':'active'" v-show="showCityList">{{City ? City : '请选择'}}</div>
    </div>
    <div class="ui-container">
      <section class="address">
        <ul class="city-list">
          <!--国家-->
          <li class="addList" v-for="(v,k) in stateList" @click="getStateId(v.id, v.name,k,v.valid)" v-show="showState"
              :class="{active : v.selected , disabled : !v.valid }">{{v.name}}</li>
          <!--省份-->
          <li class="addList" v-for="(v,k) in showProvinceList" @click="getProvinceId(v.id, v.name, k ,v.valid)"
              v-show="showProvince" :class="{active : v.selected , disabled : !v.valid }">{{v.name}}</li>
          <!--城市-->
          <li class="addList" v-for="(v,k) in showCityList" @click="getCityId(v.id, v.name, k , v.valid)"
              v-show="showCity" :class="{active : v.selected , disabled : !v.valid }">{{v.name}}</li>
        </ul>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {initAddressData} from 'src/service/getData'

  export default {
    components: {
      headTop
    },
    data () {
      return {
        showState: true, //国家
        showProvince: false,//省份
        showCity: false,//城市

        stateList: null, //国家列表
        showProvinceList: null, //省级列表
        showCityList: null,  //城市列表

        state: null,  //国家
        province: null, //省
        city: null,  //城市

        State: null, //国家
        Province: null,//省
        City: null,

        // v-for循环判断是否为当前
        selected: false,
      }
    },

    mounted(){
      this.getInitData();
    },
    methods: {
      async getInitData(){
        await initAddressData().then(res => {
          if (res.status === 200) {
            this.stateList = res.obj.addressData;
          }
        });
      },
      _filter (list, name, k){
        let result = [];
        for (let i in list[k]) {
          if (i === name) {
            result = list[k][i];
          }
        }
        return result;
      },
      getStateId(id, name, k, suatus){
        if (!suatus) {
          return
        }
        this.state = id;
        this.State = name;

        this.showState = false;
        this.showProvince = true;
        this.showCity = false;
        this.showProvinceList = this._filter(this.stateList, 'provinceList', k);

        if (this.stateList[k].cityList) {
          if (this._filter(this.stateList, 'cityList', k).length) {
            let cityList = this._filter(this.stateList, 'cityList', k);
            this.showProvinceList = [...this.showProvinceList, ...cityList];
          }
        }

        //点击选择当前
        this.stateList.map(a => a.selected = false);
        this.stateList[k].selected = true;
      },
      statedSelected(){
        this.showProvinceList = null;
        this.showCityList = null;

        this.State = null;
        this.Province = null;
        this.City = null;

        this.showState = true;
        this.showProvince = false;
        this.showCity = false;
      },
      getProvinceId(id, name, k, suatus){
        if (!suatus) {
          return
        }

        this.province = id;
        this.Province = name;
        this.showState = false;
        this.showProvince = false;
        this.showCity = true;

        if (!this.showProvinceList[k].cityList) {
          this.$emit('siteData', {state: this.state, city: this.province, State: this.State, City: this.Province});
          this.closeSiteSelect();
          return
        }

        this.showCityList = this._filter(this.showProvinceList, 'cityList', k);

        //点击选择当前
        this.showProvinceList.map(a => a.selected = false);
        this.showProvinceList[k].selected = true;
      },
      provinceSelected(){
        this.showCityList = null;

        this.Province = null;
        this.City = null;

        this.showState = false;
        this.showProvince = true;
        this.showCity = false;
      },
      getCityId(id, name, k, suatus){

        if (!suatus) {
          return
        }

        this.city = id;
        this.City = name;

        //点击选择当前
        this.showCityList.map(a => a.selected = false);
        this.showCityList[k].selected = true;
        this.$emit('siteData', {
          state: this.state,
          province: this.province,
          city: this.city,
          State: this.State,
          Province: this.Province,
          City: this.City
        });
        this.closeSiteSelect();
      },
      closeSiteSelect(){
        this.$emit('closeSiteSelect');
      },
      citySelected(){
        this.showState = false;
        this.showProvince = false;
        this.showCity = true;
      },
    },
  }
</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .page-padding {
    padding-top: p2r(184);
  }

  .siteTitle {
    position: absolute;
    top: p2r(88);
    left: 0;
    right: 0;
    @include wh(100%, p2r(96));
    display: flex;
    align-items: center;
    border-bottom: 1px solid $bc;
    background: $bgc2;
    z-index: 50;
    .area {
      font-size: p2r(28);
      padding: 0 p2r(30);
    }
    .active {
      border-bottom: p2r(4) solid $blue;
      line-height: p2r(94);
      color: $blue;
    }
  }

  .city-list {
    li {
      height: p2r(80);
      font-size: p2r(24);
      padding: 0 p2r(20);
      border-bottom: 1px solid $bc;
      line-height: p2r(79);
      position: relative;
      overflow: hidden;
    }

    .disabled {
      color: $fc;
    }

    .active {
      color: $blue;
    }
    .active:before {
      content: '';
      display: block;
      width: p2r(15);
      height: p2r(30);
      border-right: 1px solid $blue;
      border-bottom: 1px solid $blue;
      transform: rotate(45deg) translateY(-90%);
      position: absolute;
      top: 50%;
      right: p2r(50);
    }
  }
</style>
