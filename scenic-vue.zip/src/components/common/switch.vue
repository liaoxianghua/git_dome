<template>
  <div class="on-off-box" :class="[isOff?'off':'on']" @click="changer">
    <input id="isReceive" type="checkbox">
    <span for="isReceive"></span>
  </div>
</template>

<script>
    export default {
      data(){
        return {
        }
      },
      props: ['isOff'],
      computed:{
      },
      methods:{
        changer(){
          this.$emit('changer');
        },
      }
    }
</script>

<style lang="scss">
  @import '../../style/mixin';
  /*开关图标样式*/
  .on-off-box{
    width:p2r(100);
    position:relative;
    border-radius: p2r(31);
    height:p2r(60);
    span{
      width:p2r(56);
      height:p2r(56);
      background:$bgc2;
      border-radius: 50%;
      display:block;
      position:absolute;
      top:p2r(2);
    }
    input{
      visibility: hidden;
    }
  }

  .off{
    background:#4dd865;
    span{
      right:p2r(2);
      box-shadow:p2r(-1) p2r(0) p2r(2) $mc;
    }
  }
  .on{
    background:$fc2;
    border:1px solid $bc;
    span{
      border:1px solid $bc;
      left:p2r(0);
      box-sizing: border-box;
      top:0;
      box-shadow:p2r(2) p2r(0) p2r(4) $bc;
    }
  }
</style>
