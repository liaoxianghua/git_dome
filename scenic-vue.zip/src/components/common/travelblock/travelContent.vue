<!--游记展示-->
<template>
    <div class="travel-wrapper">
        <list-title titleText="游记"></list-title>
        <div class="travel-content  sides-mar">
            <div class="user-head">
                <img src="../../../images/elmlogo.jpeg" alt="">
                <p class="inaline">我叫啥子嘛</p>
            </div>
            <h3>去了一次汤口</h3>
            <p class="ellipsis">去了一趟道口，到了到了好开心，完了完了要刺激，美了美了不要命！</p>
            <img src="../../../images/banner.png" alt="">
            <div class="travel-comment">
              <div>
                <p>112345</p>
                <p>112345</p>
                <p>112345</p>
              </div>
                <p class="issue-time">1分钟前</p>
            </div>
        </div>
    </div>
</template>

<script>
    import listTitle from './traveTitle';
    export default{
        components:{
            listTitle,
        }
    }
</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';
    /*游记*/
  .travel-wrapper{
    @include bmb;
  }
    .travel-content{
      padding:0 p2r(20);
    h3{
        font-size:p2r(26);
        line-height:1;
        margin-bottom:p2r(10);
    }
    >p{
         @include sc();
         line-height: (44/24);
         margin-bottom:p2r(1);
     }
    >img{
         width:100%;
         max-height: p2r(240);
     }
    }

    .user-head{
      padding:p2r(20) p2r(10);
      display:flex;
      img{
          width:p2r(72);
          border:p2r(1) solid $bc;
          border-radius: 50%;
          height:p2r(72);
          margin-right:p2r(10);
      }
      p{
          align-self:center;
          font-size: p2r(26);
      }
    }
    .travel-comment{
      display:flex;
      padding:p2r(20) 0;
      @include fj;
      >div{
        display: flex;
        p{
          display:flex;
          align-items: center;
          flex:1;
          padding:0 p2r(5);
          width:p2r(158);
        }
        p:before{
          margin-right:p2r(22);
          content: '';
          display: inline-block;
        }
        p:first-child:before{
          @include wh(p2r(24),p2r(24));
          @include bis('../../../images/icon/praise-icon.png')
        }
        p:nth-child(2):before{
          @include wh(p2r(28),p2r(26));
          @include bis('../../../images/icon/comment-icon.png')
        }
        p:nth-child(3):before{
          @include wh(p2r(24),p2r(22));
          @include bis('../../../images/icon/share-icon.png')
        }
        p:last-child{
          margin:0;
        }
      }
      p{
        @include sc();
      }
      .issue-time{
          text-align: center;
          border:p2r(1) solid $bc;
          font-size: p2r(20);
          border-radius: p2r(13);
          padding:0 p2r(10);
          line-height:(26/20);
      }
    }

</style>
