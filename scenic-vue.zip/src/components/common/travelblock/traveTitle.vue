<!--列表title-->
<template>
    <div class="home-module-title">
        <div class="title-text" >
            <h3 v-if="titleText">{{titleText}}</h3>
          <slot name="img-title"></slot>
        </div>
      <slot name="more" class="more"></slot><!--搜索-->
    </div>
</template>

<script>
    export default{
      props:['titleText'],
    }
</script>

<style lang="scss" scoped>
  @import '../../../style/mixin';

    /*模块中的tit样式*/
    .home-module-title{
        display: flex;
        border-bottom:1px solid $bc;
        padding:p2r(20) p2r(20);
        justify-content: space-between;
        line-height:1;
        background:$fc2;
    h3{
        @include sc(p2r(30));
        padding-left:p2r(15);
        border-left:p2r(4) solid $fc3;
        align-self: center;
        line-height:1;
    }
    .title-text>img{
        float: left;
        max-width:p2r(200);
        max-height:p2r(22);
        margin-left:p2r(20);
        display:block;
        margin-top:p2r(2);
    }
    .title-text{
        display:flex;
    }
    .more{
        @include sc(p2r(24),$fc);
      display:flex;
      align-items: center;
      margin-right:p2r(12);
      a{
        color: $fc;
      }
    }
    .more:after{
      display: inline-block;
      content:'';
      align-self: center;
      margin-left:p2r(18);
      @include wh(p2r(14),p2r(28));
      @include bis('../../../images/icon/enter-icon.png');
    }
    }
</style>
