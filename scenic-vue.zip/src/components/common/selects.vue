<template>
  <div class="ui-body ui-padding-header ui-gray-bg">
    <head-top :headTitle="selectTitle">
      <div class="btn-left btn-back btn-all" @click="closeSelect" slot="btn"></div>
    </head-top>
    <div class="ui-container">
      <section class="option-wrap">
        <ul class="list">
          <template v-for="item in optionArr">
            <li class="disable" v-if="item.disable">
              {{item.text}} <i class="i-icon icon-roundcheckfill" v-show="selectedValue == item.value"></i>
            </li>
            <li @click="changeSelect(item.value,item.text)" v-else>
              {{item.text}} <i class="i-icon icon-roundcheckfill" v-show="selectedValue == item.value"></i>
            </li>
          </template>
        </ul>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {}
    },
    props: ['selectTitle', 'optionArr', 'selectedValue', 'selectedText'],
    components: {
      headTop,
    },
    methods: {
      changeSelect: function (val, text) {
        this.$emit('changeSelect', val, text);
        this.closeSelect();
      },
      closeSelect: function () {
        this.$emit('closeSelect');
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .option-wrap {
    .list {
      background-color: $bgc2;
      li {
        padding: p2r(20) p2r(20);
        border-bottom: 1px solid $bc;
        @include sc(p2r(28), $mc);
        line-height: p2r(40);
        position: relative;
        overflow: hidden;
        .i-icon {
          @include ct();
          font-family: "iconfont" !important;
          font-style: normal;
          -webkit-font-smoothing: antialiased;
          @include sc(p2r(40), $blue);
          line-height: p2r(88);
          display: inline-block;
          right: p2r(20);
        }
        &.disable {
          color: $fc;
        }
      }
    }
  }
</style>
