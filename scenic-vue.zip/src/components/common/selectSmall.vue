<template>
  <div class="ui-body page-body">
    <div class="ui-container">
      <section class="small-option-wrap">
        <ul class="list">
          <li v-for="item in optionArr" @click="changeSelect(item.value,item.text)">
            {{item.text}} <i class="i-icon icon-check" v-show="selectedValue == item.value"></i>
          </li>
        </ul>
        <div class="small-close" @click="closeSelect" slot="btn">取消</div>
      </section>
    </div>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'

  export default {
    data(){
      return {}
    },
    props: ['optionArr', 'selectedValue', 'selectedText'],
    components: {
      headTop,
    },
    methods: {
      changeSelect: function (val, text) {
        this.$emit('changeSelect', val, text);
        this.closeSelect();
      },
      closeSelect: function () {
        this.$emit('closeSelect');
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';

  .page-body {
    background-color: rgba(0, 0, 0, 0.8);
  }

  .small-option-wrap {
    width: 90%;
    position: absolute;
    left: 5%;
    bottom: p2r(24);
    .list {
      background-color: $bgc2;
      @include borderRadius(p2r(16));
      overflow: hidden;
      margin-bottom: p2r(24);
      li {
        padding: p2r(20) p2r(20);
        border-bottom: 1px solid $bc;
        @include sc(p2r(28), $mc);
        line-height: p2r(40);
        position: relative;
        .i-icon {
          @include ct();
          font-family: "iconfont" !important;
          font-style: normal;
          -webkit-font-smoothing: antialiased;
          @include sc(p2r(40), $blue);
          line-height: p2r(88);
          display: inline-block;
          right: p2r(20);
        }
        &:last-child{
          border: none;
        }
      }
    }
    .small-close {
      background-color: $bgc2;
      padding: p2r(20) p2r(20);
      @include sc(p2r(34), $blue);
      line-height: p2r(40);
      @include borderRadius(p2r(16));
      text-align: center;
    }
  }
</style>
