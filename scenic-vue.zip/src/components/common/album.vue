<template>
  <transition name="router-slidT" mode="out-in">
    <div class="slide-album" v-if="picUrl">
      <div class="item"><img :src="picUrl"></div>
      <div class="close" @click="closeAlbum()"><i class="icon iconfont icon-roundclose"></i></div>
    </div>
  </transition>
</template>

<script>

  export default {
    data(){
      return {
        pic: null
      }
    },
    props: ['picUrl'],
    mounted(){
    },
    methods: {
      closeAlbum: function () {
        this.$emit('closeAlbum');
      }
    }
  }
</script>

<style lang="scss">
  @import 'src/style/mixin';

  .slide-album {
    @include wh(100%, 100%);
    background-color: rgba(0, 0, 0, 0.8);
    position: fixed;
    left: 0;
    top: 0;
    z-index: 101;
    .item {
      width: 100%;
      height: 82%;
      overflow: hidden;
      position: absolute;
      left: 0;
      top: 6%;
      img {
        max-width: 100%;
        max-height: 100%;
        @include center;
      }
    }
    .close {
      @include cl;
      bottom: p2r(24);
      .icon {
        @include sc(p2r(64), $fc);
      }
    }
  }
</style>
