<!--
<template>
  <div class="item">
    <div class="thum">
      <video ref="video" class="video-thum" preload="auto" :poster="videoitem.pictureUrl" @loadedmetadata="play"  @click="play" :src="videoitem.skipUrl">
      </video>
    </div>
    <div class="user-info">
      <img src="../../images/head_img.jpg" class="img-head">
      <span class="span-title ellipsis">{{videoitem.subTitle}}</span>
      <span class="span-name">郭小明</span>
      <a class="a-fav" @click="videoPraise(videoitem.id,videoitem.isFlag)"><i class="i-fav"></i><br>{{videoitem.pointPraiseCount+addend}}</a>
    </div>
    &lt;!&ndash;播放按钮&ndash;&gt;
    <div v-show="!isPlay" class="live-control"><a class="a-play" @click="play"></a></div>
  </div>
</template>

<script>
  import {Praise} from '../../service/getData'
    export default {
      data(){
        return {
          isPlay:false,
          ispraise:0,
          addend:0,
        }
      },

      methods: {
        play(){
          let videos = this.$refs.video;
          this.isPlay = true;
          if(videos.paused){
            videos.play();
          }else{
            videos.pause();
            this.isPlay = false;
          }
        },

        //点赞
        async videoPraise(currentId,Flag){
          if(Flag > 0){
            if(this.ispraise === 0){
              this.ispraise = 1;
              this.addend = 0;
            }else{
              this.ispraise = 0;
              this.addend = -1;
            }

          }else{
            if(this.ispraise === 0){
              this.ispraise = 1;
              this.addend = 1;
            }else{
              this.ispraise = 0;
              this.addend = 0;
            }
          }
          await Praise({
            id:currentId,
            type:this.ispraise,
            praiseType:3
        }).then( res => {
          if(res.status !== 200){
              return
          }
        });
        }
      }
    }
</script>

<style lang="scss">
  @import '../../style/mixin';
  .live-list {
    .item {
      position: relative;
      margin-bottom: p2r(10);
      &:last-child {
        margin-bottom: none;
      }
      .thum {
        .img-thum {
          width: 100%;
        }
        .video-thum{
          width: 100%;
        }
      }
      .user-info {
        position: absolute;
        left: p2r(20);
        right: p2r(20);
        bottom: p2r(26);
        background: rgba(255, 255, 255, 0.9);
        padding: p2r(6) 0;
        @include borderRadius(p2r(12));
        height: p2r(84);
        .img-head {
          @include wh(p2r(54), p2r(54));
          @include borderRadius(p2r(30));
          float: left;
          margin: p2r(8) p2r(32);
        }
        span {
          @include sc(p2r(28), $mc);
          width: p2r(380);
          line-height: 1.3;
        }
        .span-title {
          display: block;
          float: left;
        }
        .span-name {
          float: left;
        }
        .a-fav {
          @include ct;
          right: p2r(12);
          @include sc(p2r(24), #fc2871);
          text-align: center;
          line-height: 1;
        }
        .i-fav {
          @include wh(p2r(40), p2r(40));
          @include bis("../../images/icon/icon_live_fav.png");
          display: inline-block;
          @include borderRadius(p2r(20));
        }
      }
      .live-control {
        position:absolute;
        top:0;
        bottom:0;
        left:0;
        right:0;
        background:rgba(0,0,0,.5);
        a {
          display: inline-block;
          @include wh(p2r(80), p2r(80));
        }
        .a-play {
          @include center;
          @include bis("../../images/icon/icon_live_play.png");
        }
        .a-pause{
          border-radius: 50%;
          background:rgba(0,0,0,.7);
          text-align: center;
        }
        .a-pause:after{
          content: '';
          display:inline-block;
          width:p2r(20);
          height:p2r(40);
          border-left:p2r(5) solid rgba(255,255,255,.8);
          border-right:p2r(5) solid rgba(255,255,255,.8);
          margin-top:p2r(20);
        }
      }
    }
  }
</style>
-->
