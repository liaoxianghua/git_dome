<template>
  <header id="head_top" class="head-top" v-bind:class="{nobg:noBG}">
    <slot name="btn"></slot>
    <section class="title_head ellipsis" v-if="headTitle">
      <span class="title_text ellipsis">{{headTitle}}</span>
    </section>
  </header>
</template>

<script>
  export default {
    data(){
      return {}
    },
    mounted(){
      /*this.$refs.footer.addEventListener('touchmove', function (e) {
       e.preventDefault();
       });*/
    },
    props: ['headTitle', 'noBG'],
  }

</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  .head-top {
    background-color: $blue;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    height: p2r(88);
    .title_head {
      @include center;
      width: 50%;
      color: #fff;
      text-align: center;
      padding-bottom: p2r(8);
      .title_text {
        @include sc(p2r(34), $fc2);
        text-align: center;
      }
    }

    .btn-all {
      @include ct();
      font-family: "iconfont" !important;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      @include sc(p2r(40), $fc2);
      line-height: p2r(88);
      display: block;
    }

    .btn-left {
      left: p2r(30);
    }

    .btn-right {
      right: p2r(30);
    }

    .btn-right-1 {
      right: p2r(100);
    }

    .btn-char {
      font-family: "Microsoft Yahei", sans-serif;
      @include sc(p2r(28), $fc2);
    }

    .btn-back {
      &:before {
        content: "\E679";
      }
    }

    .btn-edit {
      &:before {
        content: "\E649";
      }
    }

    .btn-search {
      &:before {
        content: "\E65C";
      }
    }

    .btn-fav {
      &:before {
        content: "\E669";
      }
    }

    .btn-fav-1 {
      &:before {
        content: "\E668";
      }
    }

    .btn-share {
      &:before {
        content: "\E6f3";
      }
    }
  }

  .nobg {
    background: none;
  }
</style>
