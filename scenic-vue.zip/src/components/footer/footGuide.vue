<template>
  <section id='foot_guide' ref="footer">
    <section @click="gotoAddress({path: '/home'})" class="guide_item" :class="{'active':path ==='home'}">
      <i class="icon icon-home"></i>
      <span>首页</span>
    </section>
    <section @click="gotoAddress({path: '/strategy'})" class="guide_item" :class="{'active':path ==='strategy'}">
      <i class="icon icon-str"></i>
      <span>攻略</span>
    </section>
    <section @click="gotoAddress('/message')" class="guide_item">
      <i class="icon icon-msg"></i>
      <span>消息</span>
    </section>
    <section @click="gotoAddress('/user')" class="guide_item" :class="{'active':path ==='user'}">
      <i class="icon icon-user"></i>
      <span>我的</span>
    </section>
  </section>
</template>

<script>
  export default {
    data(){
      return {
        path: null,//路由路径
      }
    },
    created(){
      this.path = this.$route.path.replace('/', '');
    },
    mounted(){
      this.$refs.footer.addEventListener('touchmove', function (e) {
        e.preventDefault();
      });
    },
    computed: {
    },
    methods: {
      gotoAddress(path){
        this.$router.push(path);
      }
    },
    watch: {
      $route: function () {
        this.path = this.$route.path.replace('/', '');
      }
    }
  }


</script>

<style lang="scss" scoped>
  @import '../../style/mixin';

  #foot_guide {
    background-color: #fff;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    box-shadow: 0 -0.026667rem 0.053333rem rgba(0, 0, 0, .1);
    height: p2r(98);
    overflow: hidden;
  }

  .guide_item {
    flex: 1;
    display: flex;
    text-align: center;
    flex-direction: column;
    align-items: center;
    padding: p2r(6) 0;
    span {
      display: block;
      @include sc(p2r(24), $mc);
      margin-top: p2r(6);
    }
    .icon {
      font-family: "iconfont" !important;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      @include sc(p2r(40), $mc);
      line-height: p2r(40);
      display: block;
      width: 100%;
      overflow: hidden;
      margin-top: p2r(6);
    }
    .icon-home {
      &:before {
        content: "\E6B8";
      }
    }
    .icon-str {
      &:before {
        content: "\E649";
      }
    }
    .icon-msg {
      &:before {
        content: "\E731";
      }
    }
    .icon-user {
      &:before {
        content: "\E736";
      }
    }
  }

  .active {
    color: $fc3;
    span {
      color: $fc3;
    }
    .icon {
      color: $fc3;
    }
  }

</style>
