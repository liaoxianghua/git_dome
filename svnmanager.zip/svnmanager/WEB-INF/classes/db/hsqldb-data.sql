insert into server_info (id,host,name,user_name,password)
values(1,'192.168.1.208','208_虚拟机','root','123456')

insert into server_info (id,host,name,user_name,password)
values(2,'192.168.1.13','13测试机','weblogic10','zaqwsx1234')

insert into server_info (id,host,name,user_name,password)
values(3,'192.168.1.55','测试机Scm','has','123456')

insert into weblogic_info (id,server_id,name,host,port,wl_user,wl_password,domainPath,weblogicPath,monitor)
values(1,2,'7001web','192.168.1.13','7001','weblogic10','Weblogic10tour','/u01/weblogic10/bea/user_projects/domains/tour-new1','/u01/weblogic10/bea/wlserver_10.3/server',2);

update weblogic_info set appPath='/u02/applications/tour_test1.6/test_baseline',backupPath='/u02/applications/tour_test1.6' where id=1;

insert into weblogic_info (id,server_id,name,host,port,wl_user,wl_password,domainPath,weblogicPath,monitor)
values(2,2,'3001web','192.168.1.13','3001','weblogic','weblogic10tour','/u01/weblogic10/bea/user_projects/domains/dbtest','/u01/weblogic10/bea/wlserver_10.3/server',2);
update weblogic_info set appPath='/u02/applications/tour_test1.6/baseline',backupPath='/u02/applications/tour_test1.6' where id=2;

insert into weblogic_info (id,server_id,name,host,port,wl_user,wl_password,domainPath,weblogicPath,monitor)
values(3,1,'208_VM','192.168.1.208','7001','weblogic','12345678','/home/weblogic/user_projects/domains/base_domain','/home/weblogic/wlserver_12.1/server',2);
update weblogic_info set appPath='/home/remote',backupPath='/home/remote' where id=3;

insert into weblogic_info (id,server_id,name,host,port,wl_user,wl_password,domainPath,weblogicPath,monitor)
values(4,3,'55_local','192.168.1.55','7001','weblogic','12345678','E:\bea\user_projects\domains\base_domain','E:\bea\wlserver_12.1\server',2);

insert into weblogic_info (id,server_id,name,host,port,wl_user,wl_password,domainPath,weblogicPath,monitor)
values(5,2,'9090','192.168.1.13','9090','weblogic10','weblogic10','/u01/weblogic12c/bea/user_projects/domains/touradmin','/u01/weblogic12c/bea/wlserver_12.1/server',2);

update weblogic_info set appPath='/u01/weblogic12c/bea/user_projects/domains',backupPath='/home/weblogic10/9090' where id=5;
