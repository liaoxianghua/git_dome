create table code(
	id integer not null IDENTITY,
	cid integer,
	name varchar(200),
	val integer
);

create table weblogic_info(
	id numeric(15) not null IDENTITY,
	server_id numeric(15) not null,
	name varchar(100),
	host varchar(20),
	port integer,
	wl_user varchar(20),
	wl_password varchar(20),
	domainPath varchar(255),
	weblogicPath varchar(255),
	backupPath varchar(255),
	appPath varchar(255),
	monitor integer default 2 --1 启用 2 禁用
	
);

--服务器信息
create table server_info(
	id numeric(15) not null IDENTITY,
	host varchar(20), --主机地址
	name varchar(20), --主机别名
	user_name varchar(20),--ssh用户名
	password varchar(20)--ssh 密码
)

create table jdbc_info(
	id numeric(15) not null IDENTITY,
	weblogic_id integer not null,
	name varchar(100),
	ActiveConnectionsCurrentCount integer,
	ActiveConnectionsAverageCount integer,
	ConnectionsTotalCount integer,
	CurrCapacity integer,
	CurrCapacityHighCount integer,
	LeakedConnectionCount integer,
	WaitingForConnectionCurrentCount integer,
	WaitingForConnectionFailureTotal integer,
	WaitingForConnectionTotal integer,
	WaitingForConnectionHighCount integer,
	date timestamp
);

create table memory_info(
	id numeric(15) not null IDENTITY,
	weblogic_id integer not null,
	free numeric(15),
	total numeric(15),
	used numeric(15),
	thread integer,
	date timestamp
);

create table thread_pool_info(
	id numeric(15) not null IDENTITY,
	weblogic_id integer not null,
	completedRequestCount numeric(15),
	executeThreadIdleCount integer,
	executeThreadTotalCount integer,
	hoggingThreadCount integer,
	minThreadsConstraintsCompleted numeric(15),
	minThreadsConstraintsPending integer,
	pendingUserRequestCount integer,
	queueLength integer,
	standbyThreadCount integer,
	throughput numeric(12,3),
	date timestamp
);
