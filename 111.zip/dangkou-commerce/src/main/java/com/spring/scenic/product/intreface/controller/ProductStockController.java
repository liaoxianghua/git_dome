package com.spring.scenic.product.intreface.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.intreface.controller.CommonController;
import com.spring.scenic.product.application.ProductStockLogService;
import com.spring.scenic.product.application.ProductStockService;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.domain.ProductStockLog;
import com.spring.scenic.product.domain.vo.ProductStockVo;

@Controller
@RequestMapping(value = "/productStock")
public class ProductStockController extends CommonController {
	static Logger logger = LoggerFactory.getLogger(ProductStockController.class) ;
	@Resource
	private ProductStockService productStockService ;
	@Resource
	private ProductStockLogService productStockLogService;

	/**
	 * 添加或批量更新操作
	 * @param 套餐ID 
	 * @param 产品类型  
	 * @param 事件类型 添加或者修改 add update  
	 * @return
	 * @creator ：lenovo  
	 * @date ：2017年4月17日     
	 **
	 */
	@RequestMapping(value = "/productStockAdd")
	public String productStockAdd(Integer mealsId, Integer proudctType,String type, HttpServletRequest request) {
		request.setAttribute("mealsId", mealsId);
		request.setAttribute("proudctType", proudctType);
		request.setAttribute("type", type);
		return "/product/productStockAdd";
	}

	@ResponseBody
	@RequestMapping(value = "/productStockSave", method = { RequestMethod.POST })
	public MessageData productStockSave(ProductStockVo productStockVo, HttpServletRequest request) {
		MessageData messageData = new MessageData(200, "操作成功");
		if (productStockVo != null) {
			if (productStockVo.getCreateStartTime() == null || productStockVo.getCreateEndTime() == null) {
				logger.info("时间不能为空");
				return new MessageData(500, "时间不能为空");
			}
			if (productStockVo.getCreateStartTime().compareTo(productStockVo.getCreateEndTime()) > 0) {
				logger.info("开始时间不能大于结束时间");
				return new MessageData(500, "开始时间不能大于结束时间");
			}
			productStockVo.setCreateUser(getSellerUser().getId());
			productStockVo.setUpdateUser(getSellerUser().getId());
			if (1 == productStockVo.getType()) {
				List<ProductStock> list = productStockService.selectList(productStockVo);
				if(null != list && list.size() > 0 ){
					return new MessageData(500, "此时间段存在库存");
				}
				productStockService.addStock(productStockVo);
			}else if(2 == productStockVo.getType()){
				 int result = productStockService.batchUpdateStock(productStockVo);
				 if(2 == result){
					 logger.info("此时间段不存在库存");
					 return new MessageData(500, "此时间段不存在库存");
				 }
			}else if(3 == productStockVo.getType()){
				productStockService.updateStock(productStockVo);
			}else{
				return new MessageData(500, "方法类型不能为空");
			}
			messageData.setAttachObj(productStockVo);
		} else {
			logger.info("对像不能为空");
			return new MessageData(500, "对像不能为空");
		}
		return messageData;
	}
	//查询库存修改日志
	@RequestMapping(value = "/productStockLogList")
	public String productStockLogList(Integer mealsId, HttpServletRequest request){
		request.setAttribute("mealsId", mealsId);
		return "/product/productStockLogList";
	}
	//查询库存修改日志
	@ResponseBody
	@RequestMapping(value = "/productStockLogListData")
	public MessageData productStockLogListData(ProductStockLog productStockLog, HttpServletRequest request){
		MessageData message = new MessageData(200, "查询成功");
		List<ProductStockLog> list = productStockLogService.productStockLogList(productStockLog,true);
		PageInfo<ProductStockLog> page = new PageInfo<ProductStockLog>(list, productStockLog.getPageSize());
		message.setAttachObj(page);
		return message;
	}
	
	//点击修改库存信息
	@ResponseBody
	@RequestMapping(value = "/updateStockById")
	public MessageData updateStockById(ProductStockVo productStockVo) {
		productStockVo.setCreateUser(getSellerUser().getId());
		productStockVo.setUpdateUser(getSellerUser().getId());
		int result = productStockService.updateStock(productStockVo);
		return result > 0 ? new MessageData(200, "更新成功") : new MessageData(500, "更新失败");
	}
}
