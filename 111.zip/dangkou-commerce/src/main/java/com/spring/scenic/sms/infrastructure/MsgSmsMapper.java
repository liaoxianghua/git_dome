package com.spring.scenic.sms.infrastructure;

import java.util.List;

import com.spring.scenic.sms.domain.MsgSms;

public interface MsgSmsMapper {

    int saveMsgSmsRecord(MsgSms msgSms);

    List<MsgSms> selectMsgSms(MsgSms msgSms);

    int validateCaptcha(MsgSms msgSms);
    
    List<MsgSms> selectMsgListInTenMinInterval(MsgSms msgSms);

}