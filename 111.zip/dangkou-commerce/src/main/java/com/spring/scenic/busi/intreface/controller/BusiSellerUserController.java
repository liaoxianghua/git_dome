package com.spring.scenic.busi.intreface.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;

@Controller
@RequestMapping("user")
public class BusiSellerUserController extends BaseController {
    
    @Resource
    private BusiSellerService busiSellerService;
    
    public String userInfo(){
        
        return "user/userInfo";
    }
    
    /**
     * 
     * 此处为类方法说明:跳转到发票设置页面
     * @param 
     * @return
     * @creator ：ranmaoping(004225)  
     * @date ：2017年7月13日     
     * @memo ：   
     **
     */
    @ResponseBody
    @RequestMapping(value = "/toInvoiceSetPage",method = RequestMethod.POST)
    public MessageData productList(HttpServletRequest request) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if(sellerUser!=null){
            BusiSeller busiSeller = new BusiSeller();
            busiSeller.setId(sellerUser.getSellerId());
            busiSeller = busiSellerService.getBusiSeller(busiSeller);
            return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", busiSeller);
        }else{
            return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
        }
    }
    
    @ResponseBody
    @RequestMapping(value = "saveInvoiceSet",method = RequestMethod.POST)
    public MessageData saveInvoiceSet(HttpServletRequest request,HttpServletResponse response,BusiSeller busiSeller){
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if(sellerUser!=null){
            busiSeller.setId(sellerUser.getSellerId());
            MessageData messageData = busiSellerService.saveInvoiceSet(busiSeller);
            return messageData;
        }else{
            return new MessageData(SysConstant.OPERATE_FAILURE, SysConstant.OPERATE_FAILURE_MESSAGE, null, null, false, null, null, null);
        }
    }

}
