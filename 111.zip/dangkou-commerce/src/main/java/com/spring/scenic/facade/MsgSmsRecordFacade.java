package com.spring.scenic.facade;


public interface MsgSmsRecordFacade {

	/**
	 * 保存短信记录 订单类短信除外
	 * @param receiverNo 手机号
	 * @param content 短信内容
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月30日下午5:40:46
	 */
	boolean saveMsgSmsRecord(String receiverNo,String content);

	/**
	 * 订单处理相关短信
	 * @param receiverNo 手机号
	 * @param content 内容
	 * @param OrderNo 订单号
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月30日下午5:41:32
	 */
	boolean saveMsgSmsRecord(String receiverNo,String content,String OrderNo);
}
