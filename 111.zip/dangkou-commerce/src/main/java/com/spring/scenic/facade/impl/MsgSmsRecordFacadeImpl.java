package com.spring.scenic.facade.impl;

import java.util.Date;

import javax.annotation.Resource;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.util.SmsUtils;
import com.spring.scenic.facade.MsgSmsRecordFacade;
import com.spring.scenic.sms.application.MsgSmsRecordService;
import com.spring.scenic.sms.domain.MsgSmsRecord;

@Service(value = "msgSmsRecordFacade")
public class MsgSmsRecordFacadeImpl implements MsgSmsRecordFacade {

	static Logger logger = Logger.getLogger(MsgSmsRecordFacadeImpl.class);

	@Resource
	MsgSmsRecordService msgSmsRecordService;

	@Override
	public boolean saveMsgSmsRecord(String receiverNo, String content) {
		try {
			MsgSmsRecord entity = new MsgSmsRecord();
			JSONObject json = SmsUtils.sendSms(receiverNo, content);
			if(json != null) {
				if("0".equals(json.get("result"))){
					entity.setSendStatus(1);
				}else{
					entity.setSendStatus(2);
				}
				entity.setReturnStatus(json.get("result") == null ? null : json.get("result").toString());
				entity.setReturnContent(json.get("desc") == null ? null : json.get("desc").toString());
			}
			entity.setMsgContent(content);
			entity.setReceiverNo(receiverNo);
			entity.setCreateTime(new Date());
			msgSmsRecordService.insert(entity);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("====================短信发送失败====================" + receiverNo);
			return false;
		}
	}

	@Override
	public boolean saveMsgSmsRecord(String receiverNo, String content, String orderNo) {
		try {
			MsgSmsRecord entity = new MsgSmsRecord();
			JSONObject json = SmsUtils.sendSms(receiverNo, content);
			if(json != null) {
				if("0".equals(json.get("result"))){
					entity.setSendStatus(1);
				}else{
					entity.setSendStatus(2);
				}
				entity.setReturnStatus(json.get("result") == null ? null : json.get("result").toString());
				entity.setReturnContent(json.get("desc") == null ? null : json.get("desc").toString());
			}
			entity.setMsgContent(content);
			entity.setReceiverNo(receiverNo);
			entity.setCreateTime(new Date());
			entity.setOrderNo(orderNo);
			msgSmsRecordService.insert(entity);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("====================短信发送失败====================" + receiverNo);
			return false;
		}
	}
}
