package com.spring.scenic.product.application.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.product.application.ProductMealsService;
import com.spring.scenic.product.domain.ProductMeals;
import com.spring.scenic.product.infrastructure.ProductMealsMapper;

@Service
public class ProductMealsServiceImpl implements ProductMealsService {

	@Resource
	private ProductMealsMapper productMealsMapper;

	@Override
	public List<ProductMeals> selectAllByProductId(ProductMeals productMeals) {
		return productMealsMapper.selectAllByProductId(productMeals);
	}
	
	@Override
	public Integer addMeals(ProductMeals productMeals){
		return productMealsMapper.insert(productMeals);
	}
	
	@Override
	public Integer updateMeals(ProductMeals productMeals){
		return productMealsMapper.updateByPrimaryKeySelective(productMeals);
	}
	@Override
	public ProductMeals selectByPrimaryKey(Integer id){
		return productMealsMapper.selectByPrimaryKey(id);
	}

}
