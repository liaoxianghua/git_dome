package com.spring.scenic.order.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * 拒绝退单日志记录 此处为类说明
 * 
 * @author lzj
 * @date 2017年8月22日
 */
public class OrderChargebackRecord extends Entity<OrderChargebackRecord>
		implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 主键ID
	 */
	private Integer id;

	/**
	 * 订单编号
	 */
	private String orderNo;
	/**
	 * 会员ID
	 */
	private Integer memberId;
	/**
	 * 商户ID
	 */
	private Integer sellerId;
	/**
	 * 拒绝订单理由
	 */
	private String refundReason;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 创建人
	 */
	private Integer createUser;
	/**
	 * 类型 1表示同意 2表示拒绝
	 */
	private Integer type;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getRefundReason() {
		return refundReason;
	}

	public void setRefundReason(String refundReason) {
		this.refundReason = refundReason;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
