package com.spring.scenic.memberMsg.application;

import java.util.List;

import com.spring.scenic.memberMsg.domain.MemberMsg;



public interface MemberMsgService {
	
	public List<MemberMsg> selectMemberMsg(Integer memberId);//我的系统通知

	MemberMsg selectMemberMsgDetails(MemberMsg memberMsg);//我的系统通知详情

    /**   
     * 此处为类方法说明:查询会员收到的系统通知列表
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    public List<MemberMsg> selectSystemNoticeList(Integer memberId);

}
