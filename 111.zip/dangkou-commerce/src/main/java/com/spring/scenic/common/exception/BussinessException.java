package com.spring.scenic.common.exception;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @Description 系统业务异常封装类
 * @date 2016年12月21日
 */
public class BussinessException extends RuntimeException {

	private static final long serialVersionUID = -6163333813812928865L;
	private Logger logger = LoggerFactory.getLogger(BussinessException.class);
	private List<BussinessExceptionBean> bexbeanList;
	private String errorMessages;
	private Exception e;

	public BussinessException(String message,Exception m) {
		this.errorMessages=message;
		this.e=m;
		logger.error(errorMessages,e);
	}
	
	public BussinessException(BussinessExceptionBean bexbean) {
		if (bexbeanList == null) {
			bexbeanList = new LinkedList<BussinessExceptionBean>();
		}
		bexbeanList.add(bexbean);
		logger.error(bexbean.getErrorMessage());
	}
	
	public BussinessException(BussinessExceptionBean bexbean,Throwable cause) {
		if (bexbeanList == null) {
			bexbeanList = new LinkedList<BussinessExceptionBean>();
		}
		bexbeanList.add(bexbean);
		logger.error(bexbean.getErrorMessage(),cause);
	}

	public BussinessException(List<BussinessExceptionBean> bexbeanList) {
		this.bexbeanList = bexbeanList;
		for (BussinessExceptionBean bex : bexbeanList) {
			logger.error(bex.getErrorMessage());
		}
	}

	public BussinessException() {
		if (bexbeanList == null) {
			bexbeanList = new LinkedList<BussinessExceptionBean>();
		}
	}

	public void addBussinessException(BussinessExceptionBean bex) {
		if (bexbeanList == null) {
			bexbeanList = new LinkedList<BussinessExceptionBean>();
		}
		bexbeanList.add(bex);
		logger.error(bex.getErrorMessage());
	}

	public String getExceptionMessage() {
		StringBuffer sb = new StringBuffer();
		if (bexbeanList == null || bexbeanList.size() == 0) {

			sb.append("");
			return sb.toString();
		}
		if (bexbeanList.size() == 1) {
			sb.append(bexbeanList.get(0).getErrorMessage());
			return sb.toString();
		}
		for (BussinessExceptionBean bex : bexbeanList) {
			sb.append(bex.getErrorMessage());
			sb.append("\n");
		}
		return sb.toString();
	}
}
