package com.spring.scenic.common.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.csource.fastdfs.StorageClient;
import org.csource.fastdfs.StorageServer;
import org.csource.fastdfs.TrackerClient;
import org.csource.fastdfs.TrackerServer;
import org.springframework.web.multipart.MultipartFile;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;

/**
 * @Description 附件操作工具类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public class MultiPartUtil {
	
	private static final String IMAGE = "jpg、png、jpeg、gif";
	
	private static final String VIDEO = "ra、rm、wav、mp3、ape、cd、aiff、au、wav";
	
	private static final String EMBED = "mkv、mp4、wmv、mpg、asf、rm、rmvb、avi";
	
	private static final String OFFICE = "xlsx、xls、doc、docx、pdf、pptx、ppt";
	
	/**
	 * @Description 将多媒体附件上传至应用服务器配置目录下
	 * @param multipartFiles 多媒体附件集合
	 * @param serverPath 服务器绝对路径
	 * @param configPath 配置相对路径 
	 * @return boolean
	 * @author shuchang
	 * @throws Exception 
	 * @date 2016年8月22日
	 */
	public static boolean uploadFiles(List<MultipartFile> multipartFiles,String serverPath,String configPath) throws Exception{
		try {
			StringBuffer stringBuffer = new StringBuffer(serverPath);
			stringBuffer.append(configPath);
			for (MultipartFile file : multipartFiles) {
				File destFile = new File(stringBuffer.toString().concat(file.getOriginalFilename()));
				destFile.mkdirs();
				file.transferTo(destFile);
			}
			return true;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
		}
	}

	/**
	 * @Description 删除附件（该方法不对删除文件的集合验证，首先将其迭代如果文件存在则删除，无异常情况下返回：true）
	 * @param delFiles
	 * @return boolean
	 * @author shuchang
	 * @date 2016年9月7日
	 */
	public static boolean deleteFiles(List<File> delFiles) {
		try {
			for (File file : delFiles) {
				if(file.exists()){
					file.delete();
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("common.multi.empty"),e);
		}
		return true;
	}

	/**
	 * 
	 * @Description 附件下载
	 * @param file
	 * @param response
	 * @return void
	 * @author shuchang
	 * @throws IOException 
	 * @date 2016年10月17日
	 */
	public static void downFile(File file,String fileName, HttpServletResponse response) throws Exception {
		response.setContentType("application/octet-stream;charset=UTF-8");
		response.setHeader("Content-disposition", "attachment;filename="+new String(fileName.getBytes("GBK"), "ISO8859-1"));
		BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
		byte bytes[] = new byte[1024];
		InputStream in = new FileInputStream(file);
		int index = in.read(bytes, 0, 1024);
		while (index != -1) {
			out.write(bytes, 0, index);
			index = in.read(bytes, 0, 1024);
		}
		in.close();
		out.flush();
		out.close();
		in = null;
		out = null;
	}
	/**
	 * @Description 附件下载
	 * @param file
	 * @param response
	 * @return void
	 * @author ranmaoping
	 * @param response
	 * @throws MalformedURLException
	 */
	 public static void downloadFromFastDfs(HttpServletResponse response,String groupId,String remoteUrl,String downFileName) throws Exception {
	     try {
	    	  	TrackerClient tracker = new TrackerClient();             
				TrackerServer trackerServer = tracker.getConnection();            
				StorageServer storageServer = null;             
				StorageClient storageClient = new StorageClient(trackerServer, storageServer);             
				byte[] b = storageClient.download_file(groupId, remoteUrl);             
				if(b!=null){
					response.setContentType("application/octet-stream;charset=UTF-8");
					response.setHeader("Content-disposition", "attachment;filename="+ new String(downFileName.getBytes("GBK"), "ISO8859-1"));
					IOUtils.write(b,response.getOutputStream());
				}
	     } catch (Exception e) {
	    	 throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
	     }
     }
	/**
	 * @Description 验证是否包含附件
	 * @param filesMap 附件的MAP
	 * @param key 附件的Key
	 * @return boolean
	 * @author 006568（shuchang）
	 * @date 2017年1月6日
	 */
	public static boolean checkHasMultipartFile(Map<String, List<MultipartFile>> filesMap, String key) {
		if(filesMap==null || filesMap.isEmpty()){
			return false;
		}else{
			if(StringUtils.isBlank(key)){
				return true;
			}else{
				if(filesMap.get(key)==null||filesMap.get(key).isEmpty()){
					return false;
				}else{
					return true;
				}
			}
		}
	}

	/**
	 * @Description 校验文件类型
	 * @param formart
	 * @return Short
	 * @author 006568（shuchang）
	 * @date 2017年1月1日
	 */
	public static Short checkFileFormart(String formart) {
		if(StringUtils.isNotBlank(formart)){
			if(formart.indexOf(IMAGE)!=-1){
				return 1;
			}else if(formart.indexOf(VIDEO)!=-1){
				return 2;
			}else if(formart.indexOf(EMBED)!=-1){
				return 3;
			}else if(formart.indexOf(OFFICE)!=-1){
				return 4;
			}
		}
		return -1;
	}

}
