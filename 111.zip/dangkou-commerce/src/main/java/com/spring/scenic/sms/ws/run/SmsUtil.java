package com.spring.scenic.sms.ws.run;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.sms.ws.BeanOfSendMessage;
import com.spring.scenic.sms.ws.IMessageService;
import com.spring.scenic.sms.ws.IMessageServiceService;
import com.spring.scenic.sms.ws.RetBeanOfSendMessage;
import com.spring.scenic.sms.ws.SendMessageType;
import com.spring.scenic.sms.ws.SendTargets;
import com.spring.scenic.sms.ws.SmsParamBean;

public class SmsUtil {

    private static final QName SERVICE_NAME = new QName("http://webservice.spring.com/", "IMessageServiceService");
    
    public static RetBeanOfSendMessage sendSms(String bizFlag,String sysFlag,String smsType,String phone,String content) throws Exception {
        IMessageServiceService messageServiceService;
        try {
            messageServiceService = new IMessageServiceService(new URL(PropertiesUtil.getProperty("com.spring.scenic.sms.wsdlLocation")), SERVICE_NAME);
            IMessageService messageService = messageServiceService.getIMessageServicePort();
            BeanOfSendMessage sendMessage = new BeanOfSendMessage();
            sendMessage.setBizFlag(bizFlag);
            sendMessage.setSysFlag(sysFlag);
            
            SendMessageType sendMessageType = new SendMessageType();
            sendMessageType.getMessageType().add(smsType);
            sendMessage.setMessageTypes(sendMessageType);
            
            SmsParamBean smsParamBean = new SmsParamBean();
            smsParamBean.setContent(content);
            
            List<String> phones = new ArrayList<String>();
            phones.add(phone);
            SendTargets targets = new SendTargets();
            //targets.getTarget().addAll(phones);
            targets.getTarget().add(phone);
            smsParamBean.setTargets(targets);
            
            sendMessage.setSmsParamBean(smsParamBean);
            RetBeanOfSendMessage retBeanOfSendMessage  = messageService.sendMessage(sendMessage);
            System.out.println(retBeanOfSendMessage);
            return retBeanOfSendMessage;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    
    
    public static void main(String[] args) {
        IMessageServiceService messageServiceService;
        try {
            
            RetBeanOfSendMessage retBeanOfSendMessage = SmsUtil.sendSms(SysConstant.SMS_BIS_ID, SysConstant.SMS_SYS_ID, SysConstant.SMS_TYPE, "15802301145", "您的验证码是：1233");
            if(retBeanOfSendMessage.getIfSuccess().equals("Y")){
                System.out.println(1);
            }else {
                System.out.println(0);
            }
            
//            messageServiceService = new IMessageServiceService(new URL(PropertiesUtil.getProperty("com.spring.scenic.sms.wsdlLocation")), SERVICE_NAME);
//            IMessageService messageService = messageServiceService.getIMessageServicePort();
//            BeanOfSendMessage sendMessage = new BeanOfSendMessage();
//            sendMessage.setBizFlag("41");
//            sendMessage.setSysFlag("35");
//            
//            SendMessageType sendMessageType = new SendMessageType();
//            sendMessageType.getMessageType().add("1");
//            sendMessage.setMessageTypes(sendMessageType);
//            
//            SmsParamBean smsParamBean = new SmsParamBean();
//            smsParamBean.setContent("你好,这是舒畅测试短信！");
//            
//            List<String> phones = new ArrayList<String>();
//            phones.add("15802301145");
//            SendTargets targets = new SendTargets();
//            //targets.getTarget().addAll(phones);
//            targets.getTarget().add("15802301145");
//            smsParamBean.setTargets(targets);
//            
//            sendMessage.setSmsParamBean(smsParamBean);
//            RetBeanOfSendMessage retBeanOfSendMessage  = messageService.sendMessage(sendMessage);
//            System.out.println(retBeanOfSendMessage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
