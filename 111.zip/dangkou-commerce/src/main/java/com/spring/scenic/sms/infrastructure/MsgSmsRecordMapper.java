package com.spring.scenic.sms.infrastructure;

import com.spring.scenic.sms.domain.MsgSmsRecord;
import java.util.List;
public interface MsgSmsRecordMapper{

	public int insert(MsgSmsRecord entity);
	
	public int update(MsgSmsRecord entity);
	
	public int deleteById(Integer id);
	
	public int deleteByIds(List<Integer> ids);
	
	public MsgSmsRecord selectById(Integer id);
	
	public List<MsgSmsRecord> selectPage(MsgSmsRecord entity);
}
