package com.spring.scenic.product.domain.vo;

import java.util.Date;

import com.spring.scenic.product.domain.ProductStock;

public class ProductStockVo extends ProductStock {

	// 开始时间
	private Date createStartTime;

	// 结束时间
	private Date createEndTime;
	// 事件类型 type
	private Integer type;
	
	public String[] week;
	
	public String[] getWeek() {
		return week;
	}

	public void setWeek(String[] week) {
		this.week = week;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}
}
