package com.spring.scenic.common.intreface.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;

/**
 * 
 * @author lzj
 * 2017年4月12日10:20:36
 *
 */

public class CommonController {

	BusiSellerUser sellerUser;
	/**
	 * 初始化绑定数据，加入字符串转日期
	 * 
	 * @param request
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor dateEditor = new CustomDateEditor(format, true);
		binder.registerCustomEditor(Date.class, dateEditor);
		sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		setSellerUser(sellerUser);
	}
	public BusiSellerUser getSellerUser() {
		return sellerUser;
	}
	public void setSellerUser(BusiSellerUser sellerUser) {
		this.sellerUser = sellerUser;
	}
	

	
}
