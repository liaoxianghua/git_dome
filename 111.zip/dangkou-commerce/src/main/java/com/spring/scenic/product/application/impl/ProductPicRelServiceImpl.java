package com.spring.scenic.product.application.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductPicRelMapper;

@Service
public class ProductPicRelServiceImpl implements ProductPicRelService {

    @Resource
    private ProductPicRelMapper productPicRelMapper;
    
    @Resource
    private ProductMapper productMapper;

    @Override
    public List<ProductPicRel> list(ProductPicRel productPicRel, boolean page, Integer pageSize) {
        return productPicRelMapper.selectList(productPicRel);
    }
    @Override
    public int delete(Integer id){
        return productPicRelMapper.deleteByPrimaryKey(id);
    }
    @Override
    public List<ProductPicRel> updateIsLogo(ProductPicRel productPicRel) {
        if (productPicRel != null) {
            if (productPicRel.getProductId() == null) {
                return null;
            }
            // 更新当前产品的图片islogo为0
            ProductPicRel productPicRelParams = new ProductPicRel();
            productPicRelParams.setProductId(productPicRel.getProductId());
            productPicRelParams.setIsLogo(0);
            int result = productPicRelMapper.updateByPrimaryKeySelective(productPicRelParams);
            if (result > 0) {
                // 设置选中ID的islogo为1
                productPicRelParams.setId(productPicRel.getId());
                productPicRelParams.setIsLogo(1);
                productPicRelMapper.updateByPrimaryKeySelective(productPicRelParams);
            } else {
                return null;
            }
        }
        return null;
    }
	@Override
	public boolean productLibSave(Product product, String ids, BusiSellerUser sellerUser) {
		List<String> listIds = Arrays.asList(ids.split(","));
		boolean flag = false;
		for (String pictureLibId : listIds) {
			ProductPicRel ppr = new ProductPicRel();
			ppr.setProductId(product.getId());
			ppr.setPictureLibId(Integer.valueOf(pictureLibId));
			ppr.setCreateTime(new Date());
			ppr.setCreateUser(sellerUser.getId());
			ppr.setUpdateTime(new Date());
			ppr.setUpdateUser(sellerUser.getId());
			ppr.setIsLogo(0);
			int result = productPicRelMapper.insert(ppr);
			if(result > 0){
				flag = true;
			}
		}
		return flag;
	}

}
