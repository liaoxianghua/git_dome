package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.Dictionary;

public interface DictionaryMapper {

	List<Dictionary> getDictionaryList(Dictionary dictionary);

	int saveDictionary(Dictionary dictionary);

	int updateDictionary(Dictionary dictionary);

	Dictionary getDictionaryById(Dictionary dictionary);

	int deleteDictionary(Dictionary dictionary);

	List<Dictionary> getDictionaryListByCode(Dictionary dictionary);
	
    int getDictionnaryCountByCode(Dictionary dictionary);
    
    List<Dictionary> getProductTypeList();


}