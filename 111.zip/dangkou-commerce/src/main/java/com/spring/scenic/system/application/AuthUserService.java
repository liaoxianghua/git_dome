package com.spring.scenic.system.application;

import java.util.List;

import com.spring.scenic.system.domain.AuthResource;
import com.spring.scenic.system.domain.AuthRole;
import com.spring.scenic.system.domain.AuthUser;


public interface AuthUserService {
	

	/**
	 * @Description 验证用户是否具有指定编码（code）的权限
	 * @param code	权限编码
	 * @param user	用户
	 * @return boolean true：是；false：否
	 * @author 006568（shuchang）
	 * @date 2017年3月6日
	 */
	boolean havePermission(String code, AuthUser user);

	/**
	 * @Description 根据用户账号获取用户
	 * @param username
	 * @return AuthUser
	 * @author 006568（shuchang）
	 * @date 2017年3月6日
	 */
	AuthUser getUserByAccount(String username);

	/**
	 * @Description 获取用户角色
	 * @param authUser
	 * @return List<AuthRole>
	 * @author 006568（shuchang）
	 * @date 2017年3月6日
	 */
	List<AuthRole> getUserRoleList(AuthUser authUser);

	/**
	 * @Description 获取用户的资源权限
	 * @param authUser
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年3月6日
	 */
	List<AuthResource> getUserResourceList(AuthUser authUser);
	
	/**
	 * @Description 获取系统角色
	 * @param authRole
	 * @return List<AuthRole>
	 * @author 006568（shuchang）
	 * @date 2017年2月10日
	 */
	List<AuthRole> getRoleList(AuthRole authRole);
	
	/**
	 * @Description 根据资源获取访问需要的角色
	 * @param resource
	 * @return List<AuthRole>
	 * @author 006568（shuchang）
	 * @date 2017年2月10日
	 */
	List<AuthRole> getRoleListByResource(AuthResource resource);

	/**
	 * @Description 查询资源
	 * @param authResource
	 * @return List<AuthResource>
	 * @author 006568（shuchang）
	 * @date 2017年3月6日
	 */
	List<AuthResource> getResourceList(AuthResource authResource);
	
}
