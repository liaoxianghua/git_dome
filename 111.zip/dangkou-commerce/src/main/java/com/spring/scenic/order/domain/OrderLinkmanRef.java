package com.spring.scenic.order.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;

public class OrderLinkmanRef extends Entity<OrderLinkmanRef> implements Serializable{
	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = -586481354827079228L;

	/**
	 * 此处为属性说明
	 */

	private Integer id;
	
	private Integer orderId;//订单号ID
	
	private String orderNo;//订单号
	
	private Integer memberId;//会员ID
	
	private Integer memberDetailInfoId;//出行人ID
	
	private String nameCh;//中文姓名
	
	private String nameChPin;//中文拼音
	
	private String nameEnF;//英文姓
	
	private String nameEnS;//英文名
	
	private Integer sex;//性别(1男0女)
	
	private Integer nationality;//国籍
	
	private Date birthday;//生日
	
	private String phoneCh;//大陆移动电话
	
	private String phoneOverseas;//海外手机
	
	private String fixTelArea;//固定电话区号
	
	private String fixTel;//固定电话
	
	private String fixTelExtension;//固定电话分机
	
	private String mail;//邮箱
	
	private Integer countryId;//国家
	
	private Integer provinceId;//省份
	
	private Integer cityId;//城市
	
	private Integer isSelf;//是否本人(1是0否)
	
	private Integer createUser;//创建人
	
	private Date createTime;//创建时间
	
	private Integer updateUser;//修改人
	
	private Date updateTime;//修改时间
	
	/**
     * 非数据库字段：订单出行人证件信息
     */
    private List<OrderLinkmanDoc> orderLinkmanDocs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public Integer getMemberDetailInfoId() {
		return memberDetailInfoId;
	}

	public void setMemberDetailInfoId(Integer memberDetailInfoId) {
		this.memberDetailInfoId = memberDetailInfoId;
	}

	public String getNameCh() {
		return nameCh;
	}

	public void setNameCh(String nameCh) {
		this.nameCh = nameCh;
	}

	public String getNameChPin() {
		return nameChPin;
	}

	public void setNameChPin(String nameChPin) {
		this.nameChPin = nameChPin;
	}

	public String getNameEnF() {
		return nameEnF;
	}

	public void setNameEnF(String nameEnF) {
		this.nameEnF = nameEnF;
	}

	public String getNameEnS() {
		return nameEnS;
	}

	public void setNameEnS(String nameEnS) {
		this.nameEnS = nameEnS;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public Integer getNationality() {
		return nationality;
	}

	public void setNationality(Integer nationality) {
		this.nationality = nationality;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getPhoneCh() {
		return phoneCh;
	}

	public void setPhoneCh(String phoneCh) {
		this.phoneCh = phoneCh;
	}

	public String getPhoneOverseas() {
		return phoneOverseas;
	}

	public void setPhoneOverseas(String phoneOverseas) {
		this.phoneOverseas = phoneOverseas;
	}

	public String getFixTelArea() {
		return fixTelArea;
	}

	public void setFixTelArea(String fixTelArea) {
		this.fixTelArea = fixTelArea;
	}

	public String getFixTel() {
		return fixTel;
	}

	public void setFixTel(String fixTel) {
		this.fixTel = fixTel;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getIsSelf() {
		return isSelf;
	}

	public void setIsSelf(Integer isSelf) {
		this.isSelf = isSelf;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public List<OrderLinkmanDoc> getOrderLinkmanDocs() {
		return orderLinkmanDocs;
	}

	public void setOrderLinkmanDocs(List<OrderLinkmanDoc> orderLinkmanDocs) {
		this.orderLinkmanDocs = orderLinkmanDocs;
	}

	public String getFixTelExtension() {
		return fixTelExtension;
	}

	public void setFixTelExtension(String fixTelExtension) {
		this.fixTelExtension = fixTelExtension;
	}
    
    
}
