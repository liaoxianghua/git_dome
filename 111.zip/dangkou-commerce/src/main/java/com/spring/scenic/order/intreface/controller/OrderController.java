package com.spring.scenic.order.intreface.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.HttpClient;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.encrypt.EncryptPkUtil;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderMoneyChangeRec;
import com.spring.scenic.order.domain.OrderPayRecord;
import com.spring.scenic.order.domain.vo.OrderAndInvoice;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;


@Controller
@RequestMapping("order")
public class OrderController extends BaseController {

    @Autowired
    private OrderService orderService;

    static Logger logger = org.slf4j.LoggerFactory.getLogger(OrderController.class);
	@Resource
	private DictionaryService dictionaryService;
	@Resource
	private ProductService productService;
    /**
     * 订单列表
     */
    @RequestMapping(value = "orders", method = {RequestMethod.GET})
    public String orderList(HttpServletRequest request, Order order) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        Dictionary dictionary = new Dictionary();
        dictionary.setCode("EXPRESS_COMPANY");
        List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
        request.setAttribute("orderNew", true);
        request.setAttribute("orderSure", true);
        request.setAttribute("orderChargeback", true); //申请退单
        request.setAttribute("goodsDelivered", true); //已发货
        request.setAttribute("goodsReturn", true); //申请退货
        request.setAttribute("orderStatisic", orderStatisic);
        request.setAttribute("active", 1);
        request.setAttribute("sellerUser", sellerUser);
		request.setAttribute("expressCompanyList", expressCompanyList);
        return "order/orderList";
    }
    
    /**
     * 订单详细页
     */
    @RequestMapping(value = "detail/{id}", method = {RequestMethod.GET})
    public String detail(HttpServletRequest request, @PathVariable Integer id) {
    	try {
			
	    	Order exampleOrder = new Order();
	    	Dictionary dictionary = new Dictionary();
	        exampleOrder.setId(id);
	        Order order = orderService.getOrder(exampleOrder);
	        if(order!=null && order.getOrderRefundRecords()!=null){
	            for (OrderPayRecord orderPayRecord : order.getOrderRefundRecords()) {
	                order.setRefundPrice((order.getRefundPrice()==null?new BigDecimal(0):order.getRefundPrice()).add(orderPayRecord.getTotalPrice()));
	            }
	        }
	        Product product=productService.selectByPrimaryKey(order.getProductId());
			dictionary.setCode("EXPRESS_COMPANY");
			List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
			if(null!=expressCompanyList && null!=order){
				for (Dictionary oldDictionary : expressCompanyList) {
					if(null!=order.getExpressCompanyName() && oldDictionary.getValue().equals(order.getExpressCompanyName())){
						dictionary.setId(oldDictionary.getId());
					}
				}
			}
			if(null!=order.getExpressCompanyName()){
				Dictionary dictionaryDetail=dictionaryService.getDictionary(dictionary);
				if(null!=dictionaryDetail){
					request.setAttribute("oldexpressName", dictionaryDetail.getName());
				}
			}else{
					request.setAttribute("oldexpressName", null);
			}
	        request.setAttribute("order", order);
	        request.setAttribute("active", 1);
	        request.setAttribute("expressCompanyList", expressCompanyList);
	        request.setAttribute("product", product);
	        return "order/detail";
			} catch (Exception e) {
				e.printStackTrace();
			}
    	return null;
    }
    
    /**
     * 取消、确认操作修改订单状态
     */
    @RequestMapping(value = "detail/status/{id}/{status}", method = {RequestMethod.GET})
    public String detail(HttpServletRequest request, @PathVariable Integer id, @PathVariable Integer status) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        Order exampleOrder = new Order();
        exampleOrder.setId(id);
        exampleOrder.setOrderStatus(status);
        orderService.updateOrderStatus(exampleOrder,sellerUser);
        Order order = orderService.getOrder(exampleOrder);
        if(order!=null && order.getOrderRefundRecords()!=null){
            for (OrderPayRecord orderPayRecord : order.getOrderRefundRecords()) {
                order.setRefundPrice((order.getRefundPrice()==null?new BigDecimal(0):order.getRefundPrice()).add(orderPayRecord.getTotalPrice()));
            }
        }
        request.setAttribute("order", order);
        request.setAttribute("active", 1);
        return "order/detail";
    }
    
    /**
     * 首页进入订单列表
     */
    @RequestMapping(value = "orderList/{status}", method = {RequestMethod.GET})
    public String orderList(HttpServletRequest request, Order order,@PathVariable String status) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if(StringUtils.isNotBlank(status)){
            if(status.equals("today_all")){
                request.setAttribute("createTimeStart", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("createTimeEnd", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("active", 1);
            }else if(status.equals("total_new")){
                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_NEW.getCode()));
                request.setAttribute("active", 6);
            }else if(status.equals("total_chargeback")){
            	request.setAttribute("active", 7);
//                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_CHARGEBACK.getCode()));
            	request.setAttribute("orderChargeback", true); //申请退单
                request.setAttribute("goodsReturn", true); //申请退货
            }else if(status.equals("today_canceled")){
            	request.setAttribute("active", 1);
                request.setAttribute("createTimeStart", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("createTimeEnd", DateUtil.formatDate(new Date(), DateUtil.YYYY_MM_DD));
                request.setAttribute("status", Integer.valueOf(SysEnum.ORDER_STATUS_CANCELED.getCode()));
            }
        }
        Dictionary dictionary = new Dictionary();
    	dictionary.setCode("EXPRESS_COMPANY");
    	List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
        request.setAttribute("orderStatisic", orderStatisic);
        request.setAttribute("sellerUser", sellerUser);
        request.setAttribute("expressCompanyList", expressCompanyList);
        return "order/orderList";
    }
    
    /**
     * 查询订单数据
     */
    @ResponseBody
    @RequestMapping(value = "getOrderListData", method = {RequestMethod.POST})
    public MessageData getOrderListData(HttpServletRequest request, Order order) {
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);   	
    	Integer sellerId = sellerUser.getSellerId();
    	order.setSellerId(sellerId);
        List<Order> list = orderService.getOrderListWithWarn(order, true);
        PageInfo<Order> page = new PageInfo<Order>(list, order.getPageSize());
        MessageData message = new MessageData(200, "查询成功");
        Map<String, Object> map = new HashMap<String,Object>();
        Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
        map.put("page", page);
        map.put("orderStatisic", orderStatisic);
        message.setAttachObj(map);
        return message;
    }
    
    /**
     * 更改订单状态
     */
    @ResponseBody
    @RequestMapping(value = "changeOrderStatus", method = {RequestMethod.POST})
    public MessageData changeOrderStatus(HttpServletRequest request, Order order) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        orderService.updateOrderStatus(order,sellerUser);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
    }
    
    /**
     * 保存订单数据
     */
    @ResponseBody
    @RequestMapping(value = "saveSellerRemark", method = {RequestMethod.POST})
    public MessageData saveSellerRemark(HttpServletRequest request, Order order) {
        orderService.saveSellerRemark(order);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE);
    }
    
    /**
     * 保存订单金额调整记录
     */
    @ResponseBody
    @RequestMapping(value = "saveOrderMoneyChange", method = {RequestMethod.POST})
    public MessageData saveOrderMoneyChange(HttpServletRequest request, OrderMoneyChangeRec orderMoneyChangeRec) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        orderService.saveOrderMoneyChange(sellerUser,orderMoneyChangeRec);
        List<OrderMoneyChangeRec> orderMoneyChangeRecs = orderService.getOrderMoneyChangeList(orderMoneyChangeRec);
        
        //更新订单应付金额
        Order exampleOrder = new Order();
        exampleOrder.setOrderNo(orderMoneyChangeRec.getOrderNo());
        Order order = orderService.getOrder(exampleOrder);
        //最新应付金额=应付金额+调整后的金额
        BigDecimal payPrice = order.getPayPrice().add(orderMoneyChangeRec.getMoney());
        order.setPayPrice(payPrice);
        
        BigDecimal payedPrice = order.getPayedPrice();
        if(payedPrice==null){
            payedPrice = BigDecimal.ZERO;
        }
        //付款金额为0且已付为0且有支付记录：全款
        if(payPrice.compareTo(BigDecimal.ZERO)==0){
            if(payPrice.compareTo(payedPrice)==0){
                if(order.getOrderPayRecords()!=null && !order.getOrderPayRecords().isEmpty()){
                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
                }
            }else if(payPrice.compareTo(payedPrice) < 0){
            	order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
            }
        }else {
            if(payedPrice.compareTo(BigDecimal.ZERO)==0){//付款金额不为且已付为0：未付款
                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_NO.getCode()));
            }else{//其他
                if(payedPrice.compareTo(payPrice)==-1){
                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()));
                }else if(payedPrice.compareTo(payPrice)==0){
                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
                }else if(payedPrice.compareTo(payPrice)==1){
                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
                }
            }
        }
        orderService.updateOrderPayPrice(order);
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("moenychanges", orderMoneyChangeRecs);
        map.put("payPrice", payPrice);
        return new MessageData(SysConstant.OPERATE_SUCCESS, SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, null, map);
    }
    /**
     * 订单导出
     */
    @ResponseBody
    @RequestMapping(value = "downOrderFile", method = {RequestMethod.GET})
    public void downOrderFile(HttpServletResponse response,HttpServletRequest request,@RequestParam String orderNo,@RequestParam String memberAccount,
    		@RequestParam String linkMan,@RequestParam Integer productId,@RequestParam String productName,@RequestParam Date createTimeStart,
    		@RequestParam Date createTimeEnd,@RequestParam Date travelTimeStart,@RequestParam Date travelTimeEnd,@RequestParam String os,@RequestParam String phone
    		) {
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
    	OrderAndInvoice orderAndInvoice = new OrderAndInvoice();
		orderAndInvoice.setSellerId(sellerUser.getSellerId());
		orderAndInvoice.setMemberAccount(memberAccount);
		orderAndInvoice.setPhone(phone);
		orderAndInvoice.setLinkMan(linkMan);
		orderAndInvoice.setProductId(productId);
		orderAndInvoice.setProductName(productName);
		if(createTimeStart!=null){
			orderAndInvoice.setCreateTimeStart(DateUtil.getDayMinTime(createTimeStart));
		}
        if(createTimeEnd!=null){
	        orderAndInvoice.setCreateTimeEnd(DateUtil.getDayMaxTime(createTimeEnd));
		}
        if(travelTimeStart!=null){
			orderAndInvoice.setTravelTimeStart(DateUtil.getDayMinTime(travelTimeStart));
		}
        if(travelTimeEnd!=null){
			orderAndInvoice.setTravelTimeEnd(DateUtil.getDayMaxTime(travelTimeEnd));
		}
		orderAndInvoice.setOrderNo(orderNo);
		if(StringUtils.isNotBlank(os)){
			String[] strStatus = os.split(",");
			Integer[] status = new Integer[strStatus.length];
			for (int j = 0; j < strStatus.length; j++) {
				status[j] = Integer.valueOf(strStatus[j]);
			}
			orderAndInvoice.setStatuses(status);
		}
        orderService.downOrderFile(response,request,orderAndInvoice);
    }
    
    /**
     * 退款
     */
    @ResponseBody
    @RequestMapping(value = "orderRefund", method = {RequestMethod.POST})
    public MessageData orderRefund(HttpServletRequest request,OrderPayRecord refundRecord) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        if(sellerUser!=null){
            try {
                logger.warn("OrderController orderRefund refundRecord refundRecord id:"+refundRecord.getId());
                logger.warn("OrderController orderRefund refundRecord orderId:"+refundRecord.getOrderId());
                logger.warn("OrderController orderRefund refundRecord refundPrice:"+refundRecord.getTotalPrice());
                logger.warn("OrderController orderRefund refundRecord remark:"+refundRecord.getRemark());
                
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("encode", EncryptPkUtil.encodeId(refundRecord.getId().toString()));
                map.put("refundPrice", refundRecord.getTotalPrice());
                map.put("remark", StringUtils.isBlank(refundRecord.getRemark())?"退款":refundRecord.getRemark());
                map.put("sellerId", sellerUser.getSellerId());
                //调用退款接口
                String url = PropertiesUtil.getProperty("scenic.api.refund.url");
                JSONObject refundResult = JSON.parseObject(HttpClient.sendPost(url, map).toString());
                if(refundResult!=null){
                    logger.warn("OrderController orderRefund refundResult status:"+refundResult.get("status"));
                    logger.warn("OrderController orderRefund refundResult message:"+refundResult.get("message"));
                    if(200 != Integer.valueOf(refundResult.get("status").toString())){
                        return new MessageData(500, refundResult.get("message")==null?"退款失败了...":refundResult.get("message").toString());
                    }else{
                        return new MessageData(200, "退款成功！");
                    }
                }else{
                    return new MessageData(200, "退款失败了...");
                }
            } catch (Exception e) {
                logger.warn("OrderController orderRefund error...",e);
                return new MessageData(500, "退款服务调用失败！");
            }
        }else{
            return new MessageData(500, "请登录后操作！");
        }
    }
    
    /**
     * 弹出退款框时，将参数传到弹出层
     */
    @ResponseBody
    @RequestMapping(value = "refund/refundPage", method = {RequestMethod.POST})
    public MessageData refundPage(OrderPayRecord refundRecord){ 
        return new MessageData(200, "退款失败",refundRecord);
    }
    /**
     * 
     * 核销码
     * @param request
     * @param order
     * @return
     * @creator ：lzj  
     * @date ：2017年8月23日下午6:19:52
     */
    @ResponseBody
    @RequestMapping(value = "updateOrderWriteOffCode", method = {RequestMethod.POST})
    public MessageData updateOrderWriteOffCode(HttpServletRequest request,Order order){ 
    	MessageData data=new MessageData(200, "核销成功");
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
    	 if(sellerUser!=null){
    		 try {
    			 order.setSellerId(sellerUser.getSellerId());
    			 order.setWriteoffcode(StringUtils.isNotBlank(order.getWriteoffcode()) ? order.getWriteoffcode().toLowerCase():null);
    			 Order oldOrder=orderService.selectOrderWriteOffCode(order);
    			 if(oldOrder==null){
    				 data.setStatusCode(201);
    				 data.setMessage("核销码不正确，请确认！");
    				 return data;
    			 }
    			 //	仅全款或超额支付订单，显示核销码 	适用于”景点”类和”购物”类产品订单
    			 if(oldOrder.getSaledCheck()==1){
    				 data.setStatusCode(201);
    				 data.setMessage("核销码已使用");
    				 return data; 
    			 }
 
    			 if(oldOrder.getPayStatus()!=3 && oldOrder.getPayStatus()!=4){
    				 data.setStatusCode(201);
    				 data.setMessage("订单未全款，无法核销");
    				 return data; 
    			 }
    			 if(oldOrder.getOrderStatus()==5){
    				 data.setStatusCode(201);
    				 data.setMessage("该订单已退单，无法核销");
    				 return data; 
    			 }
 
    			 order.setSaledCheck(1);
    			 order.setOrderStatus(6);
    			 order.setId(oldOrder.getId());
    			 orderService.updateOrderWriteOffCode(order);
			} catch (Exception e) {
				// TODO: handle exception
				   logger.warn("OrderController orderRefund error...");
	           return new MessageData(500, "核销失败");
			}
    	 }else{
    		 return new MessageData(500, "请登录后操作！");
    	 }
    	return data;
    }
    
    @ResponseBody
    @RequestMapping(value = "orderRefused", method = {RequestMethod.POST})
    public MessageData orderRefused(HttpServletRequest request, Order order,Integer type,String inputReasons) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        MessageData data=new MessageData(200, "操作成功");
        try {
    		if(sellerUser==null){
    			data.setMessage("请登录后操作！");
    			data.setStatusCode(500);
    			return data;
            }
    		 
			if(StringUtils.isNotBlank(inputReasons)){
				if(inputReasons.length()>512){
					data.setMessage("您已超过512个字符，请重新输入");
					data.setStatusCode(500);
					return data;
				}
			}
			if(type==1){
				order.setOrderStatus(5);//接受退单
			}else if(type==2){
//				Order orderOld=orderService.selectOrderWriteOffCode(order);
//				if(orderOld.getPayStatus()>1){
//					data.setMessage("商家取消“已确认”订单仅限于“未付款”订单");
//					data.setStatusCode(500);
//					return data;
//				}
				order.setOrderStatus(3);//拒绝退单
			}
		 
    	    data = orderService.updateOrderRefused(order,sellerUser,type,inputReasons);//更改订单状态   	   
    	    return data;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
	          return new MessageData(500, "退单失败！");
		}
    }  
    
    /**
     * 确认退货
     * 此处为类方法说明
     * @param request
     * @param order
     * @param type
     * @param refundReasons
     * @return
     * @creator ：Administrator  
     * @date ：2017年9月7日下午6:52:10
     */
    @ResponseBody
    @RequestMapping(value = "confirmReturnGoods", method = {RequestMethod.POST})
    public MessageData confirmReturnGoods(HttpServletRequest request, Order order,Integer type,String refundReasons) {
        BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
        MessageData data=new MessageData(200, "操作成功");
        try {
    		if(sellerUser==null){
    			data.setMessage("请登录后操作！");
    			data.setStatusCode(500);
    			return data;
            }
			if(StringUtils.isNotBlank(refundReasons)){
				if(refundReasons.length()>512){
					data.setMessage("您已超过512个字符，请重新输入");
					data.setStatusCode(500);
					return data;
				}
			}
			if(type == 1){
				order.setOrderStatus(9);//接受退货，接受后，订单状态为已退货。
			}else if(type==2){
				order.setOrderStatus(7);//拒绝退货，拒绝后，订单状态回到已发货
			}
    	    data = orderService.updateOrderReturnGoods(order,sellerUser,type,refundReasons);//更改订单状态   	   
    	    return data;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
	          return new MessageData(500, "退货失败！");
		}
    } 
    
    @ResponseBody
    @RequestMapping(value = "updateOrderExpress", method = {RequestMethod.POST})
    public MessageData updateOrderExpress(HttpServletRequest request,Order order,Integer type){ 
    	MessageData data=new MessageData(200, "操作成功");
    	BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
    	  try {
    		  if(sellerUser==null){
      			data.setMessage("请登录后操作！");
      			data.setStatusCode(500);
      			return data;
              }
    		  //已发货
    		  if(type==0){
    			  order.setOrderStatus(7);
    			  //确认时间为当前时间，+7天
    			  order.setExpressConfirmTime(DateUtil.currentDateAddOrReduce(new Date(), 7));
    		  }else if(type>1){
    			  logger.error("异常操作，手动修改");
    			  data.setMessage("快递修改失败");
    			  data.setStatusCode(201);
    			  return data;
    		  }
    		  orderService.updateOrderExpress(order,sellerUser,type);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			data.setMessage("添加快递失败");
			data.setStatusCode(201);
		}
    	  return data;
    }
}
