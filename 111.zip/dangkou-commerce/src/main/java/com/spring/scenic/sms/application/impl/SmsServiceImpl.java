package com.spring.scenic.sms.application.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.sms.application.SmsService;
import com.spring.scenic.sms.domain.MsgSms;
import com.spring.scenic.sms.infrastructure.MsgSmsMapper;

@Service
public class SmsServiceImpl implements SmsService {
    
    @Autowired
    private MsgSmsMapper msgSmsMapper;

    @Override
    public int saveMsgSmsRecord(String phone, String businessType, String sms) {
    	try {
            MsgSms msgSms = new MsgSms();
            msgSms.setReceiverNo(phone);
            msgSms.setMsgContent(sms);
            msgSms.setBusinessType(businessType);
            msgSms.setSendStatus(1);
            msgSms.setCreateTime(new Date());
            return msgSmsMapper.saveMsgSmsRecord(msgSms);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public List<MsgSms> getSmsRecordList(MsgSms msgSms) {
        try {
            return msgSmsMapper.selectMsgSms(msgSms);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public int validateCaptcha(MsgSms msgSms) {
        try {
            return msgSmsMapper.validateCaptcha(msgSms);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public boolean validateTheCaptcha(MsgSms msgSms) {
        try {
            return msgSmsMapper.validateCaptcha(msgSms)>0;
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

    @Override
    public int saveMsgSmsRecord(MsgSms msgSms) {
        try {
            return msgSmsMapper.saveMsgSmsRecord(msgSms);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }



}
