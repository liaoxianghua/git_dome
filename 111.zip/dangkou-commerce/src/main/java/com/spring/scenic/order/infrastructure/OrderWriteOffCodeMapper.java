package com.spring.scenic.order.infrastructure;

import com.spring.scenic.order.domain.OrderWriteOffCode;
/**
 *  核销记录mapper
 * 此处为类说明
 * @author lzj
 * @date 2017年8月16日
 */
public interface OrderWriteOffCodeMapper {

      
    /**
     * 修改核销记录
     * 此处为类方法说明
     * @param orderWriteOffCode
     * @return
     * @creator ：lzj  
     * @date ：2017年8月16日下午7:27:13
     */
	int updateorderWriteOffCode(OrderWriteOffCode orderWriteOffCode);
    
}
