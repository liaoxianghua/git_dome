package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.order.domain.OrderLinkmanDoc;

public interface OrderLinkmanDocMapper {
	
	List<OrderLinkmanDoc> getOrderLinkmanDocList(OrderLinkmanDoc orderLinkmanDoc);

}
