package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.order.domain.OrderLinkmanRef;

public interface OrderLinkmanRefMapper {

	List<OrderLinkmanRef> getOrderLinkmanRefList(OrderLinkmanRef orderLinkmanRef);
}
