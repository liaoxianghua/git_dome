package com.spring.scenic.product.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class KeywordRef extends Entity<KeywordRef> implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private String ids;

    private Integer outRelatedId;
    
    private Integer outRelatedType;
    
    private Integer keywordId;
    
    private Date createTime;

    private Integer createUser;
    
    private String createUserName;

    private Date updateTime;

    private Integer updateUser;
    
    private String updateUserName;
    
    private Integer ord;
    
    private Keyword keyword;
    
    private String flag;
    
	public Integer getKeywordId() {
		return keywordId;
	}

	public void setKeywordId(Integer keywordId) {
		this.keywordId = keywordId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOutRelatedId() {
		return outRelatedId;
	}

	public void setOutRelatedId(Integer outRelatedId) {
		this.outRelatedId = outRelatedId;
	}

	public Integer getOutRelatedType() {
		return outRelatedType;
	}

	public void setOutRelatedType(Integer outRelatedType) {
		this.outRelatedType = outRelatedType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateUserName() {
		return updateUserName;
	}

	public Keyword getKeyword() {
		return keyword;
	}

	public void setKeyword(Keyword keyword) {
		this.keyword = keyword;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Integer getOrd() {
		return ord;
	}

	public void setOrd(Integer ord) {
		this.ord = ord;
	}

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    
}