package com.spring.scenic.product.domain.vo;

import java.util.List;

import com.spring.scenic.product.domain.ProductStock;

/**
 * 库存日历
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年4月13日
 */
public class ProductStockMounthVo  { 
	
	List<ProductStock> stocks;

	public List<ProductStock> getStocks() {
		return stocks;
	}

	public void setStocks(List<ProductStock> stocks) {
		this.stocks = stocks;
	}
}
