package com.spring.scenic.common.util;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.EnumMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;



 /**
  * 二维码生成工具
  * 此处为类说明
  * @author lzj
  * @date 2017年8月16日
  */
public class DimensionUtil {
	private static final Logger LOGGER = Logger.getLogger(DimensionUtil.class);

	/**
	 * 生成二维码
	 * @param args
	 */
	public static String genQC(String url,String filePath) {
		int size = 250;
		String fileType = "png";
		File myFile = new File(filePath);
		myFile.getParentFile().mkdirs();
		try {
			
			Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
			hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
			
			hintMap.put(EncodeHintType.MARGIN, 1); 
			hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
 
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			BitMatrix byteMatrix = qrCodeWriter.encode(url, BarcodeFormat.QR_CODE, size,
					size, hintMap);
			int CrunchifyWidth = byteMatrix.getWidth();
			BufferedImage image = new BufferedImage(CrunchifyWidth, CrunchifyWidth,
					BufferedImage.TYPE_INT_RGB);
			image.createGraphics();
 
			Graphics2D graphics = (Graphics2D) image.getGraphics();
			graphics.setColor(Color.WHITE);
			graphics.fillRect(0, 0, CrunchifyWidth, CrunchifyWidth);
			graphics.setColor(Color.BLACK);
 
			for (int i = 0; i < CrunchifyWidth; i++) {
				for (int j = 0; j < CrunchifyWidth; j++) {
					if (byteMatrix.get(i, j)) {
						graphics.fillRect(i, j, 1, 1);
					}
				}
			}
			ImageIO.write(image, fileType, myFile);
		} catch (Exception e) {
			LOGGER.error(e);
			return "";
		} 
		return filePath;
	}
	
	/**
	 * 二维码生成写入流
	 * @param url
	 * @param filePath
	 * @return
	 */
	public static InputStream genQC(String url) {
		int size = 250;
		String fileType = "png";
		try {
			
			Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
			hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
			
			hintMap.put(EncodeHintType.MARGIN, 1); 
			hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
 
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			BitMatrix byteMatrix = qrCodeWriter.encode(url, BarcodeFormat.QR_CODE, size,
					size, hintMap);
			int CrunchifyWidth = byteMatrix.getWidth();
			BufferedImage image = new BufferedImage(CrunchifyWidth, CrunchifyWidth,
					BufferedImage.TYPE_INT_RGB);
			image.createGraphics();
 
			Graphics2D graphics = (Graphics2D) image.getGraphics();
			graphics.setColor(Color.WHITE);
			graphics.fillRect(0, 0, CrunchifyWidth, CrunchifyWidth);
			graphics.setColor(Color.BLACK);
 
			for (int i = 0; i < CrunchifyWidth; i++) {
				for (int j = 0; j < CrunchifyWidth; j++) {
					if (byteMatrix.get(i, j)) {
						graphics.fillRect(i, j, 1, 1);
					}
				}
			}
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			ImageIO.write(image, fileType, os);
			InputStream is = new ByteArrayInputStream(os.toByteArray());
			return is;
		} catch (Exception e) {
			LOGGER.error(e);
		} 
		return null;
	}
	 /**
	  * 根据URL链接生成二维码64位图片
	  * @param url 要访问的后台的接口地址
	  * @return
	  * @creator ：lzj  
	  * @date ：2017年8月16日下午4:55:23
	  */
	public static String base64ImageGenQC(String url) {
		int size = 250;
		String fileType = "png";
		try {
			
			Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
			hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
			
			hintMap.put(EncodeHintType.MARGIN, 1); 
			hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
 
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			BitMatrix byteMatrix = qrCodeWriter.encode(url, BarcodeFormat.QR_CODE, size,
					size, hintMap);
			int CrunchifyWidth = byteMatrix.getWidth();
			BufferedImage image = new BufferedImage(CrunchifyWidth, CrunchifyWidth,
					BufferedImage.TYPE_INT_RGB);
			image.createGraphics();
 
			Graphics2D graphics = (Graphics2D) image.getGraphics();
			graphics.setColor(Color.WHITE);
			graphics.fillRect(0, 0, CrunchifyWidth, CrunchifyWidth);
			graphics.setColor(Color.BLACK);
 
			for (int i = 0; i < CrunchifyWidth; i++) {
				for (int j = 0; j < CrunchifyWidth; j++) {
					if (byteMatrix.get(i, j)) {
						graphics.fillRect(i, j, 1, 1);
					}
				}
			}
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			ImageIO.write(image, fileType, os);
			byte[] b = os.toByteArray();
			os.close();
			//输出流转图片字节流
            String Base64Image= new String(Base64.encodeBase64(b));
            return Base64Image;
		} catch (Exception e) {
			LOGGER.error(e);
		} 
		return null;
	}
	
	/**
     * 给二维码图片添加Logo
     * 
     * @param qrPic
     * @param logoPic
     */
//    public void addLogo_QRCode(File qrPic, File logoPic, LogoConfig logoConfig)
//    {
//        try
//        {
//            if (!qrPic.isFile() || !logoPic.isFile())
//            {
//                System.out.print("file not find !");
//                System.exit(0);
//            }
//
//            /**
//             * 读取二维码图片，并构建绘图对象
//             */
//            BufferedImage image = ImageIO.read(qrPic);
//            Graphics2D g = image.createGraphics();
//
//            /**
//             * 读取Logo图片
//             */
//            BufferedImage logo = ImageIO.read(logoPic);
//            
//            int widthLogo = logo.getWidth(), heightLogo = logo.getHeight();
//            
//            // 计算图片放置位置
//            int x = (image.getWidth() - widthLogo) / 2;
//            int y = (image.getHeight() - logo.getHeight()) / 2;
//
//            //开始绘制图片
//            g.drawImage(logo, x, y, widthLogo, heightLogo, null);
//            g.drawRoundRect(x, y, widthLogo, heightLogo, 15, 15);
//            g.setStroke(new BasicStroke(logoConfig.getBorder()));
//            g.setColor(logoConfig.getBorderColor());
//            g.drawRect(x, y, widthLogo, heightLogo);
//            
//            g.dispose();
//            
//            ImageIO.write(image, "jpeg", new File("D:/newPic.jpg"));
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//    }
	
}
