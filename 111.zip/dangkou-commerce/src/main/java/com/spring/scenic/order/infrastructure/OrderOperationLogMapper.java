package com.spring.scenic.order.infrastructure;

import com.spring.scenic.order.domain.OrderOperationLog;


public interface OrderOperationLogMapper {

	void saveOrderOperationLog(OrderOperationLog orderOperationLog);
	
}
