package com.spring.scenic.order.application;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderMoneyChangeRec;
import com.spring.scenic.order.domain.vo.OrderAndInvoice;

public interface OrderService {

    Map<String, Integer> getOrderStatistic(BusiSellerUser sellerUser);

    List<Order> getOrderList(Order order, boolean page);

    Order getOrder(Order exampleOrder);

    List<Order> getOrderListWithWarn(Order order, boolean page);

    int updateOrderStatus(Order order,BusiSellerUser sellerUser);

    int saveSellerRemark(Order order);

    int saveOrderMoneyChange(BusiSellerUser sellerUser, OrderMoneyChangeRec orderMoneyChangeRec);

    List<OrderMoneyChangeRec> getOrderMoneyChangeList(OrderMoneyChangeRec orderMoneyChangeRec);

    BigDecimal calculatePayPrice(BigDecimal orderPrice, List<OrderMoneyChangeRec> orderMoneyChangeRecs);

    int updateOrderPayPrice(Order order);

	void downOrderFile(HttpServletResponse response,HttpServletRequest request,OrderAndInvoice orderAndInvoice);//订单的导出

	public Order selectByOrderNo(String orderId);

	Order selectOrderWriteOffCode(Order order);

	int updateOrderWriteOffCode(Order order);

	MessageData updateOrderRefused(Order order, BusiSellerUser sellerUser,Integer type, String inputReasons);

	MessageData updateOrderReturnGoods(Order order, BusiSellerUser sellerUser,Integer type, String refundReasons);

	/**
	 * 增加快递信息
	 * 此处为类方法说明
	 * @param order
	 * @param type 
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年9月6日下午4:57:49
	 */

	int updateOrderExpress(Order order, BusiSellerUser sellerUser, Integer type);


}
