package com.spring.scenic.system.infrastructure;

import java.util.List;

import com.spring.scenic.system.domain.VersionRecord;
public interface VersionRecordMapper{

	public int insert(VersionRecord entity);
	
	public int update(VersionRecord entity);
	
	public int deleteById(Integer id);
	
	public int deleteByIds(List<Integer> ids);
	
	public VersionRecord selectById(Integer id);
	
	public List<VersionRecord> selectPage(VersionRecord entity);

    public VersionRecord selectMaxAndroidVersion();

    public VersionRecord selectMaxIOSVersion();
}
