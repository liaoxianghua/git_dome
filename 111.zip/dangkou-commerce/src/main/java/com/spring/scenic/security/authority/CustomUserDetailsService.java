package com.spring.scenic.security.authority;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.spring.scenic.busi.application.BusiSellerUserService;
import com.spring.scenic.busi.domain.BusiSellerUser;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	
    @Autowired
    private BusiSellerUserService busiSellerUserService;

    @Override
	public UserDetails loadUserByUsername (String username) throws UsernameNotFoundException{
	    BusiSellerUser busiSellerUser = null;
        try {
            busiSellerUser = busiSellerUserService.getSellerByAccount(username);
    		if(busiSellerUser==null||busiSellerUser.getPwd()==null||"".equals(busiSellerUser.getPwd())){
    			throw new UsernameNotFoundException("error:User :"+username+" password is empty...");
    		}
    		String password = busiSellerUser.getPwd().toUpperCase();
    		UserDetails userDetails = new User(username, password, true, true, true, true,new HashSet<GrantedAuthority>());
    		return userDetails;
        } catch (Exception e) {
            throw new AuthenticationServiceException("获取商户信息异常！");
        }
	}
}