package com.spring.scenic.product.domain.vo;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

/**
 * 
 * 产品查询类
 * @author liaoxianghua
 * @date 2017年3月23日
 */
public class ProductVo extends Entity<ProductVo> implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = -852508785184092001L;

	private Integer id;

	/**
	 * 上架开始时间
	 */
	private Date saleStartTime;

	/**
	 * 上架结束时间
	 */
	private Date saleEndTime;

	/**
	 * 创建开始时间
	 */
	private Date createStartTime;

	// 创建结束时间
	private Date createEndTime;

	// 商家名称
	private Integer sellerId;

	// 是否上架
	private Integer isSale;

	// 产品名称
	private String productName;

	// 产品类别
	private Integer productType;

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public Integer getIsSale() {
		return isSale;
	}

	public void setIsSale(Integer isSale) {
		this.isSale = isSale;
	}

	public Date getSaleStartTime() {
		return saleStartTime;
	}

	public void setSaleStartTime(Date saleStartTime) {
		this.saleStartTime = saleStartTime;
	}

	public Date getSaleEndTime() {
		return saleEndTime;
	}

	public void setSaleEndTime(Date saleEndTime) {
		this.saleEndTime = saleEndTime;
	}

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}
}
