package com.spring.scenic.order.infrastructure;

import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.vo.OrderAndInvoice;
import com.spring.scenic.order.domain.vo.OrderStatistic;

public interface OrderMapper {

    List<Order> getOrderList(Order order);

    List<OrderStatistic> getOrderStatisticTotal(BusiSellerUser sellerUser);

    List<OrderStatistic> getOrderStatisticToday(BusiSellerUser sellerUser);

    Order getOrder(Order exampleOrder);

    List<Order> getOrderListWithWarn(Order order);

    int updateOrderStatus(Order order);

    int saveSellerRemark(Order order);

    int updateOrderPayPrice(Order order);
    
    List<OrderAndInvoice> selectOrderAndInvoice(OrderAndInvoice orderAndInvoice);
    /**
     * 查询已确认 已支付 超支付 过了出行日期的订单
     * 此处为类方法说明
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月9日上午10:21:28
     */
    List<Order> getOrderListForQuartz();
    
    /**
     * 查询出过了确认时间 但是还没有确认的新单
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月17日下午4:51:55
     */
    List<Order> selectUnConfirm();
    
    /**
     * 更新订单状态
     * 此处为类方法说明
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年5月9日上午10:21:28
     */
    void updateOrderStatusForQuartz(List<Order> list);
    /***
     * 
     *  描述: 根据订单编号查询出对应的订单信息
     * @param orderId
     * @return
     * @creator ：lzj  
     * @date ：2017年5月12日下午4:44:40
     */
	public Order selectByOrderNo(String orderId);
	/**
	 * 修改订单状态 和对应的核销码
	 * 此处为类方法说明
	 * @param order
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年8月18日下午3:39:10
	 */
	int updateOrderWriteOffCode(Order order);
	
	Order selectOrderWriteOffCode(Order order);
	/**
	 * 新增倒计时时间结束，订单自动进入“已完成”状态
	 * 此处为类方法说明
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年9月11日下午1:51:12
	 */
	List<Order> selectCountdownOrderStatus();
	/**
	 * 更新订单状态 倒计时时间结束，订单自动进入“已完成”状态
	 * 此处为类方法说明
	 * @param list
	 * @creator ：lzj  
	 * @date ：2017年9月11日下午2:17:33
	 */
	void updateCountdownOrderStatusQuartz(List<Order> list);

}
