package com.spring.scenic.sms.application;

import com.spring.scenic.sms.domain.MsgSmsRecord;
import java.util.List;

/**
 * 短信记录表服务接口。
 */
public interface MsgSmsRecordService {

	/**
	 * 基础添加
	 */
	public int insert(MsgSmsRecord entity);
	
	/**
	 * 基础更新
	 */
	public int update(MsgSmsRecord entity);
	
	/**
	 * 单个删除
	 */
	public int deleteById(Integer id);
	
	/**
	 * 批量删除 
	 */
	public int deleteByIds(List<Integer> ids);
	
	/**
	 * 根据主键查找
	 */
	public MsgSmsRecord selectById(Integer id);
	
	/**
	 * 分页可带条件查找
	 */
	public List<MsgSmsRecord> selectPage(MsgSmsRecord entity, boolean page);
}
