package com.spring.scenic.busi.application;

import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.domain.MessageData;

public interface BusiSellerService {
    
    BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser);

    MessageData saveInvoiceSet(BusiSeller busiSeller);

    BusiSeller getBusiSeller(BusiSeller busiSeller);
    /**
     * 首页显示用户商户信息
     * @param sellerUser
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年7月28日下午1:14:25
     */
    BusiSeller selectScenicSellerInfo(BusiSellerUser sellerUser);

}
