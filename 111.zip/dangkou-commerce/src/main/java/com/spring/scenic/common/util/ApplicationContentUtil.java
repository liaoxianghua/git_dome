package com.spring.scenic.common.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
 
/**
 * @Description 系统上下文工具类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public class ApplicationContentUtil implements ApplicationContextAware {
	
	public static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)throws BeansException {
		if(ApplicationContentUtil.applicationContext==null){
			ApplicationContentUtil.applicationContext=applicationContext;
		}
	}

	public static ApplicationContext getApplicationContext(){
		return ApplicationContentUtil.applicationContext;
	}
	
	public static Object getBean(String beanName){
		return ApplicationContentUtil.applicationContext.getBean(beanName);
	}

	public static HttpServletRequest getHttpServletRequest (){
		return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	}
	
	public static HttpSession getHttpSession() {
		return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
	}

	public static String getServletContextRealPath (){
		return getHttpServletRequest().getServletContext().getRealPath("");
	}
	
	
}
