package com.spring.scenic.picture.domain.vo;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class BusiPictureLibVo extends Entity<BusiPictureLibVo> {
	
	private Date createStartTime;
	private Date createEndTime;
	private String picName;// 图片名称 
	private Integer useType;
	private Integer createUser;
	private Integer valid;
	
	
	public Integer getValid() {
		return valid;
	}

	public void setValid(Integer valid) {
		this.valid = valid;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Integer getUseType() {
		return useType;
	}

	public void setUseType(Integer useType) {
		this.useType = useType;
	}

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}

	public String getPicName() {
		return picName;
	}

	public void setPicName(String picName) {
		this.picName = picName;
	}
}
