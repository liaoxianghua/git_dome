package com.spring.scenic.sms.domain;

import com.spring.scenic.common.domain.Pager;
/**
 * 实体对象：短信记录表
 */
public class MsgSmsRecord extends Pager<MsgSmsRecord>{

	private static final long serialVersionUID = 4065887035574600999L;

	// ~~~~实体属性
	// 主键
	private Integer id;
	// 订单号
	private String orderNo;
	// 手机号
	private String receiverNo;
	// 短信内容
	private String msgContent;
	// 返回内容
	private String returnContent;
	// 返回状态
	private String returnStatus;
	// 发送状态  0未发送 1成功 2 失败
	private Integer sendStatus;
	// 创建人
	private Integer createUser;
	// 创建时间
	private java.util.Date createTime;
	// 修改人
	private Integer updateUser;
	// 修改时间
	private java.util.Date updateTime;
 
	public Integer getId() {
		return this.id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderNo() {
		return this.orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getReceiverNo() {
		return this.receiverNo;
	}
	public void setReceiverNo(String receiverNo) {
		this.receiverNo = receiverNo;
	}
	public String getMsgContent() {
		return this.msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	public String getReturnContent() {
		return this.returnContent;
	}
	public void setReturnContent(String returnContent) {
		this.returnContent = returnContent;
	}
	public String getReturnStatus() {
		return this.returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	public Integer getSendStatus() {
		return this.sendStatus;
	}
	public void setSendStatus(Integer sendStatus) {
		this.sendStatus = sendStatus;
	}
	public Integer getCreateUser() {
		return this.createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public java.util.Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(java.util.Date createTime) {
		this.createTime = createTime;
	}
	public Integer getUpdateUser() {
		return this.updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
	public java.util.Date getUpdateTime() {
		return this.updateTime;
	}
	public void setUpdateTime(java.util.Date updateTime) {
		this.updateTime = updateTime;
	}
}
