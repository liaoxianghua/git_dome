package com.spring.scenic.common.util;

import java.util.UUID;

import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dahantc.api.sms.json.JSONHttpClient;
 

public class SmsUtils {

	private static Logger logger = LoggerFactory.getLogger(SmsUtils.class);

	private static String account = "dh1866";// 用户名（必填）

	private static String password = "@niCZj9R";// 密码（必填）

	public static String sign = "【荡口古镇】"; // 短信签名（必填）

	public static String subcode = ""; // 子号码（可选）

	public static String msgid = UUID.randomUUID().toString().replace("-", ""); // 短信id，查询短信状态报告时需要，（可选）

	public static String sendtime = ""; // 定时发送时间（可选）
	
    /**   
     *发送短信
     */
    public static JSONObject sendSms(String phone,String content){
		JSONObject json = new JSONObject();
		try {
			JSONHttpClient jsonHttpClient = new JSONHttpClient("http://www.dh3t.com");
			jsonHttpClient.setRetryCount(1);
			String sendhRes = jsonHttpClient.sendSms(account, password, phone, content, sign, subcode);
			logger.info("提交单条普通短信响应：" + sendhRes);
			if (sendhRes.startsWith("{")) {
				json = JSONObject.fromObject(sendhRes);
			}
			return json;
		} catch (Exception e) {
			logger.error("短信发送异常===》{}", e.getMessage());
			json.put("result", "500");
			json.put("desc", "JSON转化异常 返回的不是JSON数据 ");
			return json;
		}
	}

}
