package com.spring.scenic.common.util.encrypt;

import com.spring.SpringEncryptor;

/**
 * 加解密工具
 */
public class EncryptPkUtil {
	
	private static SpringEncryptor sEncryptor = null;

	//解密
	public static String decodeId(String id) {
		if (sEncryptor == null) {
			sEncryptor = new SpringEncryptor();
		}
		id = sEncryptor.decode(id);
		return id;
	}
    //加密
	public static String encodeId(String id) {
		if (sEncryptor == null) {
			sEncryptor = new SpringEncryptor();
		}
		id = sEncryptor.encode(id);
		return id;
	}
}
