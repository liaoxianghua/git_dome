package com.spring.scenic.order.domain;

import java.io.Serializable;

import com.spring.scenic.common.domain.Entity;

public class OrderLinkmanDoc extends Entity<OrderLinkmanDoc> implements Serializable{
	
	private static final long serialVersionUID = -634033038706123574L;

	/**
	 * 此处为属性说明
	 */

	private Integer id;
	
	private Integer refId;//订单出行人关联ID
	
	private Integer documentId;//证件ID
	
	private String documentName;//证件名称
	
	private String documentNo;//证件编号
	
	private Integer  isDefault;//是否默认

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRefId() {
		return refId;
	}

	public void setRefId(Integer refId) {
		this.refId = refId;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public Integer getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Integer isDefault) {
		this.isDefault = isDefault;
	}


	
}
