package com.spring.scenic.busi.domain;

import java.util.Date;
/**
 * 
 * 此处为类说明：商户实体类
 * @author rmp
 * @date 2017年7月13日
 */
public class BusiSeller {
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 商户名
     */
    private String sellerName;
    /**
     * 所属景区id
     */
    private Integer scenicSellerId;
    /**
     * 备注
     */
    private String remark;
    /**
     * 是否有效（1：是0：否）
     */
    private Integer valid;
    /**
     * 创建人
     */
    private Integer createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private Integer updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 发票类型
     */
    private Integer invoiceType;
    /**
     * 快递支付方式
     */
    private Integer deliverPayWay;
    /**
     * 预付价格
     */
    private Integer prePayPrice;
    /**
     * 是否当面领取1：是，0：否
     */
    private Integer isTakeByselef;
    /**
     * 领取地址
     */
    private String takeAddress;
    
    private Integer userId;
    private String username;
    private Integer sellerId;
    private String truename;
    private String cityName;
    private String provinceName;
    private String cityAreaName;
    private String scenicSellerName;
    private String address;
    private String tel;
    private String starLevel;
    private String introduce;
    private Integer scenicSellerType;
    private Integer typeCategory;
    private String typeCategoryName;
    private Integer scenicValid;
    
    public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getTruename() {
		return truename;
	}

	public void setTruename(String truename) {
		this.truename = truename;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getCityAreaName() {
		return cityAreaName;
	}

	public void setCityAreaName(String cityAreaName) {
		this.cityAreaName = cityAreaName;
	}

	public String getScenicSellerName() {
		return scenicSellerName;
	}

	public void setScenicSellerName(String scenicSellerName) {
		this.scenicSellerName = scenicSellerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getStarLevel() {
		return starLevel;
	}

	public void setStarLevel(String starLevel) {
		this.starLevel = starLevel;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public Integer getScenicSellerType() {
		return scenicSellerType;
	}

	public void setScenicSellerType(Integer scenicSellerType) {
		this.scenicSellerType = scenicSellerType;
	}

	public Integer getTypeCategory() {
		return typeCategory;
	}

	public void setTypeCategory(Integer typeCategory) {
		this.typeCategory = typeCategory;
	}

	public String getTypeCategoryName() {
		return typeCategoryName;
	}

	public void setTypeCategoryName(String typeCategoryName) {
		this.typeCategoryName = typeCategoryName;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName == null ? null : sellerName.trim();
    }

    public Integer getScenicSellerId() {
        return scenicSellerId;
    }

    public void setScenicSellerId(Integer scenicSellerId) {
        this.scenicSellerId = scenicSellerId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getValid() {
        return valid;
    }

    public void setValid(Integer valid) {
        this.valid = valid;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(Integer invoiceType) {
        this.invoiceType = invoiceType;
    }

    public Integer getDeliverPayWay() {
        return deliverPayWay;
    }

    public void setDeliverPayWay(Integer deliverPayWay) {
        this.deliverPayWay = deliverPayWay;
    }

    public Integer getPrePayPrice() {
        return prePayPrice;
    }

    public void setPrePayPrice(Integer prePayPrice) {
        this.prePayPrice = prePayPrice;
    }

    public Integer getIsTakeByselef() {
        return isTakeByselef;
    }

    public void setIsTakeByselef(Integer isTakeByselef) {
        this.isTakeByselef = isTakeByselef;
    }

    public String getTakeAddress() {
        return takeAddress;
    }

    public void setTakeAddress(String takeAddress) {
        this.takeAddress = takeAddress == null ? null : takeAddress.trim();
    }

    public Integer getScenicValid() {
        return scenicValid;
    }

    public void setScenicValid(Integer scenicValid) {
        this.scenicValid = scenicValid;
    }
    
    
}