package com.spring.scenic.product.application.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.product.application.ProductStockLogService;
import com.spring.scenic.product.domain.ProductStockLog;
import com.spring.scenic.product.infrastructure.ProductStockLogMapper;
@Service
public class ProductStockLogServiceImpl implements ProductStockLogService {

	@Resource
	private ProductStockLogMapper productStockLogMapper;
	@Override
	public List<ProductStockLog> productStockLogList(ProductStockLog productStockLog,boolean page) {
		if (page) {
            PageHelper.startPage(productStockLog.getPageNum(), productStockLog.getPageSize());
        }
		return productStockLogMapper.select(productStockLog);
	}

}
