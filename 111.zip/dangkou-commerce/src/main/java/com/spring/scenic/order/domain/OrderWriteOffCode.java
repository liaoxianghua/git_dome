package com.spring.scenic.order.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * 此处为类说明 核销码
 * 
 * @author lzj
 * @date 2017年8月16日
 */
public class OrderWriteOffCode implements Serializable {

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1L;
	// 主键ID
	private Integer id;
	// 订单ID
	private String orderNo;
	// 核销方式 0表示 未操作 1表示扫码方式 2表示 手动输入
	private Integer scanMethod;
	// 核销码
	private String writeoffcode;
	// 是否核销（景点类和购物） 0表示 未核销 1 已核销
	private Integer saledCheck;
	// 商户ID
	private Integer sellerId;
	// 创建时间
	private Date createTime;
	// 创建者 (M网会员下单者)
	private Integer createUser;
	// 修改时间
	private Date updateTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getScanMethod() {
		return scanMethod;
	}

	public void setScanMethod(Integer scanMethod) {
		this.scanMethod = scanMethod;
	}

	public String getWriteoffcode() {
		return writeoffcode;
	}

	public void setWriteoffcode(String writeoffcode) {
		this.writeoffcode = writeoffcode;
	}

	public Integer getSaledCheck() {
		return saledCheck;
	}

	public void setSaledCheck(Integer saledCheck) {
		this.saledCheck = saledCheck;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
