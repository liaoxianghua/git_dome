package com.spring.scenic.comment.application;

import java.util.List;

import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.comment.domain.vo.ProductCommentVo;

/**
 * 
 * @author lzj
 * 描述:商品点评表
 * 日期:2017年4月1日15:22:08
 */
public interface ProductCommentService {

	/**
	 * 
	 * @param productComment
	 * @param flag
	 * @param pageSize
	 * @return
	 * 描述:查询商品点评列表
	 */
	public List<ProductComment> list(ProductCommentVo productCommentVo, boolean page);
	/**
	 * 
	 * @param productCommentVo
	 * @return
	 *  修改推荐状态
	 */
	public int updatestatus(ProductCommentVo productCommentVo);
	
	public  ProductComment findByIdProductComment(ProductCommentVo productCommentVo);
	/**
	 * 
	 * @param productCommentVo
	 * @return
	 * 描述:商家回复
	 * 2017年3月2日10:24:41
	 */
	public int updateReply(ProductCommentVo productCommentVo);
	/***
	 * 
	 * 此处为类方法说明
	 * @param productCommentVo
	 * @return
	 * @creator ：lzj
	 * @date ：2017年7月17日上午10:36:43
	 */
	public int updatePicStatus(ProductCommentVo productCommentVo,Integer userId);

}
