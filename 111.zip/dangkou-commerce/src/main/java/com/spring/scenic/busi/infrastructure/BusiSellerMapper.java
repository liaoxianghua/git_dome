package com.spring.scenic.busi.infrastructure;

import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;

public interface BusiSellerMapper {

    BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser);

    BusiSeller getBusiSeller(BusiSeller busiSeller);

    int updateByPrimaryKey(BusiSeller busiSellerExample);
    
    BusiSeller selectScenicSellerInfo(BusiSellerUser sellerUser);
    
}