package com.spring.scenic.system.intreface.controller;

import java.security.interfaces.RSAPublicKey;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.application.BusiSellerUserService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.domain.PasswordVo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.util.RSAUtils;
import com.spring.scenic.common.util.RSAkey;
import com.spring.scenic.facade.MsgSmsRecordFacade;
import com.spring.scenic.notice.application.NoticeService;
import com.spring.scenic.notice.domain.BusiNotice;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.security.authority.CustomInvocationSecurityMetadataSourceService;
import com.spring.scenic.security.authority.CustomUserDetailsService;
import com.spring.scenic.system.application.VersionRecordService;


/**
 * @Description 系统登录、退出等基础接口
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
@Controller
@RequestMapping("index")
public class IndexController {
	
    @Autowired
    private OrderService orderService;
    
    @Autowired
    private NoticeService noticeService;
    
	@Autowired
	private CustomUserDetailsService customUserDetailsService;
	@Resource
	private BusiSellerService busiSellerService;
	
	@Autowired
	private CustomInvocationSecurityMetadataSourceService  customInvocationSecurityMetadataSourceService;
	
	@Autowired
    private BusiSellerUserService busiSellerUserService;
	
	@Resource
	private MsgSmsRecordFacade msgSmsRecordFacade;
	
	@Resource
    private VersionRecordService versionRecordService;
	
	private static final Logger logger = Logger.getLogger(IndexController.class);
	/**
	 * 登录进主页
	 */
	@RequestMapping(value = "home", method = RequestMethod.GET)
	public String home(HttpServletRequest request,HttpServletResponse response) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(sellerUser == null){
			request.getSession().removeAttribute("user");
			request.getSession().invalidate();
			return "index/login";
		}
		BusiSeller busiSeller = busiSellerService.selectScenicSellerInfo(sellerUser);

		Map<String,Integer> orderStatisic = orderService.getOrderStatistic(sellerUser);
		BusiNotice topNotice = noticeService.getTop1Notice();
		List<BusiNotice> top5Notices = noticeService.getTop5Notice();
		request.setAttribute("active", 0);
		request.setAttribute("busiSeller", busiSeller);
		request.setAttribute("orderStatisic", orderStatisic);
		request.setAttribute("topNotice", topNotice);
		request.setAttribute("top5Notices", top5Notices);
		request.setAttribute("trueName", sellerUser.getTruename());
		request.getSession().setAttribute("trueName", sellerUser.getTruename());
		return "index/home";
	}
	
    
	/**
	 * 登出
	 */
	@RequestMapping(value="logout",method=RequestMethod.GET)
	public String logoutUser(HttpServletRequest request,HttpServletResponse response){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null){
		   new SecurityContextLogoutHandler().logout(request, response, authentication);
		}
		HttpSession session = request.getSession(true);
        if (session != null) {
        	session.removeAttribute(SysConstant.SESSION_USER);
        	session.invalidate();
        }
		return "index/login";
	}
	/**
	 * 修改密码
	 */
	@RequestMapping(value="updatepwd",method=RequestMethod.GET)
	public String updatepwd(HttpServletRequest request,HttpServletResponse response,PasswordVo vo){
		return "index/updateForgetPassword";
	}/**
	 * 确定修改密码
	 */
	@ResponseBody
	@RequestMapping(value="doUpdatepwd",method=RequestMethod.POST)
	public String doUpdatepwd(HttpServletRequest request,HttpServletResponse response,PasswordVo vo){
		BusiSellerUser busiSellerUser =(BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		BusiSellerUser bsu= busiSellerUserService.updatePwdById(vo,busiSellerUser);
		if(SysConstant.MESSAGE_TYPE_SUCCESS.equals(bsu.getFlag())){
			return "400";
		}else{
			return bsu.getFlag();
		}		
	}
	/**
	 * 忘记密码页面
	 */
	@RequestMapping(value="forgetPassword",method=RequestMethod.GET)
	public String forgetPasswordPage(HttpServletRequest request,HttpServletResponse response,PasswordVo vo){
		return "index/forgetPassword";
	}
	/**
	 * 获取验证码操作
	 */
	@ResponseBody
	@RequestMapping(value = "sendVerifyNum", method = RequestMethod.POST)
	public String getVerifyNum(HttpServletRequest request,HttpServletResponse response,PasswordVo vo){
		try {
            String phone=vo.getTelephone();//获取到客户端发来的手机号
            BusiSellerUser busiSellerUser = busiSellerUserService.getUserNameByPhone(request,vo);
            if(null!=busiSellerUser){
            	String[] beforeShuffle = new String[] {"0","1","2","3","4","5","6","7","8","9"};
            	String code = "";
            	for (int i = 0; i < 4; i++) {
            	    code+=beforeShuffle[new Random().nextInt(10)];
            	}
                //调用短信接口
            	//boolean sendSms = SmsUtils.sendSms(phone, "您好！您的验证码是："+code.toString()+"，请注意查收。");
            	boolean sendSuccess = msgSmsRecordFacade.saveMsgSmsRecord(phone, "您好！您的验证码是："+code.toString()+"，请注意查收。");
                if(sendSuccess){
                	HttpSession session = request.getSession();
          	        session.setAttribute(SysConstant.SESSION_VERIFY_CODE, code);
          	        session.setAttribute(SysConstant.SESSION_VERIFY_PHONE, phone);
          	        session.setAttribute(SysConstant.SESSION_VERIFY_DATE, System.currentTimeMillis());
          	        logger.warn("【调用短信接口】手机号："+phone+"，，获取验证码："+code+"，成功！");
          	        return "400";
          	    }else {
          	    	logger.warn("【调用短信接口】手机号："+phone+"，获取验证码："+code+"，失败！");
          	        return "短信发送失败";
          	    }
            }else{
                return "该手机号未绑定";
            }   
        } catch (Exception e) {
            logger.error("发送验证码失败！",e);
            return "短信发送失败";
        }   
	}
	/**
	 * 下一步按钮操作
	 */
	@ResponseBody
	@RequestMapping(value="updatePassword",method=RequestMethod.POST)
	public String updatePassword(HttpServletRequest request,HttpSession session,PasswordVo vo){
		String msg = "手机号或验证码不能为空";
		String verifyCode=vo.getVerifyNum();
		String verifyPhone =  vo.getTelephone();
		if(StringUtils.isNotBlank(verifyPhone) && StringUtils.isNotBlank(verifyCode)){
			if(session.getAttribute(SysConstant.SESSION_VERIFY_DATE)!=null){
				long afterTiem = (long)session.getAttribute(SysConstant.SESSION_VERIFY_DATE);
				if((System.currentTimeMillis()-afterTiem)>=(5*60*1000)){
					msg = "验证码已过期";
				}else{
					if(verifyCode.equals(session.getAttribute(SysConstant.SESSION_VERIFY_CODE))&&verifyPhone.equals(session.getAttribute(SysConstant.SESSION_VERIFY_PHONE))) {
						session.setAttribute(SysConstant.SESSION_VERIFY_CODE, null);
						//session.setAttribute(SysConstant.SESSION_VERIFY_PHONE, null);
						session.setAttribute(SysConstant.SESSION_VERIFY_DATE, null);
						msg = "400";
					}else{
						msg = "验证码不正确或验证码与手机不匹配";
					}
				}
			}else{
				msg = "验证码未发送";
			}
		}
		return msg;
	}

	/**
	 * 忘记密码的修改页面
	 */
	@RequestMapping(value="toUpdatePswPage",method=RequestMethod.GET)
	public String toUpdatePswPage(HttpServletRequest request,HttpServletResponse response){
		return "index/updatePassword";
	}
	/**
	 * 确定修改操作
	 */
	@ResponseBody
	@RequestMapping(value="toUpdatePassword",method=RequestMethod.POST)
	public String toUpdatePassword(HttpServletRequest request,HttpServletResponse response,BusiSellerUser busiSellerUser,PasswordVo vo){
		String msg=null;
		String newPassword= vo.getNewPassword();
		String confirPassword=vo.getConfirmPass();
		if(null!=newPassword||null!=confirPassword){
			this.busiSellerUserService.updatePwdByPhone(vo,busiSellerUser,request);
			msg = "400";
		}else{
			msg = "修改失败";
		}		
		return msg;
	}		
	
	/**
	 * 获取RSA公钥
	 */
	@ResponseBody
	@RequestMapping(value="getPublicKey",method=RequestMethod.POST)
	public RSAkey getPublicKey(HttpServletRequest request,HttpServletResponse response){
		RSAPublicKey publicKey = RSAUtils.getDefaultPublicKey();
		String modules=new String(Hex.encodeHex(publicKey.getModulus().toByteArray()));
		String exponent=new String(Hex.encodeHex(publicKey.getPublicExponent().toByteArray()));
		return new RSAkey(modules,exponent);
	}
	
	/**
	 * 验证用户是否首次登陆
	 */
	@ResponseBody
	@RequestMapping(value="validateFirstLogin",method=RequestMethod.POST)
	public boolean validateFirstLogin(HttpServletRequest request,HttpServletResponse response){
		return true;
	}
	
	@RequestMapping(value="main",method=RequestMethod.GET)
	public void main(HttpServletRequest request,HttpServletResponse response){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		System.out.println(authentication.getPrincipal());
		BusiSellerUser authUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		System.out.println(customUserDetailsService.loadUserByUsername(authUser.getUsername()));
		customInvocationSecurityMetadataSourceService.initResourceConfig();
	}
	/**
     * 参数验证(验证码)
     * @param httpSession
     * @param verifyNum
     */
    /*private void validInputParameters(HttpServletRequest request,String verifyNum) {
    	String verifyCode = (String) request.getSession().getAttribute(SysConstant.SESSION_VERIFY);
		if(StringUtils.isBlank(verifyNum) || StringUtils.isBlank(verifyCode)){
			request.setAttribute("loginError",MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
		}
		if (!verifyCode.toLowerCase().equals(verifyNum.toLowerCase())) {
			request.setAttribute("loginError",MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.wrongverifycode")); // 验证码不正确
		}		
	}*/
	
	/**
	 * 
	 * 判断服务是否正常
	 */
	@ResponseBody
    @RequestMapping(value="hello",method=RequestMethod.GET)
    public String hello(HttpServletRequest request,HttpServletResponse response){
        return "Hello！";
    }
	
	/**
     * 生成app下载路径二维码
     */
    @ResponseBody
    @RequestMapping(value="generateAPPdownLoadQC",method=RequestMethod.POST)
    public MessageData generateAPPdownLoadQC(HttpServletRequest request,HttpServletResponse response){
        MessageData messageData = versionRecordService.generateAPPdownLoadQC();
        return messageData;
    }       
	
}
