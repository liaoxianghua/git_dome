package com.spring.scenic.common.domain;


public class Pager<T> {

	/**
	 * 开始页
	 */
	protected Integer pageNum; 
	
	/**
	 * 每页大小
	 */
	protected Integer pageSize;

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	} 
}
