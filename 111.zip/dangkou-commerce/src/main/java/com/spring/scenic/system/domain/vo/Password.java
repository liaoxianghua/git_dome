package com.spring.scenic.system.domain.vo;

import java.io.Serializable;

/**
 * 密码
 * @author ranmaoping
 * 2017-01-14
 */
public class Password implements Serializable {
	
	private static final long serialVersionUID = -7780679957569654380L;
	
	/**
	 * 旧密码
	 */
	private String oldPassword;
	
	/**
	 * 新密码
	 */
	private String newPassword;
	
	/**
	 * 确认密码
	 */
	private String confirmPass;
	
	/**
	 * 用户ID
	 */
	private Integer userId;
	
	/**
	 * 登录密码
	 */
	private String loginPassword;

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPass() {
		return confirmPass;
	}

	public void setConfirmPass(String confirmPass) {
		this.confirmPass = confirmPass;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	
}	
