package com.spring.scenic.picture.intreface.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.intreface.controller.CommonController;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.picture.domain.vo.BusiPictureAttachVo;
import com.spring.scenic.picture.domain.vo.BusiPictureLibVo;

@Controller
@RequestMapping(value = "/picture")
public class PictureController extends CommonController {

	@Resource
	private BusiPictureLibService busipicturelibservice;

	@RequestMapping(value = "/pictures")
	public String pictures(HttpServletRequest request) {
		request.setAttribute("active", 3);
		return "picture/pictureList";
	}

	@ResponseBody
	@RequestMapping(value = "/picturesListData")
	public MessageData  picturesListData(BusiPictureLibVo busipicturelibvo, HttpServletRequest request) {
		MessageData messageData = new MessageData(200, "查询成功");
		if (StringUtils.isNotBlank(busipicturelibvo.getPicName())) {
			busipicturelibvo.setPicName(busipicturelibvo.getPicName().trim());
		}
		 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		 busipicturelibvo.setCreateUser(sellerUser.getId());
		 if(StringUtils.isNotBlank(busipicturelibvo.getPicName())){
			 busipicturelibvo.setPicName(busipicturelibvo.getPicName().trim());
		 }else{
			 busipicturelibvo.setPicName(null);
		 }
		 if(busipicturelibvo.getPageSize()>20){
			 busipicturelibvo.setPageSize(busipicturelibvo.getPageSize());
		 }else{
			 busipicturelibvo.setPageSize(20);
		 }
		List<BusiPictureLib> list = busipicturelibservice.list(busipicturelibvo, true);

		PageInfo<BusiPictureLib> page = new PageInfo<BusiPictureLib>(list,busipicturelibvo.getPageSize());
		request.setAttribute("page", page);
		messageData.setAttachObj(page);
		return messageData;
	}
	
	@ResponseBody
	@RequestMapping(value = "/picturesForProduct")
	public MessageData  picturesForProduct(BusiPictureLibVo busipicturelibvo, HttpServletRequest request) {
		MessageData messageData = new MessageData(200, "查询成功");
		if (StringUtils.isNotBlank(busipicturelibvo.getPicName())) {
			busipicturelibvo.setPicName(busipicturelibvo.getPicName().trim());
		}
		 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		 busipicturelibvo.setCreateUser(sellerUser.getId());
		 if(StringUtils.isNotBlank(busipicturelibvo.getPicName())){
			 busipicturelibvo.setPicName(busipicturelibvo.getPicName().trim());
		 }else{
			 busipicturelibvo.setPicName(null);
		 }
		List<BusiPictureLib> list = busipicturelibservice.list(busipicturelibvo, false);

		PageInfo<BusiPictureLib> page = new PageInfo<BusiPictureLib>(list,busipicturelibvo.getPageSize());
		request.setAttribute("page", page);
		messageData.setAttachObj(page);
		return messageData;
	}

	// 上传文件
	@ResponseBody
	@RequestMapping(value = "/saveUploadFile", method = { RequestMethod.POST })
	public MessageData saveUploadFile(HttpServletRequest request,String key) {

		MessageData messageData = new MessageData(200, "操作成功");
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
			messageData.setStatusCode(200);
			Map<String, Object> map = new HashMap<String, Object>();
			
			BusiPictureAttachVo busiPictureAttachvo=busipicturelibservice.saveUploadFile(filesMap);
			if(busiPictureAttachvo!=null){
				map.put("busiPictureAttachvo", busipicturelibservice.saveUploadFile(filesMap));
			}else{
				messageData.setStatusCode(500);
				messageData.setMessage("文件服务器异常");
				return messageData;
			}
			messageData.setAttachObj(map);
		} catch (Exception e) {
			messageData.setStatusCode(500);
			messageData.setMessage("文件服务器异常");
		}
		return messageData;

	}
	// 新增图片库
	@ResponseBody
	@RequestMapping(value = "/saveData", method = { RequestMethod.POST })
	public MessageData saveData(HttpServletRequest request,
								String url,String picName,
								String useType
			                   ) {
		 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		 if(StringUtils.isBlank(picName)){
			  return new MessageData(500, "请填写图片名称");
		 }
		String[] urlList = url.split(",");
		if(null==urlList ||""==url ||urlList.length==0){
			 return new MessageData(500, "请选择文件");
		}
		int result=0;
		  result=busipicturelibservice.saveData(picName.trim(),useType,url,sellerUser.getId());
		  if (result > 0) {
			  return new MessageData(200, "操作成功");
	      } else {
	    	  return new MessageData(500, "操作失败");
	      }
		
	}
	//  图片置为无效
	@ResponseBody
	@RequestMapping(value = "/delPicture", method = { RequestMethod.POST })
	public MessageData delPicture(HttpServletRequest request,Integer id) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		MessageData messageData = new MessageData(200, "操作成功");
		try {
			int result=busipicturelibservice.delPicture(id,sellerUser.getId());
		  if (result > 0) {
			  messageData.setStatusCode(200);
	      } else {
	    	  messageData.setStatusCode(500);
	    	  messageData.setMessage("置为失效失败");
	      }
		} catch (Exception e) {
			  messageData.setStatusCode(500);
			messageData.setMessage(e.getMessage());
		}
		return messageData;
	}

}
