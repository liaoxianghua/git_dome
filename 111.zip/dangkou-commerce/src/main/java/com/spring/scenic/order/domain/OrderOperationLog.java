package com.spring.scenic.order.domain;

import java.io.Serializable;
import java.util.Date;

import com.spring.scenic.common.domain.Entity;

public class OrderOperationLog extends Entity<OrderOperationLog> implements Serializable{

	/**
	 * 此处为属性说明
	 */
	private static final long serialVersionUID = 1884700290893067726L;

	/**
	 * 主键
     */
    private Integer id;
    
    /**
     * 订单ID
     */
    private Integer orderId;

    /**
     * 订单编号
     */
    private String orderNo;
    
    /**
     * 会员ID
     */
    private Integer memberId;
    
    /**
     * 商户ID
     */
    private Integer sellerId;

    /**
     * 快递公司名称
     */
    private String expressCompanyName;
    
    /**
     * 快递单号
     */
    private String expressNumber;
    
    /**
     * 发送信息
     */
    private String msgTitle;
    
    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 创建时间
     */
    private Date createDate;

    /**
     * 状态标识     1：	确认收货  2：	申请退货 3：已发货 4：定时任务自动变为已完成 5：确认退货;
     */
    private Integer status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getExpressCompanyName() {
		return expressCompanyName;
	}

	public void setExpressCompanyName(String expressCompanyName) {
		this.expressCompanyName = expressCompanyName;
	}

	public String getExpressNumber() {
		return expressNumber;
	}

	public void setExpressNumber(String expressNumber) {
		this.expressNumber = expressNumber;
	}

	public String getMsgTitle() {
		return msgTitle;
	}

	public void setMsgTitle(String msgTitle) {
		this.msgTitle = msgTitle;
	}

	public Integer getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
    
   
  
}