package com.spring.scenic.system.application.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DimensionUtil;
import com.spring.scenic.common.util.MultiPartUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.storage.fastdfs.storage.StorageService;
import com.spring.scenic.system.application.VersionRecordService;
import com.spring.scenic.system.domain.VersionRecord;
import com.spring.scenic.system.infrastructure.VersionRecordMapper;

@Service("versionRecordService")
public class VersionRecordServiceImpl implements VersionRecordService {
    
    private Logger logger = LoggerFactory.getLogger(VersionRecordServiceImpl.class);

	@Resource
	private VersionRecordMapper versionRecordMapper;
	
	@Resource(name = "fastDFSStorageService")
	private StorageService fastDFSStorageService;
	
	@Override
	public int insert(VersionRecord entity) {
		return versionRecordMapper.insert(entity);
	}
	
	@Override
	public int update(VersionRecord entity) {
		return versionRecordMapper.update(entity);
	}
	
	@Override
	public VersionRecord selectById(Integer id) {
		return versionRecordMapper.selectById(id);
	}
	
	@Override
	public int deleteById(Integer id) {
		return versionRecordMapper.deleteById(id);
	}
	
	@Override
	public int deleteByIds(List<Integer> ids) {
		return versionRecordMapper.deleteByIds(ids);
	}

    @Override
    public void contractAttachDownload(HttpServletResponse response, VersionRecord versionRecord) {
        try {
            VersionRecord version = versionRecordMapper.selectById(versionRecord.getId());
            if(version!=null) {
                String fileUrl = version.getAppUrl();
                logger.error("该文件的全路径为:"+fileUrl);
                if(StringUtils.isNotBlank(fileUrl)) {
                    String substrSuffix = fileUrl.substring(PropertiesUtil.getProperty(SysConstant.ATTACHMENT_VISIT_URL).length(), fileUrl.length());
                    String groupId = substrSuffix.substring(0,substrSuffix.indexOf("/"));
                    String remoteUrl =  substrSuffix.substring(substrSuffix.indexOf("/")+1,substrSuffix.length());
                    version.setFileName(remoteUrl);
                    logger.error("该文件的groupID为："+groupId);
                    logger.error("该文件的基本路径为:"+remoteUrl);
                    MultiPartUtil.downloadFromFastDfs(response, groupId, remoteUrl, version.getFileName());         
                }
            }else{
                throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
            }
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"),e);
        }

    }
    //读取配置文件中的地址，生成二维码,返回到登录页面
    @Override
    public MessageData generateAPPdownLoadQC() {
        String base64ImageQRCode = null;
        String appdownLoadQC = PropertiesUtil.getProperty("app.qr.code.download.page.url");
        logger.info("APP下载的地址为================="+appdownLoadQC);
        if(StringUtils.isNotBlank(appdownLoadQC)) {
            base64ImageQRCode = DimensionUtil.base64ImageGenQC(appdownLoadQC);
            base64ImageQRCode = "data:image/png;base64,"+base64ImageQRCode;
        }
//        Map<String,String> map = new HashMap<String,String>();
//        VersionRecord maxAndroidVersion = versionRecordMapper.selectMaxAndroidVersion();
//        VersionRecord maxIOSVersion = versionRecordMapper.selectMaxIOSVersion();
//        if(null!=maxAndroidVersion) {
//            String androidQC = DimensionUtil.base64ImageGenQC(maxAndroidVersion.getAppUrl());
//            map.put("androidQC","data:image/png;base64,"+androidQC);
//        }
//        if(null!=maxIOSVersion) {
//            String iOSQC = DimensionUtil.base64ImageGenQC(maxIOSVersion.getAppUrl());
//            map.put("iOSQC","data:image/png;base64,"+iOSQC);
//        }
        return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE,base64ImageQRCode);
    }
    
}
