package com.spring.scenic.system.application;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.system.domain.VersionRecord;

/**
 * 版本控制表服务接口。
 */
public interface VersionRecordService{

	/**
	 * 基础添加
	 */
	public int insert(VersionRecord entity);
	
	/**
	 * 基础更新
	 */
	public int update(VersionRecord entity);
	
	/**
	 * 单个删除
	 */
	public int deleteById(Integer id);
	
	/**
	 * 批量删除 
	 */
	public int deleteByIds(List<Integer> ids);
	
	/**
	 * 根据主键查找
	 */
	public VersionRecord selectById(Integer id);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     *******************************************************************************
     * @creator ：004225  
     * @date ：2017年9月18日     
     * @memo ：   
     **
     */
    public void contractAttachDownload(HttpServletResponse response, VersionRecord versionRecord);

    /**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：冉茂平（004225）  
     * @date ：2017年9月18日     
     * @memo ：   
     **
     */
    public MessageData generateAPPdownLoadQC();
    
}
