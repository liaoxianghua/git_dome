package com.spring.scenic.sms.application;

import java.util.List;

import com.spring.scenic.sms.domain.MsgSms;

public interface SmsService {

    int saveMsgSmsRecord(String phone, String businessType, String sms);

    List<MsgSms> getSmsRecordList(MsgSms msgSms);

    int validateCaptcha(MsgSms msgSms);

    boolean validateTheCaptcha(MsgSms msgSms);

    int saveMsgSmsRecord(MsgSms msgSms);

}
