package com.spring.scenic.security;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.application.BusiSellerUserService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.common.util.MessageUtil;
import com.spring.scenic.common.util.RSAUtils;
import com.spring.scenic.common.util.ScenicSecurityTool;

public class CustomUsernamePasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
	
	private Logger logger = LoggerFactory.getLogger(CustomUsernamePasswordAuthenticationFilter.class);

	@Autowired
	private BusiSellerService busiSellerService;
	
	@Autowired
	private BusiSellerUserService busiSellerUserService;
	

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request,HttpServletResponse response) throws AuthenticationException {
		
		if (!"POST".equals(request.getMethod())) {
			throw new AuthenticationServiceException("Authentication method not supported: "+ request.getMethod());
		}
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.debug("UnsupportedEncoding:" + e.getMessage());
			throw new RuntimeException("Can not handle the request,the supported encoding should be cast utf-8...");
		}
		HttpSession httpSession = request.getSession(false);
		String username = obtainUsername(request);
		String password = obtainPassword(request);
		String verifyCode = ScenicSecurityTool.obj2String(request.getParameter(SysConstant.VERIFYCODE));
		String remember = ScenicSecurityTool.obj2String(request.getParameter(SysConstant.REMENBERME));
		String language = ScenicSecurityTool.obj2String(request.getParameter(SysConstant.LANGUAGE));
		setLanguage(httpSession, language);
		validInputParameters(httpSession, username, password,verifyCode);
		BusiSeller busiSeller = null;
		BusiSellerUser busiSellerUser = null;
		try {
			busiSellerUser = busiSellerUserService.getSellerByAccount(username);
			busiSeller = busiSellerService.getBusiSellerByUser(busiSellerUser);
		} catch (Exception e) {
			logger.error("获取商户信息异常！",e);//该账号不存在
			httpSession.setAttribute("loginError", "获取商户信息异常！");
	        throw new AuthenticationServiceException("获取商户信息异常！");
		}
        if(busiSellerUser==null || busiSeller==null){
            httpSession.setAttribute("loginError", "用户名或密码错误!");
            throw new AuthenticationServiceException("用户名或密码错误！");
        }else{
            if (!password.equals(busiSellerUser.getPwd().toUpperCase())) {
                httpSession.setAttribute("loginError", "用户名或密码错误！");
                throw new AuthenticationServiceException("用户名或密码错误！");
            }
            if(Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode()).equals(busiSellerUser.getValid())){
                httpSession.setAttribute("loginError", "该账号未激活！");
                throw new AuthenticationServiceException("该账号未激活！");
            }
            if(Integer.valueOf(SysEnum.COMMON_VALID_NO.getCode()).equals(busiSeller.getValid())){
                httpSession.setAttribute("loginError", "该账号所属商户未激活！");
                throw new AuthenticationServiceException("该账号所属商户未激活！");
            }
        }
        httpSession.setAttribute("loginError", null);
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(username, password);
		setDetails(request, usernamePasswordAuthenticationToken);
		setCookie(request, response, remember, username);
		httpSession.setAttribute(SysConstant.SESSION_USER, busiSellerUser);
		return this.getAuthenticationManager().authenticate(usernamePasswordAuthenticationToken);
	}

	/**
	 * 设置语种信息
	 */
	public void setLanguage(HttpSession httpSession,String language) {
		if (SysConstant.LANGUAGE_CHINESE.equals(language)) {
			Locale locale = new Locale("zh", "CN");
			httpSession.setAttribute(SysConstant.LANGUAGE, "zh");
			httpSession.setAttribute(SysConstant.LANGUAGE_PAGE, "zh-CN");
			httpSession.setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME,locale);
		} else if (SysConstant.LANGUAGE_ENGLISH.equals(language)) {
			Locale locale = new Locale("en", "US");
			httpSession.setAttribute(SysConstant.LANGUAGE, "en");
			httpSession.setAttribute(SysConstant.LANGUAGE_PAGE, "en-US");
			httpSession.setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME,locale);
		}
	}

	/**
	 * 设置cookie
	 */
	public void setCookie(HttpServletRequest request,HttpServletResponse response, String remember, String username) {
		try {
			if ("yes".equals(remember)) {
				Cookie cookie = new Cookie(SysConstant.REMENBER_USERNAME,URLEncoder.encode(username,"UTF-8"));
				cookie.setMaxAge(60 * 60 * 24 * 7);
				cookie.setPath("/");
				response.addCookie(cookie);
				response.addHeader("SET-COOKIE", "JSESSIONID=" + username+ ";Path=/;HttpOnly");
			}else{
				Cookie cookie = new Cookie(SysConstant.REMENBER_USERNAME,null);
				cookie.setMaxAge(60 * 60 * 24 * 7);
				cookie.setPath("/");
				response.addCookie(cookie);
				response.addHeader("SET-COOKIE", "JSESSIONID=" + username+ ";Path=/;HttpOnly");
			}
		} catch (Exception e) {
			logger.error("UserName: "+username+" Add Cookie failure...",e);
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.userinfoerror"));
		}
	}

	/**
	 * inputValid输入参数验证（验证码、用户名、密码）
	 */
	public void validInputParameters(HttpSession httpSession, String username, String password,String verifyCode) {
		String checkVerifyCode = ScenicSecurityTool.obj2String(httpSession.getAttribute(SysConstant.VERIFYCODE));
		if (StringUtils.isEmpty(username)) {
			httpSession.setAttribute("loginError",MessageUtil.getMessage("common.login.nameisnull"));// 用户名不能为空
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.nameisnull"));// 用户名不能为空
		}
		if (StringUtils.isEmpty(password)) {
			httpSession.setAttribute("loginError",MessageUtil.getMessage("common.login.passwordisnull"));// 密码不能为空
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.passwordisnull")); // 密码不能为空
		}
		if(StringUtils.isBlank(verifyCode) || StringUtils.isBlank(checkVerifyCode)){
			httpSession.setAttribute("loginError",MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
		}
		if (!checkVerifyCode.toLowerCase().equals(verifyCode.toLowerCase())) {
			httpSession.setAttribute("loginError",MessageUtil.getMessage("common.login.wrongverifycode"));// 验证码不正确
			throw new AuthenticationServiceException(MessageUtil.getMessage("common.login.wrongverifycode")); // 验证码不正确
		}
	}

	@Override
	protected String obtainUsername(HttpServletRequest request) {
		Object obj = request.getParameter(SysConstant.USERNAME);
		return null == obj ? "" : obj.toString();
	}

	@Override
	protected String obtainPassword(HttpServletRequest request) {
		Object obj = request.getParameter(SysConstant.PASSWORD);
		return null == obj ? "" : MD5.getMD5Encode(RSAUtils.decryptStringByJs(obj.toString().trim()));
	}

}
