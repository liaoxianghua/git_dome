package com.spring.scenic.busi.application.impl;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.infrastructure.BusiSellerMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;

@Service
public class BusiSellerServiceImpl implements BusiSellerService {

    @Autowired
    private BusiSellerMapper busiSellerMapper;
    
    @Resource
    private DictionaryService dictionaryService;

    @Override
    public BusiSeller getBusiSellerByUser(BusiSellerUser busiSellerUser) {
        try {
            return busiSellerMapper.getBusiSellerByUser(busiSellerUser);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }
    
    /**
     * 更新发票设置
     */
    @Override
    public MessageData saveInvoiceSet(BusiSeller busiSeller) {
        try {
            BusiSeller busiSellerExample = busiSellerMapper.getBusiSeller(busiSeller);
            if(null!=busiSellerExample) {
                //后台校验发票相关值是否符合业务规则
                Integer invoiceType = busiSeller.getInvoiceType();
                Integer deliverPayWay = busiSeller.getDeliverPayWay();
                Integer prePayPrice = busiSeller.getPrePayPrice();
                Integer isTakeByselef = busiSeller.getIsTakeByselef();
                String takeAddress = busiSeller.getTakeAddress();
                if(null==invoiceType) {
                    return new MessageData(201,"请选择发票类型！");
                }
                if(invoiceType.equals(Integer.valueOf(SysEnum.INVOICE_TYPE_PAPER.getCode()))) {
                    if(null==deliverPayWay) {
                        return new MessageData(202,"请选择【快递到付】或者【快递预付】中的一种！");
                    }else {
                        if(null!=deliverPayWay && deliverPayWay.equals(Integer.valueOf(SysEnum.DELIVER_PAY_TYPE_PRE.getCode()))) {
                            if(null==busiSeller.getPrePayPrice()) {
                                return new MessageData(203,"请输入快递预付金额！");
                            }
                            String regex = "^(0|[1-9]([0-9]{0,2}))$";
                            Pattern pattern = Pattern.compile(regex);
                            Matcher matcher = pattern.matcher(prePayPrice.toString());
                            if(!matcher.matches()) {
                                return new MessageData(204,"请输入大于或者等于0的整数，最大长度为3位！");
                            }
                        }
                    }
                }
                if(null!=isTakeByselef) {
                    if(isTakeByselef.equals(Integer.valueOf(SysEnum.IS_TAKE_BY_SELF_YES.getCode()))) {
                        if(StringUtils.isBlank(takeAddress)) {
                            return new MessageData(205,"勾选允许自取复选框后，自取地址不能为空！");
                        }
                        if(takeAddress.length()>200) {
                            return new MessageData(206,"自取地址的长度不能超过200！");
                        }
                    }
                }
                busiSellerExample.setInvoiceType(invoiceType);
                busiSellerExample.setDeliverPayWay(deliverPayWay);
                busiSellerExample.setPrePayPrice(prePayPrice);
                busiSellerExample.setIsTakeByselef(isTakeByselef);
                busiSellerExample.setTakeAddress(takeAddress);
            }
            busiSellerMapper.updateByPrimaryKey(busiSellerExample);
            return new MessageData(SysConstant.OPERATE_SUCCESS,SysConstant.OPERATE_SUCCESS_MESSAGE, null, null, false, null, "", null);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
        
        
    }

    @Override
    public BusiSeller getBusiSeller(BusiSeller busiSeller) {
        try {
            return busiSellerMapper.getBusiSeller(busiSeller);
        } catch (Exception e) {
            throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
        }
    }

	@Override
	public BusiSeller selectScenicSellerInfo(BusiSellerUser sellerUser) {
        BusiSeller busiSeller = busiSellerMapper.selectScenicSellerInfo(sellerUser);
        Dictionary dictionary = new Dictionary();
        Map<String, List<Dictionary>> mapDic = dictionaryService.initDictionary(dictionary);
        //设置景区类型 type 1：景区/景点(subType 1:古镇 2: 自然山水 3:人造园林...) 景区星级：1: 1A 2:2A 3:3A 4:4A 5:5A...
        //2:商户 (subType 1:餐饮 2: 住宿 )  
        if(null!=busiSeller) {
            if(null!=busiSeller.getScenicSellerType()) {
                //设置景区类型下的子类型
                if(busiSeller.getScenicSellerType().equals(Integer.valueOf(SysEnum.MAIN_TYPE_SCENIC.getCode()))) {
                    if(null!=busiSeller.getTypeCategory()) {
                        //设置景区子类型名称
                        List<Dictionary> dicScenic = mapDic.get("SCENIC_TYPE");
                        busiSeller.setTypeCategoryName(getDicName(String.valueOf(busiSeller.getTypeCategory()), dicScenic));
                        //设置景区星级
                        if(StringUtils.isNotBlank(busiSeller.getStarLevel())) {
                            List<Dictionary> dicStarLevel = mapDic.get("SCENIC_LEVEL");
                            busiSeller.setStarLevel(getDicName(busiSeller.getStarLevel(), dicStarLevel));
                        }
                    }
                }else {//设置商户类型下的子类型
                    if(null!=busiSeller.getTypeCategory()) {
                        List<Dictionary> dicSeller = mapDic.get("SELLER_TYPE");
                        busiSeller.setTypeCategoryName(getDicName(String.valueOf(busiSeller.getTypeCategory()), dicSeller));
                    }
                }
                
            }
        }
        return busiSeller;
    }
    
	//获取数据字典名称
	private String getDicName(String value, List<Dictionary> dics) {
        if (dics != null && !dics.isEmpty()) {
            for (Dictionary dataDictionary : dics) {
                if (dataDictionary.getValue().equals(value)) {
                    return dataDictionary.getName();
                }
            }
        }
        return null;
    }
    
    

}
