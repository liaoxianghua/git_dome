package com.spring.scenic.comment.intreface.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.comment.application.ProductCommentService;
import com.spring.scenic.comment.domain.ProductComment;
import com.spring.scenic.comment.domain.vo.ProductCommentVo;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;

/**
 * 
 * @author lzj 描述:点评管理 日期:2017年4月1日13:45:35
 */
@Controller
@RequestMapping(value = "/comment")
public class CommentController {
	
	Logger logger = LoggerFactory.getLogger(CommentController.class);

	@Resource
	private ProductCommentService productCommentService;
	@Resource
	private OrderService orderService;

	@RequestMapping(value = "/commentList")
	public String commentList(HttpServletRequest request) {
		request.setAttribute("active", 4);
		return "comments/commentList";
	}

	/**
	 * 
	 * @param ProductComment
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/commentListData")
	public MessageData  commentListData(
			ProductCommentVo productCommentVo, HttpServletRequest request) {
		 BusiSellerUser sellerUser = (BusiSellerUser)request.getSession().getAttribute(SysConstant.SESSION_USER);
		 productCommentVo.setCreateUser(sellerUser.getSellerId());
		 MessageData message = new MessageData(200,"查询成功");
		if (StringUtils.isBlank(productCommentVo.getOrderId())) {
			productCommentVo.setOrderId(null);
		}
		if (StringUtils.isBlank(productCommentVo.getSellerComtent())) {
			productCommentVo.setSellerComtent(null);
		}
		if (StringUtils.isBlank(productCommentVo.getSrc())) {
			productCommentVo.setSrc(null);
		}
		if(productCommentVo.getIsPictureComment()!=null){
			productCommentVo.setIsPictureComment(1);
		}
		Order order=orderService.selectByOrderNo(productCommentVo.getOrderId()!=null ?productCommentVo.getOrderId().trim():null);
		if(null!=order){
			 productCommentVo.setOrderId(order.getId().toString());
		}
		 
		List<ProductComment> list = productCommentService.list(productCommentVo, true);

		PageInfo<ProductComment> page = new PageInfo<ProductComment>(list,
				productCommentVo.getPageSize());
		message.setAttachObj(page);
		return message;
	}

	// 修改是否推荐
	@ResponseBody
	@RequestMapping(value = "/updatestatus", method = { RequestMethod.POST })
	public MessageData updatestatus(ProductCommentVo productCommentVo,
			HttpServletRequest request) {
		int result = productCommentService.updatestatus(productCommentVo);
		if (result > 0) {
			return new MessageData(200, "操作成功");
		} else {
			return new MessageData(500, "操作失败");
		}
	}

	// 编辑评论
	@ResponseBody
	@RequestMapping(value = "/editcomment", method = { RequestMethod.POST })
	public MessageData editcomment(ProductCommentVo productCommentVo,
			HttpServletRequest request) {
		MessageData messageData = new MessageData(200, "操作成功");

		ProductComment productComment = productCommentService
				.findByIdProductComment(productCommentVo);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("productComment", productComment);
		messageData.setAttachObj(map);
		return messageData;
	}

	//点评回复
	@ResponseBody
	@RequestMapping(value = "/saveComment", method = { RequestMethod.POST })
	public MessageData saveComment(ProductCommentVo productCommentVo,
			HttpServletRequest request) {
		MessageData messageData = new MessageData(200, "操作成功");

		if (StringUtils.isBlank(productCommentVo.getSellerComtent())) {
			messageData.setStatusCode(500);
			messageData.setMessage("您输入的信息不能为空");
			return messageData;
		}

		int result = productCommentService.updateReply(productCommentVo);
		if (result > 0) {
			return messageData;
		} else {
			messageData.setMessage("操作成功");
			messageData.setStatusCode(500);
			return messageData;
		}
	}
	/**
	 * 
	 * 修改用户评论状态
	 * @param productCommentVo
	 * @param request
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年7月18日上午10:57:37
	 */
	@ResponseBody
	@RequestMapping(value = "/updatePicStatus", method = { RequestMethod.POST })
	public MessageData updatePicStatus(ProductCommentVo productCommentVo,
			HttpServletRequest request) {
		
		MessageData messageData = new MessageData(200, "操作成功");
		BusiSellerUser sellerUser = (BusiSellerUser)request.getSession().getAttribute(SysConstant.SESSION_USER);
		try {
			productCommentService.updatePicStatus(productCommentVo,sellerUser.getId());
			return messageData;
		} catch (Exception e) {
			// TODO: handle exception
			return new MessageData(500, "操作失败");
		}
		
	}

}
