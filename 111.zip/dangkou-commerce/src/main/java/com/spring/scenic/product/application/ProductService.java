package com.spring.scenic.product.application;


import java.util.List;

import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.system.domain.City;

public interface ProductService {

    List<Product> list(Product product, boolean page, Integer pageSize);

    ProductWithBLOBs selectByPrimaryKey(Integer id);
  
    int updateByPrimaryKeySelective(ProductWithBLOBs product);
    
    int updateBatch(String ids,Integer isSale,BusiSellerUser sellerUser);
    
    int saveProduct(ProductWithBLOBs productWithBLOBs);

    int update(ProductWithBLOBs product);
    /**
     * 查询产品关联的关键字
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年4月18日     
     * @memo ：   
     */
    List<KeywordRef> getRealtiveKeywordList(KeywordRef keywordRef);
    /**
     * 查询所有产品可用的关键字
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：liaoxianghua  
     * @date ：2017年4月18日     
     * @memo ：   
     **
     */
	List<Keyword> getSysConfigKeywordsByImagine(Keyword keyword);

	/**
	 * 产品保存关键字
	 * @param 
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年4月18日     
	 * @memo ：   
	 */
	KeywordRef productKeyWordSave(BusiSellerUser user, KeywordRef keywordRef,Keyword keyword);
	
	/**   
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年3月16日     
     * @memo ：   
     **
     */
    void updateSysConfigKeywordOrder(KeywordRef keywordRef);
    
	
	int deleteSysConfigKeyword(KeywordRef keywordRef);
	/**
     * 查询所有城市信息
     * 此处为类方法说明
     * @param 
     * @return
     * @creator ：ranmaoping 
     * @date ：2017年4月19日     
     * @memo ：   
     **
     */
    List<City> getCityList();
    /**
     * 复制产品
     * @param productId
     * @return
     */
	boolean copyProduct(Integer productId,Integer userId);
	
	

    
    
}
