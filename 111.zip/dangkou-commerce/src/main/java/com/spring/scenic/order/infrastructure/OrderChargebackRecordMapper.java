package com.spring.scenic.order.infrastructure;

import com.spring.scenic.order.domain.OrderChargebackRecord;

public interface OrderChargebackRecordMapper {
	/**
	 * 保存拒绝退单日志记录
	 * 此处为类方法说明
	 * @param orderChargebackRecord
	 * @return
	 * @creator ：lzj  
	 * @date ：2017年8月22日上午9:37:17
	 */
    public int saveOrderChargebackRecord(OrderChargebackRecord orderChargebackRecord);

}
