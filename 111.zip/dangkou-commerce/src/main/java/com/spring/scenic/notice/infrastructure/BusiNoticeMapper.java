package com.spring.scenic.notice.infrastructure;

import java.util.List;

import com.spring.scenic.notice.domain.BusiNotice;


public interface BusiNoticeMapper {

    List<BusiNotice> getNoticeList(BusiNotice notice);

    BusiNotice getNotice(BusiNotice BusiNotice);

    BusiNotice getTop1Notice();

    List<BusiNotice> getTop5Notice(int mxa);
    
    void updateReadCountById(BusiNotice exsitedNotice);//通过id更新阅读数
    
}