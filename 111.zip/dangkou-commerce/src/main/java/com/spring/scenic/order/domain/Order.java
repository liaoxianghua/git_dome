package com.spring.scenic.order.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.spring.scenic.common.domain.Entity;
import com.spring.scenic.product.domain.ProductWithBLOBs;

public class Order extends Entity<Order> implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 8159443737756488984L;

    /**
     * 主键
     */
    private Integer id;

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * 第三方订单号
     */
    private String thirdNo;
    
    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品ID
     */
    private Integer productId;

    /**
     * 套餐名称
     */
    private String mealsName;

    /**
     * 套餐ID
     */
    private Integer mealsId;

    /**
     * 订单状态
     */
    private Integer orderStatus;

    /**
     * 支付状态
     */
    private Integer payStatus;

    /**
     * 联系人
     */
    private String linkMan;

    /**
     * 联系电话
     */
    private String phone;

    /**
     * 电子邮箱
     */
    private String email;

    /**
     * 订单金额
     */
    private BigDecimal orderPrice;

    /**
     * 订单数量
     */
    private Integer orderCount;

    /**
     * 订单类型 
     */
    private Integer orderType;

    /**
     * 游客备注
     */
    private String remark;

    /**
     * 商户备注
     */
    private String sellerRemark;

    /**
     * 单价
     */
    private BigDecimal productPrice;

    /**
     * 成人价
     */
    private BigDecimal adultPrice;

    /**
     * 成人数量
     */
    private Integer adultCount;

    /**
     * 儿童价
     */
    private BigDecimal childPrice;

    /**
     * 儿童数量
     */
    private Integer childCount;

    /**
     * 来源
     */
    private Integer src;

    /**
     * 确认时间
     */
    private Date confirmTime;

    /**
     * 创建人
     */
    private Integer createUser;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private Integer updateUser;
    
    /**
     * 修改时间
     */
    private Date updateTime;
    
    /**
     * 商户ID
     */
    private Integer sellerId;
    
    /**
     * 会员ID
     */
    private Integer memberId;
    
    /**
     * 会员账号 
     */
    private String memberAccount;
    
    /**
     * 出发日期
     */
    private Date travelTime;
    
    /**
     * 第三方订单对接人
     */
    private String thirdFrom;
    
    /**
     * 用户需知
     */
    private String userKnow;
    
    /**
     * 是否需要发票
     */
    private Integer needInvoice;
    
    /**
     * 应付金额
     */
    private BigDecimal payPrice;
    
    /**
     * 已付金额
     */
    private BigDecimal payedPrice;
    
    /**
     * 虚拟字段：已退金额
     */
    private BigDecimal refundPrice;
    
    /**
     * 单房差
     */
    private BigDecimal singleroomPrice;
    
    /**
     * 制单人
     */
    private Integer makeUser;
    
    /**
     * 取消时间
     */
    private Date cancelTime;
    
    /**
     * 非数据库字段：创建时间开始
     */
    private Date createTimeStart;
    
    
    /**
     * 非数据库字段：创建时间结束
     */
    private Date createTimeEnd;
    
    
    /**
     * 非数据库字段：出发日期开始
     */
    private Date travelTimeStart;
    
    /**
     * 非数据库字段：出发日期结束
     */
    private Date travelTimeEnd;
    
    /**
     * 非数据库字段：产品
     */
    private ProductWithBLOBs product;
    
    /**
     * 非数据库字段：发票信息
     */
    private OrderInvoice invoice;
    
    /**
     * 非数据库字段：是否出现提醒（1:是）
     */
    private Integer warn;
    
    /**
     * 非数据库字段：订单金额调整记录
     */
    private List<OrderMoneyChangeRec> orderMoneyChanges;

    /**
     * 非数据库字段：订单支付记录  Delivery_address
     */
    private List<OrderPayRecord> orderPayRecords;
    
    
    /**
     * 非数据库字段：退款记录
     */
    private List<OrderPayRecord> orderRefundRecords;
    
    /**
     * 非数据库字段：订单出行人信息
     */
    private List<OrderLinkmanRef> orderLinkmanRefs;   
    
    
    /**
     * 非数据库字段：订单状态查询字段(多选)
     */
    private Integer[] statuses;
    /**
     * 微信号
     */
    private String weixin;
    /**
     * 核销码
     */
    private String writeoffcode;
    /**
     * 是否核销
     */
    private Integer saledCheck;
    /**
     * 快递公司名字
     */
    private String expressCompanyName;
    /**
     * 快递订单号
     */
    private String expressNumber;
    /**
     * 快递确认收货时间
     */
    private Date expressConfirmTime;
    
    /**
     * 收件人地址
     */
    private String recipientAddress;
    /**
     * 商品类型
     */
    private Integer goodsType;
    /**
     * 购物类订单快递费
     */
    private Integer uniformPostage;
    
    public String getWeixin() {
		return weixin;
	}

	public void setWeixin(String weixin) {
		this.weixin = weixin;
	}

	public Integer[] getStatuses() {
        return statuses;
    }

    public void setStatuses(Integer[] statuses) {
        this.statuses = statuses;
    }

    public OrderInvoice getInvoice() {
        return invoice;
    }

    public void setInvoice(OrderInvoice invoice) {
        this.invoice = invoice;
    }

    public BigDecimal getPayPrice() {
        return payPrice;
    }

    public void setPayPrice(BigDecimal payPrice) {
        this.payPrice = payPrice;
    }

    public BigDecimal getPayedPrice() {
        return payedPrice;
    }

    public void setPayedPrice(BigDecimal payedPrice) {
        this.payedPrice = payedPrice;
    }

    public Integer getNeedInvoice() {
        return needInvoice;
    }

    public void setNeedInvoice(Integer needInvoice) {
        this.needInvoice = needInvoice;
    }

    public Integer getWarn() {
        return warn;
    }

    public void setWarn(Integer warn) {
        this.warn = warn;
    }

    public ProductWithBLOBs getProduct() {
        return product;
    }

    public void setProduct(ProductWithBLOBs product) {
        this.product = product;
    }

    public Date getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(Date travelTime) {
        this.travelTime = travelTime;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getThirdNo() {
        return thirdNo;
    }

    public void setThirdNo(String thirdNo) {
        this.thirdNo = thirdNo == null ? null : thirdNo.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode == null ? null : productCode.trim();
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getMealsName() {
        return mealsName;
    }

    public void setMealsName(String mealsName) {
        this.mealsName = mealsName == null ? null : mealsName.trim();
    }

    public Integer getMealsId() {
        return mealsId;
    }

    public void setMealsId(Integer mealsId) {
        this.mealsId = mealsId;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(Integer payStatus) {
        this.payStatus = payStatus;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan == null ? null : linkMan.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }


    public Integer getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSellerRemark() {
        return sellerRemark;
    }

    public void setSellerRemark(String sellerRemark) {
        this.sellerRemark = sellerRemark == null ? null : sellerRemark.trim();
    }

    public BigDecimal getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(BigDecimal orderPrice) {
        this.orderPrice = orderPrice;
    }

    public BigDecimal getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    public BigDecimal getAdultPrice() {
        return adultPrice;
    }

    public void setAdultPrice(BigDecimal adultPrice) {
        this.adultPrice = adultPrice;
    }

    public Integer getAdultCount() {
        return adultCount;
    }

    public void setAdultCount(Integer adultCount) {
        this.adultCount = adultCount;
    }

    public BigDecimal getChildPrice() {
        return childPrice;
    }

    public void setChildPrice(BigDecimal childPrice) {
        this.childPrice = childPrice;
    }

    public Integer getChildCount() {
        return childCount;
    }

    public void setChildCount(Integer childCount) {
        this.childCount = childCount;
    }

    public Integer getSrc() {
        return src;
    }

    public void setSrc(Integer src) {
        this.src = src;
    }

    public Date getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(Date confirmTime) {
        this.confirmTime = confirmTime;
    }

    public String getUserKnow() {
        return userKnow;
    }

    public void setUserKnow(String userKnow) {
        this.userKnow = userKnow == null ? null : userKnow.trim();
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(Integer updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTimeStart() {
        return createTimeStart;
    }

    public void setCreateTimeStart(Date createTimeStart) {
        this.createTimeStart = createTimeStart;
    }

    public Date getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(Date createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public Date getTravelTimeStart() {
        return travelTimeStart;
    }

    public void setTravelTimeStart(Date travelTimeStart) {
        this.travelTimeStart = travelTimeStart;
    }

    public Date getTravelTimeEnd() {
        return travelTimeEnd;
    }

    public void setTravelTimeEnd(Date travelTimeEnd) {
        this.travelTimeEnd = travelTimeEnd;
    }

    public String getThirdFrom() {
        return thirdFrom;
    }

    public void setThirdFrom(String thirdFrom) {
        this.thirdFrom = thirdFrom;
    }

    public List<OrderMoneyChangeRec> getOrderMoneyChanges() {
        return orderMoneyChanges;
    }

    public void setOrderMoneyChanges(List<OrderMoneyChangeRec> orderMoneyChanges) {
        this.orderMoneyChanges = orderMoneyChanges;
    }

    public List<OrderPayRecord> getOrderPayRecords() {
        return orderPayRecords;
    }

    public void setOrderPayRecords(List<OrderPayRecord> orderPayRecords) {
        this.orderPayRecords = orderPayRecords;
    }

    public BigDecimal getSingleroomPrice() {
        return singleroomPrice;
    }

    public void setSingleroomPrice(BigDecimal singleroomPrice) {
        this.singleroomPrice = singleroomPrice;
    }

    public Integer getMakeUser() {
        return makeUser;
    }

    public void setMakeUser(Integer makeUser) {
        this.makeUser = makeUser;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

	public List<OrderLinkmanRef> getOrderLinkmanRefs() {
		return orderLinkmanRefs;
	}

	public void setOrderLinkmanRefs(List<OrderLinkmanRef> orderLinkmanRefs) {
		this.orderLinkmanRefs = orderLinkmanRefs;
	}

    public List<OrderPayRecord> getOrderRefundRecords() {
        return orderRefundRecords;
    }

    public void setOrderRefundRecords(List<OrderPayRecord> orderRefundRecords) {
        this.orderRefundRecords = orderRefundRecords;
    }

    public BigDecimal getRefundPrice() {
        return refundPrice;
    }

    public void setRefundPrice(BigDecimal refundPrice) {
        this.refundPrice = refundPrice;
    }

	public String getWriteoffcode() {
		return writeoffcode;
	}

	public void setWriteoffcode(String writeoffcode) {
		this.writeoffcode = writeoffcode;
	}

	public Integer getSaledCheck() {
		return saledCheck;
	}

	public void setSaledCheck(Integer saledCheck) {
		this.saledCheck = saledCheck;
	}

	public String getExpressCompanyName() {
		return expressCompanyName;
	}

	public void setExpressCompanyName(String expressCompanyName) {
		this.expressCompanyName = expressCompanyName;
	}

	public String getExpressNumber() {
		return expressNumber;
	}

	public void setExpressNumber(String expressNumber) {
		this.expressNumber = expressNumber;
	}

	public Date getExpressConfirmTime() {
		return expressConfirmTime;
	}

	public void setExpressConfirmTime(Date expressConfirmTime) {
		this.expressConfirmTime = expressConfirmTime;
	}

	public String getRecipientAddress() {
		return recipientAddress;
	}

	public void setRecipientAddress(String recipientAddress) {
		this.recipientAddress = recipientAddress;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}

	public Integer getUniformPostage() {
		return uniformPostage;
	}

	public void setUniformPostage(Integer uniformPostage) {
		this.uniformPostage = uniformPostage;
	}
    
}
