package com.spring.scenic.system.domain;

import java.util.Date;

import com.spring.scenic.common.domain.Entity;
/**
 * 实体对象：版本控制表
 */
public class VersionRecord extends Entity<VersionRecord>{

	private static final long serialVersionUID = 6531316474532092574L;

	// ~~~~实体属性
	// 主键
	private Integer id;
	// 应用名称
	private String appName;
	// 应该类型 1安卓 2 IOS
	private Integer appType;
	// 版本号
	private String appVersion;
	// 下载地址
	private String appUrl;
	// 是否有效  0无效 1 有效
	
	private String fileName;

	private Integer isValid;
	// 描述
	private String remark;
	// 创建时间
	private Date createTime;
	// 创建人
	private Integer createUser;
	// 修改时间
	private Date updateTime;
	// 修改人
	private Integer updateUser;
	//修改人姓名
	private String updateUserName;
 
	public Integer getId() {
		return this.id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAppName() {
		return this.appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public Integer getAppType() {
		return this.appType;
	}
	public void setAppType(Integer appType) {
		this.appType = appType;
	}
	public String getAppVersion() {
		return this.appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getAppUrl() {
		return this.appUrl;
	}
	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}
	public Integer getIsValid() {
		return this.isValid;
	}
	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}
	public String getRemark() {
		return this.remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getCreateUser() {
		return this.createUser;
	}
	public void setCreateUser(Integer createUser) {
		this.createUser = createUser;
	}
	public Date getUpdateTime() {
		return this.updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getUpdateUser() {
		return this.updateUser;
	}
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getUpdateUserName() {
        return updateUserName;
    }
    public void setUpdateUserName(String updateUserName) {
        this.updateUserName = updateUserName;
    }
	
	
}
