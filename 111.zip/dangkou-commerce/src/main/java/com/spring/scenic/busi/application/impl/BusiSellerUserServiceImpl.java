package com.spring.scenic.busi.application.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.scenic.busi.application.BusiSellerUserService;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.busi.domain.PasswordVo;
import com.spring.scenic.busi.infrastructure.BusiSellerUserMapper;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.MD5;
import com.spring.scenic.common.util.ScenicSecurityTool;


@Service
public class BusiSellerUserServiceImpl implements BusiSellerUserService {

    @Autowired
    private BusiSellerUserMapper busiSellerUserMapper;
    
    @Override
    public BusiSellerUser getSellerByAccount(String username) {
        
        return busiSellerUserMapper.getSellerByAccount(username);
    }
    //通过手机号tel查询出用户和电话号和Id
    @Override
    public BusiSellerUser getUserNameByPhone(HttpServletRequest request,PasswordVo vo) {
        return busiSellerUserMapper.getUserNameByPhone(vo.getTelephone());
    }
    //通过电话tel进行密码修改
    @Override
    public BusiSellerUser updatePwdByPhone(PasswordVo vo,BusiSellerUser busiSellerUser,HttpServletRequest request) { 
    	    String phone = (String) request.getSession().getAttribute(SysConstant.SESSION_VERIFY_PHONE);
    	    String newPassword = vo.getNewPassword();
    	    String confirmPassword = vo.getConfirmPass();
    	    if (newPassword.equals(confirmPassword)) {//判断确认密码和新密码是否相同
				String regex = "(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,16})$";
				Pattern pattern=Pattern.compile(regex);
				Matcher matcher=pattern.matcher(newPassword);
				if(matcher.matches()){//验证通过
				   String Password = ScenicSecurityTool.MD5(newPassword);//将新密码加密
				   busiSellerUser.setPwd(Password);//重新设置密码
				   busiSellerUser.setPhone(phone);;
					this.busiSellerUserMapper.updatePwdByPhone(busiSellerUser);//更新密码		
                  } 
            }
			return busiSellerUser;
    } 
    //通过ID修改密码
	public BusiSellerUser updatePwdById(PasswordVo vo,BusiSellerUser busiSellerUser) { 
	try {
		BusiSellerUser userInfo=null;
		if(busiSellerUser !=null){
			userInfo= busiSellerUserMapper.queryUserInfoById(busiSellerUser.getId());
		}
		String flag = "";
		String md5Password = MD5.getMD5Encode(vo.getLoginPassword());//对原密码进行MD5加密
		if (userInfo !=null && userInfo.getPwd().equals(md5Password)) {//判断加密的密码是否一致
			if(!vo.getLoginPassword().equals(vo.getNewPassword())){
				if ((vo.getConfirmPass().equals(vo.getNewPassword()))) {//判断确认密码和新密码是否相同
					String regex = "(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,16})$";
					Pattern pattern=Pattern.compile(regex);
					Matcher matcher=pattern.matcher(vo.getNewPassword());
					if(matcher.matches()){//验证通过
					   String Password = ScenicSecurityTool.MD5(vo.getNewPassword());//将新密码加密
					   busiSellerUser.setPwd(Password);//重新设置密码
						this.busiSellerUserMapper.updatePwdById(busiSellerUser);//更新密码	//更新密码		
						flag = SysConstant.MESSAGE_TYPE_SUCCESS;	//返回成功	 
				   }else{
					   flag= SysConstant.MESSAGE_TYPE_NOTMATCH;
				   }
				}else{
					flag= SysConstant.MESSAGE_TYPE_ERROR;//当密码不一致返回error
				}
			}else{
				flag= SysConstant.MESSAGE_TYPE_SAME;//当新密码与原密码相同返回same
			}
		} else {
			flag= SysConstant.MESSAGE_TYPE_FAIL;//当原密码不一致返回fail
		}
		busiSellerUser.setFlag(flag);
		return busiSellerUser;
	} catch (Exception e) {
		throw new BussinessException(new BussinessExceptionBean("exception.error.systemupdatepassword"), e);
	}
	}
}
