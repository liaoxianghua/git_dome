package com.spring.scenic.order.application.impl;

import java.awt.Color;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.facade.MsgSmsRecordFacade;
import com.spring.scenic.memberMsg.domain.MemberMsg;
import com.spring.scenic.memberMsg.infrastructure.MemberMsgMapper;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderChargebackRecord;
import com.spring.scenic.order.domain.OrderMoneyChangeRec;
import com.spring.scenic.order.domain.OrderOperationLog;
import com.spring.scenic.order.domain.OrderWriteOffCode;
import com.spring.scenic.order.domain.vo.OrderAndInvoice;
import com.spring.scenic.order.domain.vo.OrderStatistic;
import com.spring.scenic.order.infrastructure.OrderChargebackRecordMapper;
import com.spring.scenic.order.infrastructure.OrderInvoiceMapper;
import com.spring.scenic.order.infrastructure.OrderMapper;
import com.spring.scenic.order.infrastructure.OrderMoneyChangeRecMapper;
import com.spring.scenic.order.infrastructure.OrderOperationLogMapper;
import com.spring.scenic.order.infrastructure.OrderWriteOffCodeMapper;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductStock;
import com.spring.scenic.product.infrastructure.ProductMapper;
import com.spring.scenic.product.infrastructure.ProductStockMapper;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderMapper orderMapper;

	@Autowired
	private OrderMoneyChangeRecMapper orderMoneyChangeRecMapper;

	@Autowired
	private OrderInvoiceMapper orderInvoiceMapper;

	@Resource
	private ProductMapper productMapper;

	@Resource
	private ProductStockMapper productStockMapper;
	
	@Resource
    private MemberMsgMapper memberMsgMapper;
	@Resource
	private OrderWriteOffCodeMapper orderWriteOffCodeMapper;
	@Resource
	private OrderChargebackRecordMapper	orderChargebackRecordMapper;
	
	@Resource
    private MsgSmsRecordFacade msgSmsRecordFacade;
	@Resource
	private OrderOperationLogMapper orderOperationLogMapper;
    @Resource
    private DictionaryService dictionaryService;

	@Override
	public List<Order> getOrderList(Order order, boolean page) {
		try {
			if (page) {
				PageHelper.startPage(order.getPageNum(), order.getPageSize());
			}
			return orderMapper.getOrderList(order);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<Order> getOrderListWithWarn(Order order, boolean page) {
		try {
			if (order.getTravelTimeStart() != null) {
				order.setTravelTimeStart(DateUtil.getDayMinTime(order.getTravelTimeStart()));
			}
			if (order.getTravelTimeEnd() != null) {
				order.setTravelTimeEnd(DateUtil.getDayMaxTime(order.getTravelTimeEnd()));
			}
			if (order.getCreateTimeStart() != null) {
				order.setCreateTimeStart(DateUtil.getDayMinTime(order.getCreateTimeStart()));
			}
			if (order.getCreateTimeEnd() != null) {
				order.setCreateTimeEnd(DateUtil.getDayMaxTime(order.getCreateTimeEnd()));
			}
			if (page) {
				PageHelper.startPage(order.getPageNum(), order.getPageSize());
			}
			return orderMapper.getOrderListWithWarn(order);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * 统计某个商户的各种状态数量
	 */
	@Override
	public Map<String, Integer> getOrderStatistic(BusiSellerUser sellerUser) {
		Map<String, Integer> statistic = new HashMap<String, Integer>();
		List<OrderStatistic> orderStatisticToday = orderMapper.getOrderStatisticToday(sellerUser);
		Map<Integer, Integer> orderStatisticTodayMap = toMap(orderStatisticToday);
		List<OrderStatistic> orderStatisticTotal = orderMapper.getOrderStatisticTotal(sellerUser);
		Map<Integer, Integer> orderStatisticTotalMap = toMap(orderStatisticTotal);

		// 今日新单
		statistic.put(SysConstant.ORDER_TODAY_ALL,
				orderStatisticTodayMap.get(0) == null ? 0 : orderStatisticTodayMap.get(0));
		// 今日取消
		statistic.put(SysConstant.ORDER_TODAY_CANCELED, orderStatisticTodayMap.get(2) == null ? 0
				: orderStatisticTodayMap.get(2));
		// 待确认订单
		statistic.put(SysConstant.ORDER_TOTAL_NEW,
				orderStatisticTotalMap.get(1) == null ? 0 : orderStatisticTotalMap.get(1));
		// 申请退单
		statistic.put(SysConstant.ORDER_TOTAL_CHARGEBACK, (orderStatisticTotalMap.get(4) == null ? 0
				: orderStatisticTotalMap.get(4))+ (orderStatisticTotalMap.get(8) == null ? 0
						: orderStatisticTotalMap.get(8)));
		return statistic;
	}

	private Map<Integer, Integer> toMap(List<OrderStatistic> orderStatistics) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		if (orderStatistics != null && !orderStatistics.isEmpty()) {
			for (OrderStatistic orderStatistic : orderStatistics) {
				map.put(orderStatistic.getStatus(), orderStatistic.getCount());
			}
		}
		return map;
	}

	@Override
	public Order getOrder(Order exampleOrder) {
		return orderMapper.getOrder(exampleOrder);
	}

	@Override
	public int updateOrderStatus(Order order,BusiSellerUser sellerUser) {
		int i = 0;
		try {
			if (order.getId() == null || order.getOrderStatus() == null) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
			} else {
				Order orderParam = new Order();
				MemberMsg memberMsg = new MemberMsg();
				orderParam.setId(order.getId());
				Order temp = orderMapper.getOrder(orderParam);
				boolean needEditStock = false;
					if(null != temp){
	                    if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CANCELED.getCode())){//取消操作
	                        if(temp.getOrderStatus() == 1){//订单是新单-->已取消
	                            temp.setOrderStatus(2);
	                            i = orderMapper.updateOrderStatus(temp);
	                            memberMsg.setMemberId(temp.getCreateUser());
	                    		//消息默认为未阅读状态
	                    		memberMsg.setMsgStatus(0);
	                    		memberMsg.setMsgType(3);
	                    		memberMsg.setCreateTime(new Date()); 
	                    		memberMsg.setMsgTitle("订单状态变更");
	                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已取消!");  
	                    		memberMsgMapper.addMemberMsg(memberMsg);
	                        }if(temp.getOrderStatus() == 3){//已确认的订单取消-->已退单
	                            temp.setOrderStatus(5);
	                            i = orderMapper.updateOrderStatus(temp);
	                            memberMsg.setMemberId(temp.getCreateUser());
	                    		//消息默认为未阅读状态
	                    		memberMsg.setMsgStatus(0);
	                    		memberMsg.setMsgType(3);
	                    		memberMsg.setCreateTime(new Date()); 
	                    		memberMsg.setMsgTitle("订单状态变更");
	                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已退单!");  
	                    		memberMsgMapper.addMemberMsg(memberMsg);
	                        }
	                        needEditStock = true;
	                    }else if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())){//确认操作
	                        if(temp.getOrderStatus() == 1){//订单是新单-->已确认
	                            temp.setOrderStatus(3);
	                            i = orderMapper.updateOrderStatus(temp);
	                            memberMsg.setMemberId(temp.getCreateUser());
	                    		//消息默认为未阅读状态
	                    		memberMsg.setMsgStatus(0);
	                    		memberMsg.setMsgType(3);
	                    		memberMsg.setCreateTime(new Date()); 
	                    		memberMsg.setMsgTitle("订单状态变更");
	                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已确认!");  
	                    		memberMsgMapper.addMemberMsg(memberMsg);
	                        }else if(temp.getOrderStatus() == 4){//已确认的订单取消-->已退单
	                            temp.setOrderStatus(5);
	                            i = orderMapper.updateOrderStatus(temp);
	                            memberMsg.setMemberId(temp.getCreateUser());
	                    		//消息默认为未阅读状态
	                    		memberMsg.setMsgStatus(0);
	                    		memberMsg.setMsgType(3);
	                    		memberMsg.setCreateTime(new Date()); 
	                    		memberMsg.setMsgTitle("订单状态变更");
	                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已退单!");  
	                    		memberMsgMapper.addMemberMsg(memberMsg);
	                    		needEditStock = true;
	                        }
	                    }else{
	                    	if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CHARGEBACKED.getCode()) || temp.getOrderStatus() == 4 ){
	                    		needEditStock = true;
	                    		memberMsg.setMemberId(temp.getCreateUser());
	                    		//消息默认为未阅读状态
	                    		memberMsg.setMsgStatus(0);
	                    		memberMsg.setMsgType(3);
	                    		memberMsg.setCreateTime(new Date()); 
	                    		memberMsg.setMsgTitle("订单状态变更");
	                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已退单!");  
	                    		memberMsgMapper.addMemberMsg(memberMsg);
	                    	}else{
	                    		if(order.getOrderStatus()==Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())||temp.getProduct().getProductType()==2){
	                    			memberMsg.setMemberId(temp.getCreateUser());
		                    		//消息默认为未阅读状态
		                    		memberMsg.setMsgStatus(0);
		                    		memberMsg.setMsgType(3);
		                    		memberMsg.setCreateTime(new Date()); 
		                    		memberMsg.setMsgTitle("订单状态变更");
		                    		memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"已发货!");  
		                    		memberMsgMapper.addMemberMsg(memberMsg);
	                    		}
	                    	}
	                        temp.setOrderStatus(order.getOrderStatus());
	                        i = orderMapper.updateOrderStatus(temp);
	                    }
	                    if(needEditStock){//是否需要退库存
	                    	Product product = productMapper.selectByPrimaryKey(temp.getProductId());
	                    	product.setUpdateTime(new Date());
	                    	product.setUpdateUser(sellerUser.getId());
	                    	if (temp.getOrderType().equals(1)) {//景区
	                    		product.setSaleNum(product.getSaleNum()
	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
	                    		ProductStock productStock = new ProductStock();
	                    		productStock.setPlayDay(temp.getTravelTime());
	                    		productStock.setMealsId(temp.getMealsId());
	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
	                    		if(null != productStock){
	                    			productStock.setUpdateTime(new Date());
	                    			productStock.setUpdateUser(sellerUser.getId());
	                    			productStock.setSaleNum(productStock.getSaleNum()
	                    					- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
	                    		}
	                    	} else if (temp.getOrderType().equals(3)) {//线路
	                    		product.setSaleNum(product.getSaleNum()
	                    				- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
	                    				- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
	                    		ProductStock productStock = new ProductStock();
	                    		productStock.setPlayDay(temp.getTravelTime());
	                    		productStock.setMealsId(temp.getMealsId());
	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
	                    		if(null != productStock){
	                    			productStock.setUpdateTime(new Date());
	                    			productStock.setUpdateUser(sellerUser.getId());
	                    			productStock.setSaleNum(productStock.getSaleNum()
	                    					- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
	                    					- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
	                    		}
	                    	} else if (temp.getOrderType().equals(2)){//购物
	                    		product.setSaleNum(product.getSaleNum()
	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
	                    	}
	                    }
					}
				}
				return i;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveSellerRemark(Order order) {
		try {
			return orderMapper.saveSellerRemark(order);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public int saveOrderMoneyChange(BusiSellerUser sellerUser, OrderMoneyChangeRec orderMoneyChangeRec) {
		try {
			orderMoneyChangeRec.setCreateTime(new Date());
			orderMoneyChangeRec.setCreateUser(sellerUser.getId());
			return orderMoneyChangeRecMapper.saveOrderMoneyChange(orderMoneyChangeRec);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public List<OrderMoneyChangeRec> getOrderMoneyChangeList(OrderMoneyChangeRec orderMoneyChangeRec) {
		try {
			return orderMoneyChangeRecMapper.getOrderMoneyChangeList(orderMoneyChangeRec);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public BigDecimal calculatePayPrice(BigDecimal orderPrice, List<OrderMoneyChangeRec> orderMoneyChangeRecs) {
		BigDecimal changeMoney = new BigDecimal(0);
		if (orderMoneyChangeRecs != null && !orderMoneyChangeRecs.isEmpty()) {
			for (OrderMoneyChangeRec orderMoneyChangeRec : orderMoneyChangeRecs) {
				changeMoney = changeMoney.add(orderMoneyChangeRec.getMoney());
			}
		}
		orderPrice = orderPrice.add(changeMoney);
		return orderPrice;
	}

	@Override
	public int updateOrderPayPrice(Order order) {
		try {
			MemberMsg memberMsg = new MemberMsg();
			memberMsg.setMemberId(order.getCreateUser());
    		//消息默认为未阅读状态
    		memberMsg.setMsgStatus(0);
    		memberMsg.setMsgType(3);
    		memberMsg.setCreateTime(new Date()); 
    		memberMsg.setMsgTitle("应付金额变更");
    		memberMsg.setMsgContent("你的订单"+order.getOrderNo()+"应付金额已变更!应付金额为"+order.getPayPrice()+"");  
    		memberMsgMapper.addMemberMsg(memberMsg);
    		return orderMapper.updateOrderPayPrice(order);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * 订单导出
	 * @param response
	 */
	@Override
	public void downOrderFile(HttpServletResponse response, HttpServletRequest request,OrderAndInvoice orderAndInvoice) {
		List<OrderAndInvoice> orderAndInvoices;	
		try {	
			orderAndInvoices = orderMapper.selectOrderAndInvoice(orderAndInvoice);
			if (null!= orderAndInvoices) {
				response.setContentType("application/octet-stream;charset=UTF-8");
				response.setHeader("Content-disposition", "attachment;filename="
						+ new String("订单.xlsx".getBytes("GBK"), "ISO8859-1"));
				ServletOutputStream outputStream = response.getOutputStream();

				XSSFWorkbook workbook = new XSSFWorkbook();

				XSSFColor blackColor = new XSSFColor(Color.BLACK);

				XSSFCellStyle styleData = workbook.createCellStyle();
				styleData.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				styleData.setTopBorderColor(blackColor);
				styleData.setBottomBorderColor(blackColor);
				styleData.setLeftBorderColor(blackColor);
				styleData.setRightBorderColor(blackColor);
				styleData.setBorderTop(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				styleData.setBorderRight(XSSFCellStyle.BORDER_THIN);

				XSSFCellStyle styleHeader = workbook.createCellStyle();
				styleHeader.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				styleHeader.setTopBorderColor(blackColor);
				styleHeader.setBottomBorderColor(blackColor);
				styleHeader.setLeftBorderColor(blackColor);
				styleHeader.setRightBorderColor(blackColor);
				styleHeader.setBorderTop(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				styleHeader.setBorderRight(XSSFCellStyle.BORDER_THIN);

				XSSFFont font = workbook.createFont();
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				styleHeader.setFont(font);

				XSSFCellStyle redHeader = workbook.createCellStyle();
				redHeader.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				redHeader.setTopBorderColor(blackColor);
				redHeader.setBottomBorderColor(blackColor);
				redHeader.setLeftBorderColor(blackColor);
				redHeader.setRightBorderColor(blackColor);
				redHeader.setBorderTop(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				redHeader.setBorderRight(XSSFCellStyle.BORDER_THIN);

				XSSFFont redFont = workbook.createFont();
				redFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				redFont.setColor(XSSFFont.COLOR_RED);
				redHeader.setFont(redFont);

				createOrderSheet(workbook, styleHeader, styleData, orderAndInvoices);
				workbook.write(outputStream);
				outputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	/**
	 * 创建excel内容
	 * @param workbook
	 * @param styleHeader
	 * @param styleData
	 * @param orders
	 */
	private void createOrderSheet(XSSFWorkbook workbook, XSSFCellStyle styleHeader, XSSFCellStyle styleData,
		List<OrderAndInvoice> orderAndInvoices) {
		try {
			OrderAndInvoice orderAndInvoice = null;
			XSSFCell cell = null;
			XSSFRichTextString text = new XSSFRichTextString();
			String orderHeaders[] =
					new String[] { "订单号", "下单时间", "订单状态", "产品名称", "套餐", "出行时间", "联系人", "联系手机", "联系邮箱", "订单金额", "应付金额",
							"已付金额", "是否需要发票", "发票抬头", "领取方式", "邮寄地址" };
			XSSFSheet sheet = workbook.createSheet("订单");
			sheet.setDefaultColumnWidth((short) 20);
			XSSFRow row = sheet.createRow(0);
			for (short i = 0; i < orderHeaders.length; i++) {
				cell = row.createCell(i);
				text.setString(orderHeaders[i]);
				cell.setCellValue(text);
				cell.setCellStyle(styleHeader);
			}
			for (int i = 0; i < orderAndInvoices.size(); i++) {
				row = sheet.createRow(i + 1);
				orderAndInvoice = orderAndInvoices.get(i);
				for (int j = 0; j < 16; j++) {
					cell = row.createCell(j);
					cell.setCellStyle(styleData);
					if (j == 0) {// 订单号
						if (null != orderAndInvoice.getOrderNo()) {
							text.setString(orderAndInvoice.getOrderNo());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 1) {// 下单时间
						if (null != orderAndInvoice.getCreateTime()) {
							Date createTime = orderAndInvoice.getCreateTime();
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							text.setString(sdf.format(createTime));
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 2) {// 订单状态
						if (null != orderAndInvoice.getOrderStatus()) {
							if (orderAndInvoice.getOrderStatus() == 0) {
								text.setString("全部");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 1) {
								text.setString("新单");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 2) {
								text.setString("已取消");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 3) {
								text.setString("已确认");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 4) {
								text.setString("申请退单");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 5) {
								text.setString("已退单");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 6) {
								text.setString("已完成");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 7) {
								text.setString("已发货");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 8) {
								text.setString("申请退货");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getOrderStatus() == 9) {
								text.setString("已退货");
								cell.setCellValue(text);
							}
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 3) {// 产品名称
						if (null != orderAndInvoice.getProductName()) {
							text.setString(orderAndInvoice.getProductName());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 4) {// 套餐
						if (null != orderAndInvoice.getMealsName()) {
							text.setString(orderAndInvoice.getMealsName());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 5) {// 出行时间
						if (null != orderAndInvoice.getTravelTime()) {
							Date travelTime = orderAndInvoice.getTravelTime();
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							text.setString(sdf.format(travelTime));
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 6) {// 联系人
						if (null != orderAndInvoice.getLinkMan()) {
							text.setString(orderAndInvoice.getLinkMan());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 7) {// 联系手机
						if (null != orderAndInvoice.getPhone()) {
							text.setString(orderAndInvoice.getPhone());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 8) {// 联系邮箱
						if (null != orderAndInvoice.getEmail()) {
							text.setString(orderAndInvoice.getEmail());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 9) {// 订单金额
						if (null != orderAndInvoice.getOrderPrice()) {
							BigDecimal orderPrice = orderAndInvoice.getOrderPrice();
							text.setString(orderPrice.toString());
							cell.setCellValue(text);
						} else {
							text.setString("0.00");
							cell.setCellValue(text);
						}
					} else if (j == 10) {// 应付金额
						if (null != orderAndInvoice.getPayPrice()) {
							BigDecimal payPrice = orderAndInvoice.getPayPrice();
							text.setString(payPrice.toString());
							cell.setCellValue(text);
						} else {
							text.setString("0.00");
							cell.setCellValue(text);
						}
					} else if (j == 11) {// 已付金额
						if (null != orderAndInvoice.getPayedPrice()) {
							BigDecimal payedPrice = orderAndInvoice.getPayedPrice();
							text.setString(payedPrice.toString());
							cell.setCellValue(text);
						} else {
							text.setString("0.00");
							cell.setCellValue(text);
						}
					} else if (j == 12) {// 是否需要发票
						if (null != orderAndInvoice.getNeedInvoice()) {
							if (orderAndInvoice.getNeedInvoice() == 0) {
								text.setString("否");
								cell.setCellValue(text);
							} else if (orderAndInvoice.getNeedInvoice() == 1) {
								text.setString("是");
								cell.setCellValue(text);
							}
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 13) {// 发票抬头
						if (null != orderAndInvoice.getTitle()) {
							text.setString(orderAndInvoice.getTitle());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 14) {// 领取方式
						if (null != orderAndInvoice.getGainType()) {
							if(orderAndInvoice.getGainType() == 0){
								text.setString("当面领取");
								cell.setCellValue(text);
							}else if(orderAndInvoice.getGainType() == 1){
								text.setString("邮寄到付");
								cell.setCellValue(text);
							}
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					} else if (j == 15) {// 邮寄地址
						if (null != orderAndInvoice.getTakeAddress()) {
							text.setString(orderAndInvoice.getTakeAddress());
							cell.setCellValue(text);
						} else {
							text.setString("");
							cell.setCellValue(text);
						}
					}
				}
			}
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Order selectByOrderNo(String orderId) {
		// TODO Auto-generated method stub
		return orderMapper.selectByOrderNo(orderId);
	}

	@Transactional
	@Override
	public int updateOrderWriteOffCode(Order order) {
		try {
			orderMapper.updateOrderWriteOffCode(order);
			OrderWriteOffCode orderWriteOffCode=new OrderWriteOffCode();
			orderWriteOffCode.setSellerId(order.getSellerId());
			orderWriteOffCode.setWriteoffcode(order.getWriteoffcode());
			orderWriteOffCode.setSaledCheck(1);//已核销
			orderWriteOffCode.setScanMethod(2);//手动输入
			orderWriteOffCode.setUpdateTime(new Date());
			orderWriteOffCodeMapper.updateorderWriteOffCode(orderWriteOffCode);
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public Order selectOrderWriteOffCode(Order order) {
		try {
				return orderMapper.selectOrderWriteOffCode(order);
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}

	@Override
	public MessageData updateOrderRefused(Order order,BusiSellerUser sellerUser, Integer type, String inputReasons) {
		 
		MessageData messageData = new MessageData(200, "操作成功");
		//拒绝退单日志记录
		OrderChargebackRecord orderChargebackRecord=new OrderChargebackRecord();
			try {
				if (order.getId() == null || order.getOrderStatus() == null) {
					throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
				} else {
					Order temp=selectOrderWriteOffCode(order);
					MemberMsg memberMsg = new MemberMsg();
					boolean needEditStock = false;
					if(temp.getOrderStatus()==4){
						if(type==1){
							temp.setOrderStatus(5);
							orderChargebackRecord.setType(1);//同意退单
							memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已退单!");  
							needEditStock=true;
						}else{
							temp.setOrderStatus(3);
							orderChargebackRecord.setType(2);//拒绝退单记录
							memberMsg.setMsgContent("你的订单"+temp.getOrderNo()+"订单状态已拒绝!"); 
						}
						orderMapper.updateOrderStatus(temp);
						//增加退单操作日志记录
						orderChargebackRecord.setMemberId(temp.getCreateUser());
                    	orderChargebackRecord.setSellerId(temp.getSellerId());
                    	orderChargebackRecord.setRefundReason(inputReasons);//拒绝理由
                    	orderChargebackRecord.setCreateUser(temp.getSellerId());
                    	orderChargebackRecord.setCreateTime(new Date());
                    	orderChargebackRecord.setOrderNo(temp.getOrderNo());
                    	orderChargebackRecord.setType(type);
                    	orderChargebackRecordMapper.saveOrderChargebackRecord(orderChargebackRecord);
                		//消息默认为未阅读状态
                		memberMsg.setMsgStatus(0);
                		memberMsg.setMsgType(3);
                		memberMsg.setCreateTime(new Date()); 
                		memberMsg.setMsgTitle("订单状态变更");
                		memberMsg.setBusinessId(temp.getId());
                		memberMsg.setMemberId(temp.getCreateUser());
                		memberMsg.setBusinessId(temp.getId());
                		memberMsgMapper.addMemberMsg(memberMsg);
                		//是否需要退库存
                    	if(needEditStock){
  	                    	Product product = productMapper.selectByPrimaryKey(temp.getProductId());
  	                    	product.setUpdateTime(new Date());
  	                    	product.setUpdateUser(sellerUser.getId());
  	                    	if (temp.getOrderType().equals(1)) {//景区
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    		ProductStock productStock = new ProductStock();
  	                    		productStock.setPlayDay(temp.getTravelTime());
  	                    		productStock.setMealsId(temp.getMealsId());
  	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
  	                    		if(null != productStock){
  	                    			productStock.setUpdateTime(new Date());
  	                    			productStock.setUpdateUser(sellerUser.getId());
  	                    			productStock.setSaleNum(productStock.getSaleNum()
  	                    					- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
  	                    		}
  	                    	} else if (temp.getOrderType().equals(3)) {//线路
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
  	                    				- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    		ProductStock productStock = new ProductStock();
  	                    		productStock.setPlayDay(temp.getTravelTime());
  	                    		productStock.setMealsId(temp.getMealsId());
  	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
  	                    		if(null != productStock){
  	                    			productStock.setUpdateTime(new Date());
  	                    			productStock.setUpdateUser(sellerUser.getId());
  	                    			productStock.setSaleNum(productStock.getSaleNum()
  	                    					- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
  	                    					- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
  	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
  	                    		}
  	                    	} else if (temp.getOrderType().equals(2)){//购物
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    	}
  	                    }
                    	if(type==1){
                    		//SmsUtils.sendSms(temp.getPhone(), "尊敬的用户，您申请退单的订单（【"+temp.getOrderNo()+"】）商家已接受，请等待退款。");
                    		msgSmsRecordFacade.saveMsgSmsRecord(temp.getPhone(), "尊敬的用户，您申请退单的订单:"+temp.getOrderNo()+"商家已接受，请等待退款。",temp.getOrderNo());
						}else{
							 //SmsUtils.sendSms(temp.getPhone(), "尊敬的用户，您申请退单的订单（【"+temp.getOrderNo()+"】）商家已拒绝（【"+inputReasons+"】）");
							 inputReasons=(null!=inputReasons && StringUtils.isNotBlank(inputReasons)) ? "（"+inputReasons+"）" :"";
							 msgSmsRecordFacade.saveMsgSmsRecord(temp.getPhone(), "尊敬的用户，您申请退单的订单:"+temp.getOrderNo()+":商家已拒绝"+inputReasons+"",temp.getOrderNo());
						}
                    	return messageData;
					}else{
						messageData.setMessage("订单已退,请勿重复操作!");
						messageData.setStatusCode(500);
						return messageData;
					}
				}
				
			} catch (Exception e) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}

	@Override
	public MessageData updateOrderReturnGoods(Order order,BusiSellerUser sellerUser, Integer type, String refundReasons) {
		MessageData messageData = new MessageData(200, "操作成功");
		//订单操作日志记录
		OrderOperationLog orderOperationLog = new OrderOperationLog();
		refundReasons = (null!=refundReasons && StringUtils.isNotBlank(refundReasons)) ? "（"+refundReasons+"）" :"";
			try {
				if (order.getId() == null || order.getOrderStatus() == null) {
					throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
				} else {
					Order temp = selectOrderWriteOffCode(order);
					MemberMsg memberMsg = new MemberMsg();
					boolean needEditStock = false; //是否需要修改库存
					if(temp.getOrderStatus() == 8){
						if(type == 1){
							temp.setOrderStatus(9);//接受退货，接受后，订单状态为已退货。
							String msgContent = "你的订单（"+temp.getOrderNo()+"）商家接受退货!";
							memberMsg.setMsgContent(msgContent); 
							orderOperationLog.setMsgTitle(msgContent);//发送的消息
							needEditStock = true;
						}else{
							temp.setOrderStatus(7);//拒绝退货，拒绝后，订单状态回到已发货
							String msgContent = "你的订单（"+temp.getOrderNo()+"）商家拒绝退货!" + refundReasons;
							memberMsg.setMsgContent(msgContent); 
							orderOperationLog.setMsgTitle(msgContent);//发送的消息
						}
						orderMapper.updateOrderStatus(temp);
						//增加订单操作日志记录
						//Status 1：	确认收货  2：	申请退货 3：已发货 4：定时任务自动变为已完成 5：确认退货'
						addOrderOperationLog(temp, sellerUser, orderOperationLog, 5);
                		//消息默认为未阅读状态
                		memberMsg.setMsgStatus(0);
                		memberMsg.setMsgType(3);
                		memberMsg.setCreateTime(new Date()); 
                		memberMsg.setMsgTitle("订单状态变更");
                		memberMsg.setBusinessId(temp.getId());
                		memberMsg.setMemberId(temp.getCreateUser());
                		memberMsg.setBusinessId(temp.getId());
                		memberMsgMapper.addMemberMsg(memberMsg);
                		//是否需要退库存
                    	if(needEditStock){
  	                    	Product product = productMapper.selectByPrimaryKey(temp.getProductId());
  	                    	product.setUpdateTime(new Date());
  	                    	product.setUpdateUser(sellerUser.getId());
  	                    	if (temp.getOrderType().equals(1)) {//景区
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    		ProductStock productStock = new ProductStock();
  	                    		productStock.setPlayDay(temp.getTravelTime());
  	                    		productStock.setMealsId(temp.getMealsId());
  	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
  	                    		if(null != productStock){
  	                    			productStock.setUpdateTime(new Date());
  	                    			productStock.setUpdateUser(sellerUser.getId());
  	                    			productStock.setSaleNum(productStock.getSaleNum()
  	                    					- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
  	                    		}
  	                    	} else if (temp.getOrderType().equals(3)) {//线路
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
  	                    				- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    		ProductStock productStock = new ProductStock();
  	                    		productStock.setPlayDay(temp.getTravelTime());
  	                    		productStock.setMealsId(temp.getMealsId());
  	                    		productStock = productStockMapper.selectByPrimaryParam(productStock);
  	                    		if(null != productStock){
  	                    			productStock.setUpdateTime(new Date());
  	                    			productStock.setUpdateUser(sellerUser.getId());
  	                    			productStock.setSaleNum(productStock.getSaleNum()
  	                    					- (temp.getAdultCount() == null ? 0 : temp.getAdultCount())
  	                    					- (temp.getChildCount() == null ? 0 : temp.getChildCount()));
  	                    			productStockMapper.updateByPrimaryKeySelective(productStock);
  	                    		}
  	                    	} else if (temp.getOrderType().equals(2)){//购物
  	                    		product.setSaleNum(product.getSaleNum()
  	                    				- (temp.getOrderCount() == null ? 0 : temp.getOrderCount()));
  	                    		productMapper.updateByPrimaryKey(product);// 修改产品的已售金额
  	                    	}
  	                    }
                    	if(type == 1){
                    		msgSmsRecordFacade.saveMsgSmsRecord(temp.getPhone(), "尊敬的用户，您申请退货的订单:"+temp.getOrderNo()+"，商家已接受，请等待退款。",temp.getOrderNo());
						}else{
							msgSmsRecordFacade.saveMsgSmsRecord(temp.getPhone(), "尊敬的用户，您申请退货的订单："+temp.getOrderNo()+"，商家已拒绝"+refundReasons,temp.getOrderNo());
						}
                    	return messageData;
					}else{
						messageData.setMessage("商品已退,请勿重复操作!");
						messageData.setStatusCode(500);
						return messageData;
					}
				}
			} catch (Exception e) {
				throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
			}
	}
	
	@Override
	public int updateOrderExpress(Order order,BusiSellerUser sellerUser, Integer type) {
		int flag=0;
		try {
			if(type==0){
				Order orderParam = new Order();
				orderParam.setId(order.getId());
				Order temp = orderMapper.getOrder(orderParam);
				String msgTitle="亲爱的用户，您的订单"+temp.getOrderNo()+"，商家已发货，请注意查收。";
				MemberMsg memberMsg = new MemberMsg();
				//消息默认为未阅读状态
				memberMsg.setMsgStatus(0);
				memberMsg.setMsgType(3);
				memberMsg.setCreateTime(new Date()); 
				//亲爱的用户，您的订单XXX，商家已发货，请注意查收。快递单号：XXXX（快递公司）
				String showExpressNumber=StringUtils.isNotBlank(order.getExpressNumber()) ? order.getExpressNumber() :null;
				 //增加查询物流列表
				String newExpressName=null;
				String current_MSG="";
	    		Dictionary dictionary = new Dictionary();
	    		dictionary.setCode("EXPRESS_COMPANY");
	    		List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
	    		if(null!=order.getExpressCompanyName()){
	    			for (Dictionary dictionary2 : expressCompanyList) {
						if(dictionary2.getValue().equals(order.getExpressCompanyName())){
							newExpressName=dictionary2.getName();
						}
					}
	    		}
	    		if(null==showExpressNumber && null==newExpressName){
	    			current_MSG="";
	    		}else if(null!=showExpressNumber && null==newExpressName){
	    			current_MSG="快递单号："+showExpressNumber;
	    		}else if(null!=showExpressNumber && null!=newExpressName){
	    			current_MSG="快递单号："+showExpressNumber+"("+newExpressName+")";
	    		}else if(null==showExpressNumber && null!=newExpressName){
	    			current_MSG="快递单号："+"("+newExpressName+")";
	    		}
	    		
				memberMsg.setMsgTitle("订单状态变更");
        		memberMsg.setMsgContent(msgTitle+current_MSG);
				memberMsg.setBusinessId(temp.getId());
				memberMsg.setMemberId(temp.getCreateUser());
				memberMsg.setBusinessId(temp.getId());
				flag=memberMsgMapper.addMemberMsg(memberMsg);
				OrderOperationLog orderOperationLog=new OrderOperationLog();
				//1：	确认收货  2：	申请退货 3：已发货 4：定时任务自动变为已完成 5：确认退货'
				orderOperationLog.setMsgTitle(msgTitle+current_MSG);
				addOrderOperationLog(temp, sellerUser, orderOperationLog, 3);
			}
			 flag=orderMapper.updateOrderWriteOffCode(order);
			return flag;
		} catch (Exception e) {
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"), e);
		}
	}
	/**
	 * 
	 * 此处为类方法说明
	 * @param temp 订单
	 * @param sellerUser 商户
	 * @param orderOperationLog 操作日志对象
	 * @param Status 1：	确认收货  2：	申请退货 3：已发货 4：定时任务自动变为已完成 5：确认退货'
	 * @creator ：lzj  
	 * @date ：2017年9月12日上午11:13:58
	 */
	public void addOrderOperationLog(Order temp,BusiSellerUser sellerUser,OrderOperationLog orderOperationLog,Integer Status){
		orderOperationLog.setOrderId(temp.getId());
		orderOperationLog.setOrderNo(temp.getOrderNo());
		orderOperationLog.setMemberId(temp.getMemberId());
		orderOperationLog.setSellerId(temp.getSellerId());
		orderOperationLog.setCreateUser(sellerUser.getId());
		orderOperationLog.setCreateDate(new Date());
		orderOperationLog.setStatus(Status);
		orderOperationLogMapper.saveOrderOperationLog(orderOperationLog);
	}
}
