package com.spring.scenic.schedule.application;

public interface SchedulerService {

}
