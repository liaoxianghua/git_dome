package com.spring.scenic.common.config;

/**
 * @Description 系统级常量配置类
 * @author 006568（shuchang）
 * @date 2016年12月21日
 */
public class SysConstant {
	
	//用户名
	public static final String USERNAME = "j_username";
	//密码
	public static final String PASSWORD = "j_password";
	//验证码
    public static final String VERIFYCODE = "j_verifyCode";
    //记住我
    public static final String REMENBERME = "j_remember";
	//系统全局字典
	public static final String SYS_DIC = "SYS_DIC";
	//分页页码
	public static final int PAGE_PAGESIZE = 10;
	//最大分页数
	public static final int PAGE_PAGESIZE_MAX = 100000000;
	//是否分页：是
	public static final boolean PAGE_TRUE = true;
	//是否分页：否
	public static final boolean PAGE_FALSE = false;
	//用户禁用
	public static final Short VALITY_NO = 0;
	//用户可用
	public static final Short VALITY_YES = 1;
	//SESSION保存用户的key
	public static final String SESSION_USER = "user";
	//SESSION保存的验证码
	public static final String SESSION_VERIFY_CODE = "SESSION_VERIFY_CODE";
	//SESSION保存的手机号
	public static final String SESSION_VERIFY_PHONE = "SESSION_VERIFY_PHONE";
	
	public static final String SESSION_VERIFY_DATE = "SESSION_VERIFY_DATE";
	//系统语言
	public static final String LANGUAGE = "language";
	//SESSION保存页面语言种类key
	public static final String LANGUAGE_PAGE = "languagePage";
	//页面语言：英语
	public static final String LANGUAGE_ENGLISH = "en_US";
	//页面语言：中文
	public static final String LANGUAGE_CHINESE = "zh_CN";
	//记住用户保存的key
	public static final String REMENBER_USERNAME = "commerce_remenber_username";
	//操作成功
	public static final int OPERATE_SUCCESS = 200;
	//操作成功
	public static final String OPERATE_SUCCESS_MESSAGE = "操作成功！";
	//操作失败
	public static final int OPERATE_FAILURE = 500;
	//操作失败
	public static final String OPERATE_FAILURE_MESSAGE = "操作失败！";
	
	//附件访问地址
	public static final String ATTACHMENT_VISIT_URL = "scenicweb.runtime.attachment.visit.url";
	//点评管理导入数据模板下载
	public static final String EVALUATE_TEMPLATE_PATH = "scenicweb.runtime.evaluate.template.path";
	//重置密码默认
	public static final String INITIAL_PASSWORD = "123456";
	//禁用启用标识0禁用1启用
	public static final String IS_FORBIDDEN_FLAG_NO = "0";
	//禁用启用标识0禁用1启用
	public static final String IS_FORBIDDEN_FLAG_YES = "1";
	//修改密码操作返回消息提示
	public static final String MESSAGE_TYPE_SUCCESS = "success";
	
	public static final String MESSAGE_TYPE_FAIL = "fail";
	
	public static final String MESSAGE_TYPE_ERROR = "error";
	
	public static final String MESSAGE_TYPE_SAME = "same";
	
	public static final String MESSAGE_TYPE_NOTMATCH = "notmatch";
	//操作成功
	public static final String OPT_SUCCESS = "success";
	//操作失败
	public static final String OPT_FAIL = "fail";
	
	public static final String FASTDFS_GROUP_ID = "com.spring.scenic.fastdfs.group";
	
	
	/*********************************以下是业务常量字段*********************************/
    public static final String ORDER_TODAY_ALL = "todayAll";
	
    public static final String ORDER_TODAY_NEW = "todayNew";
    
    public static final String ORDER_TODAY_CANCELED = "todayCanceled";
    
    public static final String ORDER_TOTAL_NEW = "totalNew";
    
    public static final String ORDER_TOTAL_CHARGEBACK = "totalChargeBack";
    
    //短信业务ID
    public static final String SMS_BIS_ID = "41";
    //短信应用ID
    public static final String SMS_SYS_ID ="35";
    //短信类别ID
    public static final String SMS_TYPE = "1";
    //关键字已存在
    public static final String OPT_EXIST = "exist"; 

}
