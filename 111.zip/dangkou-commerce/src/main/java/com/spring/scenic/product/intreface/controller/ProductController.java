package com.spring.scenic.product.intreface.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;

import com.github.pagehelper.PageInfo;
import com.github.pagehelper.StringUtil;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.CustomerDateEditor;
import com.spring.scenic.common.intreface.controller.CommonController;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.picture.domain.vo.BusiPictureLibVo;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.product.domain.KeywordRef;
import com.spring.scenic.product.domain.Product;
import com.spring.scenic.product.domain.ProductPicRel;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.City;
import com.spring.scenic.system.domain.Dictionary;

@Controller
@RequestMapping(value = "/product")
public class ProductController extends CommonController {

	Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Resource
	private ProductService productService;

	@Resource
	private ProductPicRelService productPicRelService;

	@Resource
	private BusiPictureLibService busiPictureLibService;

	@Resource
	private DictionaryService dictionaryService;

	@RequestMapping(value = "/productList")
	public String productList(HttpServletRequest request) {
		request.setAttribute("active", 2);
		Dictionary dictionary = new Dictionary();
		dictionary.setCode("PRODUCT_TYPE");
		List<Dictionary> list = dictionaryService.getDictionaryListByCode(dictionary);
		request.setAttribute("list", list);
		return "product/productList";
	}

	/**
	 * 产品关键字
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年4月18日
	 ** 
	 */
	@ResponseBody
	@RequestMapping(value = "/productKeyWord")
	public MessageData productKeyWord(Integer productId, HttpServletRequest request) {
		KeywordRef keywordRef = new KeywordRef();
		// 3产品类型
		keywordRef.setOutRelatedType(3);
		keywordRef.setOutRelatedId(productId);
		List<KeywordRef> list = productService.getRealtiveKeywordList(keywordRef);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("keywords", list);
		map.put("productId", productId);
		MessageData messageData = new MessageData(200, "");
		messageData.setAttachObj(map);
		return messageData;
	}

	/**
	 * 关键字列表
	 * @param
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年4月20日
	 */
	@ResponseBody
	@RequestMapping(value = "/keyWordList")
	public MessageData keyWordList(Keyword keyword, HttpServletRequest request) {

		MessageData messageData = new MessageData(200, "");
		if(keyword != null && StringUtil.isNotEmpty(keyword.getName()) ){
			List<Keyword> list = productService.getSysConfigKeywordsByImagine(keyword);
			messageData.setAttachObj(list);
		}else {
		    messageData.setStatusCode(201);
		}
		return messageData;
	}

	@ResponseBody
	@RequestMapping(value = "/updateSysConfigKeywordOrder")
	public MessageData updateSysConfigKeywordOrder(KeywordRef keywordRef) {
		productService.updateSysConfigKeywordOrder(keywordRef);
		return new MessageData(200, "更新成功");
	}

	/**
	 * 产品关键字添加
	 * @param
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年4月18日
	 ** 
	 */
	@ResponseBody
	@RequestMapping(value = "/productKeyWordSave")
	public MessageData productKeyWordSave(Keyword keyword, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		KeywordRef kk = new KeywordRef();
		
		kk.setOutRelatedId(keyword.getOutRelatedId());
		kk.setKeywordId(keyword.getKeywordId());
		KeywordRef keywordRef = productService.productKeyWordSave(sellerUser, kk, keyword);
		if(keywordRef != null && "fail".equals(keywordRef.getFlag())){
			return  new MessageData(500, "该产品已添加【"+keywordRef.getKeyword().getName()+"】关键字！");
		}
		if(keywordRef != null && "exist".equals(keywordRef.getFlag())){
            return  new MessageData(500, "【"+keywordRef.getKeyword().getName()+"】关键字已存在！");
        }
		MessageData messageData = new MessageData(200, "添加成功");
		messageData.setAttachObj(keywordRef);
		return messageData;
	}

	/**
	 * 产品删除关键字
	 * @param
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年4月18日
	 * @memo ：
	 ** 
	 */
	@ResponseBody
	@RequestMapping(value = "/productKeyWordDelete")
	public MessageData productKeyWordDelete(KeywordRef keywordRef, HttpServletRequest request) {
		productService.deleteSysConfigKeyword(keywordRef);
		MessageData messageData = new MessageData(200, "");
		return messageData;
	}

	@RequestMapping(value = "/productKeyWorkAdd")
	public String productKeyWorkAdd(Integer productId, HttpServletRequest request) {
		request.setAttribute("productId", productId);
		return "/product/productKeyWorkAdd";
	}

	// 产品列表
	@ResponseBody
	@RequestMapping(value = "/productListData")
	public MessageData productListData(Product productVo, HttpServletRequest request) {
		MessageData message = new MessageData(200, "");
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if (sellerUser != null) {
			productVo.setSellerId(sellerUser.getSellerId());
		}
		if (productVo != null) {
			if (productVo.getIsSale() == null) {
				productVo.setIsSale(1);
			}
			if (productVo.getSaleStartTime() != null && productVo.getSaleEndTime() != null
					&& productVo.getSaleStartTime().compareTo(productVo.getSaleEndTime()) > 0) {
				return new MessageData(500, "开始时间必须小于结束时间");
			}
			if (productVo.getCreateStartTime() != null && productVo.getCreateEndTime() != null
					&& productVo.getCreateStartTime().compareTo(productVo.getCreateEndTime()) > 0) {
				return new MessageData(500, "开始时间必须小于结束时间");
			}
		}
		List<Product> list = productService.list(productVo, true, productVo.getPageSize());
		Dictionary dictionary = new Dictionary();
		Map<String, List<Dictionary>> mapDic = dictionaryService.initDictionary(dictionary);
		List<Dictionary> dic = mapDic.get("PRODUCT_TYPE");
		for (Product d : list) {
			d.setProductTypeName(getDicName(String.valueOf(d.getProductType()), dic));
			if (d.getProductType() == 1) {
				List<Dictionary> dicScenic = mapDic.get("PRODUCT_TYPE_SCENIC");
				d.setProductSubTypeName(getDicName(String.valueOf(d.getProductSubType()), dicScenic));
			} else if (d.getProductType() == 2) {
				List<Dictionary> dicShopping = mapDic.get("PRODUCT_TYPE_SHOPPING");
				d.setProductSubTypeName(getDicName(String.valueOf(d.getProductSubType()), dicShopping));
			} else if (d.getProductType() == 3) {
				List<Dictionary> dicLine = mapDic.get("PRODUCT_TYPE_LINE");
				d.setProductSubTypeName(getDicName(String.valueOf(d.getProductSubType()), dicLine));
			}
		}
		PageInfo<Product> page = new PageInfo<Product>(list, productVo.getPageSize());
		message.setAttachObj(page);
		return message;
	}

	private String getDicName(String value, List<Dictionary> dics) {
		if (dics != null && !dics.isEmpty()) {
			for (Dictionary dataDictionary : dics) {
				if (dataDictionary.getValue().equals(value)) {
					return dataDictionary.getName();
				}
			}
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/addProduct")
	public MessageData addProduct(HttpServletRequest request) {
		MessageData message = new MessageData(200, "");
		Dictionary dictionary = new Dictionary();
		dictionary.setCode("PRODUCT_TYPE");
		List<Dictionary> list = dictionaryService.getDictionaryListByCode(dictionary);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("list", list);
		List<City> listCitys = productService.getCityList();
		map.put("listCitys", listCitys);
		message.setAttachObj(map);
		return message;
	}

	/**
	 * 添加保存
	 */
	@ResponseBody
	@RequestMapping(value = "/productSave", method = { RequestMethod.POST })
	public MessageData productSave(ProductWithBLOBs product, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		product.setSellerId(sellerUser.getSellerId());
		product.setCreateUser(sellerUser.getId());
		product.setUpdateUser(sellerUser.getId());
		int result = 0;
		if (product != null && product.getId() != null) {
			result = productService.updateByPrimaryKeySelective(product);
		} else {
			result = productService.saveProduct(product);
		}
		if (result > 0) {
			return new MessageData(200, "操作成功", result);
		} else {
			return new MessageData(500, "操作失败");
		}
	}

	// 上下架 启禁用
	@ResponseBody
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	public MessageData update(ProductWithBLOBs product, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		product.setUpdateUser(sellerUser.getId());
		if (product.getIsSale() != null) {
			ProductWithBLOBs p = productService.selectByPrimaryKey(product.getId());
			if (p != null) {
				String result = checkProductForIsSale(p);
				if(StringUtil.isNotEmpty(result)){
					return new MessageData(500, result);
				}
			} else {
				return new MessageData(500, "产品不存在");
			}
		}
		int result = productService.updateByPrimaryKeySelective(product);
		if (result > 0) {
			return new MessageData(200, "操作成功");
		} else {
			return new MessageData(500, "操作失败");
		}
	}

	public String checkProductForIsSale(ProductWithBLOBs p) {
		StringBuffer sb = new StringBuffer();
		if(p.getProductSubType() == null){
			sb.append("二级类别  ");
		}
		if (p.getRecommend() == null) {
			sb.append("经理推荐      ");
		}
		if (p.getRemark() == null) {
			sb.append("图文说明     ");
		}
		if (p.getOrderRule() == null) {
			sb.append("预定规则     ");
		}
		if (p.getReturnRule() == null) {
			sb.append("退改规则    ");
		}
		if(sb.length() > 0){
			sb.append(" 不能为空！");
		}
		return sb.toString();
	}

	// 批量上下架商品
	@ResponseBody
	@RequestMapping(value = "/updateBatchIsSale", method = { RequestMethod.POST })
	public MessageData updateBatchIsSale(String ids, Integer isSale, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		// TODO
		Integer result = productService.updateBatch(ids, isSale, sellerUser);
		if(result == SysConstant.OPERATE_FAILURE){
			return new MessageData(500, "所选产品中有信息不全的产品,请检查！");
		}
		return new MessageData(200, "操作成功");
	}

	// to编辑
	@ResponseBody
	@RequestMapping(value = "/toProductEdit", method = { RequestMethod.POST })
	public MessageData toProductEdit(Integer id, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		MessageData messageData = new MessageData(200, "操作成功");
		// 基本属性
		ProductWithBLOBs productWithBLOBs = productService.selectByPrimaryKey(id);
		ProductPicRel productPicRel = new ProductPicRel();
		productPicRel.setCreateUser(sellerUser.getId());
		productPicRel.setProductId(productWithBLOBs.getId());
		// 图片
		List<ProductPicRel> listProductPic = productPicRelService.list(productPicRel, false, null);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("productWithBLOBs", productWithBLOBs);
		map.put("listProductPic", listProductPic);
		// 产品大类
		Dictionary dictionary = new Dictionary();
		if (productWithBLOBs.getProductType() != null) {
			if (productWithBLOBs.getProductType() == 1) {
				dictionary.setCode("PRODUCT_TYPE_SCENIC");
			} else if (productWithBLOBs.getProductType() == 2) {
				dictionary.setCode("PRODUCT_TYPE_SHOPPING");
			} else if (productWithBLOBs.getProductType() == 3) {
				dictionary.setCode("PRODUCT_TYPE_LINE");
			}
		} else {
			logger.info("产品类别错误");
			return new MessageData(500, "产品类别错误");
		}
		List<Dictionary> list = dictionaryService.getDictionaryListByCode(dictionary);
		map.put("productSubTypesDictionary", list);
		List<City> listCitys = productService.getCityList();
		map.put("listCitys", listCitys);
		messageData.setAttachObj(map);
		return messageData;
	}

	// 编辑保存
	@ResponseBody
	@RequestMapping(value = "/productEditSave")
	public MessageData productEditSave(ProductWithBLOBs productWithBLOBs, HttpServletRequest request) {
		int result = productService.update(productWithBLOBs);
		if (result > 0) {
			MessageData messageData = new MessageData(200, "操作成功");
			return messageData;
		} else {
			MessageData messageData = new MessageData(200, "操作成功");
			return messageData;
		}
	}

	// 根据产品ID 获取图片
	@ResponseBody
	@RequestMapping(value = "/productPicList", method = { RequestMethod.POST })
	public MessageData productPicList(Integer productId) {
		ProductPicRel productPicRel = new ProductPicRel();
		productPicRel.setProductId(productId);
		Product product = productService.selectByPrimaryKey(productId);
		if (null == product) {
			return new MessageData(500, "产品不存在");
		}
		productPicRel.setCreateUser(getSellerUser().getId());
		List<ProductPicRel> listProductPic = productPicRelService.list(productPicRel, false, null);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("listProductPic", listProductPic);
		map.put("product", product);
		MessageData messageData = new MessageData(200, "操作成功");
		messageData.setAttachObj(map);
		return messageData;
	}

	// 设置为LOGO
	@ResponseBody
	@RequestMapping(value = "/isLogoUpdate", method = { RequestMethod.POST })
	public MessageData logoUpdate(ProductPicRel productPicRel, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		MessageData messageData = new MessageData(200, "操作成功");
		productPicRel.setUpdateTime(new Date());
		productPicRel.setUpdateUser(sellerUser.getId());
		productPicRelService.updateIsLogo(productPicRel);
		messageData.setStatusCode(200);
		return messageData;
	}

	// 删除关联图片
	@ResponseBody
	@RequestMapping(value = "/deletePicRel", method = { RequestMethod.POST })
	public MessageData delete(Integer id, HttpServletRequest request) {
		int result = productPicRelService.delete(id);
		if (result > 0) {
			return new MessageData(200, "删除成功");
		} else {
			return new MessageData(500, "删除失败");
		}
	}

	// 跳转可关联图片
	@RequestMapping(value = "/productPicAdd", method = { RequestMethod.GET })
	public String productPicAdd(Integer productId, Integer useType, HttpServletRequest request) {
		request.setAttribute("productId", productId);
		request.setAttribute("useType", useType);
		return "/product/productPicAdd";
	}

	// 查询可关联图数据
	@ResponseBody
	@RequestMapping(value = "/productPicListData", method = { RequestMethod.POST })
	public PageInfo<BusiPictureLib> productPicList(BusiPictureLibVo busiPictureLibVo, HttpServletRequest request) {
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		busiPictureLibVo.setCreateUser(sellerUser.getId());
		busiPictureLibVo.setValid(1);
		List<BusiPictureLib> list = busiPictureLibService.list(busiPictureLibVo, true);
		PageInfo<BusiPictureLib> page = new PageInfo<BusiPictureLib>(list, busiPictureLibVo.getPageSize());
		return page;
	}

	// 保存可选图片
	@ResponseBody
	@RequestMapping(value = "/productLibSave", method = { RequestMethod.POST })
	public MessageData productLibSave(Integer productId, String ids, HttpServletRequest request) {

		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		ProductWithBLOBs product = null;
		if (productId != null) {
			product = productService.selectByPrimaryKey(productId);
		} else {
			return new MessageData(500, "产品不存在");
		}
		if (StringUtil.isEmpty(ids)) {
			return new MessageData(500, "至少选择一张图片");
		}
		boolean result = productPicRelService.productLibSave(product, ids, sellerUser);
		if (result) {
			return new MessageData(200, "保存成功");
		} else {
			return new MessageData(500, "保存失败");
		}
	}
	
	@ResponseBody
	@RequestMapping("copy")
	public MessageData copyProduct(Integer productId, HttpServletRequest request){
		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(SysConstant.SESSION_USER);
		if(sellerUser == null){
			return new MessageData(500, "未登录");
		}
		MessageData messageData = new MessageData(200, "复制成功");
		boolean result  = productService.copyProduct(productId,sellerUser.getId());
		if(!result){
			return new MessageData(500, "复制失败");
		}
		return messageData;
	}
	// 时间格式化
	@InitBinder
	public void initBinder(WebDataBinder binder, WebRequest request) {
		binder.registerCustomEditor(Date.class, new CustomerDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
	}
}
