package com.spring.scenic.sms.application.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.scenic.sms.infrastructure.MsgSmsRecordMapper;
import com.spring.scenic.sms.domain.MsgSmsRecord;
import com.spring.scenic.sms.application.MsgSmsRecordService;
import java.util.List;
import com.github.pagehelper.PageHelper;

@Service("msgSmsRecordService")
public class MsgSmsRecordServiceImpl implements MsgSmsRecordService {

	@Resource
	private MsgSmsRecordMapper msgSmsRecordMapper;
	
	@Override
	public int insert(MsgSmsRecord entity) {
		return msgSmsRecordMapper.insert(entity);
	}
	
	@Override
	public int update(MsgSmsRecord entity) {
		return msgSmsRecordMapper.update(entity);
	}
	
	@Override
	public MsgSmsRecord selectById(Integer id) {
		return msgSmsRecordMapper.selectById(id);
	}
	
	@Override
	public int deleteById(Integer id) {
		return msgSmsRecordMapper.deleteById(id);
	}
	
	@Override
	public int deleteByIds(List<Integer> ids) {
		return msgSmsRecordMapper.deleteByIds(ids);
	}
	
	@Override
	public List<MsgSmsRecord> selectPage(MsgSmsRecord entity, boolean page) {
		if (page) {
			PageHelper.startPage(entity.getPageNum(), entity.getPageSize());
		}
		return msgSmsRecordMapper.selectPage(entity);
	}
}
