/**
 * Created by lenovo on 2017/3/10.
 */
(function(){
var scenic = {
    init:function(){
        /*编辑器*/
        var recommend=UE.getEditor('container-recommend',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:1000,
            initialFrameHeight:200
        });
        var imgText=UE.getEditor('container-img-text',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:200
        });
        var trffic=UE.getEditor('container-trffic',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:200
        });
        var reserve=UE.getEditor('container-reserve',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:200
        });
        var retreat=UE.getEditor('container-retreat',{
            toolbars: [['undo', 'redo','|','fontsize','|','fullscreen',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:200
        });
    } 
}

//调用初始化
$(function(){
   scenic.init();
});
})();




