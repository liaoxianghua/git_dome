$(function(){
	doSearch();
});

function init(params){
	$.post(orderListDataUrl,params,function(returndata){
		var data = returndata.attachObj.page;
	 
		$("#totalChargeBack").html(returndata.attachObj.orderStatisic.totalChargeBack);
		$("#totalNew").html(returndata.attachObj.orderStatisic.totalNew);
		if(data && data.list&& data.list.length>0){
			var html = template("searchList",{items:data.list});
			$("#orders").html(html);
			var pagerHtml = template("pager",{page:data});
			$("#pagerData").html(pagerHtml);
		}else{
			$("#orders").html("没有查询到数据");
			$("#pagerData").html(null);
		}
	},"JSON");
}

//分页
var pagerIndex = function(v){
	var queryParams = $('#orderSearch').serializeObject();
	var orderStatus = queryParams.statuses;
	delete queryParams.statuses;
	var status=''; 
	var statuses = {};
	if(orderStatus!=null){		
		//重新组装 statuses json串
		for(var i=0; i<orderStatus.length; i++){ 
			status = parseInt(orderStatus[i]);
			var statusesarr = [];
			for ( var b in statuses){
				statusesarr.push(b);
			}
			var a = "statuses["+statusesarr.length+"]";
			statuses[a] = status;
		};
	}
	var pagerParams = {pageNum:v,pageSize:$("#pageSize").val()}; 
	$.extend(queryParams,pagerParams,statuses);
	$.post(orderListDataUrl,queryParams,function(returndata){
		var data = returndata.attachObj.page;
		$("#totalChargeBack").html(returndata.attachObj.orderStatisic.totalChargeBack);
		$("#totalNew").html(returndata.attachObj.orderStatisic.totalNew);
		if(data && data.list&& data.list.length>0){
			var html = template("searchList",{items:data.list});
			$("#orders").html(html);
			var pagerHtml = template("pager",{page:data});
			$("#pagerData").html(pagerHtml);
		}else{
			$("#orders").html("没有查询到数据");
			$("#pagerData").html(null);
		}
	},"json");
};

//分页条数变化
var pageSizeChange = function(){
	pagerIndex(1);
};

//点击确定
var pageNumChange = function(){
	pagerIndex($("#pageNum").val());
};

//更换页码
function changePageNum(pag,max,pageNum){
	var reg = /^[1-9]\d*$/;
	if(pag.value==""||pag.value==null){
		$("#pageNum").val(pageNum);
	}
	if(!reg.test(pag.value)){
		$("#pageNum").val(pageNum);
	}else{
		if(pag.value>max){
			$("#pageNum").val(max);
		}
	}
}

//显示三方订单
function showThirdOrder(thirdNo,thirdFrom){
	bootbox.alert("showThirdOrder"+thirdNo);
}

//取消(剔除状态为3，warn！=1的)
function doCancel(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				pagerIndex($("#pageNum").val());
				$("#orderSearch").click();
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}

//确认订单
function doConfirm(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
//			console.log($("#orderSearch").serializeObject());
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				pagerIndex($("#pageNum").val());
				$("#orderSearch").click();
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}

//确认发货
//function doSendGoods(obj,id,orderNo){
//	$("#hexiaoma").val(id);
//	$("#hexiaomaorderNo").val(orderNo);
//}

$("#sub_hxcode").click(function (){
	var hxcode=$.trim($("#hxcode").val());
	if(hxcode=null || hxcode==""){
		bootbox.alert("核销码不能为空！");
		return;
	}
	if($("#hxcode").val().length<6){
		bootbox.alert("请输入6位核销码");
		return;
	}
	 
	if(!/^[a-zA-Z0-9]{6}$/.test($("#hxcode").val())){
		bootbox.alert("核销码只能是数字或字母");
		return;
	}
 
//	var queryParams={"id":$.trim($("#hexiaoma").val()),"writeoffcode":$.trim($("#hxcode").val()),"orderNo":$.trim($("#hexiaomaorderNo").val())};
	var queryParams={"writeoffcode":$.trim($("#hxcode").val())};
	
	$.post(updateOrderWriteOffCodeUrl,queryParams,function(data){
		if(data.statusCode == 200){
			$("#hxcode").val(null);
			$("#hexiaoma").val(null);
			$("#hexiaomaorderNo").val(null);
			bootbox.alert(data.message);
			$(".close-adjust-money-modal").click();
			doSearch();
			return ;
		}else{ 
//			$("#hxcode").val(null)
//			$("#hexiaoma").val(null)
//			$("#hexiaomaorderNo").val(null)
			bootbox.alert(data.message);
//			$(".close-adjust-money-modal").click();
//			doSearch();
			return ;
		}
		
	},"json");
});


//确认退单
function doChargeback(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				pagerIndex($("#pageNum").val());
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}
//确认退单
$("#curent_order").click(function (){
	var type = $("#isValid input[name='valid']:checked").val();
	var id = $("#tuidanId").val();
	var orderNo = $("#tuidanorderNo").text();
	var inputReasons = $("#inputReasons").val();
	if(inputReasons !=null){
		if(inputReasons.length>512){
			bootbox.alert("您已超过512个字符，请重新输入");
			return ;
		}
	}
 
	$.ajax({
		url: basePath+"/order/orderRefused",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"orderNo":orderNo,"type":type,"inputReasons":inputReasons},
	})
	.done(function(data) {
		bootbox.alert(data.message);
		$(".close-change-order-status-modal").click();
		$("#inputReasons").val(null);
//		pagerIndex($("#pageNum").val());
		doSearch();
		return ;
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
		$(".close-change-order-status-modal").click();
		$("#inputReasons").val(null);
		doSearch();
		return ;
	});
});


//确认退货
function doChargeback(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				pagerIndex($("#pageNum").val());
				doSearch();
				return ;
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
				doSearch();
				return ;
			});
		}
	});
}
//确认退货
$("#confirmRefund").click(function (){
	var type = $("#refundOperation input[name='operationValid']:checked").val();
	var id = $("#refundGoodsId").val();
	var orderNo = $("#confirmRefundOrderNo").text();
	var refundReasons = $("#refundReasons").val();
	if(refundReasons !=null){
		if(refundReasons.length>512){
			bootbox.alert("您已超过512个字符，请重新输入");
			return ;
		}
	}
 
	$.ajax({
		url: basePath+"/order/confirmReturnGoods",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"orderNo":orderNo,"type":type,"refundReasons":refundReasons},
	})
	.done(function(data) {
		bootbox.alert(data.message);
		$(".close-confirm-refund-modal").click();
		$("#refundReasons").val(null);
		doSearch();
		return ;
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
		$(".close-confirm-refund-modal").click();
		$("#refundReasons").val(null);
		doSearch();
		return ;
	});
});

//点击全部、申请退单、待处理tab页
function selects(obj,status){
	$(obj).parent().parent().children().removeClass("active");
	$(obj).parent().addClass("active");
	if(status==0){
		doReset();
	}else if(status==4){
		doReset();		
		$("#order-chargeback").prop('checked','checked');
		$("#goods-return").prop('checked','checked');
//		document.getElementById("order-sure").disabled=true;
//		document.getElementById("order-complete").disabled=true;
//		document.getElementById("order-canceled").disabled=true;
//		document.getElementById("order-chargebacked").disabled=true;
//		document.getElementById("order-new").disabled=true;
//		doReset();	
	}else if(status==1){
		doReset();		
		$("#order-new").prop('checked','checked');
//		document.getElementById("order-sure").disabled=true;
//		document.getElementById("order-complete").disabled=true;
//		document.getElementById("order-canceled").disabled=true;
//		document.getElementById("order-chargebacked").disabled=true;
//		document.getElementById("order-chargeback").disabled=true;
//		doReset();	
	}
	doSearch();
}

//点击搜索
function doSearch(){
	var queryParams = $('#orderSearch').serialize();
	var createTimeStart = $("#createTimeStart").val();
	var createTimeEnd = $("#createTimeEnd").val();
	var travelTimeStart = $("#travelTimeStart").val();
	var travelTimeEnd = $("#travelTimeEnd").val();
	var cts = Date.parse(createTimeStart.replace(/-/g,   "/"));
    var cte = Date.parse(createTimeEnd.replace(/-/g,   "/"));
    var tts = Date.parse(travelTimeStart.replace(/-/g,   "/"));
    var tte = Date.parse(travelTimeEnd.replace(/-/g,   "/"));
	var ct = cte - cts;
	var tt = tte - tts;
	if(createTimeStart.length>0 && createTimeEnd.length>0){
        if(ct<0){
        	bootbox.alert("下单日期止应大于下单日期起");
           return false;
        }
    } 
	if(travelTimeStart.length>0 && travelTimeEnd.length>0){
        if(tt<0){
        	bootbox.alert("出行日期止应大于出行日期起");
           return false;
        }
    }
	var params = $('#orderSearch').serializeObject();
	if(params != null && params.productId != null ){
		if(!/^[0-9]*$/.test(params.productId)){
			bootbox.alert("产品ID必须是数字");
			return false;
		}
	}
	init(queryParams);
}
$("#downFile").on('click', function(event) {
	var orderNo = $.trim($("#orderNo").val());
	var memberAccount = $.trim($("#memberAccount").val());
	var linkMan = $.trim($("#linkMan").val());
	var phone = $.trim($("#phone").val());
	var productId = $.trim($("#productId").val());
	var productName = $.trim($("#productName").val());
	var createTimeStart = $.trim($("#createTimeStart").val());
	var createTimeEnd = $.trim($("#createTimeEnd").val());
	var travelTimeStart = $.trim($("#travelTimeStart").val());
	var travelTimeEnd = $.trim($("#travelTimeEnd").val());
	var orderStatus=document.getElementsByName('statuses');
	var os=''; 
	for(var i=0; i<orderStatus.length; i++){ 
		if(orderStatus[i].checked) 
			os+=orderStatus[i].value+',';
	} 
	window.location.href = basePath+"/order/downOrderFile?orderNo="+orderNo+"&memberAccount="+memberAccount+"&linkMan="+linkMan
	+"&productId="+productId+"&productName="+productName+"&createTimeStart="+createTimeStart+"&createTimeEnd="+createTimeEnd
	+"&travelTimeStart="+travelTimeStart+"&travelTimeEnd="+travelTimeEnd+"&os="+os+"&phone="+phone;
});

//点击清空
function doReset(){
	$("#orderNo").val(null);
	$("#memberAccount").val(null);
	$("#linkMan").val(null);
	$("#phone").val(null);
	$("#productId").val(null);
	$("#productName").val(null);
	$("#createTimeStart").val(null);
	$("#createTimeEnd").val(null);
	$("#travelTimeStart").val(null);
	$("#travelTimeEnd").val(null);
	$("[name='statuses']").removeAttr("checked");
	document.getElementById("doResets").style.display = "none";
}
//输入搜索条件显现清空按钮
function Clear(){
	var orderNo = $("#orderNo").val();
	var memberAccount = $("#memberAccount").val();
	var linkMan = $("#linkMan").val();
	var productId = $("#productId").val();
	var productName = $("#productName").val();
	var createTimeStart = $("#createTimeStart").val();
	var createTimeEnd = $("#createTimeEnd").val();
	var travelTimeStart = $("#travelTimeStart").val();
	var travelTimeEnd = $("#travelTimeEnd").val();
	if(orderNo!=null||memberAccount!=null||linkMan!=null||productId||productName!=null||
	   createTimeStart!=null||createTimeEnd!=null||travelTimeStart!=null||travelTimeEnd==null){
		$("#doResets").css("display",false);
	}
}

function doChargebackValue(obj,id,orderNo){
	$("#is-valid1").prop("checked","checked");
	$("#inputReasons").val("");
	$("#tuidanId").val(id);
	$("#tuidanorderNo").html(orderNo);
}
//确认退货
function doConfirmRefund(obj,id,orderNo){
	$("#accept1").prop("checked","checked");
	$("#refundReasons").val("");
	$("#refundGoodsId").val(id);
	$("#confirmRefundOrderNo").html(orderNo);
}

$("#hexiaoButtonId").click(function(){
	$("#hxcode").val("");
});

//发货
function fhValue(obj,id,orderNo){
	$("#fhId").val(id);
	$("#fhnorderNo").html(orderNo);
	$("#expressCompanyId").val("");
	$("#expressnumber").val("");
}
$("#order_fh").click(function(){
	var id=$("#fhId").val();
	var expressCompanyId=$("#expressCompanyId option:selected").val();
	var expressnumber=$.trim($("#expressnumber").val());
	if(null!=expressnumber && expressnumber.length>0){
		if(!/^[a-zA-Z0-9]{1,20}$/.test(expressnumber)){
			bootbox.alert("快递订单号只能是数字或字母");
			return;
		}
	}
//	if((expressnumber!=null && expressnumber.length>0) || (expressCompanyId!=null && expressCompanyId!="")){
//		if(expressnumber==null || expressnumber.length==0){
//			bootbox.alert("快递单号不能为空")
//			return;
//		}
//		if(expressCompanyId==null || expressCompanyId==""){
//			bootbox.alert("请选择快递公司")
//			return;
//		}
//	}
	$.post(basePath+"/order/updateOrderExpress",
		   {"id": id,"expressCompanyName":expressCompanyId,
		   "expressNumber":expressnumber,"type":0}, function(data) {
		if(data.statusCode==200){
//			bootbox.alert("已发货");
		}else{
			bootbox.alert(data.message);
		}
		$(".close-deliver-goods-modal").click();
		$("#orderfh").hide();
		doSearch();
		return ;
	}, "JSON");
	 
});