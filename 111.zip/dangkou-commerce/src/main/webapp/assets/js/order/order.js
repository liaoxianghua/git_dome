
//保存备注
function saveSellerRemark(id){
	var remark=$("#sellerRemark").val();
	if(remark==''){
		bootbox.alert("请输入备注!");
		return;
	}
	if(remark.length>4000){
		bootbox.alert("备注在4000字以内!");
		return;
	}
	$.ajax({
		url: basePath+"/order/saveSellerRemark",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"sellerRemark":$("#sellerRemark").val()},
	})
	.done(function(data) {
		bootbox.alert(data.message);
		setTimeout(pageReload,2000);
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
	});
}

//改变订单状态
function changeOrderStatus(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				$(obj).attr("disabled",true);
				$(obj).css("display","none");
				$(".order-genre").css("display","none");
				if(orderStatus==2){
					$("#orderSure").css("display","none");
				}
				setTimeout(pageReload,2000);
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}


//保存调整金额
function saveOrderMoneyChange(orderNo){
	var money = $("#adjust-money").val();
	var payMoney = $("#money-should").attr("data-val");
	var moneyF = /^([-][1-9]{1}|[-][0-9]{1}\.\d{1,2}|[-][1-9]{1}[0-9]{1,7}|[-][1-9]{1}[0-9]{1,5}\.\d{1,2}|[1-9]{1}|[0-9]{1}\.\d{1,2}|[1-9]{1}[0-9]{1,7}|[1-9]{1}[0-9]{1,5}\.\d{1,2})$/;
	var mRemark = $("#adjust-remark").val();
	if(money==''){
		bootbox.alert("请输入金额!");
		return;
	}
	if(!moneyF.test(money)){
		bootbox.alert("请输入有效的金额!");
		return;
	}
	if(mRemark.length>4000){
		bootbox.alert("备注在4000以内!");
		return;
	}
	payMoney = $("#money-should").attr("data-val");
	if(payMoney==0){
		if(parseFloat(money)<0){
			bootbox.alert("调整后金额不能为小于0！");
			return;
		}
	}else{
		//alert(money+'~~payMoney:'+payMoney);
		//alert(parseFloat(money)+parseFloat(payMoney));
		if((parseFloat(money)+parseFloat(payMoney))<0){
			bootbox.alert("调整后金额不能为小于0！");
			return;
		}
	}
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$("#order_sub").attr("disabled", true);
			$.ajax({
				url: basePath+"/order/saveOrderMoneyChange",
				type: 'POST',
				dataType: 'json',
				data: {"orderNo":orderNo,"money":$("#adjust-money").val(),"remark":$("#adjust-remark").val()},
			})
			.done(function(data) {
				//bootbox.alert(data.message);
				var html = template("orderMoneyChanges",{items:data.attachObj.moenychanges});
				$("#money-should").attr("data-val",data.attachObj.payPrice);
				$("#money-should").html('¥ '+data.attachObj.payPrice);
				$("#adjustOrderPrice").html(html);
				$("#adjust-money").val(null);
				$("#adjust-remark").val(null);
				//$('#adjust-money-modal').modal('toggle');
				$(".close-adjust-money-modal").click();
				$("#order_sub").attr("disabled", false);
				setTimeout(pageReload,2000);
			})
			.fail(function(data) {
				$("#order_sub").attr("disabled", false);
				bootbox.alert(data.responseText);
			});
		}
	});
}

function pageReload(){
	window.location.reload();
}

$(".close-adjust-money-modal").click(function(){
	 $("#moneyAdjust")[0].reset();
});

$("#order_cancel").click(function(){
	 $("#moneyAdjust")[0].reset();
});

function doChargebackValue(obj,id,orderNo){
	$("#is-valid1").prop("checked","checked");
	$("#inputReasons").val("");
	$("#tuidanId").val(id);
	$("#tuidanorderNo").html(orderNo);
}
//确认退货
function doConfirmRefundDetail(obj,id,orderNo){
	$("#accept1").prop("checked","checked");
	$("#refundReasons").val("");
	$("#refundGoodsId").val(id);
	$("#confirmRefundDetailOrderNo").html(orderNo);
}

//确认退单
$("#curent_order").click(function (){
	var type = $("#isValid input[name='valid']:checked").val();
	var id = $("#tuidanId").val();
	var orderNo = $("#tuidanorderNo").text();
	var inputReasons = $("#inputReasons").val();
	if(inputReasons !=null){
		if(inputReasons.length>512){
			bootbox.alert("您已超过512个字符，请重新输入");
			return ;
		}
	}
	$.ajax({
		url: basePath+"/order/orderRefused",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"orderNo":orderNo,"type":type,"inputReasons":inputReasons},
	})
	.done(function(data) {
		bootbox.alert(data.message);
		$(".close-change-order-status-modal").click();
		$("#inputReasons").val(null);
//		pagerIndex($("#pageNum").val());
		setTimeout(pageReload,2000);
		return ;
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
		$(".close-change-order-status-modal").click();
		$("#inputReasons").val(null);
		setTimeout(pageReload,2000);
		return ;
	});
});

function doChargeback(obj,id,orderStatus){
	bootbox.confirm("你确定要执行该操作吗?",function(result) {
		if(result){
			$.ajax({
				url: basePath+"/order/changeOrderStatus",
				type: 'POST',
				dataType: 'json',
				data: {"id":id,"orderStatus":orderStatus},
			})
			.done(function(data) {
				bootbox.alert(data.message);
				pagerIndex($("#pageNum").val());
			})
			.fail(function(data) {
				bootbox.alert(data.responseText);
			});
		}
	});
}
//确认退货
$("#confirmRefundDetail").click(function (){
	var type = $("#refundOperation input[name='operationValid']:checked").val();
	var id = $("#refundGoodsId").val();
	var orderNo = $("#confirmRefundDetailOrderNo").text();
	var refundReasons = $("#refundReasons").val();
	if(refundReasons !=null){
		if(refundReasons.length>512){
			bootbox.alert("您已超过512个字符，请重新输入");
			return ;
		}
	}
	$.ajax({
		url: basePath+"/order/confirmReturnGoods",
		type: 'POST',
		dataType: 'json',
		data: {"id":id,"orderNo":orderNo,"type":type,"refundReasons":refundReasons},
	})
	.done(function(data) {
		bootbox.alert(data.message);
		$(".close-confirm-refund-detail-modal").click();
		$("#refundReasons").val(null);
		setTimeout(pageReload,2000);
		return ;
	})
	.fail(function(data) {
		bootbox.alert(data.responseText);
		$(".close-confirm-refund-detail-modal").click();
		$("#refundReasons").val(null);
		setTimeout(pageReload,2000);
		return ;
	});
});
//发货
function fhValue(obj,id,orderNo){
	$("#fhId").val(id);
	$("#fhnorderNo").html(orderNo);
	$("#expressCompanyId").val("");
	$("#expressnumber").val("");
}
$("#order_fh").click(function(){
	var id=$("#fhId").val();
	var expressCompanyId=$("#expressCompanyId option:selected").val();
	var expressnumber=$.trim($("#expressnumber").val());
	if(null!=expressnumber && expressnumber.length>0){
		if(!/^[a-zA-Z0-9]{1,20}$/.test(expressnumber)){
			bootbox.alert("快递订单号只能是数字或字母")
			return;
		}
	}
//	if((expressnumber!=null && expressnumber.length>0) || (expressCompanyId!=null && expressCompanyId!="")){
//		if(expressnumber==null || expressnumber.length==0){
//			bootbox.alert("快递单号不能为空")
//			return;
//		}
//		if(expressCompanyId==null || expressCompanyId==""){
//			bootbox.alert("请选择快递公司")
//			return;
//		}
//	}	 
	$.post(basePath+"/order/updateOrderExpress",
		   {"id": id,"expressCompanyName":expressCompanyId,
		   "expressNumber":expressnumber,"type":0}, function(data) {
//			   console.log(data);
		if(data.statusCode==200){
//			bootbox.alert("已发货");
		}else{
			bootbox.alert(data.message);
		}
		$(".close-deliver-goods-modal").click();
		$("#orderfh").hide();
		setTimeout(pageReload,2000);
	}, "JSON");
	 
});
function updateWlButton(expressNum){
//	console.log("aaaaaaa");
	$("#updateExpressnumberId").val(expressNum);
	$("#updateDiv").hide();
	$("#tjDiv").show();
}
$("#tjwlButton").click(function(){
	var id=$("#orderId").val();
	var expressCompanyId=$("#updateExpressCompanyId option:selected").val();
	var expressnumber=$("#updateExpressnumberId").val();
	 
	if(expressnumber!=null && expressnumber.length>0){
		if(!/^[a-zA-Z0-9]{1,20}$/.test(expressnumber)){
			bootbox.alert("快递订单号只能是数字或字母")
			return;
		}
	}
//	if((expressnumber!=null && expressnumber.length>0) || (expressCompanyId!=null && expressCompanyId!="")){
//		if(expressnumber==null || expressnumber.length==0){
//			bootbox.alert("快递单号不能为空")
//			return;
//		}
//		if(expressCompanyId==null || expressCompanyId==""){
//			bootbox.alert("请选择快递公司")
//			return;
//		}
//	}	
		
	$.post(basePath+"/order/updateOrderExpress",
			   {"id": id,"expressCompanyName":expressCompanyId,
			   "expressNumber":expressnumber,"type":1}, function(data) {
				   console.log(data);
			if(data.statusCode==200){
				bootbox.alert("修改物流成功");
			}else{
				bootbox.alert(data.message);
			}
			setTimeout(pageReload,2000);
			$("#updateDiv").show();
			$("#tjDiv").hide();
		}, "JSON");
});
 