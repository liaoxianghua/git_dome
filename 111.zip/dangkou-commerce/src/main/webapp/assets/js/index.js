/**
 * Created by lenovo on 2017/3/21.
 */
/*激活时间选择*/
$(".form_datetime").datetimepicker({
    format: "yyyy MM dd - hh:ii",
    autoclose: true,
    todayBtn: true,
    language: 'zh-CN',
    pickerPosition: "bottom-right"
});



