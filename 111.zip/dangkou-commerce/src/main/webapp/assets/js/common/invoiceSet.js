

 	//点击发票设置按钮
  	$("#toInvoiceSetPageBtn").click(function(){
 		$.post(toInvoiceSetPageUrl,{},function(data){
 			if(data.statusCode == 200){
 				var html = template("invoiceSetScript",{items:data.attachObj});
 				$("#invoiceSetDiv").html(html);
 				invoiceTypeRadioClick();
 				deliverTypeRadioClick();
 				checkBoxClick();
 				saveInvoiceSet();
 			}else{
 				bootbox.alert(data.message)
 			}
 		} ,"json");
  	})

  	//点击发票类型单选框
  	function invoiceTypeRadioClick() {
  	   $(":radio[name='invoiceType']").click(function(){
  	      if($(this).val()==1) {
  	      	  $("#arrivePay").hide();
  	          $("#prePay").hide();
  	          $(":radio[name='deliverPayWay']").attr('checked',false);
  	          $("#getBySelf").hide();
  	          $("#getBySelfCheckBox").attr('checked',false);
  	          $("#advance_priceEdit").hide();
  	          $("#advance_priceEdit").val(null);
  	          $("#accessAddressEdit").hide();
  	          $("#accessAddressEdit").val(null);
  	          $("#getBySelfCheck").val(null);
  	      }	 
  	      if($(this).val()==2) {
  	    	 $("#arrivePay").hide();
 	          $("#prePay").hide();
 	          $(":radio[name='deliverPayWay']").attr('checked',false);
 	          $("#getBySelf").hide();
 	          $("#getBySelfCheckBox").attr('checked',false);
 	          $("#advance_priceEdit").hide();
 	          $("#advance_priceEdit").val(null);
 	          $("#accessAddressEdit").hide();
 	          $("#accessAddressEdit").val(null);
 	          $("#getBySelfCheck").val(null);
  	      }	
  	      if($(this).val()==3) {
  	          $("#arrivePay").show();
  	          $("#prePay").show();
  	          //默认选中快递到付
  	          $("input:radio[name='deliverPayWay']").get(0).checked=true;
  	          //$(":radio[name='deliverPayWay']:first").attr("checked",true);
  	          //$("input[name=deliverPayWay][value='" + 1 + "']").attr("checked",true);
  	          $("#getBySelf").show();
  	          //$("#advance_priceEdit").hide();
  	      }
  	  });
  	}
  	
  	//点击选择纸质发票快递付费方式
  	function deliverTypeRadioClick() {
  	   $(":radio[name='deliverPayWay']").click(function(){
  		      if($(this).val()==1) {
  		    	  $("#advance_priceEdit").hide();
  		    	  $("#advance_priceEdit").val(null);
  		      }
  		      if($(this).val()==2) {
  		    	  $("#advance_priceEdit").show();
  		      }
  		  });
  	}
  	
  	function checkBoxClick() {
  	//点击自取复选框
  	 	$("#getBySelfCheckBox").click(function(){
  	 		if($(this).is(':checked')) {
  	 			$("#getBySelfCheck").val(1);
  	 			$("#accessAddressEdit").show();
  	 		}else{
  	 			$("#getBySelfCheck").val(0);
  	 			$("#accessAddressEdit").hide();
  	 			$("#accessAddressEdit").val(null);
  	 		}
  	 	});
  	}
  	
  	//保存发票设置
  	function saveInvoiceSet() {
  		$("#invoiceSetFormId #saveInvoiceSetBtn").click(function() {
  			if(paramValidata()) {
  				//当面领取未选择时候，置为0
  				if($("#getBySelfCheck").val()==""||$("#getBySelfCheck").val()==undefined||$("#getBySelfCheck").val()==null) {
  					$("#getBySelfCheck").val(0);
  					console.log($("#getBySelfCheck").val());
  				}
  				console.log($("#getBySelfCheck").val());
  	  			$("#invoiceSetFormId #saveInvoiceSetBtn").attr("disabled",true);
  	  			var param = ($("#invoiceSetFormId").serialize());
  	  			$.ajax({
  	  		        url: saveInvoiceSetUrl,
  	  		        type: 'POST',
  	  		        dataType: 'json',
  	  		        data: param,
  	  		        success: function(data) {
  	  		        	$("#invoiceSetFormId #saveInvoiceSetBtn").attr("disabled",false);
  	  		        	if(data.statusCode==200) {
  	  		        		$("#saveInvoiceSetCloseButton").click();
  	  		        		bootbox.alert(data.message);
  	  		        	}else {
  	  		        		bootbox.alert(data.message);
  	  		        	}
  	  		        },
  	  		        error: function(data) {
  	  		        	bootbox.alert(data.responseText);
  	  		        	$("#invoiceSetFormId #saveInvoiceSetBtn").attr("disabled",false);
  	  		        }
  	  		    });
  			}
  		});
  	}
  	function paramValidata() {
  		//console.log($("#getBySelfCheckBox").is(':checked'))
		//校验输入值是否符合规则
		if($(":radio[name='invoiceType']:checked").val()==3) {
			if($(":radio[name='deliverPayWay']:checked").val()==undefined) {
				bootbox.alert("请选择【快递到付】或者【快递预付】中的一种！");
				return false;
			}else {
				if($(":radio[name='deliverPayWay']:checked").val()==2) {
					var prePayPrice = $("#advance_priceEdit").val();
					if(null==prePayPrice||""==prePayPrice||undefined==prePayPrice) {
						bootbox.alert("请输入快递预付金额！");
						return false;
					}else {
						//var re = /^(0|[1-9][0-9]*)$/ ;//0或非0开头的整数
						var re = /^(0|[1-9]([0-9]{0,2}))$/ 
						if(!re.test(prePayPrice)) {
							bootbox.alert("请输入大于或者等于0的整数，最大长度为3位！");
							return false;
						}
					}
				}
			}
			if($("#getBySelfCheckBox").is(':checked')) {
				var takeAddress = $("#accessAddressEdit").val().trim();
				$("#accessAddressEdit").val(takeAddress);
				if(null==takeAddress||""==takeAddress||undefined==takeAddress) {
					bootbox.alert("勾选允许自取复选框后，自取地址不能为空！");
					return false;
				}else {
					if(takeAddress.length>200) {
						bootbox.alert("自取地址的长度不能超过200！");
  						return false;
					}
				}
			}
		}
		return true;
  	}
 	