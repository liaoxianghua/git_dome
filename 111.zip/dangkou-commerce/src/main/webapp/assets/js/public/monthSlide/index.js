/**
 * Created by lenovo on 2017/3/21.
 */
define(function(require,exports,module){
    var $ = require('jquery');

    /*构造函数*/
    function mainSlide(obj){
        this.container = obj.container;
        // this.container = $('.month-select-group');
        this.prevBtn = obj.prevBtn;
        this.nextBtn = obj.nextBtn;
        this.mainSlide = obj.mainSlide;
        this.slides = obj.slides;
        /**/
        this.displayNum = obj.displayNum;
        this.distance = obj.distance;
        this.totalwidth = obj.totalwidth;
    }

    /*通用方法*/
    mainSlide.prototype ={
        //初始化
        init:function(){
        /*设置滑动块的宽度*/
            this.totalwidth = this.slides.length*(this.slides.children('a').outerWidth()+parseInt(this.slides.css('paddingLeft'))*2);
            this.mainSlide.css('width',this.totalwidth+'px');
            //启动事件监听
            this.event();
        },
        //移动
        move:function(d){
            this.distance+= d*this.displayNum*this.slides.outerWidth();
            if( this.distance>0 ){
                this.distance = 0;
                return;
            }else if(this.distance<=-this.totalwidth){
                this.distance = -this.totalwidth+this.displayNum*this.slides.outerWidth();
                return;
            }
            console.log(this.distance);
            this.mainSlide.css('transform','translateX('+this.distance+'px)');
        },
        //事件监听
        event:function(){
            var thit = this;
            this.prevBtn.on('click',function(e){
                e.preventDefault();
                thit.move(1);
            });
            this.nextBtn.on('click',function(e){
                e.preventDefault();
                thit.move(-1);
            });
            this.slides.on('click',function(e){
                e.preventDefault();
                $(this).addClass('active').siblings('.active').removeClass('active');
            })
        }

    }
    exports.slide = mainSlide;
});