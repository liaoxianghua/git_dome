/**
 * Created by lenovo on 2017/3/21.
 */
define(function(require,exports,module){
    var $ = require('jquery');

    function BallHint(obj){
        this.triggerBtn = obj.triggerBtn;
        //this.hintContainer = obj.hintContainer;
    }

    BallHint.prototype = {
        isHint:function(){
            var thit =  this;
            this.triggerBtn.on('mouseover',function(){
                $(this).next().show(200);
            });
            this.triggerBtn.on('mouseout',function(){
                $(this).next().hide(200);
            });
        }
    }

    exports.BallHint = BallHint;
});