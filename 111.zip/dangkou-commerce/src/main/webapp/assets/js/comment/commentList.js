$(function(){
	init($("#searchForm").serialize());
});

$("#searchButton").click(function(){
	if($('#checkbox-id').is(':checked')) {
	    // do something
	}
	var params = $("#searchForm").serializeObject();
	if(params != null){
		if(params.orderId != null){
			if(!/^[0-9]*$/.test(params.orderId)){
				bootbox.alert("订单ID必须是数字")
				return false;
			}
		}
		if(params.productId != null){
			if(!/^[0-9]*$/.test(params.productId)){
				bootbox.alert("产品ID必须是数字")
				return false; 
			}
		}
	}
	
	init(params);
})
//调用回车键进行对数据的插叙
 $(document).on("keyup", function(event){
	   if(event.keyCode==13){
			var params = $("#searchForm").serializeObject();
			if(params != null){
				if(params.orderId != null){
					if(!/^[0-9]*$/.test(params.orderId)){
						bootbox.alert("订单ID必须是数字")
						return false;
					}
				}
				if(params.productId != null){
					if(!/^[0-9]*$/.test(params.productId)){
						bootbox.alert("产品ID必须是数字")
						return false;
					}
				}
			}
			
			init(params);
	    }
 }); 

$(document).on("keyup", function(event){
	if(event.keyCode==46){
		$("#commentid input[type='text']").val("");
		$("#commentid .form-control").val("");
		init(null);
	}
});


function init(params){
	$.post(commentListDataDataUrl,params,function(returndata){
		var data = returndata.attachObj
		if(data && data.list&& data.list.length>0){
			var html = template("searchList",{items:data.list});
			$("#searchListData").html(html);
			var pagerHtml = template("pager",{page:data});
			$("#pagerData").html(pagerHtml);
		}else{
			$("#searchListData").html("没有查询到数据");
			$("#pagerData").html("");
		}
	},"JSON");
}

//修改推荐状态
function updateState(param){
	$.post(updatestatusUrl,param,function(data){
		if(data.statusCode == 200){
			bootbox.alert(data.message);
//			$("#isSale").val(global.saleStatus)
			init($("#searchForm").serialize());
		}else{
			bootbox.alert(data.message);
		}
	},"JSON");
}

//回复
function editcomment(id){
	$.post(editcommentUrl,{id:id},function(data){
		if(data && data.attachObj != null){
			var _product = data.attachObj.productComment;
			var html = template("productEdit",{product:_product});
			$("#comments").html(html);
		}
	},"JSON");
} 

$("#commentEdtBtnSave").click(function() {

	var sellerComtent =$('#sellerComtent').val();
	if(!sellerComtent){
		bootbox.alert("您输入的信息不能为空");
		return;
	}
	console.log("大小:"+sellerComtent.length);
	if(sellerComtent.length>500){
		bootbox.alert("您输入的回复信息不能超过500长度");
		return;
	}
	var params=$("#productEdtiBtnSaveForm").serialize();
	$.post(saveCommentUrl,params,function(data){
		if(data.statusCode == 200){
			bootbox.alert(data.message);
			init($("#searchForm").serialize());
		}else{
			bootbox.alert(data.message);
		}
	},"json");
	parent.$('.close').click();
})

//修改图片状态
function dpdeal(id,valid){
	$.post(updatePicStatusUrl,{"id":id},function(data){
		if(data.statusCode == 200){
			if(valid==1){
				bootbox.alert("删除成功");
			}else{
				bootbox.alert("恢复成功");
			}
//			$("#isSale").val(global.saleStatus)
			init($("#searchForm").serialize());
		}else{
			bootbox.alert(data.message);
		}
	},"JSON");
}
//更换页码
function changePageNum(pag,max,pageNum){
	//debugger;
	var reg = /^[1-9]\d*$/;
	if(pag.value==""||pag.value==null){
		$("#pageNum").val(pageNum);
	}
	if(!reg.test(pag.value)){
		$("#pageNum").val(pageNum);
	}else{
		if(pag.value>max){
			$("#pageNum").val(max);
		}
	}
}
