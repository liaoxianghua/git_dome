define(function(require,exports,module){
    var $ = require('jquery');
    var monthSlide  = require('../public/monthSlide/index');
    var modal = require('../public/model/index');
    var editor = require('../public/editor/editorIndex');   
    /*初始化*/
    function init(){
      
        /*编辑器*/
        var recommend=UE.getEditor('container-recommend',{
            toolbars: [['undo', 'redo','|','fontsize','|',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:1000,
            initialFrameHeight:60
        });
        
//        recommend.addListener("ready", function () {        
//        	
//        });
        
        var imgText=UE.getEditor('container-img-text',{
            toolbars: [['undo', 'redo','|','fontsize','|',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:60
        });
        var trffic=UE.getEditor('container-trffic',{
            toolbars: [['undo', 'redo','|','fontsize','|',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:4000,
            initialFrameHeight:60
        });
        var reserve=UE.getEditor('container-reserve',{
            toolbars: [['undo', 'redo','|','fontsize','|',
                'bold','italic','|','removeformat','|','justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:60
        });
        var retreat=UE.getEditor('container-retreat',{
            toolbars: [['undo', 'redo','|','fontsize','|',
                'bold','italic','|','removeformat','|', 'justifyleft','justifycenter','|',
                'forecolor','|','link','|','insertimage','|','source','|'
            ]],
            zIndex:1060,
            maximumWords:2000,
            initialFrameHeight:60
        });

       
        /*编辑器问题解决*/
        var editorAmend = new editor.Editor({
            $editorBth:$('[data-target="#product-editor"]'),//获取编辑点击按钮
            $modalEle:$('#product-editor'),//模态框外层盒子
            $fullBtn:$('.edui-for-fullscreen .edui-button-body'),//全屏按钮
            $editorBlock:$('.edui-editor.edui-default')//编辑器外层包裹层
        });
        editorAmend.init();
        /*激活modal*/
        repertoryModal.init(); 
               
    }
 
    /*实例化模态框修改*/
    var repertoryModal = new modal.modal($('#repertory-Modal'));

   
    exports.init=init;
});




