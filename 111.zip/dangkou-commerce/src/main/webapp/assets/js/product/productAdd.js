$(function(){  
	
	//初始化城市下拉框样式
	$('.bs-select').selectpicker({
		noneSelectedText:'',
        iconBase: 'fa',
        tickIcon: 'fa-check'
    });
}); 
function toProductAdd(){
	initEdit();
	$.post(addProductUrl,{},function(data){
		if(data.statusCode == 200){
			var html = template("productAddScript",{items:data.attachObj.list})
			$("#productAddData").html(html)
			countWords('add-product-name','title_shownum_label',200);
			initCityData(data.attachObj.listCitys,"add-city","");
			saveProduct();
		}else{
			bootbox.alert(data.message)
		}
	} ,"json");
}
//清空富文本
function initEdit() {
	$("#baseinfo li").removeClass("active");
	$("#baseinfo li:first").addClass("active");
	$("#baseTab div").removeClass("in active")
	$("#baseTab div:first").addClass("in active");
	var recommend = UE.getEditor('container-recommend');
	recommend.setContent("")
	var remark = UE.getEditor('container-img-text');
	remark.setContent("")
	var traffic = UE.getEditor('container-trffic');
	traffic.setContent("")
	var orderRule = UE.getEditor('container-reserve');
	orderRule.setContent("")
	var returnRule = UE.getEditor('container-retreat');
	returnRule.setContent("")
}
function saveProduct(){
	//保存产品
	$("#saveProductButton").click(function(e){
			var param  = $("#saveProductForm").serializeObject();
		 	var flag = false;
			  if(!/^[0-9]*$/.test(param.confirmHour)){
				  	$("#confirmTimeSpanId").html("请输入整数");
			        $("#confirmTimeSpanId").show();
			        flag = true;
			        return false;
			  }else{
				  $("#confirmTimeSpanId").hide();
			  }
			  if(param.confirmHour == null || param.confirmHour.length > 8){
			        $("#confirmTimeSpanId").show();
			        $("#confirmTimeSpanId").html("最长8位整数")
			        flag = true;
			  }else{
				  $("#confirmTimeSpanId").hide();
			  }
			  if(!param.productName || param.productName == null || param.productName.trim().length == 0){
			        $("#productNameSpanId").show();
			        $("#add-product-name").val("");
			        $("#title_shownum_label").html(0);
			        flag = true;
			  }else{
				  $("#productNameSpanId").hide();
			  }
			  if(!param.cityId){
			        $("#addCitySpanId").show();
			        flag = true;
			  }else{
				  $("#addCitySpanId").hide();
			  }
			if(flag){
				return false;
			}
			$.post(saveProductUrl,param,function(data){
				if(data.statusCode == 200){
					init($("#searchForm").serialize());
					$("#saveProductForm")[0].reset();
					$("#cityId option:first").attr("selected",true);
					$("#saveProductCloseButton").click();
					$("#spanId").click();
					editProduct(data.attachObj);
					$("#add-city").selectpicker("refresh");
				}else{
					bootbox.alert(data.message)
				}
			} ,"json");
	});
}

//计数器
function countWords(editedId, showId,maxCount){ 
	var fullStr = $("#"+editedId).val();
	var charCount = fullStr.length; 
	if(charCount>maxCount) {
		var subCount = fullStr.substring(maxCount,charCount).length;
		$("#"+editedId).val(fullStr.substring(0,maxCount));
		charCount = charCount - subCount;
	}
	var rExp = /[^A-Za-z0-9]/gi; 
	var spacesStr = fullStr.replace(rExp, ' '); 
	var cleanedStr = spacesStr + ' '; 
	do{ 
		var old_str = cleanedStr; 
		cleanedStrcleanedStr = cleanedStr.replace(' ', ' '); 
	}while( old_str != cleanedStr ); 
	var splitString = cleanedStr.split(' '); 
	document.getElementById(showId).innerHTML = charCount; 
}