$(function(){
	$("#searchPicFormBtn").click(function(){
		initProductList($("#searchPicForm").serialize())
	});
	$("#productPicAddBtn").click(function(){
		var valArr = new Array;
	    $("input[name='id']:checked").each(function(i){
			valArr[i] = $(this).val();
	    });
		var vals = valArr.join(',');//转换为逗号隔开的字符串
		$.post(productLibSaveUrl,{ids:vals,productId:$("#picProductId").val()},function(data){
			if(data.statusCode == 200){
				bootbox.alert(data.message)
				$("#isSale").val(global.saleStatus)
				initProductList($("#searchPicForm").serialize());
				productPicList($("#picProductId").val());
				$("#productPicListScriptCloseBtn").click();
				$("#searchPicForm")[0].reset();
			}else{
				bootbox.alert(data.message)
			}
		},"JSON");

	});
}); 
 
//模拟关闭 
function doClose(){
	$("#searchPicForm")[0].reset();
	//$('#productPicListDiv').modal('hide');
}
function initProductList(queryParams){
	$.post(productPicListDataUrl,queryParams,function(data){
		if(data && data.list && data.list.length > 0){
			var html = template("productPicListScript",{items:data.list,page:data,productId:queryParams.productId});
			$("#productPicListData").html(html)
			$("#productPicAddBtn").show();
		}else{
			$("#productPicListData").html("没有数据")
			$("#productPicAddBtn").hide();
		}
	},"json")
}
function toProductPicAdd($this,productId){
	$.post(productPicListDataUrl,{id:productId},function(data){
		$("#picProductId").val(productId)
		var html = template("productPicListScript",{items:data.list,page:data,productId:productId});
		$("#productPicListData").html(html)
	},"json")
}


var pagerPicIndex = function(v){
	var queryParams = $('#searchPicForm').serializeObject();  
	var pagerParams = {pageNum:v,pageSize:$("#pagePicSize").val()} 
	$.extend(queryParams,pagerParams)
	$.post(productPicListDataUrl,queryParams,function(data){
		var html = template("productPicListScript",{items:data.list,page:data,productId:queryParams.productId});
		$("#productPicListData").html(html)
	},"json")
}
var pagePicSizeChange = function(){
	pagerPicIndex(1);
}
var pagePicNumChange = function(){
	pagerPicIndex($("#pagePicNum").val());
}