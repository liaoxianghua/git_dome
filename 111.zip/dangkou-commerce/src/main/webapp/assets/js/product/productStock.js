$(function(){  
}); 
//to添加或修改库存
function toStockAddOrUpdate($this,type,id,proudctType){
	var html = template("productStockAddOrEditScript",{type:type,mealsId:id,proudctType:proudctType});
	$("#productStockAddOrEditData").html(html);
	productStockSave();
}
//添加或修改库存
function productStockSave(){
	$("#productStockAddSaveBtn").click(function(){
		var params = $("#productStockAddForm").serializeObject();
		var mealsId = params.mealsId;
		var flag = false;
		if(!params.createEndTime){
			$("#createEndTimeSpanId").show();
			flag =true;
		}else{
			$("#createEndTimeSpanId").hide();
		}
		if(!params.createStartTime){
			$("#createStartTimeSpanId").show();
			flag =true;
		}else{
			$("#createStartTimeSpanId").hide();
		}
		if(params.productType == 1){
			if(!params.price){
				$("#priceSpanId").show();
				$("#priceSpanId").html("必填");
				flag =true;
			}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(params.price)){
				$("#priceSpanId").show();
				$("#priceSpanId").html("请填入正数,精确到小数点后2位");
				flag = true;
			}else if(params.price.length > 5){
				$("#priceSpanId").show();
				$("#priceSpanId").html("超出长度限制");
				flag = true;
			}else{
				$("#priceSpanId").hide();
			}
		}else if(params.productType == 3){
			if(!params.singleRoomPrice){
				$("#singleRoomPriceSpanId").show();
				flag =true;
			}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(params.singleRoomPrice)){
				$("#singleRoomPriceSpanId").show();
				$("#singleRoomPriceSpanId").html("请填入正数,精确到小数点后2位");
				flag = true;
			}else if(params.singleRoomPrice.length > 5){
				$("#singleRoomPriceSpanId").show();
				$("#singleRoomPriceSpanId").html("超出长度限制");
				flag = true;
			}else{
				$("#singleRoomPriceSpanId").hide();
			}
			
			if(!params.childPrice){
				$("#childPriceSpanId").show();
				flag =true;
			}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(params.childPrice)){
				$("#childPriceSpanId").show();
				$("#childPriceSpanId").html("请填入正数,精确到小数点后2位");
				flag = true;
			}else if(params.childPrice.length > 5){
				$("#childPriceSpanId").show();
				$("#childPriceSpanId").html("超出库存最大限制");
				flag = true;
			}else{
				$("#childPriceSpanId").hide();
			}
			
			if(!params.adultPrice){
				$("#adultPriceSpanId").show();
				flag =true;
			}else if(!/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(params.adultPrice)){
				$("#adultPriceSpanId").show();
				$("#adultPriceSpanId").html("请填入正数,精确到小数点后2位");
				flag = true;
			}else if(params.adultPrice.length > 5){
				$("#adultPriceSpanId").show();
				$("#adultPriceSpanId").html("超出库存最大限制");
				flag = true;
			}else{
				$("#adultPriceSpanId").hide();
			}
		}
		
		if(!params.totalNum){
			 $("#totalNumSpanId").show();
			 $("#totalNumSpanId").html("必填");
		     flag = true;
		}else if(!/^[0-9]*$/.test(params.totalNum)){
			$("#totalNumSpanId").show();
			$("#totalNumSpanId").html("请输入正整数");
	        flag = true;
		}else if(params.totalNum < 1){
			$("#totalNumSpanId").show();
			$("#totalNumSpanId").html("请输入正整数");
			flag = true;
		}else if(params.totalNum > 9999){
			$("#totalNumSpanId").show();
			$("#totalNumSpanId").html("超出库存最大限制");
			flag = true;
		}else{
			$("#totalNumSpanId").hide();
		}
		if(!flag){
			//防重复提交
			$("#productStockAddSaveBtn").attr("disabled","disabled");
			$.ajax({
				url:addProductStockUrl,
				data:params,
				traditional:true,
				type:"post",
				dataType:"json",
				success:function(data){
					bootbox.alert(data.message)
					$("#clossProductAddBtn").click();
					$("#productStockAddForm")[0].reset();
					showStock("",mealsId,"");
				},
				error:function(data){
					$("#productStockAddSaveBtn").removeAttr("disabled");
					bootbox.alert(data.message)
				}
			});
		}else{
			$("#productStockAddSaveBtn").removeAttr("disabled");
		}
	});
}