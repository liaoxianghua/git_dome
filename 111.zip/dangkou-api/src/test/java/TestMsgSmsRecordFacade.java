import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.facade.MsgSmsRecordFacade;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/applicationContext.xml")
@WebAppConfiguration
public class TestMsgSmsRecordFacade {
 
	@Resource
	private MsgSmsRecordFacade msgSmsRecordFacade;
	
	@Test
	public void insert() {
//		msgSmsRecordFacade.saveMsgSmsRecord("15925686576", "你的订单号已发货");
	}
	
	@Test
	public void saveMsgSmsRecord() {
		System.out.println(PropertiesUtil.getProperty("pay.env.Flag"));
//		msgSmsRecordFacade.saveMsgSmsRecord("15925686576", "你的订单号已发货","2017083000009");
	}
 
}
