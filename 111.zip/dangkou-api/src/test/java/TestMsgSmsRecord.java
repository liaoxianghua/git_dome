import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.spring.scenic.sms.application.MsgSmsRecordService;
import com.spring.scenic.sms.domain.MsgSmsRecord;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:config/applicationContext.xml")
@WebAppConfiguration
public class TestMsgSmsRecord {
 
	@Resource
	private MsgSmsRecordService msgSmsRecordService;  
	
	@Test
	public void insert() {
//		MsgSmsRecord entity = new MsgSmsRecord();
//		entity.setReceiverNo("15925686596");
//		entity.setCreateUser(1);
//		entity.setMsgContent("你的订单已发货");
//		entity.setOrderNo("2569658696547856");
//		entity.setReturnContent("22");
//		entity.setSendStatus(1);
//		entity.setReturnStatus("0");
//		entity.setCreateTime(new Date());
//		entity.setUpdateTime(new Date());
//		entity.setUpdateUser(3);
//		msgSmsRecordService.insert(entity);
//		System.out.println(entity.getId());
	}

	@Test
	public void update(){
//		MsgSmsRecord entity = new MsgSmsRecord();
//		entity.setId(9);
//		entity.setReceiverNo("2");
//		entity.setCreateUser(3);
//		entity.setMsgContent("2");
//		entity.setOrderNo("2");
//		entity.setReturnContent("2");
//		entity.setSendStatus(2);
//		entity.setReturnStatus("2");
//		entity.setCreateTime(new Date());
//		entity.setUpdateTime(new Date());
//		entity.setUpdateUser(2);
//		msgSmsRecordService.update(entity);
	}
	
	@Test
	public void deleteByPrimaryKey(){ 
//		msgSmsRecordService.deleteById(4);
	}
	
	@Test
	public void deleteByIds(){ 
//		List<Integer> list = new ArrayList<Integer>();
//		list.add(5);
//		list.add(7);
//		msgSmsRecordService.deleteByIds(list);
	}
	
	@Test
	public void selectByPrimaryKey(){ 
//		MsgSmsRecord msgSmsRecord = msgSmsRecordService.selectById(12);
//		System.out.println(msgSmsRecord.getMsgContent());
	}
	
	@Test
	public void selectPage(){ 
//		MsgSmsRecord entity = new MsgSmsRecord();
//		entity.setPageNum(1);
//		entity.setPageSize(10);
//		List<MsgSmsRecord> list = msgSmsRecordService.selectPage(entity, true);
//		System.out.println(list.size());
	}
}
