package com.spring.scenic.pay.controller.weixin;



/**
 * WeixinSetting
 * 此处为类说明
 * @author liaoxianghua
 * @date 2017年7月25日
 */
public class WeixinSetting {
    //开放平台信息
    private String openAppId;
    private String openAppSecret;
    private String openAuthDomain;
    private String wxScanLoginCallBack;
    //公众号信息
    private String appid;
    private String appSecret;
    private String apikey;
    private String mch_id;
    //域名地址
  	private String domain;
  	//api接口名称
  	private String pathName;
	 
	public String getPathName() {
		return pathName;
	}
	public void setPathName(String pathName) {
		this.pathName = pathName;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getAppid() {
		return appid;
	}
	public String getAppSecret() {
		return appSecret;
	}
	public String getApikey() {
		return apikey;
	}
	public String getMch_id() {
		return mch_id;
	}
	public void setAppid(String appid) {
		this.appid = appid;
	}
	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	public void setApikey(String apikey) {
		this.apikey = apikey;
	}
	public void setMch_id(String mch_id) {
		this.mch_id = mch_id;
	}
    public String getOpenAppId() {
        return openAppId;
    }
    public void setOpenAppId(String openAppId) {
        this.openAppId = openAppId;
    }
    public String getOpenAppSecret() {
        return openAppSecret;
    }
    public void setOpenAppSecret(String openAppSecret) {
        this.openAppSecret = openAppSecret;
    }
    public String getOpenAuthDomain() {
        return openAuthDomain;
    }
    public void setOpenAuthDomain(String openAuthDomain) {
        this.openAuthDomain = openAuthDomain;
    }
    public String getWxScanLoginCallBack() {
        return wxScanLoginCallBack;
    }
    public void setWxScanLoginCallBack(String wxScanLoginCallBack) {
        this.wxScanLoginCallBack = wxScanLoginCallBack;
    }
    
}
