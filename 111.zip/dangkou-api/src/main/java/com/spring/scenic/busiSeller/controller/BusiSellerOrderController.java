 
package com.spring.scenic.busiSeller.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.application.BusiSellerOrderService;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.DateUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.encrypt.EncryptPkUtil;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderMoneyChangeRec;
import com.spring.scenic.order.domain.OrderPayRecord;
import com.spring.scenic.picture.domain.BusiPictureLib;
import com.spring.scenic.product.application.ProductPicRelService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.ProductWithBLOBs;
import com.spring.scenic.system.application.DictionaryService;
import com.spring.scenic.system.domain.Dictionary;


/**
 * 商户中心M网订单接口
 */
@Controller
@RequestMapping("busiSeller")
@Api(value = "商户中心M网接口", description = "商户中心M网订单相关")
public class BusiSellerOrderController extends BaseController{
	
    @Resource
    private BusiSellerOrderService busiSellerOrderService;
    
    @Resource
	private ProductPicRelService productPicRelService;

	@Resource
	private ProductService productService;

	private Logger logger = LoggerFactory.getLogger(BusiSellerOrderController.class);
    @Resource
    private OrderService orderService;
    @Resource
    private DictionaryService dictionaryService;
    
    /**
     * 查询订单数据
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value = "getOrderListData", method = {RequestMethod.POST})
    @ApiOperation(httpMethod = "POST", value = "商户中心M网订单列表", notes = "查询各种状态的订单数据", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageNum", value = "第几页", dataType = "Integer", paramType = "query", required = true),
        @ApiImplicitParam(name = "pageSize", value = "每页大小", dataType = "Integer", paramType = "query", required = true),
        @ApiImplicitParam(name = "orderStatus", value = "查询类别(null、全部；1、待处理；2、取消；3、待完成；4、申请退单)", dataType = "Integer", paramType = "query", required = false),
        @ApiImplicitParam(name = "createTimeStart", value = "今日时间", dataType = "Date", paramType = "query", required = false)
    })
    public MessageData getOrderListData(HttpServletRequest request,Integer orderStatus, Integer pageNum, Integer pageSize,Date createTimeStart) {
        try {
            BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER); 
            if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
            Order order = new Order();
            order.setSellerId(sellerUser.getSellerId());
            order.setOrderStatus(orderStatus);
            order.setCreateTimeStart(createTimeStart);
            order.setPageNum(pageNum);
            order.setPageSize(pageSize);
            List<Order> list = busiSellerOrderService.getOrderListWithWarn(order, true);
            for(Order orderTemp : list){
            	//订单id加密
                orderTemp.setEncode(EncryptPkUtil.encodeId(String.valueOf(orderTemp.getId())));
                orderTemp.setId(null);
            }
            PageInfo<Order> page = new PageInfo<Order>(list, order.getPageSize());
            Map<String, Object> map = new HashMap<String,Object>();
            Map<String,Integer> orderStatisic = busiSellerOrderService.getOrderStatisticBySatatus(sellerUser);
            //增加查询物流列表
    		Dictionary dictionary = new Dictionary();
    		dictionary.setCode("EXPRESS_COMPANY");
    		List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
    		map.put("expressCompanyList", expressCompanyList);
            map.put("page", page);
            map.put("orderStatisic", orderStatisic);
            return new MessageData(SysConstant.SUCCESS, "查询成功", map);
        } catch (Exception e) {
            logger.info(e.getMessage(),e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 查询订单详情
     * 此处为类方法说明
     * @param session
     * @param request
     * @param encode
     * @return
     * @creator ：xiangbin  
     * @date ：2017年7月24日下午6:37:59
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderDetail",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网订单详情", notes = "订单详情、出行人、支付情况、发票信息、卖家备注、客人备注")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
    })
    public MessageData busiSellerOrderDetail(HttpSession session,HttpServletRequest request,String encode){
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		MessageData message = new MessageData(SysConstant.SUCCESS, "成功");
    	    Map<String, Object> map = new HashMap<String, Object>();
    	    if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
    	    //增加查询物流列表
    		Dictionary dictionary = new Dictionary();
    		dictionary.setCode("EXPRESS_COMPANY");
    		List<Dictionary> expressCompanyList = dictionaryService.getDictionaryListByCode(dictionary);
    		map.put("expressCompanyList", expressCompanyList);
    		 
    		
            Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
    	    Order order = busiSellerOrderService.getOrderDetail(orderId);//订单详情
    	    if(null!=order) {
    	    	// 基本属性
    	    	ProductWithBLOBs   product = productService.selectByPrimaryKey(order.getProductId());
    	        if(order.getFileUrl()==null){
                    // 产品图片
                    List<BusiPictureLib> productPicList = productPicRelService.getProductPicOrDefault(product);
                    if(productPicList==null || productPicList.isEmpty()){//没图片给默认图片
                        product.setMainPic(PropertiesUtil.getProperty("scenic_default_user_img"));
                        order.setFileUrl(product.getMainPic());
                    }else{//有图片取第一张
                        product.setMainPic(productPicList.get(0).getFileUrl());
                        product.setProductPics(productPicList);
                        order.setFileUrl(product.getMainPic());
                    }
                }
    	        
    	      //支付记录id加密
                List<OrderPayRecord> payRecordeList = null;
                payRecordeList = order.getOrderPayRecords();
                for(OrderPayRecord orderPayRecord : payRecordeList){
                    //订单id加密
                    orderPayRecord.setEnCode(EncryptPkUtil.encodeId(String.valueOf(orderPayRecord.getId())));
                    orderPayRecord.setId(null);
                }
                order.setEncode(encode);
                order.setId(null);
                map.put("product", product);
    	    }else{
    	    	 map.put("product", null);
    	    }
    	    
    		if(null!=expressCompanyList && null!=order){
    			for (Dictionary oldDictionary : expressCompanyList) {
    				if(null!=order.getExpressCompanyName() && oldDictionary.getValue().equals(order.getExpressCompanyName())){
    					dictionary.setId(oldDictionary.getId());
    				}
    			}
    		}
    		if(null!=order.getExpressCompanyName()){
    			dictionary.setCode(null);
    			Dictionary dictionaryDetail=dictionaryService.getDictionary(dictionary);
    			if(null!=dictionaryDetail){
    				map.put("oldexpressName", dictionaryDetail.getName());
    			}else{
    				map.put("oldexpressName",null);
    			}
    		}else{
    			map.put("oldexpressName",null);
    		}
    	    
    	    map.put("order", order);
    	    message.setObj(map);
    	    message.setMessage("查询成功！");
    	    return message;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    /**
     * 保存订单备注
     * 此处为类方法说明
     * @param httpSession
     * @param request
     * @param sellerRemark
     * @param encode
     * @return
     * @creator ：xiangbin  
     * @date ：2017年7月24日下午7:20:14
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderRemark",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网订单备注", notes = "订单备注内容")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "sellerRemark", value = "商户订单备注", required = true, dataType = "String", paramType = "query"),
    })
    public MessageData busiSellerOrderRemark(HttpSession httpSession,HttpServletRequest request,String sellerRemark,String encode){
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		MessageData messageData = new MessageData(null,null);
    		if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
            Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
    	    messageData = busiSellerOrderService.saveSellerRemark(orderId,sellerRemark);//保存订单备注内容   	   
    	    return messageData;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    /**
     * 订单状态的修改
     * 此处为类方法说明
     * @param httpSession
     * @param request
     * @param encode
     * @param orderStatus
     * @return
     * @creator ：xiangbin  
     * @date ：2017年7月25日下午4:23:14
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderStatus",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网订单状态", notes = "订单状态按钮")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "orderStatus", value = "订单状态", required = true, dataType = "Integer", paramType = "query"),
    })
    public MessageData busiSellerOrderStatus(HttpSession httpSession,HttpServletRequest request,String encode,Integer orderStatus){
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
            Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
    		Order order = new Order();
    		order.setId(orderId);
    		order.setOrderStatus(orderStatus);
    		MessageData messageData = new MessageData(null,null);
    	    messageData = busiSellerOrderService.updateOrderStatus(order,sellerUser);//更改订单状态   	   
    	    return messageData;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    /**
     * 商户中心M网订单金额调整
     * 此处为类方法说明
     * @param httpSession
     * @param request
     * @param encode
     * @param money
     * @param remark
     * @return
     * @creator ：Administrator  
     * @date ：2017年8月9日下午1:34:04
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/saveBusiSellerOrderMoneyChange",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网订单金额调整", notes = "订单金额调整")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
    	@ApiImplicitParam(name = "money", value = "调整金额", required = true, dataType = "BigDecimal", paramType = "query"),
        @ApiImplicitParam(name = "remark", value = "备注", required = false, dataType = "String", paramType = "query")
    })
    public MessageData saveBusiSellerOrderMoneyChange(HttpSession httpSession, HttpServletRequest request, BigDecimal money, String encode, String remark){
    	try {
    		MessageData messageData = new MessageData(null, null, null);
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser == null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		if(null == money) {
    			return new MessageData(SysConstant.FAILURE, "订单调整金额不能为空！");
    		}
    		if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
    		if(StringUtils.isNotBlank(remark)) {
    			if(remark.length()>50) {
    				messageData.setStatus(202);
    				messageData.setMessage("最多可以输入50个字符!");
    				return messageData;
    			}
            }
    		Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
    		Order order = busiSellerOrderService.getOrderDetail(orderId);
    		if(order.getPayPrice().add(money).compareTo(BigDecimal.ZERO)== -1) {
    			return new MessageData(SysConstant.FAILURE, "调整后金额不能小于0！");
    		}
    		if(order.getOrderStatus() == 1 || order.getOrderStatus() == 3 ||order.getOrderStatus() == 4 || order.getOrderStatus() == 7 || order.getOrderStatus() == 8){
	    		String orderNo = order.getOrderNo();
		    	busiSellerOrderService.saveBusiSellerOrderMoneyChange(sellerUser, orderNo, money, remark);
			    List<OrderMoneyChangeRec> orderMoneyChangeRecs = busiSellerOrderService.getBusiSellerOrderMoneyChangeList(orderNo);
			    //金额调整人
			    //String moneyChangePeople = sellerUser.getTruename();
			    
			    //最新应付金额=应付金额+调整后的金额
			    BigDecimal payPrice = order.getPayPrice().add(money);
			    order.setPayPrice(payPrice);
		        
		        BigDecimal payedPrice = order.getPayedPrice();
		        if(payedPrice == null){
		            payedPrice = BigDecimal.ZERO;
		        }
		        //付款金额为0且已付为0且有支付记录：全款
		        if(payPrice.compareTo(BigDecimal.ZERO)==0){
		            if(payPrice.compareTo(payedPrice)==0){
		                if(order.getOrderPayRecords()!=null && !order.getOrderPayRecords().isEmpty()){
		                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
		                }
		            }else if(payPrice.compareTo(payedPrice) < 0){
		                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
		            }
		        }else {
		            if(payedPrice.compareTo(BigDecimal.ZERO)==0){//付款金额不为且已付为0：未付款
		                order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_NO.getCode()));
		            }else{//其他
		                if(payedPrice.compareTo(payPrice)==-1){
		                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()));
		                }else if(payedPrice.compareTo(payPrice)==0){
		                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_ALL.getCode()));
		                }else if(payedPrice.compareTo(payPrice)==1){
		                    order.setPayStatus(Integer.valueOf(SysEnum.ORDER_PAY_STATUS_PAID_EXCESS.getCode()));
		                }
		            }
		        }
		        busiSellerOrderService.updateBusiSellerOrderPayPrice(order);
		        busiSellerOrderService.updateOrderPayInfo(order);
		        Map <String,Object> dataMap = new HashMap<String,Object>(); 
	            dataMap.put("moneyChanges", orderMoneyChangeRecs);
	            dataMap.put("payPrice", payPrice);
	            //dataMap.put("moneyChangePeople", moneyChangePeople);
	            messageData.setStatus(SysConstant.SUCCESS);
	            messageData.setMessage(SysConstant.MESSAGE_SUCCESS);
	            messageData.setObj(dataMap);
	            return messageData;
    		}else{
    			return new MessageData(SysConstant.FAILURE, "该订单不能调整金额");
    		}
	    }catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
	    }
    }
    
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderRefused",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网申请退单", notes = "商户中心M网申请退单")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "type", value = "订单类型  1表示确认退单  2表示拒绝退单", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "inputReasons", value = "拒绝理由", required = false, dataType = "String", paramType = "query"),
    })
    public MessageData busiSellerOrderRefused(HttpSession httpSession,
    										  HttpServletRequest request,
    										  String encode,
    		 								  Integer type,
    		 								  String inputReasons){
    	MessageData messageData =new  MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
			if(StringUtils.isNotBlank(inputReasons)){
				if(inputReasons.length()>512){
					messageData.setMessage("您已超过512个字符，请重新输入");
					messageData.setStatus(201);
					return messageData;
				}
			}
			Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
			Order order = new Order();
			order.setId(orderId);
			if(type==1){
				order.setOrderStatus(5);//接受退单
			}else if(type==2){
//				Order orderOld=orderService.selectOrderWriteOffCode(order);
//				if(orderOld.getPayStatus()>1){
//					messageData.setMessage("商家取消“已确认”订单仅限于“未付款”订单");
//					messageData.setStatus(201);
//					return messageData;
//				}
				order.setOrderStatus(3);//拒绝退单
			}
			 
    	    messageData = busiSellerOrderService.updateBusiSellerOrderRefused(order,sellerUser,type,inputReasons);//订单退单	   
    	    return messageData;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    
    /**
     * 申请退货
     * 此处为类方法说明
     * @param httpSession
     * @param request
     * @param encode
     * @param type
     * @param inputReasons
     * @return
     * @creator ：Administrator  
     * @date ：2017年9月8日下午2:12:50
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderReturnGoods",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网申请退货", notes = "商户中心M网申请退货")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "type", value = "订单类型  1表示确认退货  2表示拒绝退货", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "refundReasons", value = "输入理由", required = false, dataType = "String", paramType = "query"),
    })
    public MessageData busiSellerOrderReturnGoods(HttpSession httpSession, HttpServletRequest request, String encode, Integer type, String refundReasons){
    	MessageData messageData =new  MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser == null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		if(StringUtils.isBlank(encode)) {
                return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
            }
			if(StringUtils.isNotBlank(refundReasons)){
				if(refundReasons.length()>512){
					messageData.setMessage("您已超过512个字符，请重新输入");
					messageData.setStatus(201);
					return messageData;
				}
			}
			Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
			Order order = new Order();
			order.setId(orderId);
			if(type == 1){
				order.setOrderStatus(9);//接受退货，接受后，订单状态为已退货。
			}else if(type == 2){
				order.setOrderStatus(7);//拒绝退货，拒绝后，订单状态回到已发货
			}
    	    messageData = busiSellerOrderService.updateBusiSellerOrderReturnGoods(order,sellerUser,type,refundReasons);//更改订单状态   
    	    return messageData;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/updateOrderExpress",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "发货和修改物流信息", notes = "发货和修改物流信息")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "encode", value = "订单加密ID", required = true, dataType = "String", paramType = "query"),
    	@ApiImplicitParam(name = "expressCompanyName", value = "公司名字", required = true, dataType = "String", paramType = "query"),
    	@ApiImplicitParam(name = "expressNumber", value = "订单号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "type", value = "订单类型 0表示发货  1表示修改物流", required = false, dataType = "Integer", paramType = "query"),
    })
    public MessageData updateOrderExpress(HttpServletRequest request,String encode,
    									  String expressCompanyName,String expressNumber,Integer type){ 
    	MessageData data=new MessageData(200, "操作成功");
    	Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
    	Order order=new Order();
    	  try {
    		  //已发货
    		  if(type==0){
    			  order.setOrderStatus(7);
    			  order.setExpressConfirmTime(DateUtil.currentDateAddOrReduce(new Date(), 7));
    		  }else if(type>1){
    			  logger.error("异常操作，手动修改");
    			  data.setMessage("快递修改失败");
    			  data.setStatus(201);
    			  return data;
    		  }
    		  
    		  //确认时间为当前时间，+7天
    		  order.setExpressCompanyName(expressCompanyName);
    		  order.setId(orderId);
    		  order.setExpressNumber(expressNumber);
    		  orderService.updateOrderExpress(order,type);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			data.setMessage("添加快递失败");
			data.setStatus(201);
		}
    	  return data;
    }
}

