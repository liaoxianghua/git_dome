

package com.spring.scenic.message.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.content.domain.vo.MyCommentVo;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberMsg;
import com.spring.scenic.praise.application.PushPraiseService;
import com.spring.scenic.praise.domain.MyPushPraise;
import com.spring.scenic.security.MemberAuthentiction;


/**
 * 
 * 此处为类说明：会员消息模块接口
 * @author rmp
 * @date 2017年5月5日
 */

@Controller
@RequestMapping("messages")
@Api(value = "messageController", description = "会员消息模块接口")
public class MessageController extends BaseController{
	
	@Autowired
	private TravelNotesCommentService travelNotesCommentService;
	@Autowired
	private PushPraiseService pushPraiseService;
	@Autowired
	private MemberCollectionService membercollectionService;
	@Autowired
	private MemberMsgService memberMsgService;
	@Autowired
	private MemberBasicService memberBasicService;
	
	private Logger logger = LoggerFactory.getLogger(MessageController.class);
	
    /**
     * 
     * 此处为类方法说明:查询会员本人的点赞列表,点赞类别(1、游记攻略；2、产品的评论；3、直播)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="selectMemberPraiseList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员本人的被点赞列表", notes = "点赞列表", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectMemberPraiseList(HttpServletRequest request,HttpSession httpSession){
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                Map<String,Object> map=new HashMap<String,Object>();
                Integer memberId = memberBasic.getId();
                List<MyPushPraise> memberPraiseList = pushPraiseService.selectMemberPraiseList(memberId);
                map.put("memberPraiseList", memberPraiseList);
                messageData.setStatus(SysConstant.SUCCESS);
                messageData.setMessage("查询成功！");
                messageData.setObj(map);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录！");
            }
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }

    /**
     * 
     * 此处为类方法说明:查询会员本人的游记被评论列表,点赞类别(1、游记攻略；2、产品的评论；3、系统消息)
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="selectMemberCommentList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员的游记评论列表", notes = "评论列表", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectMemberCommentList(HttpServletRequest request,HttpSession httpSession){
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                Map<String,Object> map = new HashMap<String,Object>();
                Integer memberId = memberBasic.getId();
                List<MyCommentVo> memberTravelNoteCommentList = travelNotesCommentService.selectMemberCommentList(memberId);//我的游记攻略列表
                map.put("memberTravelNoteCommentList", memberTravelNoteCommentList);
                messageData.setStatus(SysConstant.SUCCESS);
                messageData.setMessage("查询成功！");
                messageData.setObj(map);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录！");
            }
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:查询会员收到的系统通知列表
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="selectSystemNoticeList",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员收到的系统通知列表", notes = "通知列表", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectSystemNoticeList(HttpServletRequest request,HttpSession httpSession){
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                Map<String,Object> map = new HashMap<String,Object>();
                Integer memberId = memberBasic.getId();
                List<MemberMsg> memberTravelNoteCommentList = memberMsgService.selectSystemNoticeList(memberId);//我的游记攻略列表
                map.put("memberTravelNoteCommentList", memberTravelNoteCommentList);
                messageData.setStatus(SysConstant.SUCCESS);
                messageData.setMessage("查询成功！");
                messageData.setObj(map);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录！");
            }
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:查询会员收到的系统通知详情
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月5日     
     * @memo ：   
     **
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="selectSystemNoticeDetail",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "查询会员收到的系统通知详情", notes = "通知列表", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "noticeId", value = "系统消息主键id", required = true, dataType = "Integer", paramType = "query")
    })
    public MessageData selectSystemNoticeDetail(HttpServletRequest request,HttpSession httpSession,Integer noticeId){
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                Map<String,Object> map = new HashMap<String,Object>();
                MemberMsg systemNoticeDetail = memberMsgService.selectSystemNoticeDetail(noticeId);//我的游记攻略列表
                map.put("systemNoticeDetail", systemNoticeDetail);
                messageData.setStatus(SysConstant.SUCCESS);
                messageData.setMessage("查询成功！");
                messageData.setObj(map);
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录！");
            }
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:消息设置页面  type=1 为接受评论通知开关,type=2 为接受点赞通知开关
     *             更新消息接收是否接收的状态
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="updateMessageReceiveStatus",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "消息设置页面,消息接收开关", notes = "产品和游记攻略", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "receivePraise", value = "接受、拒绝点赞(1、接受；0：拒绝)", required = true, dataType = "Integer", paramType = "query"),
    @ApiImplicitParam(name = "receiveComment", value = "接受、拒绝评论(1、接受；0：拒绝)", required = true, dataType = "Integer", paramType = "query")
    })
    //新注册的会员的点赞通知为默认的开启状态(1)
    public MessageData updateMessageReceiveStatus(HttpServletRequest request,HttpSession httpSession,Integer receivePraise,Integer receiveComment){
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(httpSession);
            if(null!=memberBasic) {
                Integer memberId = memberBasic.getId();
                messageData = memberBasicService.updateMessageReceiveStatus(memberId,receivePraise,receiveComment);
                MemberBasic member = memberBasicService.selectMemberInfo(memberId);
                request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                String cityName = member.getCityName();
                if(StringUtil.isNotEmpty(cityName)) {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,cityName);
                }else {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,"上海");
                }
            }else {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录！");
            }
            return messageData;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:批量删除会员游记被点赞记录、会员被评论记录
     * @param request
     * @param httpSession
     * @param ids
     * @return
     * @creator ：rmp  
     * @date ：2017年5月8日下午2:57:52
     */
    @CrossOrigin   
    @ResponseBody
    @RequestMapping(value="deleteMemberMessagesByBatch",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "批量删除会员游记被点赞记录、会员被评论记录、系统消息", notes = "批量删除会员游记被点赞记录、会员被评论记录、系统消息", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "ids", value = "点赞或评论的主键字符串集合，以逗号隔开", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "type", value = "type=1:点赞 type=2:评论type=3:系统消息", required = true, dataType = "Interger", paramType = "query"),
    })
    public MessageData deleteMemberMessagesByBatch(HttpServletRequest request,HttpSession httpSession,String ids,Integer type){
        List<String> delList = new ArrayList<String>();
        String[] strs = ids.split(",");
        for (String str : strs) {
            delList.add(str);
        }
        try {
            MessageData messageData = new MessageData(null,null);
            MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
            if(null!=memberBasic) {
                messageData = pushPraiseService.deleteMemberMessagesByBatch(ids,type);
            }else{
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("会员未登录!");
            }
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
}

