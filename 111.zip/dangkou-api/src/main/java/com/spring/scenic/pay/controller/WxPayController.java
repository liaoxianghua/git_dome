package com.spring.scenic.pay.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.github.sd4324530.fastweixin.api.OauthAPI;
import com.github.sd4324530.fastweixin.api.config.ApiConfig;
import com.github.sd4324530.fastweixin.api.enums.OauthScope;
import com.github.sd4324530.fastweixin.api.response.OauthGetTokenResponse;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.exception.BussinessExceptionBean;
import com.spring.scenic.common.util.IPUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.WxPropertiesUtil;
import com.spring.scenic.common.util.encrypt.EncryptPkUtil;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderPayRecordService;
import com.spring.scenic.order.application.OrderRefundService;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderPayRecord;
import com.spring.scenic.order.domain.OrderRefund;
import com.spring.scenic.pay.application.OrderPayLogService;
import com.spring.scenic.pay.application.PayService;
import com.spring.scenic.pay.controller.weixin.WXPay;
import com.spring.scenic.pay.controller.weixin.WXPayConfigImpl;
import com.spring.scenic.pay.controller.weixin.WeixinSetting;
import com.spring.scenic.pay.domain.OrderPayLog;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.sandpay.api.gateway.SandpayConstants;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderQueryRequest;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderQueryRequest.GatewayOrderQueryRequestBody;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderQueryResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderRefundResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderRefundResponse.GatewayOrderRefundResponseBody;
import com.spring.scenic.sandpay.api.gateway.response.GatwayNotifyResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatwayNotifyResponse.GatwayNotifyResponseBody;
import com.spring.scenic.sandpay.cashier.sdk.SandpayClient;
import com.spring.scenic.sandpay.cashier.sdk.SandpayRequestHead;
import com.spring.scenic.sandpay.cashier.sdk.SandpayResponseHead;
import com.spring.scenic.sandpay.cashier.sdk.util.PacketTool;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.utl.SmsUtils;

/**
 * 微信支付类
 * @author liaoxianghua
 * @date 2017年8月31日
 */
@Controller
@RequestMapping(value = "wxpay")
public class WxPayController {

	static Logger logger = LoggerFactory.getLogger(WxPayController.class);

	@Resource
	private PayService payService;

	@Resource
	private OrderService orderService;

	@Resource
	private OrderPayLogService orderPayLogService;

	@Resource
	private OrderPayRecordService orderPayRecordService;

	@Resource
	private ProductService productService;

	@Resource
	private WeixinSetting weixinSetting;

	@Resource
	private BusiSellerService busiSellerService;

	@Resource
	private OrderRefundService orderRefundService;

	/**
	 * 统一支付接口 微信获取code 支付宝直接下单
	 * @param req
	 * @param res
	 * @param session
	 * @param orderId 支付订单号
	 * @param payMoney 支付金额
	 * @param payType 支付方式
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午4:54:29
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "pay", method = { RequestMethod.GET })
	public void pay(HttpServletRequest req, HttpServletResponse res, HttpSession session, String orderId,
		BigDecimal payMoney, Integer payType) throws Exception {
		orderId = EncryptPkUtil.decodeId(orderId);
		if (orderId == null || payType == null || payMoney == null) {
			logger.info("支付条件不全orderId=" + orderId + ",payType=" + payType + ",payMoney=" + payMoney);
			throw new BussinessException(new BussinessExceptionBean("exception.syserror"));
		}
		MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
		if (member == null) {
			logger.info("==================会员未登录===================");
			return;
		}
		try {
			Order order = orderService.selectOrderDetail(Integer.valueOf(orderId));
			OrderPayRecord orderPayRecord = payService.saveOrderPayRecord(member, order, payMoney, payType);
			if (orderPayRecord == null) {
				String backUrl = weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=支付记录不存在";
				res.sendRedirect(backUrl);
				return;
			}
			// 支付宝
			if (SysEnum.PAY_METHOD_ALIPAY_WAP.getCode().equals(String.valueOf(payType))) {

				// 微信支付
			} else if (SysEnum.PAY_METHOD_WINXIN.getCode().equals(String.valueOf(payType))) {
				// 生成微信支付OauthURL，以便获取用户openid
				ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);
				OauthAPI oauthAPI = new OauthAPI(appConfig);
				String wxPayUrl =
						oauthAPI.getOauthPageUrl(weixinSetting.getDomain() + "/dangkou-api/pay/wxpay.htm?paySerialNo="
								+ orderPayRecord.getPaySerialNo(), OauthScope.SNSAPI_BASE, "1");
				res.sendRedirect(wxPayUrl);
			}
		} catch (Exception e) {
			logger.info("============支付异常============= ", e.getMessage());
		}
	}

	/**
	 * 微信预下单
	 * @param orderIds
	 * @param code
	 * @param req
	 * @param model
	 * @param resp
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午5:19:42
	 */
	@RequestMapping(value = "/wxpay", method = RequestMethod.GET)
	public String wxpay(String paySerialNo, String code, HttpServletRequest req, Model model, HttpServletResponse resp) {
		try {
			if (StringUtil.isEmpty(paySerialNo)) {
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=支付流水号不存在！");
				return null;
			}
			OrderPayRecord opr = new OrderPayRecord();
			opr.setPaySerialNo(paySerialNo);
			opr = orderPayRecordService.selectByParam(opr);
			if (BigDecimal.ZERO.compareTo(opr.getTotalPrice()) == 0) {
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=支付金额为0,无需支付！");
				return null;
			}
			// 根据Oauth接口返回code获取用户openid
			ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);

			OauthAPI oauthAPI = new OauthAPI(appConfig);
			if (code == null) {
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=无法获取code！");
				return null;
			}
			OauthGetTokenResponse oauth = oauthAPI.getToken(code);
			String openid = "";
			if (oauth != null && StringUtil.isNotEmpty(oauth.getOpenid())) {
				openid = oauth.getOpenid();
			}
			if (StringUtil.isEmpty(openid)) {
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=微信用户无法获取，请重新支付！");
				return null;
			}

			HashMap<String, String> data = new HashMap<String, String>();
			data.put("body", "订单付款");
			data.put("out_trade_no", opr.getPaySerialNo());
			data.put("total_fee", String.valueOf(opr.getTotalPrice().multiply(new BigDecimal(100))));
			data.put("spbill_create_ip", IPUtil.getIpAddr(req));
			data.put("notify_url", weixinSetting.getDomain() + "/dangkou-api/pay/payWxCallback.htm");
			data.put("trade_type", "JSAPI");
			data.put("openid", openid);
			WXPayConfigImpl config = WXPayConfigImpl.getInstance();
			WXPay wxPay = new WXPay(config);
			Map<String, String> map = wxPay.unifiedOrder(data);
			// 下单成功
			if ("SUCCESS".equals(map.get("return_code")) && "SUCCESS".equals(map.get("result_code"))) {
				SortedMap<Object, Object> signMap = new TreeMap<Object, Object>();
				signMap.put("domain", weixinSetting.getDomain());
				signMap.put("appId", map.get("appid"));
				signMap.put("timeStamp", map.get("timeStamp"));
				signMap.put("nonceStr", map.get("nonce_str"));
				signMap.put("sign", map.get("sign"));
				signMap.put("prepay_id", map.get("prepay_id"));
				signMap.put("signType", map.get("sign"));
				signMap.put("paySign", map.get("paySign"));
				signMap.put("paySerialNo", paySerialNo);
				signMap.put("domain", weixinSetting.getDomain());
				model.addAttribute("signMap", signMap);
			} else {
				logger.info("========{}======={}==========", map.get("return_code"), map.get("return_msg"));
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=预下单失败");
			}
			OrderPayLog entity = new OrderPayLog();
			entity.setNotifyData("微信预下单:" + map.get("return_msg"));
			entity.setNotifyMethod(3);
			entity.setNotifyTime(new Date());
			entity.setPaySerialNo(opr.getPaySerialNo());
			orderPayLogService.insert(entity);
			return "/pay/wxpay";
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("预下单失败", e.getMessage());
			try {
				resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=预下单失败");
			} catch (IOException e1) {
				e1.printStackTrace();
				logger.info("跳转失败", e1.getMessage());

			}
		}
		return null;
	}

	/**
	 * 微信支付成功页面跳转
	 * @param req
	 * @param resp
	 * @param paySerialNo
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月14日上午9:11:27
	 */
	@RequestMapping("/paySuccess")
	public void paySuccess(HttpServletRequest request, HttpServletResponse response, String paySerialNo) {
		try {
			payService.paySuccessDetail(paySerialNo);
			response.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=1");
		} catch (Exception e) {
			try {
				response.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			logger.error("支付成功页面异常", e.getMessage());
		}
	}

	/**
	 * 微信支付失败页面跳转
	 * @param req
	 * @param resp
	 * @param paySerialNo
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月14日上午9:11:49
	 */
	@RequestMapping("/payFailure")
	public void payFailure(HttpServletRequest req, HttpServletResponse resp, String paySerialNo) {
		try {
			OrderPayLog entity = new OrderPayLog();
			entity.setNotifyData("微信支付失败-页面点击");
			entity.setNotifyMethod(3);
			entity.setNotifyTime(new Date());
			entity.setPaySerialNo(paySerialNo);
			orderPayLogService.insert(entity);
			resp.sendRedirect(weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0");
		} catch (IOException e) {
			logger.error("支付失败页面异常", e.getMessage());
		}

	}

	/**
	 * 微信异步回调通知
	 * @param req
	 * @param res
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午4:51:41
	 */
	@ResponseBody
	@RequestMapping({ "/payWxCallback" })
	public String payWxCallback(HttpServletRequest req, HttpServletResponse res) {
		String out_trade_no = null;
		String trade_no = null;
		String tradeStatus = null;
		try {
			logger.info("========================微信回调开始========================== ");
			Map<String, String[]> requestParams = req.getParameterMap();
			{
				for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
					String name = iter.next();
					String[] values = requestParams.get(name);
					String valueStr = "";
					for (int i = 0; i < values.length; i++) {
						valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
					}
					logger.info("微信支付异步回调参数： name===========》{},varStr===========》{}", name, valueStr);
				}
				String[] data = requestParams.get("data");
				List<String> list = Arrays.asList(data);
				String dataStr = list.get(0);
				GatwayNotifyResponse srd = JSON.parseObject(dataStr, GatwayNotifyResponse.class);
				GatwayNotifyResponseBody snb = srd.getBody();
				out_trade_no = snb.getOrderCode();
				trade_no = snb.getTradeNo();
				tradeStatus = snb.getOrderStatus();

				String _totalFee = snb.getBuyerPayAmount();
				BigDecimal totalFee = new BigDecimal(_totalFee);
				BigDecimal format = new BigDecimal(100);
				totalFee = totalFee.divide(format);
				OrderPayRecord recode = new OrderPayRecord();
				recode.setPaySerialNo(out_trade_no);
				OrderPayRecord record = orderPayRecordService.selectByParam(recode);
				if (record == null) {
					logger.info("==========================={}记录记录不存在==============", snb.getOrderCode());
					return "";
				}
				if ("00".equals(record.getTradeStatus())) {

					return "respCode=000000";
				}
				if (SandpayConstants.SUCCESS_RESP_CODE.equals(srd.getHead().getRespCode())) {
					payService.wxCallback(record, dataStr, snb, out_trade_no, trade_no, tradeStatus, totalFee, record);
					return "respCode=000000";
				} else {
					OrderPayRecord orderPayRecordRefund = new OrderPayRecord();
					orderPayRecordRefund.setRemark(srd.getHead().getRespMsg());
					orderPayRecordRefund.setUpdateTime(new Date());
					orderPayRecordRefund.setValid(Integer.valueOf(SysEnum.ORDER_PAY_RECORD_VALID_3.getCode()));
					orderPayRecordService.insert(orderPayRecordRefund);
					return "fail";
				}
			}
		} catch (BussinessException be) {
			logger.info("========================BussinessException异常={}======", be.getExceptionMessage());
			// 添加日志
			saveOrderPayLog(out_trade_no, trade_no, tradeStatus, be);
			return "fail";
		} catch (Exception e) {
			logger.info("========================微信回调异常={}=========================", e.getMessage());
			// 添加日志
			saveOrderPayLog(out_trade_no, trade_no, tradeStatus, e);
			return "fail";
		}
	}

	private void saveOrderPayLog(String out_trade_no, String trade_no, String tradeStatus, Exception e) {
		OrderPayLog entity = new OrderPayLog();
		entity.setNotifyData("微信回调异常:" + e.getMessage());
		entity.setNotifyMethod(1);// 异步回调
		entity.setNotifyTime(new Date());
		entity.setPaySerialNo(out_trade_no);
		entity.setTradeNo(trade_no);
		entity.setTradeStatus(tradeStatus);
		orderPayLogService.insert(entity);
	}

	/**
	 * 退款异步通知
	 * @param req
	 * @param res
	 * @creator ：liaoxianghua
	 * @date ：2017年8月10日下午4:33:22
	 */
	@RequestMapping("/refundWxCallback")
	public String refundWxCallback(HttpServletRequest req, HttpServletResponse res) {
		try {
			Map<String, String[]> requestParams = req.getParameterMap();
			for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
				String name = iter.next();
				String[] values = requestParams.get(name);
				String valueStr = "";
				for (int i = 0; i < values.length; i++) {
					valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
				}
				logger.info("退款异步回调参数： name===========》{},varStr===========》{}", name, valueStr);
			}
			String[] data = requestParams.get("data");
			List<String> list = Arrays.asList(data);
			String dataStr = list.get(0);
			GatewayOrderRefundResponse srd = JSON.parseObject(dataStr, GatewayOrderRefundResponse.class);
			SandpayResponseHead respHead = srd.getHead();
			if (SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())) {
				GatewayOrderRefundResponseBody rrb = srd.getBody();
				payService.refuncCallbackSuccess(dataStr, rrb);
				return "respCode=000000";
			} else {
				OrderPayRecord orderPayRecordRefund = new OrderPayRecord();
				orderPayRecordRefund.setRemark(respHead.getRespMsg());
				orderPayRecordRefund.setUpdateTime(new Date());
				orderPayRecordService.insert(orderPayRecordRefund);
				return "fail";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("=============退款异步回调异常==========={}======================", e.getMessage());
			return "fail";
		}
	}

	/**
	 * 退款方法
	 * @param request
	 * @param response
	 * @param id 退款记录表ID
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月15日下午9:53:25
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping("/refund")
	public MessageData refund(HttpServletRequest request, HttpServletResponse response, String encode,
		BigDecimal refundPrice, String remark, String src, String sellerId) {
		OrderPayRecord orderPayRecord =
				orderPayRecordService.selectByPrimaryKey(Integer.valueOf(EncryptPkUtil.decodeId(encode)));
		if (orderPayRecord == null) {
			return new MessageData(500, "支付记录不存在");
		}
		Order order = orderService.selectOrderDetail(orderPayRecord.getOrderId());
		if (sellerId == null) {
			BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
			if (sellerUser == null) {
				return new MessageData(500, "用户未登录");
			}
		} else {
			if (!order.getSellerId().equals(Integer.valueOf(sellerId))) {
				return new MessageData(500, "非法用户");
			}
			try {
				BusiSellerUser sellerUser = busiSellerService.getBusiSellerUserBySellerId(Integer.valueOf(sellerId));
				if (sellerUser == null) {
					return new MessageData(500, "商户不存在");
				}
			} catch (Exception e) {
				return new MessageData(500, "获取商户出错");
			}
		}
		if (StringUtils.isBlank(encode)) {
			return new MessageData(500, "encode不能为空");
		}
		if (order == null) {
			return new MessageData(500, "订单不存在");
		}
		return payService.refundAndUpdate(orderPayRecord, weixinSetting.getDomain(), encode, refundPrice, remark);
	}

	/**
	 * 支付结果查询
	 * @param request
	 * @param response
	 * @param orderCode
	 * @creator ：liaoxianghua
	 * @date ：2017年8月8日下午4:00:54
	 */
	@ResponseBody
	@RequestMapping("/query")
	public Object query(HttpServletRequest request, HttpServletResponse response, String paySerialNo) {
		SandpayRequestHead head = new SandpayRequestHead();
		GatewayOrderQueryRequestBody body = new GatewayOrderQueryRequestBody();
		GatewayOrderQueryRequest req = new GatewayOrderQueryRequest();
		req.setHead(head);
		req.setBody(body);
		PacketTool.setDefaultRequestHead(head, SandpayConstants.GATEWAY_ORDERQUERY,
				SandpayConstants.WEIXINPAY_PRODUCTID, WxPropertiesUtil.getProperty("sandpay_mid"));
		body.setOrderCode(paySerialNo); // 商户订单号
		body.setExtend(""); // 扩展域
		OrderPayRecord recode = new OrderPayRecord();
		recode.setPaySerialNo(paySerialNo);
		// OrderPayRecord record = orderPayRecordService.selectByParam(recode);
		Object result = null;
		try {
			String url = SandpayConstants.ADDRESS_PREFIX_QUERY;
			GatewayOrderQueryResponse resp = SandpayClient.execute(req, url);
			SandpayResponseHead respHead = resp.getHead();
			if (SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())) {
				// GatewayOrderQueryResponseBody queryResponseBody =
				// resp.getBody();
				result = resp.getHead();
				// if (queryResponseBody != null) {
				// // 订单在我们这边没有成功 在杉德成功了
				// if
				// (!GatewayOrderQueryResponseBody.OrderStatus.SUCCESS.equals(recode.getTradeStatus())
				// &&
				// GatewayOrderQueryResponseBody.OrderStatus.SUCCESS.equals(queryResponseBody
				// .getOrderStatus())) {
				// record.setTradeStatus(queryResponseBody.getOrderStatus());
				// record.setTradeNo(queryResponseBody.getOriTradeNo());
				// record.setUpdateTime(new Date());
				// // record.setValid(SysEnum);
				// orderPayRecordService.updateByParam(record);
				// }
				// }
			} else {
				logger.error("txn fail respCode[{}],respMsg[{}].", respHead.getRespCode(), respHead.getRespMsg());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	@ResponseBody
	@RequestMapping("queryRefund")
	public Object queryRefund(Integer id) {
		OrderRefund orderRefund = new OrderRefund();
		// orderRefund.setOrderPayRecordId(id);
		orderRefund.setOrderId(id);
		return orderRefundService.find(orderRefund);
	}
	
	@RequestMapping("/sms")
	@ResponseBody
	public JSONObject send(String msg,int flag){
		try {
			SmsUtils.sendSms("15925686576", "你好");
			JSONObject aa = SmsUtils.sendSmsBatch("15925686576", msg,flag);
			System.out.println(aa.get("result").toString());
		 return aa;
		} catch (Exception e) {
		e.printStackTrace();
		}
		return null;
	}
}
