 
package com.spring.scenic.busiSeller.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.notice.application.NoticeService;
import com.spring.scenic.notice.domain.BusiNotice;

/**
 * 商户中心M网公告显示
 * 此处为类说明
 * @author Administrator
 * @date 2017年8月9日
 */
@Controller
@RequestMapping("busiSeller")
@Api(value = "商户中心M网接口", description = "商户中心M网公告显示")
public class BusiSellerNoticeController extends BaseController{
	
	@Autowired
    private NoticeService busiSellerNoticeService;
	
    private Logger logger = LoggerFactory.getLogger(BusiSellerNoticeController.class);
    
    /**
     * 商户中心M网终端查询所有公告信息
     * 此处为类方法说明
     * @param request
     * @param response
     * @return
     * @creator ：Administrator  
     * @date ：2017年8月9日下午3:22:17
     */
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "getNoticeListData", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "商户中心M网终端查询所有公告信息", notes = "公告信息")
    @ApiImplicitParams({
		@ApiImplicitParam(name = "pageNum", value = "第几页", dataType = "Integer", paramType = "query", required = true),
		@ApiImplicitParam(name = "pageSize", value = "每页大小", dataType = "Integer", paramType = "query", required = true)
	})
	public MessageData getNoticeListData(HttpServletRequest request,HttpServletResponse response, Integer pageNum, Integer pageSize) {
		try {
			MessageData messageData = new MessageData(null, null, null);
			 Map<String,Object> map = new HashMap<String,Object>();
			 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER); 
			if (null != sellerUser) {
				BusiNotice notice = new BusiNotice();
				notice.setPageNum(pageNum);
				notice.setPageSize(pageSize);
				List<BusiNotice> list = busiSellerNoticeService.getNoticeList(notice, true);
			    PageInfo<BusiNotice> page = new PageInfo<BusiNotice>(list, notice.getPageSize());
			    messageData.setStatus(SysConstant.SUCCESS);
	            messageData.setMessage(SysConstant.MESSAGE_SUCCESS);
				map.put("notices", page);
				messageData.setObj(map);
			} else {
				messageData.setStatus(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE);
				messageData.setMessage(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
			}
			return messageData;
		} catch (Exception e) {
			 logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
		}
	}
    
    /**
     * 商户中心M网终端查看公告信息详情
     * 此处为类方法说明
     * @param request
     * @param response
     * @return
     * @creator ：Administrator  
     * @date ：2017年8月9日下午3:22:17
     */
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "getNoticeDetailData", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "商户中心M网终端查看公告信息详情", notes = "公告信息详情")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "noticeId", value = "公告ID", required = true, dataType = "String", paramType = "query"),
    })
	public MessageData getNoticeDetailData(HttpServletRequest request,HttpServletResponse response, Integer noticeId) {
		try {
			MessageData messageData = new MessageData(null, null, null);
			 Map<String,Object> map = new HashMap<String,Object>();
			 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER); 
			if (null != sellerUser) {
				BusiNotice notice = new BusiNotice();
				notice.setId(noticeId);
		        BusiNotice exsitedNotice = busiSellerNoticeService.getNotice(notice);
		        if(null != exsitedNotice){
		        	exsitedNotice.setReadCount(exsitedNotice.getReadCount()+1);//阅读数量的增加
		        	busiSellerNoticeService.updateReadCountById(exsitedNotice);//通过id更新阅读数
		        }
		        messageData.setStatus(SysConstant.SUCCESS);
	            messageData.setMessage(SysConstant.MESSAGE_SUCCESS);
				map.put("exsitedNotice", exsitedNotice);
				messageData.setObj(map);
			} else {
				messageData.setStatus(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE);
				messageData.setMessage(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
			}
			return messageData;
		} catch (Exception e) {
			 logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
		}
	}
    
    /**
     * 商户中心M网终端下载公告附件
     * 此处为类方法说明
     * @param request
     * @param response
     * @param noticeId
     * @return
     * @creator ：Administrator  
     * @date ：2017年8月10日下午1:51:22
     */
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "noticeAttachDownload", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "商户中心M网终端下载公告附件", notes = "下载公告")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "noticeId", value = "公告ID", required = true, dataType = "String", paramType = "query"),
    })
	public MessageData noticeAttachDownload(HttpServletRequest request,HttpServletResponse response, Integer noticeId) {
		try {
			MessageData messageData = new MessageData(null, null, null);
			 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER); 
			if (null != sellerUser) {
				BusiNotice notice = new BusiNotice();
				notice.setId(noticeId);
		        BusiNotice exsitedNotice = busiSellerNoticeService.getNotice(notice);
		        if(null != exsitedNotice){
		        	exsitedNotice.setIsTop(notice.getIsTop());//是否置顶
		        	busiSellerNoticeService.noticeAttachDownload(response, exsitedNotice);
			        messageData.setStatus(SysConstant.SUCCESS);
		            messageData.setMessage(SysConstant.MESSAGE_SUCCESS);
		        }
			} else {
				messageData.setStatus(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE);
				messageData.setMessage(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
			}
			return messageData;
		} catch (Exception e) {
			 logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
		}
	}
    

}
