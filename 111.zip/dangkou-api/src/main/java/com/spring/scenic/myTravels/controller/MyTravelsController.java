 
package com.spring.scenic.myTravels.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;


/**
 *  我的游记
 */
@Controller
@RequestMapping("mytravels")
@Api(value = "MyTravelsController", description = "游记接口")
public class MyTravelsController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(MyTravelsController.class);
    
    
    @Resource
    private TravelNoteService travelnoteservice;
 
    
	@ResponseBody
	@RequestMapping(value = "listMytravel", method = RequestMethod.POST)
	@ApiOperation(value = "我的游记列表", notes = "我的游记列表")
	@CrossOrigin
	public MessageData listMytravel(HttpServletRequest request, 
		    @ApiParam(name="type",value="传递 0表示(草稿或不通过)   1 表示未审核 2 表示 已发表",required=true) @RequestParam Integer type,
		    @ApiParam(name = "pageSize", value = "每页长度",required=true) @RequestParam Integer pageSize,
		    @ApiParam(name = "pageNum", value = "页码",required=true) @RequestParam Integer pageNum,HttpSession session){
		MessageData data=new MessageData(SysConstant.SUCCESS, "成功");
		
		
	    try {
	    	MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
	    	if(memberBasic == null){
				return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
			}
	    	
	    	Map<String,Object> map=new HashMap<String,Object>();
	    	if(type==0 || type==1){
	    		TravelNotesVo travelnotesvo=new TravelNotesVo();
	    		travelnotesvo.setPageNum(pageNum == null ? 1 :pageNum);
	    		travelnotesvo.setPageSize(pageSize == null ? 10 :pageSize);
	    		travelnotesvo.setMememberId(memberBasic.getId());
	    		travelnotesvo.setType(type);
	    		List<TravelNotesVo> list=travelnoteservice.selectmytravelsList(travelnotesvo,true);
//	    		map.put("travelnotesvo",list);
	    		PageInfo<TravelNotesVo> page = new PageInfo<TravelNotesVo>(list, travelnotesvo.getPageSize());
	    		map.put("travelnotesvo", page);
	    	}else if(type==2){
	    		MaterialtravelsVo materialtravelsVo=new MaterialtravelsVo();
				materialtravelsVo.setCityName(null);
				materialtravelsVo.setStatus(1);
				materialtravelsVo.setPageNum(pageNum == null ? 1 :pageNum);
				materialtravelsVo.setPageSize(pageSize == null ? 10 :pageSize);
				materialtravelsVo.setSessionId(session.getId());
		    	materialtravelsVo.setUserId(null!=memberBasic ? memberBasic.getId() :null);
	    		List<MaterialtravelsVo> passMytravelsList=travelnoteservice.selectPassMytravelsList(materialtravelsVo,true);
	    		PageInfo<MaterialtravelsVo> page = new PageInfo<MaterialtravelsVo>(passMytravelsList, materialtravelsVo.getPageSize());
	    		map.put("passMytravelsList", page);
	    	}
	    	map.put("travelNotesCountVo", travelnoteservice.selectTravelNoteCount(memberBasic.getId()));
		   data.setObj(map);
	    } catch (Exception e) {
	    	data.setMessage("查询失败");
	    	data.setStatus(SysConstant.EXCEPTION);
	        logger.error(e.getMessage(), e);
        }
	    return data;
	}
	
		
	
	
	@ResponseBody
	@RequestMapping(value = "addMytravel", method = RequestMethod.POST)
	@ApiOperation(value = "添加游记", notes = "添加游记")
	@CrossOrigin
	public MessageData addMytravel(HttpServletRequest request, 
			@ApiParam(name="arryStr",value="前端传递的json串",required = true)  @RequestParam String arryStr){
		MessageData data=new MessageData(SysConstant.SUCCESS, "成功");
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
		}
		try {
			int flag=travelnoteservice.addMytravel(memberBasic.getId(),toDealTransferStr(arryStr));
			if(flag>0){
				return data;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		data.setStatus(SysConstant.EXCEPTION);
		data.setMessage("添加失败");
		return data;
	}
	
	@ResponseBody
	@RequestMapping(value = "updateMytravel", method = RequestMethod.POST)
	@ApiOperation(value = "修改游记", notes = "修改游记")
	@CrossOrigin
	public MessageData updateMytravel(HttpServletRequest request, 
			@ApiParam(name="arryStr",value="前端传递的json串",required = true)  @RequestParam String arryStr){
		MessageData data=new MessageData(SysConstant.SUCCESS, "修改成功");
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
		}
		try {
			int flag=travelnoteservice.updateMytravel(memberBasic.getId(),toDealTransferStr(arryStr));
			if(flag>0){
				return data;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		data.setStatus(SysConstant.EXCEPTION);
		data.setMessage("修改失败");
		return data;
	}
	
	
	@ResponseBody
	@RequestMapping(value = "deleteMytravel", method = RequestMethod.POST)
	@ApiOperation(value = "删除游记", notes = "删除游记")
	@CrossOrigin
	public MessageData deleteMytravel(HttpServletRequest request, 
			@ApiParam(name="id",value="游记最外层的ID", required = true) @RequestParam Integer id){
		MessageData data=new MessageData(SysConstant.SUCCESS, "删除成功");
		MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
		}
		try {
			
			int flag=travelnoteservice.deleteMytravel(id,memberBasic.getId());
			if(flag>0){
				return data;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		data.setStatus(SysConstant.EXCEPTION);
		data.setMessage("删除失败");
		return data;
	}
	
	@ResponseBody
	@RequestMapping(value = "selectKeyWords", method = RequestMethod.POST)
	@ApiOperation(value = "查询关键字", notes = "查询关键字")
	@CrossOrigin
	public MessageData selectKeyWords(HttpServletRequest request, 
		    @ApiParam(name="name",value="查询关键字",required=true) @RequestParam String name){
		MessageData data=new MessageData(SysConstant.SUCCESS, "成功");
	    try {
	    	Keyword  keyword=new Keyword();
	    	keyword.setName(name);
	    	keyword.setValid(1);
	    	List<Keyword> keywordList=travelnoteservice.selectKeyWordsToTraveNote(keyword);
	    	Map<String,Object> map=new HashMap<String,Object>();
	    	map.put("keywordList", keywordList);
		   data.setObj(map);
	    } catch (Exception e) {
	    	data.setMessage("查询失败");
	    	data.setStatus(SysConstant.EXCEPTION);
	        logger.error(e.getMessage(), e);
        }
	    return data;
	}
	public static  String toDealTransferStr(String inputStr){
		return inputStr.replace("&quot;", "\"").replace("&lt;", " ").replace("&gt;", " ")
			    .replace("&nbsp;", " ").replace("&iexcl;", " ").replace("%", " ").replace("&", " ").replace("+", " ");
	}
    
}
