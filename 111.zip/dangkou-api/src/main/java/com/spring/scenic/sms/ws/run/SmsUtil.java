package com.spring.scenic.sms.ws.run;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.sms.ws.BeanOfSendMessage;
import com.spring.scenic.sms.ws.IMessageService;
import com.spring.scenic.sms.ws.IMessageServiceService;
import com.spring.scenic.sms.ws.RetBeanOfSendMessage;
import com.spring.scenic.sms.ws.SendMessageType;
import com.spring.scenic.sms.ws.SendTargets;
import com.spring.scenic.sms.ws.SmsParamBean;

public class SmsUtil {

    private static Logger logger = LoggerFactory.getLogger(SmsUtil.class);
    
    private static final QName SERVICE_NAME = new QName("http://webservice.spring.com/", "IMessageServiceService");
    
    public static RetBeanOfSendMessage sendMsg(String phone,String msg){
        try {
            IMessageServiceService messageServiceService = new IMessageServiceService(new URL(PropertiesUtil.getProperty("com.spring.scenic.sms.wsdlLocation")), SERVICE_NAME);
            IMessageService messageService = messageServiceService.getIMessageServicePort();
            BeanOfSendMessage sendMessage = new BeanOfSendMessage();
            sendMessage.setBizFlag("41");
            sendMessage.setSysFlag("35");
            
            SendMessageType sendMessageType = new SendMessageType();
            sendMessageType.getMessageType().add("1");
            sendMessage.setMessageTypes(sendMessageType);
            
            SmsParamBean smsParamBean = new SmsParamBean();
            smsParamBean.setContent(msg);
            
            List<String> phones = new ArrayList<String>();
            phones.add(phone);
            SendTargets targets = new SendTargets();
            targets.getTarget().addAll(phones);
            smsParamBean.setTargets(targets);
            
            sendMessage.setSmsParamBean(smsParamBean);
            logger.info("SMS 短信发送:phone:"+phone+",msg:"+msg);
            RetBeanOfSendMessage retBeanOfSendMessage  = messageService.sendMessage(sendMessage);
            System.exit(0);
            return retBeanOfSendMessage;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException("SMS 短信发送:phone:"+phone+",msg:"+msg+"====>短信发送失败", e);
        }
    }
    
    public static RetBeanOfSendMessage sendMsg(List<String> phones,String msg){
        try {
            IMessageServiceService messageServiceService = new IMessageServiceService(new URL("http://192.168.210.51:9999/sms/springairline/service/messageService?wsdl"), SERVICE_NAME);
            IMessageService messageService = messageServiceService.getIMessageServicePort();
            BeanOfSendMessage sendMessage = new BeanOfSendMessage();
            sendMessage.setBizFlag("41");
            sendMessage.setSysFlag("35");
            
            SendMessageType sendMessageType = new SendMessageType();
            sendMessageType.getMessageType().add("1");
            sendMessage.setMessageTypes(sendMessageType);
            
            SmsParamBean smsParamBean = new SmsParamBean();
            smsParamBean.setContent(msg);
            
            SendTargets targets = new SendTargets();
            targets.getTarget().addAll(phones);
            smsParamBean.setTargets(targets);
            
            sendMessage.setSmsParamBean(smsParamBean);
            logger.info("SMS 短信发送:phones:"+phones+",msg:"+msg);
            RetBeanOfSendMessage retBeanOfSendMessage  = messageService.sendMessage(sendMessage);
            System.exit(0);
            return retBeanOfSendMessage;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BussinessException("SMS 短信发送:phones:"+phones+",msg:"+msg+" ====>短信发送失败", e);
        }
    }
    
    
    
    public static void main(String[] args) {
        
        try {
            SmsUtil.sendMsg("15802301145", "你好！");
            System.out.println(111);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        try {
//            IMessageServiceService messageServiceService = new IMessageServiceService(new URL("http://192.168.210.51:9999/sms/springairline/service/messageService?wsdl"), SERVICE_NAME);
//            IMessageService messageService = messageServiceService.getIMessageServicePort();
//            BeanOfSendMessage sendMessage = new BeanOfSendMessage();
//            sendMessage.setBizFlag("41");
//            sendMessage.setSysFlag("35");
//            
//            SendMessageType sendMessageType = new SendMessageType();
//            sendMessageType.getMessageType().add("1");
//            sendMessage.setMessageTypes(sendMessageType);
//            
//            SmsParamBean smsParamBean = new SmsParamBean();
//            smsParamBean.setContent("你好,这是舒畅测试短信！");
//            
//            List<String> phones = new ArrayList<String>();
//            phones.add("15802301145");
//            SendTargets targets = new SendTargets();
//            //targets.getTarget().addAll(phones);
//            targets.getTarget().add("15802301145");
//            smsParamBean.setTargets(targets);
//            
//            sendMessage.setSmsParamBean(smsParamBean);
//            RetBeanOfSendMessage retBeanOfSendMessage  = messageService.sendMessage(sendMessage);
//            System.out.println(retBeanOfSendMessage);
//            System.exit(0);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

}
