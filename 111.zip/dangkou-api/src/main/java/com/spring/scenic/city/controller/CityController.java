 
package com.spring.scenic.city.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.basic.application.CountryService;
import com.spring.scenic.basic.application.KeywordService;
import com.spring.scenic.basic.domain.Country;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.index.controller.IndexController;
import com.spring.scenic.product.domain.Keyword;
import com.spring.scenic.system.application.CityService;
import com.spring.scenic.system.domain.City;


/**
 * 城市接口
 */
@Controller
@RequestMapping("city")
@Api(value = "城市选择接口", description = "城市选择界面")
public class CityController extends BaseController{
	
    @Autowired
    private CityService cityService;
    
    @Autowired
    private KeywordService keywordService;
    
    @Autowired
    private CountryService countryService;
    
    private Logger logger = LoggerFactory.getLogger(IndexController.class);
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="init",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "城市定位数据初始化", notes = "城市定位数据初始化,包含热门城市", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData init(HttpServletRequest request,HttpSession httpSession){
        try {
            Map<String,Object> map = new HashMap<String,Object>();
            List<Keyword> hotCitys = keywordService.getHotCityKeyword();
            Map<String,List<City>> groupCitys = cityService.getGroupCitys();
            map.put("hotCity", hotCitys);
            map.put("groupCity", groupCitys);
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS, map);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="changeCity",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "切换城市", notes = "用户切换城市，首页城市随之刷新", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "cityName", value = "用户切换的城市", required = true, dataType = "String", paramType = "query")
    })
    public MessageData changeCity(HttpSession httpSession,String cityName){
        try {
            if(StringUtils.isNotBlank(cityName)){
                httpSession.setAttribute(BisConstant.SESSION_LOCATION_CITY, cityName);
            }
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:加载系统国家省份城市信息，组装json数据
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月10日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="initAddressData",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "国家省份城市信息初始化", notes = "国家省份城市信息初始化", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData initAddressData(HttpServletRequest request,HttpSession httpSession){
        try {
            List<Country> addressData = countryService.initAddressData();
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("addressData", addressData);
            return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS,dataMap);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    

}
