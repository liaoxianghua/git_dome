package com.spring.scenic.busiSeller.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.busi.application.BusiSellerOrderIndexService;
import com.spring.scenic.busi.application.BusiSellerOrderService;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.notice.application.NoticeService;
import com.spring.scenic.notice.domain.BusiNotice;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.vo.OrderWriteOffcodeVO;
import com.spring.scenic.order.domain.vo.TransactionMoney;
/**
 * 商户中心M网订单首页
 * 此处为类说明
 * @author xiangbin
 * @date 2017年7月27日
 */
@Controller
@RequestMapping("busiSeller")
@Api(value = "商户中心M网接口", description = "商户中心M网订单首页")
public class BusiSellerOrderIndexController extends BaseController{
	
	private static Logger logger = LoggerFactory.getLogger(BusiSellerOrderIndexController.class);

	@Autowired
    private BusiSellerOrderIndexService busiSellerOrderIndexService;
	
	@Resource
    private BusiSellerOrderService busiSellerOrderService;
	
	@Autowired
    private NoticeService noticeService;
	@Resource
	private OrderService orderService;
	
	/**
	 * 订单首页
	 * 此处为类方法说明
	 * @param session
	 * @param request
	 * @param sellerId
	 * @return
	 * @creator ：xiangbin  
	 * @date ：2017年7月24日下午4:23:55
	 */
	@CrossOrigin   
    @ResponseBody
    @RequestMapping(value="/busiSellerOrderIndex",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网订单首页", notes = "今日订单、今日取消、待确认订单、申请退单、今日成交金额、昨日成交金额、首页公告")
    @ApiImplicitParams({
    })
    public MessageData busiSellerOrderIndex(HttpSession session,HttpServletRequest request){
    	try {
    		BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
    		if(sellerUser==null){
                return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
            }
    		MessageData message = new MessageData(SysConstant.SUCCESS, "成功");
    	    Map<String, Object> map = new HashMap<String, Object>();
    	    Map<String,Integer> orderStatisic = busiSellerOrderService.getOrderStatistic(sellerUser);//今日订单、今日取消、待确认订单、申请退单
    	    TransactionMoney todayPayedPrice = busiSellerOrderIndexService.getTodayTransactionMoney(sellerUser.getSellerId());//今日成交金额
    	    TransactionMoney yesterdayPayedPrice = busiSellerOrderIndexService.getYesterdayTransactionMoney(sellerUser.getSellerId());//昨日成交金额
    		List<BusiNotice> top6Notices = noticeService.getTop6Notice();//滚动显示前6条公告
    	    map.put("orderStatisic", orderStatisic);
    	    map.put("todayPayedPrice", todayPayedPrice);
    	    map.put("yesterdayPayedPrice", yesterdayPayedPrice);
    	    map.put("sellerUser", sellerUser);
    	    map.put("top6Notices", top6Notices);
    	    message.setObj(map);
    	    message.setMessage("查询成功！");
    	    return message;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
    }
	@CrossOrigin   
	@ResponseBody
	@RequestMapping(value="/scanQCOrderWriteOffCode",method=RequestMethod.POST)
	@ApiOperation(httpMethod = "POST",value = "商户中心M网核销", notes = "扫码核销")
	@ApiImplicitParams({
		 @ApiImplicitParam(name = "writeOffCode", value = "扫描码", dataType = "String", paramType = "query", required = false),
		 @ApiImplicitParam(name = "scanMethod", value = "输入方式，手动还是扫码 0 表示扫码 1表示手动输入", dataType = "Integer", paramType = "scanMethod", required = false)
	})
	public MessageData scanQCOrderWriteOffCode(HttpSession session,HttpServletRequest request,String writeOffCode,Integer scanMethod){
		MessageData data = new MessageData(SysConstant.SUCCESS, "成功");
		StringBuffer sb=new StringBuffer();
		sb.append("writeOffCode:"+writeOffCode)
		  .append("scanMethod:"+scanMethod);
		logger.info("核销码传入数据:"+sb.toString());
		
		try {
			BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
			if(sellerUser==null){
				return new MessageData(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE, BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
			}
			if(StringUtils.isBlank(writeOffCode)){
				return new MessageData(BisConstant.INDEX_SCAN_ERROR_CODE, BisConstant.INDEX_SCAN_ERROR_MESSAGE);
			}
			OrderWriteOffcodeVO orderWriteOffcodeVO=new OrderWriteOffcodeVO();
			orderWriteOffcodeVO.setSellerId(sellerUser.getSellerId());
			orderWriteOffcodeVO.setWriteoffcode(writeOffCode.toLowerCase());
			OrderWriteOffcodeVO vo=orderService.selectWriteOffcodeVO(orderWriteOffcodeVO);
			if(vo==null){
				return new MessageData(BisConstant.INDEX_SCAN_ERROR_CODE, BisConstant.INDEX_SCAN_ERROR_MESSAGE);
			}
			Order order=new Order();
			order.setId(vo.getId());
			Order oldOrder=orderService.selectOrderWriteOffCode(order);
			 if(oldOrder.getSaledCheck()==1){
				 data.setStatus(201);
				 data.setMessage("核销码已使用");
				 return data; 
			 }

			 if(oldOrder.getPayStatus()!=3 && oldOrder.getPayStatus()!=4){
				 data.setStatus(201);
				 data.setMessage("订单未全款，无法核销");
				 return data; 
			 }
			 if(oldOrder.getOrderStatus()==5){
				 data.setStatus(201);
				 data.setMessage("该订单已退单，无法核销");
				 return data; 
			 }
			
			order.setOrderStatus(6);//把订单状态修改为已完成状态
			order.setSellerId(sellerUser.getId());
			order.setWriteoffcode(writeOffCode.toLowerCase());
			order.setSaledCheck(1);//表示已核销
			orderService.updateOrderStatusAndSaledCheck(order,scanMethod);
			//修改订单状态
			data.setMessage("核销成功");
			return data;   	    
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(BisConstant.INDEX_SCAN_ERROR_CODE, BisConstant.INDEX_SCAN_ERROR_MESSAGE);
		}
	}
 
}
