 
package com.spring.scenic.myBrowserHistory.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.vo.MyConllectionOfProduct;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;


/**
 *  我的浏览历史
 */
@Controller
@RequestMapping("MyBrowserHistory")
@Api(value = "MyBrowserHistoryController", description = " 我的浏览历史接口")
public class MyBrowserHistoryController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(MyBrowserHistoryController.class);
    
	@Resource
	private MemberCollectionService membercollectionService;
    
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "listMyBrowserHistory", method = RequestMethod.POST)
	@ApiOperation(value = "我的浏览历史列表", notes = " 我的浏览历史列表")
	public MessageData listMyBrowserHistory(HttpServletRequest request, 
		    @ApiParam(name="type",value="传递   1 表示产品 2 表示游记和攻略",required=true) @RequestParam Integer type,
		    @ApiParam(name = "strID", value = "strID串",required=true) @RequestParam String strID,
		    HttpSession session){
		try {
    		    MessageData data=new MessageData(SysConstant.SUCCESS, "成功");
    		    Map<String,Object> map=new HashMap<String,Object>();
    		    if(StringUtils.isNotBlank(strID)){
    		    	String [] list=strID.split(",");
    		    	List<Integer> ids=new ArrayList<Integer>();
    		    	for (String strId : list) {
    		    		ids.add(Integer.parseInt(strId));
					}
    		    	MemberBasic memberBasicOnline = MemberAuthentiction.getOnlineMemeber(session);
    		    	Map<String,Object> paramMap = new HashMap<String,Object>();
    		    	paramMap.put("userId", memberBasicOnline==null?null:memberBasicOnline.getId());
    		    	paramMap.put("sessionId", session.getId());
    		    	paramMap.put("ids", ids);
    		    	if(type==1){
    		    		List<MyConllectionOfProduct> myPushPraiseOfProduct  = membercollectionService.selectMyBrowserProduct(ids);//我的浏览产品历史
    		    		map.put("myPushPraiseOfProduct", myPushPraiseOfProduct);
    		    	}else if(type==2){
    		    		List<TravelNotesVo> travelNoteViewHistory  = membercollectionService.getTravelNoteViewHistory(paramMap);//我的收藏游记攻略列表
    		    	    map.put("myConllectionOfTravel", travelNoteViewHistory);
    		    	}
    		    	data.setObj(map);
    		    }
    		return data;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
		}
	}
}
