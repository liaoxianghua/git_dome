package com.spring.scenic.pay.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.sd4324530.fastweixin.api.OauthAPI;
import com.github.sd4324530.fastweixin.api.config.ApiConfig;
import com.github.sd4324530.fastweixin.api.enums.OauthScope;
import com.github.sd4324530.fastweixin.api.response.OauthGetTokenResponse;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.exception.BussinessException;
import com.spring.scenic.common.util.IPUtil;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.common.util.WxPropertiesUtil;
import com.spring.scenic.common.util.encrypt.EncryptPkUtil;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderPayRecordService;
import com.spring.scenic.order.application.OrderRefundService;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.order.domain.Order;
import com.spring.scenic.order.domain.OrderPayRecord;
import com.spring.scenic.order.domain.OrderRefund;
import com.spring.scenic.pay.application.OrderPayLogService;
import com.spring.scenic.pay.application.PayService;
import com.spring.scenic.pay.controller.weixin.WeixinSetting;
import com.spring.scenic.pay.domain.OrderPayLog;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.sandpay.api.gateway.SandSonstantEnum;
import com.spring.scenic.sandpay.api.gateway.SandpayConstants;
import com.spring.scenic.sandpay.api.gateway.request.GatewayClearFileDownloadRequest;
import com.spring.scenic.sandpay.api.gateway.request.GatewayClearFileDownloadRequest.GatewayClearFileDownloadRequestBody;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderPayRequest;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderPayRequest.GatewayOrderPayRequestBody;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderQueryRequest;
import com.spring.scenic.sandpay.api.gateway.request.GatewayOrderQueryRequest.GatewayOrderQueryRequestBody;
import com.spring.scenic.sandpay.api.gateway.response.GatewayClearFileDownloadResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderPayResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderPayResponse.GatewayOrderPayResponseBody;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderQueryResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderRefundResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatewayOrderRefundResponse.GatewayOrderRefundResponseBody;
import com.spring.scenic.sandpay.api.gateway.response.GatwayNotifyResponse;
import com.spring.scenic.sandpay.api.gateway.response.GatwayNotifyResponse.GatwayNotifyResponseBody;
import com.spring.scenic.sandpay.cashier.sdk.SandpayClient;
import com.spring.scenic.sandpay.cashier.sdk.SandpayRequestHead;
import com.spring.scenic.sandpay.cashier.sdk.SandpayResponseHead;
import com.spring.scenic.sandpay.cashier.sdk.util.DateUtil;
import com.spring.scenic.sandpay.cashier.sdk.util.PacketTool;
import com.spring.scenic.security.MemberAuthentiction;

@Controller
@RequestMapping(value = "pay")
@Api(value = "payController", description = "支付接口")
public class PayController {

	static Logger logger = LoggerFactory.getLogger(PayController.class);

	@Resource
	private PayService payService;

	@Resource
	private OrderService orderService;

	@Resource
	private OrderPayLogService orderPayLogService;

	@Resource
	private OrderPayRecordService orderPayRecordService;

	@Resource
	private ProductService productService;

	@Resource
	private WeixinSetting weixinSetting;

	@Resource
	private BusiSellerService busiSellerService;

	@Resource
	private OrderRefundService orderRefundService;
	
	 
	/**
	 * 只跳转支付成功 不产生支付结果
	 * @param session
	 * @param encode
	 * @param payMoney
	 * @param payType
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午4:56:28
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "simplepay", method = { RequestMethod.POST })
	@ApiOperation(httpMethod = "POST", value = "简单支付接口", notes = "已确认且未支付、或部分支付才可支付", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "encode", value = "订单ID", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "payMoney", value = "支付金额", dataType = "BigDecimal", paramType = "query", required = false),
			@ApiImplicitParam(name = "payType", value = "支付类别（1、微信；2：支付宝；3：银联；4、其他）", dataType = "Integer", paramType = "query", required = true) })
	public MessageData simplepay(HttpSession session, String encode, BigDecimal payMoney, Integer payType) {
		if (encode != null && payMoney != null && payType != null) {
			try {
				MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
				if (member == null) {
					return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE,
							BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE);
				} else {
					// 解密订单id
					Integer orderId = Integer.valueOf(EncryptPkUtil.decodeId(encode));
					Order order = orderService.selectOrderDetail(orderId);
					if (order.getOrderStatus() != Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())) {
						return new MessageData(SysConstant.FAILURE, "您订购的产品需与商家进一步确认，我们会尽快告知您结果，您也可以到我的->订单中查询");
					}
					if (order.getOrderStatus() == Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())
							&& (order.getPayStatus() == Integer.parseInt(SysEnum.ORDER_PAY_STATUS_NO.getCode()) || order
									.getPayStatus() == Integer.parseInt(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()))) {
						payService.saveOrderSimplePay(member, order, payMoney, payType);
						return new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
					}
					return new MessageData(SysConstant.FAILURE, "订单已支付，请不要重复支付！");
				}
			} catch (Exception e) {
				e.printStackTrace();
				return new MessageData(SysConstant.EXCEPTION, SysConstant.MESSAGE_FAILURE);
			}
		} else {
			return new MessageData(SysConstant.FAILURE, "支付条件不完整");
		}
	}
	
	@RequestMapping("/pay")
	public String test(HttpServletRequest req, HttpServletResponse resp, Model model) {

//		SortedMap<Object, Object> signMap = new TreeMap<Object, Object>();
//		signMap.put("appId", "wx5d4aa509b7a68610");
//		signMap.put("timeStamp", "1502154260");
//		signMap.put("nonceStr", "8a1286dc0af140ee99a0137f4e48ef6d");
//		signMap.put("prepay_id", "prepay_id=wx20170808090420c2a8fa71b70125982972");
//		signMap.put("signType", "MD5");
//		signMap.put("paySign", "002AE1FAA0FE4F4C14FD1652D5972A35");
//		signMap.put("contextPath", "http://cqczy.cn");
//		model.addAttribute("signMap", signMap);
		return "pay/wxpay";
	}

	/**
	 * 统一支付接口 微信获取code 支付宝直接下单
	 * @param req
	 * @param res
	 * @param session
	 * @param orderId 支付订单号
	 * @param payMoney 支付金额
	 * @param payType 支付方式
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午4:54:29
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value = "payback", method = { RequestMethod.GET })
	public void pay(HttpServletRequest req, HttpServletResponse res, HttpSession session, String orderId,
		BigDecimal payMoney, Integer payType) throws Exception {
		orderId = EncryptPkUtil.decodeId(orderId);
		if (orderId == null || payType == null || payMoney == null) {
			logger.warn("================支付条件不全orderId=" + orderId + ",payType=" + payType + ",payMoney=" + payMoney);
			throw new Exception("支付条件不全");
		}
		
//		String _ordId = orderId;
 		MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
		if (member == null) {
			logger.warn("==================会员未登录===================");
			return;
		}
		try {
//			String sHtmlText = "";
			Order order = orderService.selectOrderDetail(Integer.valueOf(orderId));
//			ProductWithBLOBs product = productService.selectByPrimaryKey(order.getProductId());
			OrderPayRecord orderPayRecord = payService.saveOrderPayRecord(member, order, payMoney, payType);
			if(orderPayRecord == null ){
				String backUrl = weixinSetting.getDomain() + "/#/paymentResult?isSuccess=0&message=支付记录不存在";
				res.sendRedirect(backUrl);
				return ;
			}
			if (SysEnum.PAY_METHOD_ALIPAY_WAP.getCode().equals(String.valueOf(payType))) {
//				logger.debug("==PAY==ALIPAY============================BEBIN============================");
//				AliPay aliPay = new AliPay();
//				aliPay.setSubject("MOID[" + orderId + "]");
//				aliPay.setOutTradeNo(orderId);
//				aliPay.setTotalFee(String.valueOf(payMoney));
//				PayUtils.buildAlipay(req, aliPay);
//				String ALIPAY_GATEWAY_NEW = "http://wappaygw.alipay.com/service/rest.htm?";
//				// 请求业务参数详细
//				StringBuilder requestDataBuilder = new StringBuilder();
//				requestDataBuilder.append("<direct_trade_create_req>");
//				requestDataBuilder.append("<notify_url>" + aliPay.getNotifyUrl() + "</notify_url>");
//				requestDataBuilder.append("<call_back_url>" + aliPay.getReturnUrl() + "</call_back_url>");
//				requestDataBuilder.append("<seller_account_name>" + aliPay.getSellerEmail() + "</seller_account_name>");
//				requestDataBuilder.append("<out_trade_no>" + aliPay.getOutTradeNo() + "</out_trade_no>");
//				requestDataBuilder.append("<subject>" + aliPay.getSubject() + "</subject>");
//				requestDataBuilder.append("<total_fee>" + aliPay.getTotalFee() + "</total_fee>");
//				requestDataBuilder.append("</direct_trade_create_req>");
//
//				Map<String, String> sParaTempToken = new HashMap<String, String>();
//				sParaTempToken.put("service", "alipay.wap.trade.create.direct");
//				sParaTempToken.put("partner", AlipayConfigBak.partner);
//				sParaTempToken.put("_input_charset", AlipayConfigBak.input_charset);
//				sParaTempToken.put("sec_id", AlipayConfigBak.sign_type);
//				sParaTempToken.put("format", "xml");
//				sParaTempToken.put("v", "1.0");
//				sParaTempToken.put("req_id", orderId);
//				sParaTempToken.put("req_data", requestDataBuilder.toString());
//
//				// 建立请求
//				String sHtmlTextToken = AlipaySubmit.buildRequest(ALIPAY_GATEWAY_NEW, "", "", sParaTempToken);
//				// URLDECODE返回的信息
//				sHtmlTextToken = URLDecoder.decode(sHtmlTextToken, AlipayConfigBak.input_charset);
//				// 获取token
//				String request_token = AlipaySubmit.getRequestToken(sHtmlTextToken);
//
//				// //////////////////////////////////根据授权码token调用交易接口alipay.wap.auth.authAndExecute//////////////////////////////////////
//				// 业务详细
//				String req_data =
//						"<auth_and_execute_req><request_token>" + request_token
//								+ "</request_token></auth_and_execute_req>";
//
//				// 把请求参数打包成数组
//				Map<String, String> sParaTemp = new HashMap<String, String>();
//				sParaTemp.put("service", "alipay.wap.auth.authAndExecute");
//				sParaTemp.put("partner", AlipayConfigBak.partner);
//				sParaTemp.put("_input_charset", AlipayConfigBak.input_charset);
//				sParaTemp.put("sec_id", AlipayConfigBak.sign_type);
//				sParaTemp.put("format", "xml");
//				sParaTemp.put("v", "1.0");
//				sParaTemp.put("req_data", req_data);
//
//				// 建立请求
//				sHtmlText = AlipaySubmit.buildRequest(ALIPAY_GATEWAY_NEW, sParaTemp, "get", "确认");
//				res.setContentType("text/html;charset=" + AlipayConfigBak.input_charset);
//				res.getWriter().write(sHtmlText);// 直接将完整的表单html输出到页面
//				res.getWriter().flush();
//				res.getWriter().close();
//				logger.debug("==PAY==TRADEID=" + aliPay.getOutTradeNo() + "==ORDERID=" + orderId);
//				logger.debug("==PAY==ALIPAY============================END======================");
			} else if (SysEnum.PAY_METHOD_WINXIN.getCode().equals(String.valueOf(payType))) {
				// 生成微信支付OauthURL，以便获取用户openid
				ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);
				OauthAPI oauthAPI = new OauthAPI(appConfig);
				String wxPayUrl =
						oauthAPI.getOauthPageUrl(PropertiesUtil.getProperty("wxpay_url")+"?paySerialNo=" + orderPayRecord.getPaySerialNo(), OauthScope.SNSAPI_BASE,
								"1");
				res.sendRedirect(wxPayUrl);
			}
		} catch (Exception e) {
			logger.info("============支付异常============= ", e.getMessage());
		}
	}

	/**
	 * 微信预下单
	 * @param orderIds
	 * @param code
	 * @param req
	 * @param model
	 * @param resp
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午5:19:42
	 */
	@RequestMapping(value = "/wxpay", method = RequestMethod.GET)
	public String wxpay(String paySerialNo, String code, HttpServletRequest req, Model model, HttpServletResponse resp) {
		try {
			SortedMap<Object, Object> signMap = new TreeMap<Object, Object>();
			signMap.put("domain", weixinSetting.getDomain());
			signMap.put("pathName", weixinSetting.getPathName());
			if (StringUtil.isEmpty(paySerialNo)) {
				resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0&message=支付流水号不存在！");
				return null;
			}
			OrderPayRecord opr = new OrderPayRecord();
			opr.setPaySerialNo(paySerialNo);
			opr = orderPayRecordService.selectByParam(opr);
			if (BigDecimal.ZERO.compareTo(opr.getTotalPrice()) == 0) {
				resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0&message=支付金额为0,无需支付！");
				return null;
			}
			// 根据Oauth接口返回code获取用户openid
			ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);
			
			OauthAPI oauthAPI = new OauthAPI(appConfig);
			if(code == null){
				resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0&message=无法获取code！");
				return null;
			}
			OauthGetTokenResponse oauth = oauthAPI.getToken(code);
			String openid = "";
			if (oauth != null && StringUtil.isNotEmpty(oauth.getOpenid())) {
				openid = oauth.getOpenid();
			}
			if (StringUtil.isEmpty(openid)) {
				resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0&message=微信用户无法获取，请重新支付！");
				return null;
			}
			logger.warn("=======微信预下单开始====支付code={}==========",paySerialNo);
			// // 杉德金额以分为单位 12位长度 不足用0补齐
			DecimalFormat df = new DecimalFormat("000000000000");
			// // 我们是以元为单位 保留两位小数
			BigDecimal format = new BigDecimal(100);
			// 组后台报文
			JSONObject payExtra = new JSONObject();
			payExtra.put("subAppid", weixinSetting.getAppid());
			payExtra.put("userId", openid);
			SandpayRequestHead head = new SandpayRequestHead();
			GatewayOrderPayRequestBody body = new GatewayOrderPayRequestBody();
			GatewayOrderPayRequest gwOrderPayReq = new GatewayOrderPayRequest();
			gwOrderPayReq.setHead(head);
			gwOrderPayReq.setBody(body);
			PacketTool.setDefaultRequestHead(head, SandpayConstants.GATEWAY_ORDERPAY, SandpayConstants.WEIXINPAY_PRODUCTID,
					WxPropertiesUtil.getProperty("sandpay_mid"));
			body.setOrderCode(opr.getPaySerialNo());
			body.setTotalAmount(df.format(format.multiply(opr.getTotalPrice())));
			body.setSubject("荡口古镇网上商城商品MOID[" + opr.getPaySerialNo() + "]");
			body.setBody("订单付款");
			body.setTxnTimeOut(DateUtil.getAfter7Days());
			body.setPayMode(SandSonstantEnum.SAND_WX.getPayMode());
			body.setPayExtra(payExtra.toString());
			body.setClientIp(IPUtil.getIpAddr(req));
			body.setNotifyUrl(PropertiesUtil.getProperty("payWxCallback_url"));
			body.setFrontUrl("");
			body.setStoreId("");
			body.setTerminalId("");
			body.setOperatorId("");
			body.setBizExtendParams("");
			body.setMerchExtendParams("");
			body.setExtend("");
			GatewayOrderPayResponse gatewayOrderPayResponse =
					SandpayClient.execute(gwOrderPayReq, SandpayConstants.ADDRESS_PREFIX_PAY);
			SandpayResponseHead respHead = gatewayOrderPayResponse.getHead();

			// 下单成功
			if (SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())) {
				logger.warn("=======微信预下单成功 杉德返回{}====支付code={}==========",respHead.getRespCode(),paySerialNo);
				GatewayOrderPayResponseBody respBody = gatewayOrderPayResponse.getBody();
				String credential = respBody.getCredential();
				JSONObject json = JSONObject.parseObject(credential);
				String result = json.getString("params");
				JSONObject resultJsonObject = JSONObject.parseObject(result);
				signMap.put("appId", resultJsonObject.getString("appId"));
				signMap.put("timeStamp", resultJsonObject.getString("timeStamp"));
				signMap.put("nonceStr", resultJsonObject.getString("nonceStr"));
				signMap.put("prepay_id", resultJsonObject.getString("package"));
				signMap.put("signType", resultJsonObject.getString("signType"));
				signMap.put("paySign", resultJsonObject.getString("paySign"));
				signMap.put("paySerialNo", paySerialNo);
				model.addAttribute("signMap", signMap);
			} else {
				logger.info("========杉德返回错误码:{}=======原因:{}==========", respHead.getRespCode(), respHead.getRespMsg());
			}

			OrderPayLog entity = new OrderPayLog();
			entity.setNotifyData("微信预下单:"+respHead.getRespCode()+respHead.getRespMsg());
			entity.setNotifyMethod(3);
			entity.setNotifyTime(new Date());
			entity.setPaySerialNo(opr.getPaySerialNo());
			orderPayLogService.insert(entity);
			return "pay/wxpay";
		} catch (Exception e) {
			e.printStackTrace();
			logger.warn("=======微信预下单失败====异常信息：{}==========",e.getMessage());
			try {
				resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0&message=预下单失败");
			} catch (IOException e1) {
				e1.printStackTrace();
				logger.warn("=======跳转失败，异常信息：{}==========",e1.getMessage());
			}
		}
		return null;
	}

	/**
	 * 微信支付成功页面跳转
	 * @param req
	 * @param resp
	 * @param paySerialNo
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月14日上午9:11:27
	 */
	@RequestMapping("/paySuccess")
	public void paySuccess(HttpServletRequest request, HttpServletResponse response,String paySerialNo){
		try {
		payService.paySuccessDetail(paySerialNo);
		response.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=1");
		}catch (Exception e) {
			try {
				response.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			logger.warn("支付成功页面异常", e.getMessage());
		}
	}

	/**
	 * 微信支付失败页面跳转
	 * @param req
	 * @param resp
	 * @param paySerialNo
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月14日上午9:11:49
	 */
	@RequestMapping("/payFailure")
	public void payFailure(HttpServletRequest req, HttpServletResponse resp,String paySerialNo){
		OrderPayLog entity = new OrderPayLog();
		entity.setNotifyData("微信支付失败-页面点击");
		entity.setNotifyMethod(3);
		entity.setNotifyTime(new Date());
		entity.setPaySerialNo(paySerialNo);
		orderPayLogService.insert(entity);
		try {
			resp.sendRedirect(weixinSetting.getDomain()+"/#/paymentResult?isSuccess=0");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * 支付宝网页支付
	 * @param req
	 * @param res
	 * @param session
	 * @param orderId
	 * @param payMoney
	 * @param payType
	 * @return
	 * @throws Exception
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午5:26:18
	 */
	@CrossOrigin
	@RequestMapping("alipay")
	public String alipay(HttpServletRequest req, HttpServletResponse res, HttpSession session, String orderId,
		BigDecimal payMoney, Integer payType) throws Exception {
//		orderId = EncryptPkUtil.decodeId(orderId);
//		String domain = AlipayPropertiesUtil.getProperty("alipay.houtrap_m_notify_url");
//		if (orderId != null && payMoney != null && payType != null) {
//			try {
//				MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
//				if (member == null) {
//					logger.info("==================会员未登录===================");
//					res.sendRedirect(domain + "isSuccess=0&message=会员未登录");
//				} else {
//					Order order = orderService.selectOrderDetail(Integer.valueOf(orderId));
//					if (order.getOrderStatus() != Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())) {
//						// return new MessageData(SysConstant.FAILURE,
//						// "您订购的产品需与商家进一步确认，我们会尽快告知您结果，您也可以到我的->订单中查询");
//					}
//					ProductWithBLOBs product = productService.selectByPrimaryKey(order.getProductId());
//					// String timeoutExpress = "1c";
//					if (product != null) {
//						// timeoutExpress = product.getConfirmHour() + "h";
//					}
//					if (order.getOrderStatus() == Integer.parseInt(SysEnum.ORDER_STATUS_CONFIRMED.getCode())
//							&& (order.getPayStatus() == Integer.parseInt(SysEnum.ORDER_PAY_STATUS_NO.getCode()) || order
//									.getPayStatus() == Integer.parseInt(SysEnum.ORDER_PAY_STATUS_PAID_PART.getCode()))) {
//						OrderPayRecord orderPayRecord = payService.saveOrderPayRecord(member, order, payMoney, payType);
//						if (orderPayRecord == null || StringUtil.isEmpty(orderPayRecord.getPaySerialNo())) {
//							res.sendRedirect(domain + "isSuccess=0&message=支付记录不存在");
//						}
//						try {
//							if (SysEnum.PAY_METHOD_ALIPAY_WAP.getCode().equals(String.valueOf(payType))) {
//								logger.debug("==PAY==ALIPAY============================BEBIN============================");
//								AliPay aliPay = new AliPay();
//								aliPay.setSubject("MOID[" + orderId + "]");
//								aliPay.setOutTradeNo(orderId);
//								aliPay.setTotalFee(String.valueOf(payMoney));
//								PayUtils.buildAlipay(req, aliPay);
//								String ALIPAY_GATEWAY_NEW = "http://wappaygw.alipay.com/service/rest.htm?";
//								// 请求业务参数详细
//								StringBuilder requestDataBuilder = new StringBuilder();
//								requestDataBuilder.append("<direct_trade_create_req>");
//								requestDataBuilder.append("<notify_url>" + aliPay.getNotifyUrl() + "</notify_url>");
//								requestDataBuilder.append("<call_back_url>" + aliPay.getReturnUrl()
//										+ "</call_back_url>");
//								requestDataBuilder.append("<seller_account_name>" + aliPay.getSellerEmail()
//										+ "</seller_account_name>");
//								requestDataBuilder
//										.append("<out_trade_no>" + aliPay.getOutTradeNo() + "</out_trade_no>");
//								requestDataBuilder.append("<subject>" + aliPay.getSubject() + "</subject>");
//								requestDataBuilder.append("<total_fee>" + aliPay.getTotalFee() + "</total_fee>");
//								requestDataBuilder.append("</direct_trade_create_req>");
//
//								Map<String, String> sParaTempToken = new HashMap<String, String>();
//								sParaTempToken.put("service", "alipay.wap.trade.create.direct");
//								sParaTempToken.put("partner", AlipayConfigBak.partner);
//								sParaTempToken.put("_input_charset", AlipayConfigBak.input_charset);
//								sParaTempToken.put("sec_id", AlipayConfigBak.sign_type);
//								sParaTempToken.put("format", "xml");
//								sParaTempToken.put("v", "1.0");
//								sParaTempToken.put("req_id", orderId);
//								sParaTempToken.put("req_data", requestDataBuilder.toString());
//
//								// 建立请求
//								String sHtmlTextToken =
//										AlipaySubmit.buildRequest(ALIPAY_GATEWAY_NEW, "", "", sParaTempToken);
//								// URLDECODE返回的信息
//								sHtmlTextToken = URLDecoder.decode(sHtmlTextToken, AlipayConfigBak.input_charset);
//								// 获取token
//								String request_token = AlipaySubmit.getRequestToken(sHtmlTextToken);
//
//								// //////////////////////////////////根据授权码token调用交易接口alipay.wap.auth.authAndExecute//////////////////////////////////////
//								// 业务详细
//								String req_data =
//										"<auth_and_execute_req><request_token>" + request_token
//												+ "</request_token></auth_and_execute_req>";
//
//								// 把请求参数打包成数组
//								Map<String, String> sParaTemp = new HashMap<String, String>();
//								sParaTemp.put("service", "alipay.wap.auth.authAndExecute");
//								sParaTemp.put("partner", AlipayConfigBak.partner);
//								sParaTemp.put("_input_charset", AlipayConfigBak.input_charset);
//								sParaTemp.put("sec_id", AlipayConfigBak.sign_type);
//								sParaTemp.put("format", "xml");
//								sParaTemp.put("v", "1.0");
//								sParaTemp.put("req_data", req_data);
//
//								// 建立请求
//								String sHtmlText =
//										AlipaySubmit.buildRequest(ALIPAY_GATEWAY_NEW, sParaTemp, "get", "确认");
//								res.setContentType("text/html;charset=" + AlipayConfigBak.input_charset);
//								res.getWriter().write(sHtmlText);// 直接将完整的表单html输出到页面
//								res.getWriter().flush();
//								res.getWriter().close();
//								logger.debug("==PAY==TRADEID=" + aliPay.getOutTradeNo() + "==ORDERID=" + orderId);
//								logger.debug("==PAY==ALIPAY============================END======================");
//							}
//
//						} catch (Exception e) {
//							logger.info("============支付异常============= ", e.getMessage());
//							res.sendRedirect(domain + "isSuccess=0&message=支付异常！");
//						}
//					}
//					res.sendRedirect(domain + "isSuccess=0&message=订单已支付，请不要重复支付！");
//				}
//			} catch (Exception e) {
//				logger.info("============支付宝支付验证异常============= ", e.getMessage());
//				res.sendRedirect(domain + "isSuccess=0&message=验证失败");
//			}
//		} else {
//			logger.info("========================支付条件不全=================== ");
//			res.sendRedirect(domain + "isSuccess=0&message=支付条件不完整");
//		}
		return "pay/pay";
	}

	/**
	 * 微信异步回调通知
	 * @param req
	 * @param res
	 * @return
	 * @creator ：liaoxianghua
	 * @date ：2017年8月1日下午4:51:41
	 */
	@ResponseBody
	@RequestMapping({ "/payWxCallback" })
	public String payWxCallback(HttpServletRequest req, HttpServletResponse res) {
		String out_trade_no = null;
		String trade_no = null;
		String tradeStatus = null;
		try {
			logger.info("========================微信回调开始========================== ");
			Map<String, String[]> requestParams = req.getParameterMap();
			{
				for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
					String name = iter.next();
					String[] values = requestParams.get(name);
					String valueStr = "";
					for (int i = 0; i < values.length; i++) {
						valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
					}
					logger.info("微信支付异步回调参数： name===========》{},varStr===========》{}", name, valueStr);
				}
				String[] data = requestParams.get("data");
				List<String> list = Arrays.asList(data);
				String dataStr = list.get(0);
				GatwayNotifyResponse srd = JSON.parseObject(dataStr, GatwayNotifyResponse.class);
				GatwayNotifyResponseBody snb =  srd.getBody();
				out_trade_no = snb.getOrderCode();
				trade_no = snb.getTradeNo();
				tradeStatus = snb.getOrderStatus();

				String _totalFee = snb.getBuyerPayAmount();
				BigDecimal totalFee = new BigDecimal(_totalFee);
				BigDecimal format = new BigDecimal(100);
				totalFee = totalFee.divide(format);
				OrderPayRecord recode = new OrderPayRecord();
				recode.setPaySerialNo(out_trade_no);
				OrderPayRecord record = orderPayRecordService.selectByParam(recode);
				if (record == null) {
					logger.info("==========================={}记录记录不存在==============",snb.getOrderCode());
					return "";
				}
				if("00".equals(record.getTradeStatus())){
					
					return "respCode=000000";
				}
				if(SandpayConstants.SUCCESS_RESP_CODE.equals(srd.getHead().getRespCode())){
					payService.wxCallback(record, dataStr, snb, out_trade_no, trade_no, tradeStatus, totalFee, record);
					return "respCode=000000";
				}else{
					OrderPayRecord orderPayRecordRefund = new OrderPayRecord();
					orderPayRecordRefund.setRemark(srd.getHead().getRespMsg());
					orderPayRecordRefund.setUpdateTime(new Date());
					orderPayRecordRefund.setValid(Integer.valueOf(SysEnum.ORDER_PAY_RECORD_VALID_3.getCode()));
					orderPayRecordService.insert(orderPayRecordRefund);
					return "fail";
				}
			}
		}catch(BussinessException be ){
			logger.info("========================BussinessException异常={}=========================", be.getExceptionMessage());
			//添加日志
    		OrderPayLog entity = new OrderPayLog();
    		entity.setNotifyData("微信回调异常:"+be.getExceptionMessage());
    		entity.setNotifyMethod(1);//异步回调
    		entity.setNotifyTime(new Date());
    		entity.setPaySerialNo(out_trade_no);
    		entity.setTradeNo(trade_no);
    		entity.setTradeStatus(tradeStatus);
    		orderPayLogService.insert(entity);
    		return "fail";
		} catch (Exception e) {
			logger.warn("========================微信回调异常={}=========================", e.getMessage());
			//添加日志
    		OrderPayLog entity = new OrderPayLog();
    		entity.setNotifyData("微信回调异常:"+e.getMessage());
    		entity.setNotifyMethod(1);//异步回调
    		entity.setNotifyTime(new Date());
    		entity.setPaySerialNo(out_trade_no);
    		entity.setTradeNo(trade_no);
    		entity.setTradeStatus(tradeStatus);
    		orderPayLogService.insert(entity);
    		return "fail";
		}
	}

	/**
	 * 支付宝回调 异步
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping({ "/payBgCallback" })
	@ResponseBody
	public String payBgCallback(HttpServletRequest request, HttpServletResponse response) {
//		logger.info("===========================支付宝异步回调开始===========================================");
		String result = null;
//		String tradeStatus = null;
//		String out_trade_no = null;
//		String trade_no = null;
//		String notify_data = null;
//		try {
//			Map<String, String> params = new HashMap<String, String>();
//			Map<String, String[]> requestParams = request.getParameterMap();
//			for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
//				String name = iter.next();
//				String[] values = requestParams.get(name);
//				String valueStr = "";
//				for (int i = 0; i < values.length; i++) {
//					valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
//				}
//				logger.info("支付宝异步回调参数： name===========》" + name + ",varStr===========》" + valueStr);
//				switch (name) {
//				case "trade_no":
//					trade_no = valueStr;
//					break;
//				case "out_trade_no":
//					out_trade_no = valueStr;
//					break;
//				case "notify_data":
//					notify_data = valueStr;
//					break;
//				}
//				params.put(name, valueStr);
//			}
//			OrderPayRecord pot = new OrderPayRecord();
//			String totalFee = null;
//			OrderPayRecord recode = new OrderPayRecord();
//			recode.setPaySerialNo(out_trade_no);
//			OrderPayRecord record = orderPayRecordService.selectByParam(recode);
//			if (record == null) {
//				logger.info("===========================" + out_trade_no
//						+ "记录记录不存在==========================================");
//				return "fail";
//			}
//			if ("2".equals(String.valueOf(record.getPayType()))) {// 支付宝
//				if (PayUtils.validAliPayRet(params)) {
//					logger.info("===========================异步验签成功==========================================");
//					// XML解析notify_data数据
//					Document doc_notify_data = DocumentHelper.parseText(params.get("notify_data").toString());
//					// 商户订单号
//					out_trade_no = doc_notify_data.selectSingleNode("//notify/out_trade_no").getText();
//					// 支付宝交易号
//					trade_no = doc_notify_data.selectSingleNode("//notify/trade_no").getText();
//					// 交易金额
//					totalFee = doc_notify_data.selectSingleNode("//notify/total_fee").getText();
//					// 交易状态
//					tradeStatus = doc_notify_data.selectSingleNode("//notify/trade_status").getText();
//					pot.setTradeNo(trade_no);
//					pot.setPaySerialNo(out_trade_no);
//					pot.setTradeStatus(tradeStatus);
//					pot.setTotalPrice(new BigDecimal(totalFee));
//					result = "success";
//				} else {
//					result = "fail";
//				}
//			}
//			// 修改订单状态
//			payService.updateOrderPayStatus(pot, new BigDecimal(totalFee));
//			// 添加日志
//			OrderPayLog entity = new OrderPayLog();
//			entity.setNotifyData(notify_data);
//			entity.setNotifyMethod(1);
//			entity.setNotifyTime(new Date());
//			entity.setPaySerialNo(out_trade_no);
//			entity.setTradeNo(trade_no);
//			entity.setTradeStatus(tradeStatus);
//			orderPayLogService.insert(entity);
//		} catch (DocumentException ex) {
//			logger.info("===========================解析返回结果异常=============================================");
//			logger.error(ex.getMessage());
//			result = ex.getMessage();
//		} catch (Exception ex) {
//			logger.info("===========================支付宝异步回调异常============================================");
//			ex.printStackTrace();
//			logger.error(ex.getMessage());
//			result = ex.getMessage();
//		}
//		logger.info("==================" + out_trade_no + "=========" + result + "=========================");
//		logger.info("===========================支付宝异步回调结束===========================================");
		return result;
	}

	/**
	 * 支付宝成功返回 同步
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping({ "/payBgCallbackSync" })
	public void payBgCallbackSync(HttpServletRequest request, HttpServletResponse response) {
//		logger.info("===========================支付宝同步回调start==========================================");
//		String out_trade_no = "";
//		String result = "";
//		String trade_no = "";
//		try {
//			// 获取支付宝GET过来反馈信息
//			Map<String, String> params = new HashMap<String, String>();
//			Map<String, String[]> requestParams = request.getParameterMap();
//			for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
//				String name = (String) iter.next();
//				String[] values = (String[]) requestParams.get(name);
//				String valueStr = "";
//				for (int i = 0; i < values.length; i++) {
//					valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
//				}
//				// 乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
//				valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");
//				logger.info("支付宝同步回调参数： name===========》" + name + ",varStr===========》" + valueStr);
//				switch (name) {
//				case "trade_no":
//					trade_no = valueStr;
//					break;
//				case "result":
//					result = valueStr;
//					break;
//				case "out_trade_no":
//					out_trade_no = valueStr;
//					break;
//				}
//				params.put(name, valueStr);
//			}
//			// 计算得出通知验证结果
//			OrderPayRecord recode = new OrderPayRecord();
//			recode.setPaySerialNo(out_trade_no);
//			OrderPayRecord record = orderPayRecordService.selectByParam(recode);
//			if (record == null) {
//				logger.info("===========================" + out_trade_no
//						+ "支付记录不存在==========================================");
//				return;
//			}
//			if ("2".equals(Integer.valueOf(record.getPayType()))) {
//				boolean verify_result = PayUtils.validRefundAliPayRet(params);
//				if (verify_result) {// 验证成功
//					logger.info("===========================验证成功=====================================================");
//					response.sendRedirect(AlipayPropertiesUtil.getProperty("alipay.houtrap_m_notify_url")
//							+ "isSuccess=1&message=支付成功");
//				} else {
//					logger.info("===========================验证失败=====================================================");
//					response.sendRedirect(AlipayPropertiesUtil.getProperty("alipay.houtrap_m_notify_url")
//							+ "isSuccess=0&message=支付失败");
//				}
//			}
//			// 添加支付回调日志
//			OrderPayLog entity = new OrderPayLog();
//			entity.setNotifyMethod(0);
//			entity.setNotifyTime(new Date());
//			entity.setPaySerialNo(out_trade_no);
//			entity.setTradeNo(trade_no);
//			entity.setTradeStatus(result);
//			orderPayLogService.insert(entity);
//		} catch (Exception e) {
//			if (logger.isDebugEnabled()) {
//				e.printStackTrace();
//			}
//			logger.info("====================回调错误==================", e.getMessage());
//		}
//		logger.info("===========================支付宝同步回调end============================================");
	}

	/**
	 * 退款异步通知
	 * @param req
	 * @param res
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月10日下午4:33:22
	 */
	@RequestMapping("/refundWxCallback")
	public String refundWxCallback(HttpServletRequest req, HttpServletResponse res){
		try {
			logger.warn("=========================退款异步通知开始=========================");
			Map<String,String[]> requestParams = req.getParameterMap();
			for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
				String name = iter.next();
				String[] values = requestParams.get(name);
				String valueStr = "";
				for (int i = 0; i < values.length; i++) {
					valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
				}
				logger.warn("退款异步回调参数： name===========》{},varStr===========》{}", name, valueStr);
			}
			String[] data = requestParams.get("data");
			List<String> list = Arrays.asList(data);
			String dataStr = list.get(0);
			GatewayOrderRefundResponse srd = JSON.parseObject(dataStr, GatewayOrderRefundResponse.class);
			SandpayResponseHead respHead = srd.getHead();
			if(SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())){
				GatewayOrderRefundResponseBody rrb = srd.getBody();
				payService.refuncCallbackSuccess(dataStr, rrb);
				return "respCode=000000";
			}else{
				OrderPayRecord orderPayRecordRefund = new OrderPayRecord();
				orderPayRecordRefund.setRemark(respHead.getRespMsg());
				orderPayRecordRefund.setUpdateTime(new Date());
				orderPayRecordService.insert(orderPayRecordRefund);
				logger.warn("=========================退款失败,失败编码{}，原因：{}=========================",respHead.getRespCode(),respHead.getRespMsg());
				return "fail";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.warn("=============退款异步回调异常==========={}======================", e.getMessage());
			return "fail";
		}
	}
	
	/**
	 * 退款方法
	 * @param request
	 * @param response
	 * @param id 退款记录表ID
	 * @return
	 * @creator ：liaoxianghua  
	 * @date ：2017年8月15日下午9:53:25
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping("/refund")
	public MessageData refund(HttpServletRequest request, HttpServletResponse response, String encode,BigDecimal refundPrice,String remark,String src,String sellerId) {
		logger.warn("=============请求退款方法开始=========订单ID{}======================", EncryptPkUtil.decodeId(encode));
		MessageData messageData = new MessageData(200, "成功");
		if(!this.canRefund()){
 			return new MessageData(500, "退款时间早上8:00至晚上22:00");
		}
//		OrderPayRecord orderPayRecord = orderPayRecordService.selectByPrimaryKey(Integer.valueOf(encode));
		OrderPayRecord orderPayRecord = orderPayRecordService.selectByPrimaryKey(Integer.valueOf(EncryptPkUtil.decodeId(encode)));
		if(orderPayRecord == null){
			messageData.setStatus(500);
			messageData.setMessage("支付记录不存在");
			return messageData;
		}
		Order order = orderService.selectOrderDetail(orderPayRecord.getOrderId());
		if(sellerId == null ){
			BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER);
			if(sellerUser == null){
				messageData.setStatus(500);
				messageData.setMessage("用户未登录");
				return messageData;
			}
		}else{
			if(!order.getSellerId().equals(Integer.valueOf(sellerId))){
				return new  MessageData(500, "非法用户");
			}
			try {
				BusiSellerUser sellerUser = busiSellerService.getBusiSellerUserBySellerId(Integer.valueOf(sellerId));
				if(sellerUser == null ){
					return new  MessageData(500, "商户不存在");
				}
			} catch (Exception e) {
				return new  MessageData(500, "获取商户出错");
			}

		}
		if(StringUtils.isBlank(encode)){
			messageData.setStatus(500);
			messageData.setMessage("encode不能为空");
			return messageData;
		}

		if(order == null ){
			return new  MessageData(500, "订单不存在");
		}
		return payService.refundAndUpdate(orderPayRecord,weixinSetting.getDomain(),encode, refundPrice, remark);
	}

	/**
	 * 支付结果查询
	 * @param request
	 * @param response
	 * @param orderCode
	 * @creator ：liaoxianghua
	 * @date ：2017年8月8日下午4:00:54
	 */
	@ResponseBody
	@RequestMapping("/query")
	public Object query(HttpServletRequest request, HttpServletResponse response, String paySerialNo) {
		SandpayRequestHead head = new SandpayRequestHead();
		GatewayOrderQueryRequestBody body = new GatewayOrderQueryRequestBody();
		GatewayOrderQueryRequest req = new GatewayOrderQueryRequest();
		req.setHead(head);
		req.setBody(body);
		PacketTool.setDefaultRequestHead(head, SandpayConstants.GATEWAY_ORDERQUERY,
				SandpayConstants.WEIXINPAY_PRODUCTID, WxPropertiesUtil.getProperty("sandpay_mid"));
		body.setOrderCode(paySerialNo); // 商户订单号
		body.setExtend(""); // 扩展域
		OrderPayRecord recode = new OrderPayRecord();
		recode.setPaySerialNo(paySerialNo);
//		OrderPayRecord record = orderPayRecordService.selectByParam(recode);
		Object result = null;
		try {
			String url = SandpayConstants.ADDRESS_PREFIX_QUERY;
			GatewayOrderQueryResponse resp = SandpayClient.execute(req, url);
			SandpayResponseHead respHead = resp.getHead();
			if (SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())) {
//				GatewayOrderQueryResponseBody queryResponseBody = resp.getBody();
				result = resp.getHead();
//				if (queryResponseBody != null) {
//					// 订单在我们这边没有成功 在杉德成功了
//					if (!GatewayOrderQueryResponseBody.OrderStatus.SUCCESS.equals(recode.getTradeStatus())
//							&& GatewayOrderQueryResponseBody.OrderStatus.SUCCESS.equals(queryResponseBody
//									.getOrderStatus())) {
//						record.setTradeStatus(queryResponseBody.getOrderStatus());
//						record.setTradeNo(queryResponseBody.getOriTradeNo());
//						record.setUpdateTime(new Date());
////						record.setValid(SysEnum);
//						orderPayRecordService.updateByParam(record);
//					}
//				}
			} else {
				logger.error("txn fail respCode[{}],respMsg[{}].", respHead.getRespCode(), respHead.getRespMsg());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
	
	@RequestMapping("download")
	public void download(HttpSession session,HttpServletResponse response,HttpServletRequest request,String date){
//		MemberBasic member = MemberAuthentiction.getOnlineMemeber(session);
//		if(member == null){
//			return;
//		}
		SandpayRequestHead head = new SandpayRequestHead();
		GatewayClearFileDownloadRequestBody body = new GatewayClearFileDownloadRequestBody();
		
		GatewayClearFileDownloadRequest req = new GatewayClearFileDownloadRequest();
		req.setHead(head);
		req.setBody(body);
		
		PacketTool.setDefaultRequestHead(head, SandpayConstants.GATEWAY_ORDERQUERY,
				SandpayConstants.WEIXINPAY_PRODUCTID, WxPropertiesUtil.getProperty("sandpay_mid"));
		body.setClearDate(date);  //清算日期
		body.setFileType("1");  //文件返回类型
		body.setExtend("");  //扩展域

		try {
			
			String url = SandpayConstants.ADDRESS_PREFIX + "/clearfile/download";
			GatewayClearFileDownloadResponse resp = SandpayClient.execute(req, url);
			
			SandpayResponseHead respHead = resp.getHead();
			
			if(SandpayConstants.SUCCESS_RESP_CODE.equals(respHead.getRespCode())) {
				System.out.println(resp.getBody().getContent());
				response.sendRedirect(resp.getBody().getContent());
				logger.info("txn success.");
			} else {
				logger.error("txn fail respCode[{}],respMsg[{}].", respHead.getRespCode(), respHead.getRespMsg());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@ResponseBody
	@RequestMapping("queryRefund")
	public Object queryRefund(Integer id){
		OrderRefund orderRefund = new OrderRefund();
//		orderRefund.setOrderPayRecordId(id);
		orderRefund.setOrderId(id);
		return orderRefundService.find(orderRefund);
	}
	
	private boolean canRefund() {
		Calendar a = Calendar.getInstance();
		Calendar b = Calendar.getInstance();
		Calendar c = Calendar.getInstance();

		a.set(Calendar.HOUR_OF_DAY, 8);
		a.set(Calendar.MINUTE, 0);
		a.set(Calendar.SECOND, 0);
		b.set(Calendar.HOUR_OF_DAY, 22);
		b.set(Calendar.MINUTE, 0);
		b.set(Calendar.SECOND, 0);
		return c.after(a) && c.before(b);
	}
}
