 
package com.spring.scenic.busiSeller.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.busi.application.BusiSellerLoginService;
import com.spring.scenic.busi.application.BusiSellerService;
import com.spring.scenic.busi.application.VersionRecordService;
import com.spring.scenic.busi.domain.BusiSeller;
import com.spring.scenic.busi.domain.BusiSellerUser;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;

/**
 * 商户中心M网登录
 * 此处为类说明
 * @author Administrator
 * @date 2017年7月24日
 */
@Controller
@RequestMapping("busiSeller")
@Api(value = "商户中心M网接口", description = "商户中心M网登录相关")
public class BusiSellerLoginController extends BaseController{
	
	@Autowired
    private BusiSellerLoginService busiSellerLoginService;
	
	@Autowired
    private BusiSellerService busiSellerService;
	
	@Resource
	private VersionRecordService versionRecordService;
    
    private Logger logger = LoggerFactory.getLogger(BusiSellerLoginController.class);
    
    /**
     * 商户M网商户登录
     * 此处为类方法说明
     * @param request
     * @param response
     * @param username
     * @param password
     * @param verifyCode
     * @param verifyCodeForPage
     * @param verifyCodeType
     * @param token
     * @param isVerifyCode
     * @return
     * @creator ：Administrator  
     * @date ：2017年7月24日上午11:11:35
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="login",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户M网终端登录接口")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "username", value = "登录用户名", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "password", value = "登录密码", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeForPage", value = "页面生成的验证码图片", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "deviceNo", value = "设备号", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "deviceType", value = "设备类型", required = false, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "deviceVersion", value = "设备版本号", required = false, dataType = "String", paramType = "query"),
    })
    public MessageData login(HttpServletRequest request,HttpServletResponse response,String username, String password, String verifyCodeForPage,
        String deviceNo ,Integer deviceType, String deviceVersion){
        try {
        	int count = 0;
            String failCount = (String) request.getSession().getAttribute(BisConstant.LOGIN_FAIL_COUNT_SELLER);
            if(failCount!=null) {
                count = Integer.valueOf(failCount);
            }
        	String sessionVerifyCode = (String) request.getSession().getAttribute(BisConstant.VERIFY_CODE_FOR_PAGE_SELLER);
            MessageData data = busiSellerLoginService.login(request,username,password,verifyCodeForPage,count,sessionVerifyCode);
            Map<String,Object> map = new HashMap<String,Object>();
            if(200==(data.getStatus())) {
                //登录成功，把商户对象存进session
            	BusiSellerUser sellerUser = (BusiSellerUser) data.getObj();
            	logger.info("商户账号为:================================="+sellerUser.getId());
            	logger.info("商户账号为:================================="+sellerUser.getUsername());
            	logger.info("设备号为:================================="+deviceNo);
            	logger.info("设备号为:================================="+deviceType);
            	logger.info("设备号为:================================="+deviceVersion);
            	if(StringUtils.isNotBlank(deviceNo)) {
            	    sellerUser.setDeviceNo(deviceNo);
            	}
            	if(null!=deviceType) {
            	    sellerUser.setDeviceType(deviceType);
                }
            	if(StringUtils.isNotBlank(deviceNo)) {
            	    sellerUser.setDeviceVersion(deviceVersion);
                }
            	//更新商户账号的设备号，设备类型，设备版本号
            	busiSellerLoginService.updateSellerUserDeviceInfo(sellerUser);
                request.getSession().setAttribute(BisConstant.SESSION_SELLER,sellerUser);
                
                map.put("sellerUser", sellerUser);
                map.put("count", 0);
                data.setObj(map);
                //清除当前session中的页面验证码和使用密码登录失败次数
                request.getSession().removeAttribute(BisConstant.LOGIN_FAIL_COUNT_SELLER);
                request.getSession().removeAttribute(BisConstant.VERIFY_CODE_FOR_PAGE_SELLER);
            }else {
                    //用户密码登录时，如果失败五次，前端需要输入验证码
                    if(count<5) {
                        count++;
                        request.getSession().setAttribute(BisConstant.LOGIN_FAIL_COUNT_SELLER,String.valueOf(count));
                    }
                    map.put("count", count);
                    data.setObj(map);
                }
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 图片验证码
     * 此处为类方法说明
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @creator ：Administrator  
     * @date ：2017年7月24日下午4:25:55
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="initVerifyCodeIoImage",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "五次输入密码登录失败生成验证码图片接口")
    public MessageData initVerifyCodeIoImage(HttpServletRequest request,HttpServletResponse response) throws IOException {
        
	      MessageData messageData = new MessageData(SysConstant.SUCCESS, "图片生成成功");
	      // 告诉客户端，输出的格式
	      response.setContentType("image/jpeg");
	      String chose = "23456789abcdefghijkmnpqrstuvwxyzABCDEFGHIJKMNPQRSTUVWXYZ";
	      char display[] = { '0', ' ', '0', ' ', '0', ' ', '0' };   
	      char ran[] = {'0', '0', '0', '0' };   
	      char temp;   
	      
	      Random rand = new Random();   
	      
	      for (int i = 0; i < 4; i++) {   
	      
	         temp = chose.charAt(rand.nextInt(chose.length()));   
	      
	         display[i * 2] = temp;   
	      
	         ran[i] = temp;   
	      }   
	      
	      String random = String.valueOf(display);   
	        
	      int width = 100, height = 30;   
	      BufferedImage image = new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB);   
	      //你拿到了一只画笔
	      Graphics g = image.getGraphics();   
	      //以下填充背景颜色   
	      //画背景颜色
	      //g.setColor(new Color(233,243,242));
	      g.setColor(new Color(53,80,118));
	      
	      g.fillRect(0, 0, width, height);   
	      //设置字体颜色   
	      g.setColor(Color.WHITE);   
	      Font font = new Font("Arial", Font.CENTER_BASELINE, 20);   
	      g.setFont(font);   
	      g.drawString(random, 15, 20);  
	      //产生随机线条   
	      for (int i = 0; i < 10; i++) {   
	          int x = rand.nextInt(width - 1);   
	          int y = rand.nextInt(height - 1);   
	          int x1 = rand.nextInt(6) + 1;   
	          int y1 = rand.nextInt(12) + 1;   
	          g.drawLine(x, y, x + x1, y + y1);   
	      }   
	        
	      g.dispose();   
	      //去掉验证码中的空格   
	      String [] interceptString = random.split(" ");   
	      String verifyCodeForPage = "";   
	      for(int i = 0;i<interceptString.length;i++){   
	          verifyCodeForPage += interceptString[i];   
	      }
	      logger.info("5次输入错误生成的验证码为："+verifyCodeForPage);
	      System.out.println("验证码是:=================================="+verifyCodeForPage);
	      request.getSession().setAttribute(BisConstant.VERIFY_CODE_FOR_PAGE_SELLER,verifyCodeForPage);
	      try {
	          ByteArrayOutputStream out = new ByteArrayOutputStream();
	          ImageIO.write(image, "JPG", out);
	          byte[] b = out.toByteArray();
	          out.close();
	          String str= new String(Base64.encodeBase64(b));
	          messageData.setObj("data:image/jpeg;base64,"+str);
	          return messageData;
	      } catch (Exception e) {
	          logger.error(e.getMessage(), e);
	          return new MessageData(SysConstant.FAILURE, "生成验证码图片失败！");
	      }
	  }
    
    /**
     * 获取验证码
     * 此处为类方法说明
     * @param request
     * @param response
     * @param session
     * @param phone
     * @return
     * @creator ：Administrator  
     * @date ：2017年7月24日下午4:53:34
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="getVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户M网终端点击获取验证码接口")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "商户手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "验证码类型", required = true, dataType = "String", paramType = "query")
    })
    public MessageData getVerifyCode(HttpServletRequest request,HttpServletResponse response, HttpSession session, String phone,String verifyCodeType){
        try {
            MessageData data = busiSellerLoginService.getVerifyCode(phone, verifyCodeType);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 重置密码之前验证码校验
     * 此处为类方法说明
     * @param request
     * @param session
     * @param phone
     * @param verifyCode
     * @param verifyCodeType
     * @param token
     * @return
     * @creator ：Administrator  
     * @date ：2017年7月24日下午4:54:07
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="validateVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户M网终端重置密码之前校验验证码是否正确接口")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册下单时获取验证码只需要验证手机号格式、是否为空)", 
        required = true, dataType = "String", paramType = "query")
    })
    public MessageData validateVerifyCode(HttpServletRequest request,HttpSession session, String phone, String verifyCode,String verifyCodeType,String token){
        try {
            MessageData data = busiSellerLoginService.validateVerifyCode(phone,verifyCode,verifyCodeType,token);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
  
    /**
     * 忘记密码,商户重置密码
     * 此处为类方法说明
     * @param request
     * @param session
     * @param phone
     * @param verifyCode
     * @param newPassword
     * @param token
     * @param verifyCodeType
     * @return
     * @creator ：Administrator  
     * @date ：2017年7月24日下午4:50:32
     */
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="resetBusiSellerPassword",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户密码重置")
    @ApiImplicitParams({
    @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "newPassword", value = "新密码", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
    required = true, dataType = "String", paramType = "query")
    })
    public MessageData resetBusiSellerPassword(HttpServletRequest request,HttpSession session, String phone,String verifyCode,String newPassword,String token,String verifyCodeType){
        try {
            MessageData data = busiSellerLoginService.updateBusiSellerPassword(phone,verifyCode,newPassword,token,verifyCodeType);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    } 
    
    /**
     * 商户中心M网退出登录
     * 此处为类方法说明
     * @param request
     * @param session
     * @return
     * @creator ：Administrator  
     * @date ：2017年7月26日下午2:34:34
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="logout",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "商户中心M网终端退出接口")
    public MessageData logout(HttpServletRequest request,HttpSession session){
        try {
            request.getSession().removeAttribute(BisConstant.SESSION_SELLER);
            request.getSession().invalidate();
            return new MessageData(SysConstant.SUCCESS, "退出成功");
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "selectSellerInfo", method = RequestMethod.POST)
	@ApiOperation(httpMethod = "POST", value = "商户中心M网终端查询单个商户基本信息", notes = "姓名、电话等信息", produces = MediaType.APPLICATION_JSON_VALUE)
	public MessageData selectSellerInfo(HttpServletRequest request,HttpServletResponse response) {
		try {
			MessageData messageData = new MessageData(null, null, null);
			 Map<String,Object> map = new HashMap<String,Object>();
			 BusiSellerUser sellerUser = (BusiSellerUser) request.getSession().getAttribute(BisConstant.SESSION_SELLER); 
			if (null != sellerUser) {
				Integer sellerId = sellerUser.getId();
				//查询商户账号信息
				BusiSellerUser sellerBasicInfo = busiSellerLoginService.selectSellerInfo(sellerId);
				sellerBasicInfo.setPwd(null);
				//查询商户账号所关联商户，商户所关联商户或者景区的信息
				BusiSeller busiSeller = busiSellerService.selectScenicSellerInfo(sellerUser);
				messageData.setStatus(SysConstant.SUCCESS);
				messageData.setMessage("查询成功");
				map.put("busiSellerUser", sellerBasicInfo);
				map.put("busiSellerScenic", busiSeller);
				messageData.setObj(map);
			} else {
				messageData.setStatus(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_CODE);
				messageData.setMessage(BisConstant.BUSISELLER_NOT_LOGIN_GLOB_MESSAGE);
			}
			return messageData;
		} catch (Exception e) {
			 logger.error(e.getMessage(), e);
			return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
		}
	}
    /**
     * 
     * 此处为类方法说明：获取最新版本
     * @param 
     * @return
     * @creator ：冉茂平(004225)  
     * @date ：2017年9月19日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value = "isNewestVersion", method = RequestMethod.POST)
    @ApiOperation(httpMethod = "POST", value = "商户中心M网终端查询单个商户基本信息", notes = "姓名、电话等信息", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "deviceType", value = "设备类型", required = true, dataType = "Integer", paramType = "query"),
        @ApiImplicitParam(name = "clientVersion", value = "客户端版本号", required = true, dataType = "String", paramType = "query"),
        })
    public MessageData isNewestVersion(HttpServletRequest request,HttpServletResponse response,Integer deviceType, String clientVersion) {
        try {
            MessageData messageData = versionRecordService.isNewestVersion(deviceType,clientVersion);
            return messageData;
        } catch (Exception e) {
             logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE,SysConstant.MESSAGE_FAILURE);
        }
    }

}
