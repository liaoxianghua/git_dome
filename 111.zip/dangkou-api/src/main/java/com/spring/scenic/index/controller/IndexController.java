 
package com.spring.scenic.index.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.content.application.TravelNotesCommentService;
import com.spring.scenic.material.application.MaterialService;
import com.spring.scenic.material.domain.vo.MaterialChannelBarVo;
import com.spring.scenic.material.domain.vo.MaterialDirectSeedingVo;
import com.spring.scenic.material.domain.vo.MaterialLoveDestinationVo;
import com.spring.scenic.material.domain.vo.MaterialVo;
import com.spring.scenic.material.domain.vo.MaterialtravelsVo;
import com.spring.scenic.member.application.MemberCollectionService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.order.application.OrderService;
import com.spring.scenic.picture.application.BusiPictureLibService;
import com.spring.scenic.praise.application.PushPraiseService;
import com.spring.scenic.product.application.ProductService;
import com.spring.scenic.product.domain.vo.ProductTouristVo;
import com.spring.scenic.security.MemberAuthentiction;
import com.spring.scenic.travelnotes.application.TravelNoteService;
import com.spring.scenic.travelnotes.domain.TravelNotes;
import com.spring.scenic.travelnotes.domain.vo.IndexTravelNotesUserCommentslVo;
import com.spring.scenic.travelnotes.domain.vo.TravelNotesVo;


/**
 * 首页模块接口
 */
@Controller
@RequestMapping("index")
@Api(value = "IndexController", description = "首页模块接口")
public class IndexController extends BaseController{
	
    
    @Autowired
    private OrderService orderService;
    @Resource
    private BusiPictureLibService busipicturelibservice;
    @Resource
    private MaterialService materialservice;
    @Resource
    private ProductService productservice;
    @Resource
    private PushPraiseService pushPraiseService;
    @Resource
    private TravelNoteService travelNoteService;
    @Resource
    private TravelNotesCommentService travelNotesCommentService;
    @Resource
    private MemberCollectionService memberCollectionService;//点赞
    
    private Logger logger = LoggerFactory.getLogger(IndexController.class);
    
    
	@ResponseBody
	@RequestMapping(value="home",method=RequestMethod.POST)
	@ApiOperation(httpMethod = "POST",value = "M网主页", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "city", value = "用户定位所在城市，一期不做定位，暂不传；后台根据会员常居地、默认上海规则取 ", required = true, dataType = "String", paramType = "query")
    })
	@CrossOrigin
	public MessageData home(HttpServletRequest request,@RequestParam String city,HttpSession session){
		MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
	    try {
	        MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
	    	Map<String,Object> map=new HashMap<String,Object>();
	    	List<Map<String, Object>> listmap=new ArrayList<Map<String,Object>>();
	    	
	    	//轮播图
	    	List<MaterialVo> list=materialservice.selectMaterial();
	    	//渠道栏
	    	List<MaterialChannelBarVo> channelbar=materialservice.selectChannelBar();
	    	//最爱目的地
	    	MaterialLoveDestinationVo materiallovedestinationvo=new MaterialLoveDestinationVo();
	    	materiallovedestinationvo.setType(BisConstant.INDEXCONTROLLER_QUERY_DOMESTIC_LOVEDESTINATION_CODE);
	    	materiallovedestinationvo.setStatus(0);
	    	List<MaterialLoveDestinationVo> loveDestination=materialservice.selectLoveDestination(materiallovedestinationvo);
	    	//直播
	    	Integer status=0;//传递0只显示2条记录
    		List<MaterialDirectSeedingVo>  directSeeding=materialservice.selectDirectSeeding(status,null,null);

    		//游记
    		MaterialtravelsVo materialtravelsVo=new MaterialtravelsVo();
	    	materialtravelsVo.setCityName(city);
	    	materialtravelsVo.setStatus(0);
	    	materialtravelsVo.setMissingCount(2);//首页默认显示当前城市阅读量最高的2篇游记
	    	materialtravelsVo.setSessionId(session.getId());//判断是否点赞过
	    	materialtravelsVo.setUserId(memberBasic==null ? null : memberBasic.getId());//判断是否收藏过
	    	materialtravelsVo.setMissingCountType(0);
	    	materialtravelsVo.setCoversImageUrl(PropertiesUtil.getProperty("scenic_default_covers_img"));
	    	List<MaterialtravelsVo>  travels=materialservice.getTravelNotesList(materialtravelsVo,false);
	    	
	    	//首页显示第一个产品
	    	ProductTouristVo productholidayhotelvo=new ProductTouristVo();
	    	productholidayhotelvo.setCity(city);
	    	productholidayhotelvo.setProductType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_productType1")));
	    	productholidayhotelvo.setSubType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_subType1")));
	    	productholidayhotelvo.setMissingCount(4);
	    	List<ProductTouristVo>  indexPageFistProduct=productservice.selectProductTourist(productholidayhotelvo);
	    	
	    	//首页显示第二个产品
	    	ProductTouristVo producttouristvo=new ProductTouristVo();
	    	producttouristvo.setCity(city);
	    	producttouristvo.setProductType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_productType2")));
	    	producttouristvo.setSubType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_subType2")));
	    	producttouristvo.setMissingCount(4);
	    	List<ProductTouristVo>  indexPageSecondProduct=productservice.selectProductTourist(producttouristvo);
	    	
	    	//首页显示第三个产品
	    	ProductTouristVo throughTrain=new ProductTouristVo();
	    	throughTrain.setCity(city);
	    	throughTrain.setProductType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_productType3")));
	    	throughTrain.setSubType(Integer.valueOf(PropertiesUtil.getProperty("scenic_api_index_default_subType3")));
	    	throughTrain.setMissingCount(4);
	    	List<ProductTouristVo>  indexPageThirdProduct = productservice.selectProductTourist(throughTrain);
	    	
	    	map.put("carouselFigure", list); //轮播图
	    	map.put("channelBar", channelbar); //渠道栏
	    	map.put("directSeeding", directSeeding); //直播
	    	map.put("travels", travels);//游记
	    	map.put("loveDestination", loveDestination); //最爱目的地
 
	    	//排在第一产品相关取值
	    	Map<String, Object> productMap1=new HashMap<String, Object>();
	    	productMap1.put("slogan", PropertiesUtil.getProperty("scenic_api_index_default_slogan1"));
	    	productMap1.put("productName", PropertiesUtil.getProperty("scenic_api_index_default_name1"));
	    	productMap1.put("productType", PropertiesUtil.getProperty("scenic_api_index_default_productType1"));
	    	productMap1.put("subType", PropertiesUtil.getProperty("scenic_api_index_default_subType1"));
	    	productMap1.put("indexPageProduct", indexPageFistProduct); // 第一个产品
	    	 
	    	//排在第二产品相关取值
	    	Map<String, Object> productMap2=new HashMap<String, Object>();
	    	productMap2.put("slogan", PropertiesUtil.getProperty("scenic_api_index_default_slogan2"));
	    	productMap2.put("productName", PropertiesUtil.getProperty("scenic_api_index_default_name2"));
	    	productMap2.put("productType", PropertiesUtil.getProperty("scenic_api_index_default_productType2"));
	    	productMap2.put("subType", PropertiesUtil.getProperty("scenic_api_index_default_subType2"));
	    	productMap2.put("indexPageProduct", indexPageSecondProduct); // 第二个产品
	    	
	    	//排在第三产品相关取值
	    	Map<String, Object> productMap3=new HashMap<String, Object>();
	    	productMap3.put("slogan", PropertiesUtil.getProperty("scenic_api_index_default_slogan3"));
	    	productMap3.put("productName", PropertiesUtil.getProperty("scenic_api_index_default_name3"));
	    	productMap3.put("productType", PropertiesUtil.getProperty("scenic_api_index_default_productType3"));
	    	productMap3.put("subType", PropertiesUtil.getProperty("scenic_api_index_default_subType3"));
	    	productMap3.put("indexPageProduct", indexPageThirdProduct); // 第三个产品
	    	
	    	listmap.add(productMap1);
	    	listmap.add(productMap2);
	    	listmap.add(productMap3);
	    	map.put("indexProductList", listmap); //首页相关产品 口号  一级类别 二级类别 和产品名字
	    	data.setObj(map);
	    	return data;
	    } catch (Exception e) {
	        logger.error(e.getMessage(), e);
	        data.setStatus(SysConstant.EXCEPTION);
            data.setMessage(SysConstant.MESSAGE_EXCEPTION);
            return data;
        }
	}
   
    
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "最爱目的地更多", notes = "最爱目的地更多")
    @RequestMapping(value = "loveDestination", method = RequestMethod.POST)
	public MessageData loveDestination(HttpServletRequest request,
			@ApiParam(name="type",value="传递 0:国内  1:出境") @RequestParam(value = "type", required = true) Integer type){
		MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
		if(null==type){
			data.setStatus(SysConstant.FAILURE);
			data.setMessage(BisConstant.PASS_PARAM_GLOB_MSG_IS_NOT_NULL);
			return data;
		}
		if(type<0 || type>2){
			data.setStatus(SysConstant.FAILURE);
			data.setMessage(BisConstant.FORBIDDEN_MSG);
			return data;
		}
	    try {
	    	MaterialLoveDestinationVo materiallovedestinationvo=new MaterialLoveDestinationVo();
	    	materiallovedestinationvo.setType(type);
	    	materiallovedestinationvo.setStatus(1);//等于表示查询所有的更多的目的地
	    	List<MaterialLoveDestinationVo> loveDestination=materialservice.selectLoveDestination(materiallovedestinationvo);
	    	data.setObj(loveDestination);//最爱目的地
	    	return data;
	    } catch (Exception e) {
	        data.setStatus(SysConstant.EXCEPTION);
            data.setMessage(SysConstant.MESSAGE_EXCEPTION);
            logger.error(e.getMessage(), e);
            return data;
        }
	}
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "直播更多", notes = "直播更多")
    @RequestMapping(value = "directSeedingMore", method = RequestMethod.POST)
    public MessageData directSeedingMore(HttpServletRequest request,HttpSession session){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	Map<String,Object> map=new HashMap<String, Object>();
    	try {
    		Integer status=1;
    		List<MaterialDirectSeedingVo>  directSeedingMore=materialservice.selectDirectSeeding(status,session.getId(),null!=memberBasic ? memberBasic.getId() :null);
    		map.put("directseedingmore", directSeedingMore);
    		data.setObj(map);//直播更多
    		return data;
    	} catch (Exception e) {
            data.setStatus(SysConstant.EXCEPTION);
            data.setMessage(SysConstant.MESSAGE_EXCEPTION);
            logger.error(e.getMessage(), e);
            return data;
    	}
    }
    
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "首页游记详情页面", notes = "首页游记详情页面")
    @RequestMapping(value = "indexTraveNotesDetail", method = RequestMethod.POST)
    public MessageData indexTraveNotesDetail(HttpServletRequest request,
    		@ApiParam(name="id",value="游记的ID") @RequestParam(value = "id", required = true) Integer id,
    		HttpSession session
    		){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	Map<String,Object> map=new HashMap<String, Object>();
    	MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	try {
    		
    		TravelNotesVo TravelNotesVo=travelNoteService.getTravelNote(id,session.getId(),memberBasic==null ? null :memberBasic.getId());
    		List<IndexTravelNotesUserCommentslVo> indexTravelNotesUserCommentslVo=travelNoteService.selectByIndexTravelNotesUserCommentslVo(id);
    		map.put("TravelNotesVo", TravelNotesVo);
    		map.put("indexTravelNotesUserCommentslVo", indexTravelNotesUserCommentslVo);
    		data.setObj(map);
		} catch (Exception e) {
            data.setStatus(SysConstant.EXCEPTION);
            data.setMessage(SysConstant.MESSAGE_EXCEPTION);
            logger.error(e.getMessage(), e);
			return data;
		}
    	return data;
    }
    
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "首页游记详情评论页面", notes = "首页游记详情评论页面")
    @RequestMapping(value = "indexTraveNotesDetailComments", method = RequestMethod.POST)
    public MessageData indexTraveNotesDetailComments(HttpServletRequest request,
    		@ApiParam(name="id",value="游记的ID") @RequestParam(value = "id", required = true) Integer id,
    		HttpSession session
    		){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	Map<String,Object> map=new HashMap<String, Object>();
    	try {
    		List<IndexTravelNotesUserCommentslVo> indexTravelNotesUserCommentslVo=travelNoteService.selectByIndexTravelNotesUserCommentslVo(id);
    		map.put("indexTravelNotesUserCommentslVo", indexTravelNotesUserCommentslVo);
    		data.setObj(map);
    	} catch (Exception e) {
            data.setStatus(SysConstant.EXCEPTION);
            data.setMessage(SysConstant.MESSAGE_EXCEPTION);
            logger.error(e.getMessage(), e);
    		return data;
    	}
    	return data;
    }
    
    
    
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "首页游记评论", notes = "首页游记评论")
    @RequestMapping(value = "insertIndexTraveNotesDetailComments", method = RequestMethod.POST)
    public MessageData insertIndexTraveNotesDetailComments(HttpServletRequest request,
    		@ApiParam(name="id",value="页面游记的ID") @RequestParam(value = "id", required = true) Integer id,
    		@ApiParam(name="comments",value="comments") @RequestParam(value = "comments", required = true) String comments
    		){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
		}
    	try {
    		if(StringUtils.isBlank(comments.trim())){
    			data.setMessage("评论内容不能为空");
	    		data.setStatus(SysConstant.EXCEPTION);
	    		return data;
    		}
        	int flag=travelNotesCommentService.insertIndexTraveNotesDetailComments(id,comments.trim(),memberBasic.getId());
       		if(flag<0){
			    data.setMessage("评论失败");
	    		data.setStatus(SysConstant.EXCEPTION);
	    		return data;
    		}
    	} catch (Exception e) {
    		data.setMessage("评论失败");
    		data.setStatus(SysConstant.EXCEPTION);
    		logger.error(e.getMessage(), e);
    		return data;
    	}
    	return data;
    }
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "首页游记收藏", notes = "首页游记收藏")
    @RequestMapping(value = "insertIndexTraveNotesDetailCollection", method = RequestMethod.POST)
    public MessageData insertIndexTraveNotesDetailCollection(HttpServletRequest request,
    		@ApiParam(name="id",value="页面游记的ID") @RequestParam(value = "id", required = true) Integer id
    		){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	MemberBasic memberBasic = MemberAuthentiction.getOnlineMemeber(request.getSession());
    	if(memberBasic == null){
			return new MessageData(BisConstant.USER_NOT_LOGIN_GLOB_CODE, BisConstant.USER_NOT_LOGIN_GLOB_MESSAGE, null);
		}
    	if(null==id){
    		data.setMessage("收藏失败");
    		data.setStatus(SysConstant.EXCEPTION);
    		return data;
    	}
    	try {
    		if(memberCollectionService.add(memberBasic.getId(), BisConstant.INDEX_COLLECTION_STATUS, id)<0){
    			data.setMessage("收藏失败");
        		data.setStatus(SysConstant.EXCEPTION);
        		return data;
    		}
    	} catch (Exception e) {
    		data.setMessage("收藏失败");
    		data.setStatus(SysConstant.EXCEPTION);
    		logger.error(e.getMessage(), e);
    		return data;
    	}
    	return data;
    }
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "首页游记增加阅读数", notes = "首页游记增加阅读数")
    @RequestMapping(value = "insertReadCountTravelNote", method = RequestMethod.POST)
    public MessageData insertReadCountTravelNote(HttpServletRequest request,
    		@ApiParam(name="id",value="页面游记的ID") @RequestParam(value = "id", required = true) Integer id
    		){
    	MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
    	 
    	try {
    		TravelNotes  travelNotes=travelNoteService.selectByPrimaryKey(id);
    		if(null==travelNotes){
    			data.setMessage(BisConstant.FORBIDDEN_MSG);
    			data.setStatus(SysConstant.EXCEPTION);
    			return data;
    		}
    	if(travelNoteService.updateReadCountTravelNote(id)<0){
    		data.setMessage("失败");
    		data.setStatus(SysConstant.EXCEPTION);
    		return data;
    	}
    	} catch (Exception e) {
    		data.setMessage("失败");
    		data.setStatus(SysConstant.EXCEPTION);
    		logger.error(e.getMessage(), e);
    		return data;
    	}
    	return data;
    }
    
    /**
     * 
     * 判断服务是否正常
     */
    @ResponseBody
    @RequestMapping(value="hello",method=RequestMethod.GET)
    public String hello(HttpServletRequest request,HttpServletResponse response){
        return "Hello";
    }
  
}
