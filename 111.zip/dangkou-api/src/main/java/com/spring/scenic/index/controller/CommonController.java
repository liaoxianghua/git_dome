 
package com.spring.scenic.index.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.sd4324530.fastweixin.api.JsAPI;
import com.github.sd4324530.fastweixin.api.config.ApiConfig;
import com.github.sd4324530.fastweixin.api.response.GetSignatureResponse;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysConstant;
import com.spring.scenic.common.domain.MessageData;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.StringUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.application.MemberDetailInfoService;
import com.spring.scenic.member.application.MemberMsgService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberSharedAccount;
import com.spring.scenic.pay.controller.weixin.WeixinSetting;
import com.spring.scenic.picture.application.BusiPictureLibService;


/**
 * 登录、密码找回等模块接口
 */
@Controller
@RequestMapping("common")
@Api(value = "公共功能接口", description = "公共功能接口如登录、修改密码、找回密码等")
public class CommonController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(CommonController.class);
    @Autowired
    private MemberDetailInfoService memberDetailInfoService;
    @Autowired
    private MemberBasicService memberBasicService;
	@Resource
	private BusiPictureLibService busipicturelibservice;
	@Resource
	private MemberMsgService memberMsgService;
	@Resource
	private WeixinSetting weixinSetting;
    
    /**
     * 
     * 此处为类方法说明：会员登录
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="login",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端登录接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "loginType", value = "登录方式、1：普通登录，2：快速登录，3第三方登录", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "password", value = "登录密码", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "短信验证码,服务器session为空时，表示不需要验证码，如果session获取有时则必须", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeForPage", value = "页面生成的验证码图片", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
        required = true, dataType = "String", paramType = "query")
        
    })
    public MessageData login(HttpServletRequest request,HttpServletResponse response,String phone, String loginType, String password, String verifyCode,String verifyCodeForPage,String verifyCodeType,String token,Integer isVerifyCode){
        try {
            int count = 0;
            String sessionVerifyCode = (String) request.getSession().getAttribute(BisConstant.VERIFY_CODE_FOR_PAGE);
            String failCount = (String) request.getSession().getAttribute(BisConstant.LOGIN_FAIL_COUNT);
            if(failCount!=null) {
                count = Integer.valueOf(failCount);
            }
            MessageData data = memberBasicService.login(request,phone,loginType,password,verifyCode,verifyCodeForPage,verifyCodeType,token,count,sessionVerifyCode);
            Map<String,Object> map = new HashMap<String,Object>();
            if(200==(data.getStatus())) {
                //登录成功，把会员对象存进session,会员所在城市存在session,如果会员没有城市，则默认为上海,
                //清除当前session中的页面验证码和使用密码登录失败次数
                MemberBasic member = (MemberBasic) data.getObj();
                request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                map.put("memberBasic", member);
                map.put("count", 0);
                String cityName = member.getCityName();
                if(StringUtil.isNotEmpty(cityName)) {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,cityName);
                }else {
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,"上海");
                }
                request.getSession().removeAttribute(BisConstant.LOGIN_FAIL_COUNT);
                request.getSession().removeAttribute(BisConstant.VERIFY_CODE_FOR_PAGE);
                data.setObj(map);
            }else {
                if("1".equals(loginType)) {
                    //用户密码登录时，如果失败五次，前端需要输入验证码
                    if(count<5) {
                        count++;
                        request.getSession().setAttribute(BisConstant.LOGIN_FAIL_COUNT,String.valueOf(count));
                    }
                    map.put("count", count);
                    data.setObj(map);
                }
            }
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
      @CrossOrigin
      @ResponseBody
      @RequestMapping(value="initVerifyCodeIoImage",method=RequestMethod.POST)
      @ApiOperation(httpMethod = "POST",value = "5次输入密码登录失败生成验证码图片接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
      public MessageData initVerifyCodeIoImage(HttpServletRequest request,HttpServletResponse response) throws IOException {
          
        MessageData messageData = new MessageData(SysConstant.SUCCESS, "图片生成成功");
        // 告诉客户端，输出的格式
        response.setContentType("image/jpeg");
        String chose = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        char display[] = { '0', ' ', '0', ' ', '0', ' ', '0' };   
        char ran[] = {'0', '0', '0', '0' };   
        char temp;   
        
        Random rand = new Random();   
        
        for (int i = 0; i < 4; i++) {   
        
           temp = chose.charAt(rand.nextInt(chose.length()));   
        
           display[i * 2] = temp;   
        
           ran[i] = temp;   
        }   
        
        String random = String.valueOf(display);   
          
        int width = 100, height = 30;   
        BufferedImage image = new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB);   
        //你拿到了一只画笔
        Graphics g = image.getGraphics();   
        //以下填充背景颜色   
        //画背景颜色
        //g.setColor(new Color(233,243,242));
        g.setColor(new Color(53,80,118));
        
        g.fillRect(0, 0, width, height);   
        //设置字体颜色   
        g.setColor(Color.WHITE);   
        Font font = new Font("Arial", Font.CENTER_BASELINE, 20);   
        g.setFont(font);   
        g.drawString(random, 15, 20);  
        //产生随机线条   
        for (int i = 0; i < 10; i++) {   
            int x = rand.nextInt(width - 1);   
            int y = rand.nextInt(height - 1);   
            int x1 = rand.nextInt(6) + 1;   
            int y1 = rand.nextInt(12) + 1;   
            g.drawLine(x, y, x + x1, y + y1);   
        }   
          
        g.dispose();   
        //去掉验证码中的空格   
        String [] interceptString = random.split(" ");   
        String verifyCodeForPage = "";   
        for(int i = 0;i<interceptString.length;i++){   
            verifyCodeForPage += interceptString[i];   
        }
        logger.info("5次输入错误生成的验证码为："+verifyCodeForPage);
        request.getSession().setAttribute(BisConstant.VERIFY_CODE_FOR_PAGE,verifyCodeForPage);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(image, "JPG", out);
            byte[] b = out.toByteArray();
            out.close();
            String str= new String(Base64.encodeBase64(b));
            messageData.setObj("data:image/jpeg;base64,"+str);
            return messageData;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, "生成验证码图片失败！");
        }
    }
    
    /**
     * 
     * 此处为类方法说明：查询会员详情信息
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年5月4日     
     * @memo ：   
     **
     */
    @CrossOrigin 
    @ResponseBody
    @RequestMapping(value="selectMemberDetailInfo",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终查询当前登录会员信息接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData selectMemberDetailInfo(HttpServletRequest request,HttpSession session){
        try {
            MessageData messageData = new MessageData(null, null, null);
            MemberBasic member =  (MemberBasic) request.getSession().getAttribute(BisConstant.SESSION_MEMBER);
            if(null==member) {
                messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                messageData.setMessage("该会员未登录");
                return messageData;
            }
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("memberBasic", member);
            messageData.setStatus(SysConstant.SUCCESS);
            messageData.setMessage("查询成功");
            messageData.setObj(map);
            return messageData;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
        
    }
    /**
     * 
     * 此处为类方法说明：退出登录
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="logout",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端退出接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    public MessageData logout(HttpServletRequest request,HttpSession session){
        try {
            request.getSession().removeAttribute(BisConstant.SESSION_MEMBER);
            request.getSession().removeAttribute(BisConstant.SESSION_LOCATION_CITY);
            request.getSession().invalidate();
            return new MessageData(SysConstant.SUCCESS, "退出成功");
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明:获取验证码
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月23日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="getVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端点击获取验证码接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型:1、会员注册,2、绑定手机号（第三方账号登录后）,3、快速登录,4、重置密码,5、修改密码,6、获取验证码【1、2需要验证手机号是否已注册；3、4、5需要验证手机号是否未注册；6、只需要验证手机号格式、是否为空】；7、商户中心M版，获取验证码用于修改密码", 
                          required = true, dataType = "String", paramType = "query")
    })
    public MessageData getVerifyCode(HttpServletRequest request,HttpServletResponse response, HttpSession session, String phone, String verifyCodeType){
        try {
            logger.error("操作场景类型:1、会员注册,2、绑定手机号（第三方账号登录后）,3、快速登录,4、重置密码,5、修改密码,6、获取验证码【1、2需要验证手机号是否已注册；3、4、5需要验证手机号是否未注册；6、只需要验证手机号格式、是否为空；7、商户中心M版，获取验证码用于修改密码");
            MessageData data = memberBasicService.getVerifyCode(phone,verifyCodeType);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 
     * 此处为类方法说明:重置密码之前验证码校验
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月24日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="validateVerifyCode",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "M网终端重置密码之前校验验证码是否正确接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "登录手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册下单时获取验证码只需要验证手机号格式、是否为空)", 
        required = true, dataType = "String", paramType = "query")
    })
    public MessageData validateVerifyCode(HttpServletRequest request,HttpSession session, String phone, String verifyCode,String verifyCodeType,String token){
        try {
            MessageData data = memberBasicService.validateVerifyCode(phone,verifyCode,verifyCodeType,token);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
    /**
     * 
     * 此处为类方法说明：用户普通注册
     * @param 
     * @return
     * @creator ：rmp  
     * @date ：2017年4月26日     
     * @memo ：   
     **
     */
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="commonRegister",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "普通注册接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "password", value = "新密码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "confirmPassword", value = "新密码", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
        required = true, dataType = "String", paramType = "query")
        })
    public MessageData commonRegister(HttpServletRequest request,HttpSession session, String phone,String verifyCode,String password,String confirmPassword,String token,String verifyCodeType){
        try {
            MessageData data = memberBasicService.AddCommonRegister(phone, verifyCode, password, confirmPassword, token, verifyCodeType);
            if(SysConstant.SUCCESS==(data.getStatus())) {
                Map<String,Object> map = new HashMap<String,Object>();
                MemberBasic member = (MemberBasic) data.getObj();
                request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                map.put("memberBasic", member);
                data.setObj(map);
            }
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="bookRegiste",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "预订注册接口", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    })
    public MessageData bookRegiste(HttpServletRequest request,HttpSession session, String phone){
        try {
            MessageData data = memberBasicService.bookRegiste(phone);
            if(200==data.getStatus()) {
                request.getSession().setAttribute("phone",phone);
            }
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    /**
     * 重置会员密码
     */
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="resetMemberPassword",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "会员密码重置", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "newPassword", value = "新密码", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
    required = true, dataType = "String", paramType = "query")
    })
    public MessageData resetMemberPassword(HttpServletRequest request,HttpSession session, String phone,String verifyCode,String newPassword,String token,String verifyCodeType){
        try {
            MessageData data = memberBasicService.updateMemberPassword(phone,verifyCode,newPassword,token,verifyCodeType);
            return data;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
	/**
	 * 
	 * 此处为类方法说明：通过第三方登录注册的会员，绑定手机号
	 * @param 
	 * @return
	 * @creator ：rmp  
	 * @date ：2017年4月26日     
	 * @memo ：   
	 **
	 */
    @CrossOrigin
	@ResponseBody
    @RequestMapping(value="memberBand",method=RequestMethod.POST)
    @ApiOperation(httpMethod = "POST",value = "是否绑定会员", notes = "M网主页包括：定位城市、Top、导航栏、直播、游记、目的地、酒店、自由行、直通车", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
    @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "token", value = "token值，唯一值", required = true, dataType = "String", paramType = "query"),
    @ApiImplicitParam(name = "verifyCodeType", value = "操作场景类型，1：会员注册,2：绑定手机号（第三方账号登录后）,3:快速登录,4：重置密码,5:修改密码;(1、2需要验证手机号是否已注册,3、4、5需要验证手机号是否未注册)", 
    required = true, dataType = "String", paramType = "query")
    })
    public MessageData memberBand(HttpServletRequest request,HttpSession session,String phone, String verifyCode, String token,String verifyCodeType){
        try {
            //校验验证码相关数据是否正确
            MessageData messageData = memberBasicService.validateVerifyCode(phone, verifyCode, verifyCodeType, token);
            if(!messageData.getStatus().equals(SysConstant.SUCCESS)) {
                return messageData;
            }else {
                //获取session中的登录方式与unionId
                String unionId = (String) session.getAttribute(BisConstant.SESSION_SHARELOGIN_UNIONID);
                Integer thirdLoginType = (Integer) session.getAttribute(BisConstant.SESSION_SHARELOGIN_TYPE);
                Map<String,Object> map = new HashMap<String,Object>();
                if(StringUtils.isBlank(unionId)||null==thirdLoginType) {
                    messageData.setStatus(BisConstant.USER_NOT_LOGIN_GLOB_CODE);
                    messageData.setMessage("该会员未通过三方登录！");
                    return messageData;
                }
                //会员已存在，建立该会员与第三方登录方式的关联关系
                if(null!=messageData.getObj()) {
                    MemberBasic member = (MemberBasic) messageData.getObj();
                    MemberSharedAccount memberSharedAccount = new MemberSharedAccount();
                    memberSharedAccount.setAccountNum(unionId);
                    memberSharedAccount.setAccountType(thirdLoginType);
                    memberSharedAccount.setMemberId(member.getId());
                    memberSharedAccount.setCreateTime(new Date());
                    memberBasicService.addMemberSharedAccount(memberSharedAccount);
                    request.getSession().setAttribute(BisConstant.SESSION_MEMBER,member);
                    //设置密码为空
                    member.setPassword(null);
                    //如果session中城市为空，则默认为上海
                    if(StringUtils.isNotBlank(member.getCityName())) {
                        session.setAttribute(BisConstant.SESSION_LOCATION_CITY,member.getCityName());
                    }else {
                        session.setAttribute(BisConstant.SESSION_LOCATION_CITY,BisConstant.LOCATION_CITY_DEFAULT);
                    }
                    map.put("memberBasic", member);
                    messageData.setMessage("绑定成功！");
                    messageData.setObj(map);
                }else {
                    //1.验证通过,新建会员信息，详细信息，共享账号信息，系统消息
                    MemberBasic memberBasic = memberBasicService.saveMemberRegisterInfo(phone,unionId,thirdLoginType);
                    //2.完善信息成功，存session,返回数据到前端
                    request.getSession().setAttribute(BisConstant.SESSION_MEMBER,memberBasic);
                    //session中默认城市为上海
                    request.getSession().setAttribute(BisConstant.SESSION_LOCATION_CITY,BisConstant.LOCATION_CITY_DEFAULT);
                    map.put("memberBasic", memberBasic);
                    messageData.setMessage("绑定成功！");
                    messageData.setObj(map);
                }
                //登录成功，移除session中的登录是次数和验证码
                request.getSession().removeAttribute(BisConstant.LOGIN_FAIL_COUNT);
                request.getSession().removeAttribute(BisConstant.VERIFY_CODE_FOR_PAGE);
                //移除session中的unionId和thirdLoginType
                request.getSession().removeAttribute(BisConstant.SESSION_SHARELOGIN_UNIONID);
                request.getSession().removeAttribute(BisConstant.SESSION_SHARELOGIN_TYPE);
                return messageData;
            }
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
            return new MessageData(SysConstant.FAILURE, SysConstant.MESSAGE_FAILURE);
        }
    }
    
	// 上传文件
    @CrossOrigin
	@ResponseBody
	@RequestMapping(value = "/saveUploadFile", method = { RequestMethod.POST })
	@ApiOperation(value = "文件上传公共接口", notes = "文件上传公共接口")
	public MessageData saveUploadFile(HttpServletRequest request) {

		MessageData messageData = new MessageData(SysConstant.SUCCESS, "上传成功");
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		Map<String, List<MultipartFile>> filesMap = multipartRequest.getMultiFileMap();
	
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("busiPictureAttachvo", busipicturelibservice.saveUploadFile(filesMap));
			messageData.setStatus(SysConstant.SUCCESS);
			messageData.setMessage("上传成功");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			messageData.setStatus(SysConstant.EXCEPTION);
			messageData.setMessage("上传失败");
		}
		messageData.setObj(map);
		return messageData;

	}
    
    @CrossOrigin
    @ResponseBody
    @ApiOperation(value = "微信分享公共接口", notes = "微信分享公共接口")
    @RequestMapping(value = "weixinShare", method = RequestMethod.POST)
    public MessageData weixinShare(HttpServletRequest request,
    		@ApiParam(name="shareUrl",value="请求后台访问的地址") @RequestParam(value = "shareUrl", required = true) String shareUrl){
    	
		MessageData data = new MessageData(SysConstant.SUCCESS, SysConstant.MESSAGE_SUCCESS);
		Map<String,Object> map=new HashMap<String, Object>();
		if(shareUrl==null){
			data.setStatus(SysConstant.FAILURE);
			data.setMessage(SysConstant.MESSAGE_PARAMETER_ERROR);
			return data;
		}
		try {
			map.put("appid", weixinSetting.getAppid());//appid
			map.put("getJsSdkSignature", getJsSdkSignature(shareUrl)); //生成的微信签名
			data.setObj(map);
			logger.info("微信分享公共接口: "+ getJsSdkSignature(shareUrl));
		} catch (Exception e) {
	        
	        logger.error(e.getMessage(), e);
			return data;
		}
		return data;
    }
    
    /**   
     * 获取微信公众号内分享配置信息
     */
    public GetSignatureResponse getJsSdkSignature(HttpServletRequest request) {
		try {
            String url = null;
            StringBuffer sb = request.getRequestURL();
            // 获取url后面所带的参数
            if (StringUtils.isNotBlank(request.getQueryString())) {
            	sb.append("?").append(request.getQueryString());
            }
            // 截取掉#后面的值
            if (sb.indexOf("#") != -1) {
            	url = sb.substring(0, sb.indexOf("#"));
            } else {
            	url = sb.toString();
            }
            logger.warn("请求的URL地址："+url);
            return getJsSdkSignature(url);
        } catch (Exception e) {
            logger.error("创建jssdk调用凭证失败！", e);
            return new GetSignatureResponse();
        }
	}
    public GetSignatureResponse getJsSdkSignature(String url) throws Exception {
		try {
			long timestamp = System.currentTimeMillis() / 1000;
			String noncestr = getRandomStr();
			ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), true);
			JsAPI JsAPI=new JsAPI(appConfig);
			logger.warn("GetSignatureResponse   appid:"+weixinSetting.getAppid());
			logger.warn("GetSignatureResponse   noncestr:"+noncestr);
			logger.warn("GetSignatureResponse   timestamp:"+timestamp);
			GetSignatureResponse wxJsapiSignature = JsAPI.getSignature(noncestr, timestamp, url);
			if(wxJsapiSignature!=null){
				logger.warn("GetSignatureResponse   wxJsapiSignature signature:"+wxJsapiSignature.getSignature());
			}
			logger.warn("wxmp-share:getJsSdkSignature:"+wxJsapiSignature);
			return wxJsapiSignature;
		} catch (Exception e) {
			logger.error("创建jssdk调用凭证失败！{}", e);
			throw e;
		}
	}
	
	public static String getRandomStr() {
		String RANDOM_STR = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	    Random RANDOM = new java.util.Random();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 16; i++) {
			sb.append(RANDOM_STR.charAt(RANDOM.nextInt(RANDOM_STR.length())));
		}
		return sb.toString();
	}    
    	/**
    	 * 
    	 * 微信测试分享接口，测试完毕可删除
    	 * @param request
    	 * @param map
    	 * @return
    	 * @creator ：lzj  
    	 * @date ：2017年8月9日下午8:42:46
    	 */
	  @RequestMapping(value = "weixinSharePage", method = RequestMethod.GET)
	  public String weixinSharePage(HttpServletRequest request,ModelMap map){
		map.put("appid", weixinSetting.getAppid());//appid
		map.put("jssdk", getJsSdkSignature(request)); //生成的微信签名
		logger.info("微信分享公共接口  APPID:"+weixinSetting.getAppid());
		logger.info("微信分享公共接口: "+ getJsSdkSignature(request));
		 
		return "/common/sharepage";
	  }
	    
}
