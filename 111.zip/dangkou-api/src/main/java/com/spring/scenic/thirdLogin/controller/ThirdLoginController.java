 
package com.spring.scenic.thirdLogin.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.io.IOException;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import weibo4j.Account;
import weibo4j.Oauth;
import weibo4j.Users;
import weibo4j.http.AccessToken;

import com.github.sd4324530.fastweixin.api.OauthAPI;
import com.github.sd4324530.fastweixin.api.config.ApiConfig;
import com.github.sd4324530.fastweixin.api.enums.OauthScope;
import com.github.sd4324530.fastweixin.api.response.OauthGetTokenResponse;
import com.qq.connect.api.OpenID;
import com.qq.connect.api.qzone.UserInfo;
import com.qq.connect.javabeans.qzone.UserInfoBean;
import com.spring.scenic.common.config.BisConstant;
import com.spring.scenic.common.config.SysEnum;
import com.spring.scenic.common.extend.BaseController;
import com.spring.scenic.common.util.PropertiesUtil;
import com.spring.scenic.member.application.MemberBasicService;
import com.spring.scenic.member.domain.MemberBasic;
import com.spring.scenic.member.domain.MemberSharedAccount;
import com.spring.scenic.member.domain.vo.WxMpUser;
import com.spring.scenic.pay.controller.weixin.WeixinSetting;
import com.spring.scenic.utl.RequestExecutor;
import com.spring.scenic.utl.SimpleGetRequestExecutor;
import com.spring.scenic.utl.WxMpOAuth2AccessToken;

 
@Controller
@RequestMapping("thirdlogin")
@Api(value = "ThirdLoginController", description = "第三方登录接口")
public class ThirdLoginController extends BaseController{
	
    private Logger logger = LoggerFactory.getLogger(ThirdLoginController.class);
    
    public static final String scenic_default_main_page = PropertiesUtil.getProperty("scenic_default_main_page");
    
    public static final String scenic_default_error_page = PropertiesUtil.getProperty("scenic_default_error_page"); 
    
    public static final String scenic_default_bind_page = PropertiesUtil.getProperty("scenic_default_bind_page"); 
    
    public static final String scenic_default_login_page = PropertiesUtil.getProperty("scenic_default_login_page"); 
    
    public static final String LANG = "zh_CN"; 

    private CloseableHttpClient httpClient = HttpClients.createDefault();
    
    private HttpHost httpProxy;
    
    @Resource
	private MemberBasicService memberBasicService;
	
	@Resource
    WeixinSetting weixinSetting;
	
	@RequestMapping(value = "wxMPLogin", method = RequestMethod.GET)
	@ApiOperation(value = "微信公众号授权登录", notes = "微信公众号内授权登录")
	public void wxMPLogin(HttpServletRequest request,HttpServletResponse response ){
	    try {
	    	logger.info("============================进入微信公众号内授权登录===================");
	        ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);
	        OauthAPI oauthAPI = new OauthAPI(appConfig);
	        String wxPayUrl = oauthAPI.getOauthPageUrl(PropertiesUtil.getProperty("wxMPLoginCallBack_url"), OauthScope.SNSAPI_USERINFO, "1");
			response.sendRedirect(wxPayUrl);
		} catch (IOException e) {
			logger.info("============================微信公众号内登录异常===================");
			e.printStackTrace();
		}
	}
	
    @RequestMapping(value = "wxMPLoginCallBack", method = RequestMethod.GET)
    @ApiOperation(value = "微信公众号授权登录回调", notes = "微信公众号授权登录回调")
    public void wxMPLoginCallBack(String code,HttpServletRequest request,HttpServletResponse response) throws IOException{
        try {
        	logger.info("============================进入微信回调接口===================");
            ApiConfig appConfig = new ApiConfig(weixinSetting.getAppid(), weixinSetting.getAppSecret(), false);
            OauthAPI oauthAPI = new OauthAPI(appConfig);
            OauthGetTokenResponse oauth = oauthAPI.getToken(code);
            String openid = "",unionid = "";
            if(null==oauth) {
                logger.error("无法获取到微信用户");
                response.sendRedirect(scenic_default_error_page);
            }else{
                if(StringUtils.isBlank(oauth.getOpenid())) {
                    logger.error("无法获取到微信Openid！");
                    response.sendRedirect(scenic_default_error_page);
                }else{
//                    unionid = oauth.getUnionid();
//                    logger.warn("此次登录的unionid为==========++"+unionid);
                    openid = oauth.getOpenid();
                    logger.warn("此次登录的opendId为==========++"+openid);
                    toHomeOrBindPage(request,response,Integer.parseInt(SysEnum.THIRD_LOGIN_TYPE_WEIXIN.getCode()),oauth.getOpenid());
                }
            }
        } catch (Exception e) {
            logger.error("wxMPLoginCallBack exception...",e);
            response.sendRedirect(scenic_default_error_page);
        }
    }
	
    /**
     * 微信扫码登录（适用在PC版网页应用）
     */
	@RequestMapping(value = "wxScanLogin", method = RequestMethod.GET)
	@ApiOperation(value = "微信扫码登录", notes = "微信扫码登录（适用在PC版网页应用）")
	public void wxScanLogin(HttpServletRequest request,HttpServletResponse response ){
		try {
			StringBuffer sb = new StringBuffer("https://open.weixin.qq.com/connect/qrconnect");
			sb.append("?appid="+weixinSetting.getOpenAppId())
			.append("&redirect_uri="+weixinSetting.getWxScanLoginCallBack())
			.append("&response_type=code&scope=snsapi_login&state="+UUID.randomUUID()+"#wechat_redirect");
			logger.warn("wxScanLogin url:"+sb.toString());
			response.sendRedirect(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("wxScanLogin-error...",e);
		}
	}

    /**
     * 微信扫码登录（适用在PC版网页应用）回调
     * @throws IOException 
     */
	@RequestMapping(value = "wxScanLoginCallBack", method = RequestMethod.GET)
	@ApiOperation(value = "微信扫码登录回调接口", notes = "微信扫码登录（适用在PC版网页应用）回调")
	public void wxScanLoginCallBack(HttpServletRequest request,HttpServletResponse response) throws IOException {
	    try {
	        logger.warn("wxScanLoginCallBack...");
			String code = request.getParameter("code");
			if(StringUtils.isNotBlank(code)){
			    logger.error("wxScanLoginCallBack code is :"+code);
			    WxMpOAuth2AccessToken wxAccessToken = oauth2getAccessToken(weixinSetting.getOpenAppId(),weixinSetting.getOpenAppSecret(),code);
			    logger.warn("wxScanLoginCallBack wxAccessToken is :"+wxAccessToken);
			    if (null != wxAccessToken && null != wxAccessToken.getAccessToken()) {
			        logger.warn("wxScanLoginCallBack accessToken is :"+wxAccessToken.getAccessToken());
			        WxMpUser wxmpUser = oauth2getUserInfo(wxAccessToken, LANG);
			        logger.warn("wxScanLoginCallBack userInfo:"+wxmpUser);
			        toHomeOrBindPage(request,response,Integer.parseInt(SysEnum.THIRD_LOGIN_TYPE_WEIXIN.getCode()),wxmpUser.getUnionId());
			    }else{
			        logger.warn("wxScanLoginCallBack accessToken is null !");
			        response.sendRedirect(scenic_default_error_page);
			    }
			}else{
			    logger.error("wxScanLoginCallBack code is null！");
			    response.sendRedirect(scenic_default_error_page);
			}
	    } catch (Exception e) {
	        logger.error("wxScanLoginCallBack error...", e);
	        response.sendRedirect(scenic_default_error_page);
		}
	}
	
    /**
     * 新浪微博登录回调
     * @throws IOException 
     */
	@RequestMapping(value = "sinaWBLoginCallBack", method = RequestMethod.GET)
	public void sinaWBLoginCallBack(HttpServletRequest request,
			 HttpServletResponse response) throws IOException {
		try {
			String code=request.getParameter("code");
			if(StringUtils.isBlank(code)){
				  response.sendRedirect(scenic_default_login_page);
				  return ;
			}
		    logger.warn("sinaWBLoginCallBack code is:"+code);
		    Oauth oauth2 = new Oauth();
			AccessToken accessTokenObj = oauth2.getAccessTokenByCode(code);
			logger.warn("sinaWBLoginCallBack accessTokenObj is:"+accessTokenObj);
			
			String accessToken = accessTokenObj.getAccessToken();
			oauth2.setToken(accessToken);
			
			Account account = new Account();
			account.client.setToken(accessToken);
			JSONObject uidJson = account.getUid();
			String uid = String.valueOf(uidJson.get("uid"));
			logger.info("sinaWBLoginCallBack uid："+uid);
			Users users = new Users();
			users.client.setToken(accessToken);
			Object obj = users.getUserCount(uid);
			logger.warn("sinaWBLoginCallBack weiboUser fans info is:"+obj);
			toHomeOrBindPage(request,response,Integer.parseInt(SysEnum.THIRD_LOGIN_TYPE_WEIBO.getCode()),uid);
		} catch (Exception e) {
		    logger.error("sinaWBLoginCallBack  exception...",e);
		    response.sendRedirect(scenic_default_error_page);
		}
	}
 
	/**
	 * QQ共享登录
	 */
	@RequestMapping(value = "qqLogin", method = RequestMethod.GET)
	@ApiOperation(value = "QQ共享登录", notes = "QQ共享登录")
	public void qqLogin(HttpServletRequest request,HttpServletResponse response ){
		try {
			response.sendRedirect(new com.qq.connect.oauth.Oauth().getAuthorizeURL(request));
		} catch (Exception e) {
			logger.error("qqLogin  exception...",e);
		}
	}
	
	 /**
     * QQ共享登录回调
     */
	@RequestMapping(value = "qqLoginCallBack", method = RequestMethod.GET)
	@ApiOperation(value = "QQ共享登录回调", notes = "QQ共享登录回调")
	public void qqLoginCallBack(HttpServletRequest request,HttpServletResponse response ) throws IOException{
	   try {
		    String accessToken = null,openID = null;
            com.qq.connect.javabeans.AccessToken accessTokenObj=(new com.qq.connect.oauth.Oauth()).getAccessTokenByRequest(request);
            if (accessTokenObj == null || "".equals(accessTokenObj.getAccessToken())) {//我们的网站被CSRF攻击了或者用户取消了授权
                logger.error("qqLoginCallBack accessTokenObj or AccessToken is null !");
                response.sendRedirect(scenic_default_error_page);
            } else {
                accessToken = accessTokenObj.getAccessToken();
                //long tokenExpireIn = accessTokenObj.getExpireIn();
                //利用获取到的accessToken 去获取当前用的openid -------- start
                OpenID openIDObj =  new OpenID(accessToken);
                openID = openIDObj.getUserOpenID();
                logger.error("qqLoginCallBack openID is:"+openID);
                //QQ空间用户信息
                UserInfo qzoneUserInfo = new UserInfo(accessToken, openID);
                UserInfoBean userInfoBean = qzoneUserInfo.getUserInfo();
                logger.info("QQ用户信息:"+userInfoBean);
                //QQ微博用户信息
                com.qq.connect.api.weibo.UserInfo weiboUserInfo = new com.qq.connect.api.weibo.UserInfo(accessToken, openID);
                com.qq.connect.javabeans.weibo.UserInfoBean weiboUserInfoBean = weiboUserInfo.getUserInfo();
                logger.info("QQ微博账号信息:"+weiboUserInfoBean);
                toHomeOrBindPage(request,response,Integer.parseInt(SysEnum.THIRD_LOGIN_TYPE_QQ.getCode()),openID);
            }
		} catch (Exception e) {
			logger.error("qqLoginCallBack  exception...",e);
			response.sendRedirect(scenic_default_error_page);
		}
	}
	 
	/**
     * 根据会员的数据判断跳转到哪个页面（没账号，跳转到绑定手机页面，有账号，跳转到首页）
     * @param loginType 微信：1 QQ：2 新浪微博：3
     * @param unionId 第三方平台的唯一标记<br>
	 * @throws IOException 
     */
    private void toHomeOrBindPage(HttpServletRequest request,HttpServletResponse response,Integer loginType, String unionId) throws IOException {
        try {
            if(null==loginType||StringUtils.isBlank(unionId)) {
                logger.error("toHomeOrBindPage  exception loginType is null or unionId is blank...");
                response.sendRedirect(scenic_default_error_page);
            }else{
                logger.warn("toHomeOrBindPage loginType(微信：1 QQ：2 新浪微博：3) is :"+loginType+" and unionId is "+unionId);
                MemberSharedAccount memberSharedAccount = new MemberSharedAccount();
                memberSharedAccount.setAccountNum(unionId);
                memberSharedAccount.setAccountType(loginType);
                MemberBasic memberBasicInfo = memberBasicService.selectMemberInfoBySharedAccount(memberSharedAccount);
                HttpSession session = request.getSession();
                //如果是绑定会员放置会员信息到session
                if(memberBasicInfo!=null && StringUtils.isNotBlank(memberBasicInfo.getMemberAccount())){
                    memberBasicInfo = memberBasicService.selectMemberInfo(memberBasicInfo.getId());
                    session.setAttribute(BisConstant.SESSION_MEMBER,memberBasicInfo);
                    session.removeAttribute(BisConstant.LOGIN_FAIL_COUNT);
                    session.removeAttribute(BisConstant.VERIFY_CODE_FOR_PAGE);
                    if(StringUtils.isNotBlank(memberBasicInfo.getCityName())) {
                        session.setAttribute(BisConstant.SESSION_LOCATION_CITY,memberBasicInfo.getCityName());
                    }else {
                        session.setAttribute(BisConstant.SESSION_LOCATION_CITY,BisConstant.LOCATION_CITY_DEFAULT);
                    }
                    response.sendRedirect(scenic_default_main_page);
                }else{
                    session.setAttribute(BisConstant.SESSION_SHARELOGIN_TYPE,loginType);
                    session.setAttribute(BisConstant.SESSION_SHARELOGIN_UNIONID,unionId);
                    response.sendRedirect(scenic_default_bind_page);
                }
            }
        } catch (Exception e) {
            response.sendRedirect(scenic_default_error_page);
        }
    }
    
    /**
     * 根据code、openAppId、openAppSecret获取微信开放平台AccessToken{accessToken、openId、unionId等}
     */
    private WxMpOAuth2AccessToken oauth2getAccessToken(String openAppId,String openAppSecret,String code) throws Exception {
        String url = "https://api.weixin.qq.com/sns/oauth2/access_token?";
        url += "appid=" + openAppId;
        url += "&secret=" + openAppSecret;
        url += "&code=" + code;
        url += "&grant_type=authorization_code";
        try {
            RequestExecutor<String, String> executor = new SimpleGetRequestExecutor();
            String responseText = executor.execute(getHttpclient(), httpProxy, url, null);
            logger.warn("wxScanLoginCallBack oauth2getAccessToken responseText is："+responseText);
            return WxMpOAuth2AccessToken.fromJson(responseText);
        } catch (Exception e) {
            logger.error("wxScanLoginCallBack oauth2getAccessToken exception...",e);
            throw e;
        }
    }
    
    /**
     * 根据accessToken、openId获取微信用户信息
     * @throws Exception 
     */
    private WxMpUser oauth2getUserInfo(WxMpOAuth2AccessToken oAuth2AccessToken, String lang) throws Exception {
        try {
            String url = "https://api.weixin.qq.com/sns/userinfo?";
            url += "access_token=" + oAuth2AccessToken.getAccessToken();
            url += "&openid=" + oAuth2AccessToken.getOpenId();
            if (lang == null) {
                url += "&lang=zh_CN";
            } else {
                url += "&lang=" + lang;
            }
            RequestExecutor<String, String> executor = new SimpleGetRequestExecutor();
            String responseText = executor.execute(getHttpclient(), httpProxy, url, null);
            logger.warn("wxScanLoginCallBack oauth2getUserInfo responseText is："+responseText);
            return WxMpUser.fromJson(responseText);
        } catch (Exception e) {
            logger.error("wxScanLoginCallBack oauth2getUserInfo exception...",e);
            throw e;
        }
    }
    
    protected CloseableHttpClient getHttpclient() {
        return httpClient;
    }
	
}
